import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:rachey/data/models/rachey_document.dart';
import 'package:rachey/features/auth/domain/auth_deep_link.dart';

void main() {
  test('sanity', () {
    expect('Rachey'.isNotEmpty, isTrue);
  });

  test('documento ignora metadados internos do Appwrite', () {
    final document = RacheyDocument.fromExistingRow('category', 'cat-1', {
      r'$createdAt': '2026-08-07T12:00:00.000Z',
      r'$permissions': <String>[],
      'nome': 'Streaming',
    });

    expect(document.payload['nome'], 'Streaming');
    expect(document.payload, isNot(contains(r'$permissions')));
  });

  test('cache inválido não é necessário para reconstruir documento válido', () {
    final document = RacheyDocument.fromCache('service-1', {
      'type': 'service',
      'ownerId': '',
      'status': 'ativo',
      'search': 'serviço',
      'payload': <String, dynamic>{'name': 'Serviço'},
      'createdAt': null,
      'updatedAt': null,
    });

    expect(document.id, 'service-1');
    expect(document.payload['name'], 'Serviço');
  });

  test('serviço usa os nomes reais das colunas do Appwrite', () {
    final document = RacheyDocument.fromExistingRow('service', 'svc-1', {
      'nome': 'Streaming',
      'valor': 19.9,
      'preco_centavos': 1990,
      'periodicidade': 'mensal',
      'dsetaque': true,
      'ativo': true,
      'ordem': 2,
    });

    expect(document.payload['name'], 'Streaming');
    expect(document.payload['priceCents'], 1990);
    expect(document.payload['featured'], isTrue);
  });

  test('assinatura usa datas e nome de serviço existentes', () {
    final document = RacheyDocument.fromExistingRow('subscription', 'sub-1', {
      'user_id': 'user-1',
      'nome_servico': 'Filmes',
      'data_inicio': '2026-08-01T00:00:00.000Z',
      'data_vencimento': '2026-09-01T00:00:00.000Z',
      'status': 'ativa',
      'valor': 25.0,
    });

    expect(document.ownerId, 'user-1');
    expect(document.payload['serviceName'], 'Filmes');
    expect(document.payload['expiresAt'], contains('2026-09-01'));
  });

  test('link de confirmação preserva as credenciais do Appwrite', () {
    final link = AuthDeepLink.tryParse(
      'rachey://auth/verify?userId=usuario-1&secret=segredo%2Bseguro',
    );

    expect(link?.kind, AuthDeepLinkKind.verification);
    expect(link?.userId, 'usuario-1');
    expect(link?.secret, 'segredo+seguro');
  });

  test('serviço decodifica períodos e valores do planos_json', () {
    final document = RacheyDocument.fromExistingRow('service', 'svc-periods', {
      'nome': 'Premium',
      'preco_centavos': 1290,
      'planos_json': jsonEncode([
        {'days': 7, 'label': '7 dias', 'price_cents': 1290},
        {'days': 30, 'label': 'Mensal', 'price_cents': 3990},
      ]),
    });

    final plans = document.payload['plans'] as List;
    expect(plans, hasLength(2));
    expect((plans.first as Map)['days'], 7);
    expect((plans.last as Map)['price_cents'], 3990);
  });

  test('planos_json inválido não derruba reconstrução do serviço', () {
    final document = RacheyDocument.fromExistingRow('service', 'svc-invalid', {
      'nome': 'Serviço',
      'planos_json': '{inválido',
      'dados_json': jsonEncode({
        'plans': [
          {'days': 14, 'price_cents': 2000},
        ],
      }),
    });

    final plans = document.payload['plans'] as List;
    expect(plans, hasLength(1));
    expect((plans.first as Map)['days'], 14);
  });

  test('cache preserva payload, datas e status', () {
    final original = RacheyDocument(
      id: 'row-1',
      type: 'order',
      ownerId: 'user-1',
      status: 'aguardando_pagamento',
      search: 'pedido 1',
      payload: const {'total': 42.5, 'provider': 'mercado_pago'},
      createdAt: DateTime.utc(2026, 8, 11, 12),
      updatedAt: DateTime.utc(2026, 8, 11, 13),
    );

    final restored = RacheyDocument.fromCache(original.id, original.toCacheData());
    expect(restored.status, original.status);
    expect(restored.payload['provider'], 'mercado_pago');
    expect(restored.createdAt, original.createdAt);
    expect(restored.updatedAt, original.updatedAt);
  });

  test('deep link ignora esquema ou rota que não sejam do Rachey', () {
    expect(
      AuthDeepLink.tryParse('https://rachey.app/auth/verify?userId=u&secret=s'),
      isNull,
    );
    expect(AuthDeepLink.tryParse('rachey://auth/outra?userId=u&secret=s'), isNull);
  });

  test('link de recuperação preserva caracteres escapados do secret', () {
    final link = AuthDeepLink.tryParse(
      'rachey://auth/recovery?userId=user-2&secret=a%2Bb%2Fc%3D',
    );
    expect(link?.kind, AuthDeepLinkKind.recovery);
    expect(link?.userId, 'user-2');
    expect(link?.secret, 'a+b/c=');
  });

  test('link de recuperação exige userId e secret', () {
    expect(
      AuthDeepLink.matches(
        'rachey://auth/recovery?userId=usuario-1',
        AuthDeepLinkKind.recovery,
      ),
      isTrue,
    );
    expect(
      AuthDeepLink.tryParse('rachey://auth/recovery?userId=usuario-1'),
      isNull,
    );
  });
}
