import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:rachey/core/settings/app_preferences.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';

class RacheyThemeButton extends StatelessWidget {
  const RacheyThemeButton({super.key});

  @override
  Widget build(BuildContext context) {
    final preferences = AppPreferencesScope.of(context);
    final dark = Theme.of(context).brightness == Brightness.dark;
    return IconButton.filledTonal(
      tooltip: dark ? 'Usar tema claro' : 'Usar tema escuro',
      onPressed: () =>
          preferences.setThemeMode(dark ? ThemeMode.light : ThemeMode.dark),
      icon: AnimatedSwitcher(
        duration: const Duration(milliseconds: 220),
        transitionBuilder: (child, animation) => RotationTransition(
          turns: Tween<double>(begin: .8, end: 1).animate(animation),
          child: FadeTransition(opacity: animation, child: child),
        ),
        child: Icon(
          dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded,
          key: ValueKey(dark),
          size: 20,
        ),
      ),
    );
  }
}

class RacheyBrandMark extends StatelessWidget {
  const RacheyBrandMark({this.size = 42, super.key});

  final double size;

  @override
  Widget build(BuildContext context) => Container(
    width: size,
    height: size,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [RacheyColors.primary, RacheyColors.darkGreen],
      ),
      borderRadius: BorderRadius.circular(size * .34),
      boxShadow: [
        BoxShadow(
          color: RacheyColors.primary.withValues(alpha: .24),
          blurRadius: 16,
          offset: const Offset(0, 7),
        ),
      ],
    ),
    child: Text(
      'R',
      style: TextStyle(
        color: Colors.white,
        fontSize: size * .52,
        fontWeight: FontWeight.w900,
        height: 1,
      ),
    ),
  );
}

class RacheySectionTitle extends StatelessWidget {
  const RacheySectionTitle({
    required this.title,
    this.subtitle,
    this.action,
    super.key,
  });

  final String title;
  final String? subtitle;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w900,
                letterSpacing: -.35,
              ),
            ),
            if (subtitle != null) ...[
              const SizedBox(height: 2),
              Text(
                subtitle!,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ],
        ),
      ),
      if (action != null) action!,
    ],
  );
}

class RacheyRemoteImage extends StatelessWidget {
  const RacheyRemoteImage({
    required this.repository,
    required this.fileId,
    this.fit = BoxFit.cover,
    this.width = 1000,
    this.height = 700,
    this.borderRadius,
    this.fallbackIcon = Icons.subscriptions_rounded,
    super.key,
  });

  final RacheyRepository repository;
  final String fileId;
  final BoxFit fit;
  final int width;
  final int height;
  final BorderRadius? borderRadius;
  final IconData fallbackIcon;

  @override
  Widget build(BuildContext context) {
    final child = fileId.isEmpty
        ? _fallback(context)
        : FutureBuilder<Uint8List>(
            future: repository.imageFile(fileId, width: width, height: height),
            builder: (_, snapshot) {
              if (snapshot.hasData) {
                return Image.memory(
                  snapshot.data!,
                  fit: fit,
                  width: double.infinity,
                  height: double.infinity,
                  gaplessPlayback: true,
                  errorBuilder: (_, __, ___) => _fallback(context),
                );
              }
              if (snapshot.hasError) return _fallback(context);
              return ColoredBox(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                child: const Center(
                  child: SizedBox.square(
                    dimension: 24,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              );
            },
          );
    return borderRadius == null
        ? child
        : ClipRRect(borderRadius: borderRadius!, child: child);
  }

  Widget _fallback(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          RacheyColors.mint,
          RacheyColors.primary.withValues(alpha: .22),
        ],
      ),
    ),
    child: Center(
      child: Icon(fallbackIcon, size: 52, color: RacheyColors.darkGreen),
    ),
  );
}

class RacheyStatusPill extends StatelessWidget {
  const RacheyStatusPill({
    required this.label,
    this.icon,
    this.color = RacheyColors.primary,
    super.key,
  });

  final String label;
  final IconData? icon;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: color.withValues(alpha: .12),
      borderRadius: BorderRadius.circular(999),
    ),
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (icon != null) ...[
          Icon(icon, size: 15, color: color),
          const SizedBox(width: 5),
        ],
        Text(
          label,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.w800,
            fontSize: 12,
          ),
        ),
      ],
    ),
  );
}
