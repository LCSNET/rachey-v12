import 'package:flutter/material.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';

class AdminWaitlistPage extends StatefulWidget {
  const AdminWaitlistPage({required this.repository, super.key});
  final RacheyRepository repository;

  @override
  State<AdminWaitlistPage> createState() => _AdminWaitlistPageState();
}

class _AdminWaitlistPageState extends State<AdminWaitlistPage> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() =>
      widget.repository.listModules('waitlist', limit: 500);
  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Future<void> _approve(Map<String, dynamic> row) async {
    try {
      await widget.repository.action('waitlist_approve', {
        'row_id': row[r'$id'],
      });
      await _refresh();
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    }
  }

  Future<void> _cancel(Map<String, dynamic> row) async {
    try {
      await widget.repository.saveModule(
        kind: 'waitlist',
        rowId: '${row[r'$id']}',
        ownerId: row['owner_id']?.toString(),
        referenceId: row['reference_id']?.toString(),
        title: '${row['title'] ?? ''}',
        status: 'cancelada',
        data: Map<String, dynamic>.from(row['data'] as Map? ?? const {}),
      );
      await _refresh();
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Lista de espera')),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorBody(error: snapshot.error!, onRetry: _refresh);
          final rows = snapshot.data ?? const [];
          if (rows.isEmpty)
            return const _EmptyBody(
              icon: Icons.hourglass_empty_rounded,
              text: 'A fila está vazia.',
            );
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: rows.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, index) {
              final row = rows[index];
              final data = row['data'] as Map? ?? const {};
              final pending = const {
                'aguardando',
                'vaga_disponivel',
              }.contains(row['status']);
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(child: Text('${index + 1}')),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${row['title'] ?? 'Serviço'}',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                Text('Cliente: ${row['owner_id'] ?? ''}'),
                              ],
                            ),
                          ),
                          Chip(label: Text(_status('${row['status'] ?? ''}'))),
                        ],
                      ),
                      const SizedBox(height: 9),
                      Text(
                        '${data['quantity'] ?? 1} unidade(s) • ${data['period_days'] ?? 30} dias',
                        style: const TextStyle(color: RacheyColors.gray),
                      ),
                      if (pending) ...[
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => _cancel(row),
                                child: const Text('Cancelar'),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: FilledButton(
                                onPressed: () => _approve(row),
                                child: const Text('Aprovar vaga'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class AdminCrmPage extends StatefulWidget {
  const AdminCrmPage({required this.repository, super.key});
  final RacheyRepository repository;

  @override
  State<AdminCrmPage> createState() => _AdminCrmPageState();
}

class _AdminCrmPageState extends State<AdminCrmPage> {
  late Future<List<Map<String, dynamic>>> _future;
  String _search = '';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async =>
      _rows(await widget.repository.adminList('perfis', limit: 500));
  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('CRM de clientes')),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorBody(error: snapshot.error!, onRetry: _refresh);
          final rows = (snapshot.data ?? const []).where((row) {
            final text = '${row['nome']} ${row['email']} ${row['telefone']}'
                .toLowerCase();
            return text.contains(_search.toLowerCase());
          }).toList();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextField(
                onChanged: (value) => setState(() => _search = value),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'Buscar nome, e-mail ou telefone',
                ),
              ),
              const SizedBox(height: 12),
              if (rows.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 120),
                  child: Center(child: Text('Nenhum cliente encontrado.')),
                )
              else
                ...rows.map(
                  (row) => Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(14),
                      leading: CircleAvatar(
                        child: Text(
                          '${row['nome'] ?? 'C'}'.substring(0, 1).toUpperCase(),
                        ),
                      ),
                      title: Text(
                        '${row['nome'] ?? 'Cliente'}',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      subtitle: Text(
                        '${row['email'] ?? ''}\n${row['telefone'] ?? ''}',
                      ),
                      isThreeLine: true,
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () async {
                        final deleted = await Navigator.push<bool>(
                          context,
                          MaterialPageRoute<bool>(
                            builder: (_) => _ClientFilePage(
                              repository: widget.repository,
                              profile: row,
                            ),
                          ),
                        );
                        if (deleted == true) await _refresh();
                      },
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    ),
  );
}

class _ClientFilePage extends StatefulWidget {
  const _ClientFilePage({required this.repository, required this.profile});
  final RacheyRepository repository;
  final Map<String, dynamic> profile;

  @override
  State<_ClientFilePage> createState() => _ClientFilePageState();
}

class _ClientFilePageState extends State<_ClientFilePage> {
  late Future<_ClientFileData> _future;
  String get userId => '${widget.profile['user_id'] ?? ''}';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_ClientFileData> _load() async {
    final values = await Future.wait<dynamic>([
      widget.repository.adminList(
        'pedidos',
        limit: 500,
        filters: {'user_id': userId},
      ),
      widget.repository.adminList(
        'pagamentos',
        limit: 500,
        filters: {'user_id': userId},
      ),
      widget.repository.adminList(
        'assinaturas',
        limit: 500,
        filters: {'user_id': userId},
      ),
      widget.repository.listModules(
        'support_ticket',
        ownerId: userId,
        limit: 500,
      ),
      widget.repository.listModules(
        'crm_note',
        referenceId: userId,
        limit: 500,
      ),
      widget.repository.listModules('crm_tag', referenceId: userId, limit: 500),
    ]);
    return _ClientFileData(
      orders: _rows(values[0]),
      payments: _rows(values[1]),
      subscriptions: _rows(values[2]),
      tickets: values[3] as List<Map<String, dynamic>>,
      notes: values[4] as List<Map<String, dynamic>>,
      tags: values[5] as List<Map<String, dynamic>>,
    );
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Future<void> _addNote() async {
    final controller = TextEditingController();
    final save = await _textDialog(
      context,
      'Nova observação',
      controller,
      'Observação interna',
    );
    if (save && controller.text.trim().isNotEmpty) {
      await widget.repository.saveModule(
        kind: 'crm_note',
        referenceId: userId,
        title: 'Observação de ${widget.profile['nome'] ?? 'cliente'}',
        data: {'text': controller.text.trim()},
      );
      await _refresh();
    }
    controller.dispose();
  }

  Future<void> _addTag() async {
    final controller = TextEditingController();
    final save = await _textDialog(
      context,
      'Nova etiqueta',
      controller,
      'Ex.: VIP, inadimplente, parceiro',
    );
    if (save && controller.text.trim().isNotEmpty) {
      await widget.repository.saveModule(
        kind: 'crm_tag',
        referenceId: userId,
        title: controller.text.trim(),
        data: {'color': '#16A36A'},
      );
      await _refresh();
    }
    controller.dispose();
  }

  Future<void> _toggleClientActive() async {
    final currentlyActive = widget.profile['ativo'] != false;
    final reason = TextEditingController();
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: Icon(currentlyActive ? Icons.person_off_outlined : Icons.person_add_alt_1_outlined),
        title: Text(currentlyActive ? 'Desativar cliente?' : 'Reativar cliente?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(currentlyActive
                ? 'O cliente será impedido de usar o Rachey até ser reativado. Os dados e histórico serão preservados.'
                : 'O cliente voltará a conseguir usar o Rachey normalmente.'),
            if (currentlyActive) ...[
              const SizedBox(height: 12),
              TextField(
                controller: reason,
                minLines: 2,
                maxLines: 5,
                decoration: const InputDecoration(labelText: 'Motivo *'),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: Text(currentlyActive ? 'Desativar' : 'Reativar')),
        ],
      ),
    );
    if (confirm != true || (currentlyActive && reason.text.trim().length < 3)) {
      reason.dispose();
      return;
    }
    final authenticated = await NativeBridge.authenticate(
      reason: currentlyActive ? 'Confirme para desativar este cliente' : 'Confirme para reativar este cliente',
    );
    if (!authenticated || !mounted) { reason.dispose(); return; }
    try {
      final result = await widget.repository.action('set_client_active', {
        'user_id': userId,
        'active': !currentlyActive,
        if (currentlyActive) 'reason': reason.text.trim(),
      });
      widget.profile['ativo'] = result['active'] == true;
      if (mounted) setState(() {});
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      reason.dispose();
    }
  }

  Future<void> _deleteClient() async {
    final reason = TextEditingController();
    final confirm = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(Icons.warning_amber_rounded, color: Colors.red),
        title: const Text('Excluir cliente definitivamente?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Isso removerá ${widget.profile['nome'] ?? 'o cliente'} do Auth, perfil e dados vinculados no banco. Esta ação não pode ser desfeita.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: reason,
              minLines: 2,
              maxLines: 5,
              decoration: const InputDecoration(labelText: 'Motivo da exclusão'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancelar')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Excluir definitivamente'),
          ),
        ],
      ),
    );
    if (confirm != true) { reason.dispose(); return; }
    final authenticated = await NativeBridge.authenticate(
      reason: 'Confirme sua identidade para excluir este cliente',
    );
    if (!authenticated || !mounted) { reason.dispose(); return; }
    try {
      await widget.repository.action('delete_client', {
        'user_id': userId,
        'reason': reason.text.trim(),
      });
      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      reason.dispose();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('${widget.profile['nome'] ?? 'Cliente'}'),
      actions: [
        IconButton(
          tooltip: widget.profile['ativo'] != false ? 'Desativar cliente' : 'Reativar cliente',
          onPressed: _toggleClientActive,
          icon: Icon(widget.profile['ativo'] != false ? Icons.person_off_outlined : Icons.person_add_alt_1_outlined),
        ),
        IconButton(
          tooltip: 'Excluir cliente',
          onPressed: _deleteClient,
          icon: const Icon(Icons.person_remove_outlined, color: Colors.red),
        ),
      ],
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<_ClientFileData>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorBody(error: snapshot.error!, onRetry: _refresh);
          final data = snapshot.data!;
          final paid = data.payments
              .where((row) => row['status'] == 'pago')
              .fold<int>(
                0,
                (sum, row) => sum + ((row['valor'] as num? ?? 0) * 100).round(),
              );
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${widget.profile['nome'] ?? 'Cliente'}',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text('${widget.profile['email'] ?? ''}'),
                      Text('${widget.profile['telefone'] ?? ''}'),
                      Text(
                        'ID: $userId',
                        style: const TextStyle(
                          fontSize: 12,
                          color: RacheyColors.gray,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Chip(
                          avatar: Icon(widget.profile['ativo'] != false ? Icons.check_circle_outline : Icons.block_outlined, size: 17),
                          label: Text(widget.profile['ativo'] != false ? 'Cliente ativo' : 'Cliente desativado'),
                        ),
                      ),
                      Wrap(
                        spacing: 6,
                        children: data.tags
                            .map(
                              (row) =>
                                  Chip(label: Text('${row['title'] ?? ''}')),
                            )
                            .toList(),
                      ),
                      TextButton.icon(
                        onPressed: _addTag,
                        icon: const Icon(Icons.new_label_outlined),
                        label: const Text('Adicionar etiqueta'),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: _CrmMetric(
                      label: 'Compras',
                      value: '${data.orders.length}',
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _CrmMetric(label: 'Financeiro', value: _money(paid)),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _CrmMetric(
                      label: 'Chamados',
                      value: '${data.tickets.length}',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Observações internas',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  IconButton.filledTonal(
                    onPressed: _addNote,
                    icon: const Icon(Icons.add_comment_outlined),
                  ),
                ],
              ),
              if (data.notes.isEmpty)
                const Card(
                  child: ListTile(
                    title: Text('Nenhuma observação cadastrada.'),
                  ),
                )
              else
                ...data.notes.map(
                  (row) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.sticky_note_2_outlined),
                      title: Text(
                        '${(row['data'] as Map? ?? const {})['text'] ?? ''}',
                      ),
                      subtitle: Text(_date('${row[r'$createdAt'] ?? ''}')),
                      trailing: IconButton(
                        onPressed: () async {
                          await widget.repository.deleteModule(
                            '${row[r'$id']}',
                          );
                          await _refresh();
                        },
                        icon: const Icon(Icons.delete_outline),
                      ),
                    ),
                  ),
                ),
              const SizedBox(height: 18),
              _Section(
                title: 'Assinaturas',
                rows: data.subscriptions,
                titleOf: (row) => '${row['nome_servico'] ?? 'Assinatura'}',
                subtitleOf: (row) =>
                    '${row['status'] ?? ''} • vence ${_date('${row['data_vencimento'] ?? ''}')}',
              ),
              _Section(
                title: 'Compras',
                rows: data.orders,
                titleOf: (row) => '${row['numero'] ?? 'Pedido'}',
                subtitleOf: (row) =>
                    '${_status('${row['status'] ?? ''}')} • ${_money((row['total_centavos'] as num?)?.round() ?? 0)}',
              ),
              _Section(
                title: 'Chamados',
                rows: data.tickets,
                titleOf: (row) => '${row['title'] ?? 'Chamado'}',
                subtitleOf: (row) => _status('${row['status'] ?? ''}'),
              ),
            ],
          );
        },
      ),
    ),
  );
}

class AdminFinancePage extends StatefulWidget {
  const AdminFinancePage({required this.repository, super.key});
  final RacheyRepository repository;

  @override
  State<AdminFinancePage> createState() => _AdminFinancePageState();
}

class _AdminFinancePageState extends State<AdminFinancePage> {
  late Future<_FinanceData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_FinanceData> _load() async {
    final values = await Future.wait<dynamic>([
      widget.repository.action('finance_summary'),
      widget.repository.listModules('goal', limit: 100),
    ]);
    return _FinanceData(
      summary: values[0] as Map<String, dynamic>,
      goals: values[1] as List<Map<String, dynamic>>,
    );
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Future<void> _expense([Map<String, dynamic>? current]) async {
    final title = TextEditingController(text: '${current?['title'] ?? ''}');
    final amount = TextEditingController(
      text: current == null
          ? ''
          : '${((current['amount_cents'] as num? ?? 0) / 100).toStringAsFixed(2)}',
    );
    final category = TextEditingController(
      text: '${(current?['data'] as Map? ?? const {})['category'] ?? ''}',
    );
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(current == null ? 'Nova despesa' : 'Editar despesa'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: title,
              decoration: const InputDecoration(labelText: 'Descrição *'),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: amount,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(labelText: 'Valor (R\$) *'),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: category,
              decoration: const InputDecoration(labelText: 'Categoria'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
    final value = double.tryParse(amount.text.replaceAll(',', '.'));
    if (save == true && title.text.trim().isNotEmpty && value != null) {
      await widget.repository.saveModule(
        kind: 'expense',
        rowId: current?[r'$id']?.toString(),
        title: title.text.trim(),
        status: 'paga',
        amountCents: (value * 100).round(),
        data: {
          'category': category.text.trim(),
          'date': DateTime.now().toIso8601String(),
        },
      );
      await _refresh();
    }
    title.dispose();
    amount.dispose();
    category.dispose();
  }

  Future<void> _goal([Map<String, dynamic>? current]) async {
    final title = TextEditingController(text: '${current?['title'] ?? ''}');
    final amount = TextEditingController(
      text: current == null
          ? ''
          : '${((current['amount_cents'] as num? ?? 0) / 100).toStringAsFixed(2)}',
    );
    final save = await _textMoneyDialog(
      context,
      current == null ? 'Nova meta' : 'Editar meta',
      title,
      amount,
    );
    final value = double.tryParse(amount.text.replaceAll(',', '.'));
    if (save && title.text.trim().isNotEmpty && value != null) {
      await widget.repository.saveModule(
        kind: 'goal',
        rowId: current?[r'$id']?.toString(),
        title: title.text.trim(),
        status: 'ativa',
        amountCents: (value * 100).round(),
        data: {'period': 'mensal'},
      );
      await _refresh();
    }
    title.dispose();
    amount.dispose();
  }

  Future<void> _export(String format) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      final result = await widget.repository.action('export_finance', {
        'format': format,
      });
      final bytes = await widget.repository.downloadFile(
        '${result['file_id']}',
      );
      final saved = await NativeBridge.saveFile(
        name: '${result['name']}',
        mimeType: '${result['mime_type']}',
        bytes: bytes,
      );
      if (!mounted) return;
      Navigator.pop(context);
      _toast(
        context,
        saved ? 'Relatório salvo no aparelho.' : 'O salvamento foi cancelado.',
      );
    } catch (error) {
      if (mounted) {
        Navigator.pop(context);
        _toast(context, _friendly(error));
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Financeiro'),
      actions: [
        PopupMenuButton<String>(
          tooltip: 'Exportar',
          onSelected: _export,
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'pdf', child: Text('Exportar PDF')),
            PopupMenuItem(value: 'xlsx', child: Text('Exportar Excel')),
          ],
        ),
      ],
    ),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () => _expense(),
      icon: const Icon(Icons.add),
      label: const Text('Despesa'),
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<_FinanceData>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorBody(error: snapshot.error!, onRetry: _refresh);
          final data = snapshot.data!;
          final summary = data.summary;
          final revenue = (summary['revenue_cents'] as num?)?.round() ?? 0;
          final expenses = (summary['expense_cents'] as num?)?.round() ?? 0;
          final cogs = (summary['cogs_cents'] as num?)?.round() ?? 0;
          final profit = (summary['profit_cents'] as num?)?.round() ?? 0;
          final maxValue = [
            revenue.abs(),
            expenses.abs(),
            cogs.abs(),
            profit.abs(),
            1,
          ].reduce((a, b) => a > b ? a : b);
          final expenseRows =
              (summary['expenses'] as List<dynamic>? ?? const [])
                  .whereType<Map>()
                  .map((row) => Map<String, dynamic>.from(row))
                  .toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
            children: [
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.65,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                children: [
                  _FinanceMetric(label: 'Receitas', value: revenue, color: RacheyColors.primary),
                  _FinanceMetric(label: 'Custo dos produtos', value: cogs, color: RacheyColors.gray),
                  _FinanceMetric(label: 'Despesas operacionais', value: expenses, color: RacheyColors.promo),
                  _FinanceMetric(label: 'Lucro líquido', value: profit, color: RacheyColors.navy),
                ],
              ),
              const SizedBox(height: 14),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Fluxo de caixa',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 16),
                      _MoneyBar(
                        label: 'Receitas',
                        value: revenue,
                        max: maxValue,
                        color: RacheyColors.primary,
                      ),
                      _MoneyBar(
                        label: 'Custo dos produtos',
                        value: cogs,
                        max: maxValue,
                        color: RacheyColors.gray,
                      ),
                      _MoneyBar(
                        label: 'Despesas operacionais',
                        value: expenses,
                        max: maxValue,
                        color: RacheyColors.promo,
                      ),
                      _MoneyBar(
                        label: 'Lucro líquido',
                        value: profit,
                        max: maxValue,
                        color: RacheyColors.navy,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Metas',
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  TextButton.icon(
                    onPressed: () => _goal(),
                    icon: const Icon(Icons.add),
                    label: const Text('Adicionar'),
                  ),
                ],
              ),
              if (data.goals.isEmpty)
                const Card(
                  child: ListTile(title: Text('Nenhuma meta definida.')),
                )
              else
                ...data.goals.map((row) {
                  final target = (row['amount_cents'] as num?)?.round() ?? 0;
                  return Card(
                    child: ListTile(
                      leading: const Icon(Icons.flag_outlined),
                      title: Text('${row['title'] ?? 'Meta'}'),
                      subtitle: LinearProgressIndicator(
                        value: target <= 0 ? 0 : (revenue / target).clamp(0, 1),
                      ),
                      trailing: Text(
                        '${_money(revenue)}\n/ ${_money(target)}',
                        textAlign: TextAlign.right,
                      ),
                      onTap: () => _goal(row),
                    ),
                  );
                }),
              const SizedBox(height: 18),
              const Text(
                'Despesas',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
              const SizedBox(height: 8),
              if (expenseRows.isEmpty)
                const Card(
                  child: ListTile(title: Text('Nenhuma despesa registrada.')),
                )
              else
                ...expenseRows.map(
                  (row) => Card(
                    child: ListTile(
                      leading: const Icon(
                        Icons.receipt_outlined,
                        color: RacheyColors.promo,
                      ),
                      title: Text('${row['title'] ?? 'Despesa'}'),
                      subtitle: Text(
                        '${(row['data'] as Map? ?? const {})['category'] ?? ''}',
                      ),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) async {
                          if (value == 'edit') {
                            await _expense(row);
                          } else {
                            await widget.repository.deleteModule(
                              '${row[r'$id']}',
                            );
                            await _refresh();
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'edit', child: Text('Editar')),
                          PopupMenuItem(
                            value: 'delete',
                            child: Text('Excluir'),
                          ),
                        ],
                        child: Text(
                          _money((row['amount_cents'] as num?)?.round() ?? 0),
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    ),
  );
}

class AdminCouponsPage extends StatefulWidget {
  const AdminCouponsPage({required this.repository, super.key});
  final RacheyRepository repository;
  @override
  State<AdminCouponsPage> createState() => _AdminCouponsPageState();
}

class _AdminCouponsPageState extends State<AdminCouponsPage> {
  late Future<List<Map<String, dynamic>>> future;
  @override
  void initState() {
    super.initState();
    future = widget.repository.listModules('coupon', limit: 500);
  }

  Future<void> refresh() async {
    setState(
      () => future = widget.repository.listModules('coupon', limit: 500),
    );
    await future;
  }

  Future<void> edit([Map<String, dynamic>? current]) async {
    final code = TextEditingController(
      text: '${current?['external_key'] ?? ''}',
    );
    final value = TextEditingController(
      text:
          '${(current?['data'] as Map? ?? const {})['percent'] ?? (current?['data'] as Map? ?? const {})['value_cents'] ?? ''}',
    );
    final due = TextEditingController(text: '${current?['due_at'] ?? ''}');
    final currentData = current?['data'] as Map? ?? const {};
    final maxUses = TextEditingController(text: '${currentData['max_uses'] ?? ''}');
    final perUser = TextEditingController(text: '${currentData['per_user_limit'] ?? ''}');
    final minOrder = TextEditingController(
      text: currentData['min_order_cents'] == null ? '' : '${((currentData['min_order_cents'] as num) / 100).toStringAsFixed(2)}',
    );
    final serviceIds = TextEditingController(text: (currentData['service_ids'] as List? ?? const []).join(','));
    var firstPurchaseOnly = currentData['first_purchase_only'] == true;
    var type = '${(current?['data'] as Map? ?? const {})['type'] ?? 'percent'}';
    var publishInGroup = current == null;
    var notifyEveryone = false;
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setDialogState) => AlertDialog(
          title: Text(current == null ? 'Novo cupom' : 'Editar cupom'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: code,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(labelText: 'Código *'),
              ),
              const SizedBox(height: 9),
              DropdownButtonFormField<String>(
                initialValue: type,
                items: const [
                  DropdownMenuItem(
                    value: 'percent',
                    child: Text('Percentual (%)'),
                  ),
                  DropdownMenuItem(
                    value: 'fixed',
                    child: Text('Valor fixo (centavos)'),
                  ),
                ],
                onChanged: (v) => setDialogState(() => type = v ?? type),
                decoration: const InputDecoration(labelText: 'Tipo'),
              ),
              const SizedBox(height: 9),
              TextField(
                controller: value,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Valor *'),
              ),
              const SizedBox(height: 9),
              TextField(
                controller: due,
                decoration: const InputDecoration(
                  labelText: 'Expira em (ISO, opcional)',
                ),
              ),
              const SizedBox(height: 8),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('Regras avançadas', style: TextStyle(fontWeight: FontWeight.w800)),
                children: [
                  TextField(controller: maxUses, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Limite total de usos', helperText: 'Vazio = sem limite')),
                  const SizedBox(height: 8),
                  TextField(controller: perUser, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Limite por cliente', helperText: 'Vazio = sem limite')),
                  const SizedBox(height: 8),
                  TextField(controller: minOrder, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Pedido mínimo (R\$)')),
                  const SizedBox(height: 8),
                  TextField(controller: serviceIds, minLines: 2, maxLines: 4, decoration: const InputDecoration(labelText: 'IDs de serviços permitidos', helperText: 'Separe por vírgulas. Vazio = todos os serviços.')),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: firstPurchaseOnly,
                    onChanged: (value) => setDialogState(() => firstPurchaseOnly = value),
                    title: const Text('Somente primeira compra'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: publishInGroup,
                onChanged: (value) => setDialogState(() {
                  publishInGroup = value;
                  if (!value) notifyEveryone = false;
                }),
                title: const Text('Publicar no Grupo Rachey'),
                subtitle: const Text('Cria uma mensagem do cupom dentro do grupo.'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: notifyEveryone,
                onChanged: publishInGroup ? (value) => setDialogState(() => notifyEveryone = value) : null,
                title: const Text('Notificar @todos'),
                subtitle: const Text('Todos os participantes recebem o aviso deste cupom.'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
    if (save == true && code.text.trim().isNotEmpty) {
      final number = int.tryParse(value.text) ?? 0;
      await widget.repository.saveModule(
        kind: 'coupon',
        rowId: current?[r'$id']?.toString(),
        externalKey: code.text.trim().toUpperCase(),
        title: code.text.trim().toUpperCase(),
        status: 'ativo',
        dueAt: DateTime.tryParse(due.text),
        data: {
          'type': type,
          if (type == 'fixed') 'value_cents': number,
          if (type != 'fixed') 'percent': number.clamp(0, 100),
          'max_uses': int.tryParse(maxUses.text.trim()) ?? 0,
          'per_user_limit': int.tryParse(perUser.text.trim()) ?? 0,
          'min_order_cents': ((double.tryParse(minOrder.text.trim().replaceAll(',', '.')) ?? 0) * 100).round(),
          'service_ids': serviceIds.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
          'first_purchase_only': firstPurchaseOnly,
        },
      );
      if (publishInGroup) {
        await widget.repository.action('group_action', {
          'operation': 'publish_coupon',
          'code': code.text.trim().toUpperCase(),
          'description': type == 'fixed'
              ? 'Novo cupom ${code.text.trim().toUpperCase()}: desconto de ${_money(number)}.'
              : 'Novo cupom ${code.text.trim().toUpperCase()}: $number% de desconto.',
          if (type == 'fixed') 'value_cents': number,
          if (type != 'fixed') 'percent': number.clamp(0, 100),
          if (due.text.trim().isNotEmpty) 'due_at': due.text.trim(),
          'notify_all': notifyEveryone,
        });
      }
      await refresh();
    }
    code.dispose();
    value.dispose();
    due.dispose();
    maxUses.dispose();
    perUser.dispose();
    minOrder.dispose();
    serviceIds.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Cupons')),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () => edit(),
      icon: const Icon(Icons.add),
      label: const Text('Novo'),
    ),
    body: RefreshIndicator(
      onRefresh: refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorBody(error: snapshot.error!, onRetry: refresh);
          final rows = snapshot.data ?? const [];
          if (rows.isEmpty)
            return const _EmptyBody(
              icon: Icons.sell_outlined,
              text: 'Nenhum cupom cadastrado.',
            );
          return ListView(
            padding: const EdgeInsets.all(16),
            children: rows.map((row) {
              final data = row['data'] as Map? ?? const {};
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.sell_outlined)),
                  title: Text(
                    '${row['external_key'] ?? 'CUPOM'}',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: Text(
                    data['type'] == 'fixed'
                        ? '${data['value_cents']} centavos'
                        : '${data['percent']}%',
                  ),
                  onTap: () => edit(row),
                  trailing: IconButton(
                    onPressed: () async {
                      await widget.repository.deleteModule('${row[r'$id']}');
                      await refresh();
                    },
                    icon: const Icon(Icons.delete_outline),
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    ),
  );
}

class AdminSettingsPage extends StatefulWidget {
  const AdminSettingsPage({required this.repository, super.key});
  final RacheyRepository repository;
  @override
  State<AdminSettingsPage> createState() => _AdminSettingsPageState();
}

class _AdminSettingsPageState extends State<AdminSettingsPage> {
  late Future<Map<String, dynamic>> future;
  final whatsapp = TextEditingController();
  final pixKey = TextEditingController();
  final pixName = TextEditingController();
  final pixCity = TextEditingController();
  final mpPublicKey = TextEditingController();
  final mpAccessToken = TextEditingController();
  final mpClientId = TextEditingController();
  final mpClientSecret = TextEditingController();
  final mpWebhookSecret = TextEditingController();
  final mpNotificationUrl = TextEditingController();
  final pixExpiration = TextEditingController(text: '45');
  final geminiApiKeys = TextEditingController();
  final aiPrimaryModel = TextEditingController(text: 'gemini-2.5-flash');
  final aiFallbackModels = TextEditingController();
  final aiSystemPrompt = TextEditingController();
  final aiTemperature = TextEditingController(text: '0.4');
  String paymentMode = 'manual';
  bool aiEnabled = false;
  final policy = TextEditingController();
  final terms = TextEditingController();
  final socials = TextEditingController();
  final faq = TextEditingController();
  final referralClientCashback = TextEditingController();
  final referralClientPoints = TextEditingController();
  final referralReferrerCashback = TextEditingController();
  final referralReferrerPoints = TextEditingController();
  String? logoId;
  String? bannerId;
  double? progress;
  bool saving = false;
  bool testingMp = false;
  bool testingAi = false;
  bool loadingAiModels = false;

  @override
  void initState() {
    super.initState();
    future = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final values = await Future.wait<dynamic>([
      widget.repository.action('app_settings'),
      widget.repository.listModules('faq', limit: 200),
    ]);
    final settings = Map<String, dynamic>.from(values[0] as Map);
    settings['_faq'] = values[1];
    final general = settings['general'] as Map? ?? const {};
    final pix = settings['pix'] as Map? ?? const {};
    final legal = settings['legal'] as Map? ?? const {};
    final loyalty = settings['loyalty'] as Map? ?? const {};
    final payments = settings['payments'] as Map? ?? const {};
    final ai = settings['ai_bot'] as Map? ?? const {};
    whatsapp.text = '${general['whatsapp'] ?? ''}';
    logoId = '${general['logo_file_id'] ?? ''}'.isEmpty
        ? null
        : '${general['logo_file_id']}';
    bannerId = '${general['banner_file_id'] ?? ''}'.isEmpty
        ? null
        : '${general['banner_file_id']}';
    pixName.text = '${pix['merchant_name'] ?? ''}';
    pixCity.text = '${pix['merchant_city'] ?? ''}';
    paymentMode = '${payments['mode'] ?? payments['payment_mode'] ?? 'manual'}';
    if (!const {'manual', 'mercado_pago', 'hybrid'}.contains(paymentMode)) paymentMode = 'manual';
    mpPublicKey.text = '${payments['mercado_pago_public_key'] ?? ''}';
    mpClientId.text = '${payments['mercado_pago_client_id'] ?? ''}';
    mpNotificationUrl.text = '${payments['mercado_pago_notification_url'] ?? ''}';
    pixExpiration.text = '${payments['pix_expiration_minutes'] ?? 45}';
    aiEnabled = ai['enabled'] == true;
    aiPrimaryModel.text = '${ai['primary_model'] ?? 'gemini-2.5-flash'}';
    aiFallbackModels.text = (ai['fallback_models'] as List? ?? const []).join('\n');
    aiSystemPrompt.text = '${ai['system_prompt'] ?? ''}';
    aiTemperature.text = '${ai['temperature'] ?? 0.4}';
    policy.text = '${legal['policy'] ?? ''}';
    terms.text = '${legal['terms'] ?? ''}';
    socials.text = '${general['socials'] ?? ''}';
    referralClientCashback.text = ((loyalty['referral_client_cashback_cents'] as num? ?? 0) / 100).toStringAsFixed(2);
    referralClientPoints.text = '${(loyalty['referral_client_points'] as num?)?.round() ?? 0}';
    referralReferrerCashback.text = ((loyalty['referral_referrer_cashback_cents'] as num? ?? 0) / 100).toStringAsFixed(2);
    referralReferrerPoints.text = '${(loyalty['referral_referrer_points'] as num?)?.round() ?? 0}';
    return settings;
  }

  Future<void> editFaq([Map<String, dynamic>? row]) async {
    final question = TextEditingController(text: '${row?['title'] ?? ''}');
    final answer = TextEditingController(
      text: '${(row?['data'] as Map? ?? const {})['answer'] ?? ''}',
    );
    final saveFaq = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(row == null ? 'Nova pergunta' : 'Editar pergunta'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: question,
              decoration: const InputDecoration(labelText: 'Pergunta *'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: answer,
              minLines: 3,
              maxLines: 8,
              decoration: const InputDecoration(labelText: 'Resposta *'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
    if (saveFaq == true &&
        question.text.trim().isNotEmpty &&
        answer.text.trim().isNotEmpty) {
      await widget.repository.saveModule(
        kind: 'faq',
        rowId: row?[r'$id']?.toString(),
        title: question.text.trim(),
        data: {'answer': answer.text.trim()},
      );
      if (mounted) setState(() => future = _load());
    }
    question.dispose();
    answer.dispose();
  }

  Future<void> deleteFaq(Map<String, dynamic> row) async {
    await widget.repository.deleteModule('${row[r'$id']}');
    if (mounted) setState(() => future = _load());
  }

  @override
  void dispose() {
    for (final controller in [
      whatsapp,
      pixKey,
      pixName,
      pixCity,
      mpPublicKey,
      mpAccessToken,
      mpClientId,
      mpClientSecret,
      mpWebhookSecret,
      mpNotificationUrl,
      pixExpiration,
      geminiApiKeys,
      aiPrimaryModel,
      aiFallbackModels,
      aiSystemPrompt,
      aiTemperature,
      policy,
      terms,
      socials,
      faq,
      referralClientCashback,
      referralClientPoints,
      referralReferrerCashback,
      referralReferrerPoints,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> upload(bool banner) async {
    final file = await NativeBridge.pickFile(mimeTypes: const ['image/*']);
    if (file == null || !mounted) return;
    setState(() => progress = 0);
    try {
      final upload = await widget.repository.uploadFile(
        file: file,
        type: banner ? 'app_banner' : 'app_logo',
        publicRead: true,
        onProgress: (value) {
          if (mounted) setState(() => progress = value / 100);
        },
      );
      setState(() {
        if (banner) {
          bannerId = upload.id;
        } else {
          logoId = upload.id;
        }
        progress = null;
      });
    } catch (error) {
      if (mounted) {
        setState(() => progress = null);
        _toast(context, _friendly(error));
      }
    }
  }

  Future<void> _savePaymentSettings() async {
    await widget.repository.action('save_app_settings', {
      'section': 'payments',
      'data': {
        'mode': paymentMode,
        'mercado_pago_public_key': mpPublicKey.text.trim(),
        'mercado_pago_client_id': mpClientId.text.trim(),
        'mercado_pago_notification_url': mpNotificationUrl.text.trim(),
        'pix_expiration_minutes': int.tryParse(pixExpiration.text.trim()) ?? 45,
        'mercado_pago_description': 'Rachey assinaturas digitais',
        if (mpAccessToken.text.trim().isNotEmpty)
          'mercado_pago_access_token': mpAccessToken.text.trim(),
        if (mpClientSecret.text.trim().isNotEmpty)
          'mercado_pago_client_secret': mpClientSecret.text.trim(),
        if (mpWebhookSecret.text.trim().isNotEmpty)
          'mercado_pago_webhook_secret': mpWebhookSecret.text.trim(),
      },
    });
  }

  Future<void> _saveAiSettings() async {
    await widget.repository.action('save_app_settings', {
      'section': 'ai_bot',
      'data': {
        'enabled': aiEnabled,
        'primary_model': aiPrimaryModel.text.trim(),
        'fallback_models': aiFallbackModels.text
            .split('\n')
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .toList(),
        'system_prompt': aiSystemPrompt.text.trim(),
        'temperature':
            double.tryParse(aiTemperature.text.replaceAll(',', '.')) ?? 0.4,
        if (geminiApiKeys.text.trim().isNotEmpty)
          'gemini_api_keys': geminiApiKeys.text
              .split('\n')
              .map((e) => e.trim())
              .where((e) => e.isNotEmpty)
              .toList(),
      },
    });
  }

  Future<void> testMercadoPago() async {
    if (testingMp) return;
    setState(() => testingMp = true);
    try {
      await _savePaymentSettings();
      final result = await widget.repository.action('test_mercado_pago');
      mpAccessToken.clear();
      mpClientSecret.clear();
      mpWebhookSecret.clear();
      if (!mounted) return;
      final nickname = '${result['nickname'] ?? ''}'.trim();
      _toast(
        context,
        nickname.isEmpty
            ? 'Mercado Pago conectado com sucesso.'
            : 'Mercado Pago conectado: $nickname.',
      );
      setState(() => future = _load());
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    } finally {
      if (mounted) setState(() => testingMp = false);
    }
  }

  Future<void> chooseAiModel() async {
    if (loadingAiModels) return;
    setState(() => loadingAiModels = true);
    try {
      await _saveAiSettings();
      final result = await widget.repository.action('list_ai_models');
      final models = (result['models'] as List? ?? const [])
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .toList();
      if (!mounted) return;
      if (models.isEmpty) {
        _toast(context, 'Nenhum modelo com generateContent foi encontrado para essa chave.');
        return;
      }
      final selected = await showDialog<String>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Escolher modelo de IA'),
          content: SizedBox(
            width: 560,
            height: 430,
            child: ListView.separated(
              itemCount: models.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, index) {
                final row = models[index];
                final id = '${row['id'] ?? ''}';
                final family = '${row['family'] ?? ''}';
                return ListTile(
                  leading: Icon(family == 'gemma' ? Icons.memory_rounded : Icons.auto_awesome_rounded),
                  title: Text('${row['name'] ?? id}', maxLines: 2, overflow: TextOverflow.ellipsis),
                  subtitle: Text(id),
                  onTap: () => Navigator.pop(dialogContext, id),
                );
              },
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancelar')),
          ],
        ),
      );
      if (selected != null && selected.trim().isNotEmpty && mounted) {
        setState(() => aiPrimaryModel.text = selected.trim());
      }
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    } finally {
      if (mounted) setState(() => loadingAiModels = false);
    }
  }

  Future<void> testAiBot() async {
    if (testingAi) return;
    setState(() => testingAi = true);
    try {
      await _saveAiSettings();
      final result = await widget.repository.action('test_ai_bot');
      geminiApiKeys.clear();
      if (!mounted) return;
      _toast(
        context,
        'IA conectada com ${result['model'] ?? 'modelo configurado'}.',
      );
      setState(() => future = _load());
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    } finally {
      if (mounted) setState(() => testingAi = false);
    }
  }

  Future<void> save() async {
    setState(() => saving = true);
    try {
      await widget.repository.action('save_app_settings', {
        'section': 'general',
        'data': {
          'whatsapp': whatsapp.text.trim(),
          'socials': socials.text.trim(),
          'theme_primary': '#16A36A',
          if (logoId != null) 'logo_file_id': logoId,
          if (bannerId != null) 'banner_file_id': bannerId,
        },
      });
      await widget.repository.action('save_app_settings', {
        'section': 'pix',
        'data': {
          if (pixKey.text.trim().isNotEmpty) 'pix_key': pixKey.text.trim(),
          'merchant_name': pixName.text.trim(),
          'merchant_city': pixCity.text.trim(),
          'description': 'Rachey assinaturas digitais',
        },
      });
      await _savePaymentSettings();
      await _saveAiSettings();
      await widget.repository.action('save_app_settings', {
        'section': 'legal',
        'data': {'policy': policy.text.trim(), 'terms': terms.text.trim()},
      });
      await widget.repository.action('save_app_settings', {
        'section': 'loyalty',
        'data': {
          'referral_client_cashback_cents': ((double.tryParse(referralClientCashback.text.replaceAll(',', '.')) ?? 0) * 100).round(),
          'referral_client_points': int.tryParse(referralClientPoints.text.trim()) ?? 0,
          'referral_referrer_cashback_cents': ((double.tryParse(referralReferrerCashback.text.replaceAll(',', '.')) ?? 0) * 100).round(),
          'referral_referrer_points': int.tryParse(referralReferrerPoints.text.trim()) ?? 0,
        },
      });
      final faqLines = faq.text
          .split('\n')
          .map((line) => line.split('|'))
          .where((parts) => parts.length >= 2)
          .toList();
      for (final parts in faqLines) {
        await widget.repository.saveModule(
          kind: 'faq',
          title: parts.first.trim(),
          data: {'answer': parts.sublist(1).join('|').trim()},
        );
      }
      faq.clear();
      if (mounted) setState(() => future = _load());
      pixKey.clear();
      mpAccessToken.clear();
      mpClientSecret.clear();
      mpWebhookSecret.clear();
      geminiApiKeys.clear();
      if (mounted) _toast(context, 'Configurações salvas e auditadas.');
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Configurações do Rachey')),
    body: FutureBuilder<Map<String, dynamic>>(
      future: future,
      builder: (_, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting)
          return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError)
          return _ErrorBody(
            error: snapshot.error!,
            onRetry: () async => setState(() => future = _load()),
          );
        final existingFaq = (snapshot.data?['_faq'] as List? ?? const [])
            .whereType<Map>()
            .map((row) => Map<String, dynamic>.from(row))
            .toList();
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: progress == null ? () => upload(false) : null,
                    icon: const Icon(Icons.image_outlined),
                    label: Text(logoId == null ? 'Enviar logo' : 'Trocar logo'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: progress == null ? () => upload(true) : null,
                    icon: const Icon(Icons.panorama_outlined),
                    label: Text(
                      bannerId == null ? 'Enviar banner' : 'Trocar banner',
                    ),
                  ),
                ),
              ],
            ),
            if (progress != null) ...[
              const SizedBox(height: 8),
              LinearProgressIndicator(value: progress),
            ],
            const SizedBox(height: 14),
            TextField(
              controller: whatsapp,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'WhatsApp'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: socials,
              minLines: 2,
              maxLines: 6,
              decoration: const InputDecoration(
                labelText: 'Redes sociais',
                helperText: 'Uma URL por linha',
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Pix',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: pixKey,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Chave Pix',
                helperText:
                    'A chave é criptografada pela Function. Deixe vazia para manter a atual.',
              ),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: pixName,
              decoration: const InputDecoration(labelText: 'Nome do recebedor'),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: pixCity,
              decoration: const InputDecoration(
                labelText: 'Cidade do recebedor',
              ),
            ),
            const SizedBox(height: 18),
            const Text('Pagamentos automáticos', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            const SizedBox(height: 4),
            const Text('As credenciais são digitadas aqui, mas ficam criptografadas no backend e não voltam para o APK.', style: TextStyle(color: RacheyColors.gray, fontSize: 12)),
            const SizedBox(height: 9),
            DropdownButtonFormField<String>(
              value: paymentMode,
              decoration: const InputDecoration(labelText: 'Modo de Pix'),
              items: const [
                DropdownMenuItem(value: 'manual', child: Text('Pix manual')),
                DropdownMenuItem(value: 'mercado_pago', child: Text('Mercado Pago automático')),
                DropdownMenuItem(value: 'hybrid', child: Text('Mercado Pago + fallback manual')),
              ],
              onChanged: (value) => setState(() => paymentMode = value ?? 'manual'),
            ),
            const SizedBox(height: 9),
            TextField(controller: mpPublicKey, decoration: const InputDecoration(labelText: 'Mercado Pago • Public Key')),
            const SizedBox(height: 9),
            TextField(controller: mpAccessToken, obscureText: true, decoration: InputDecoration(labelText: 'Mercado Pago • Access Token', helperText: ((snapshot.data?['payments'] as Map? ?? const {})['secret_status'] as Map? ?? const {})['mercado_pago_access_token'] == true ? 'Já configurado. Deixe vazio para manter.' : 'Obrigatório para Pix automático.')),
            const SizedBox(height: 9),
            TextField(controller: mpClientId, decoration: const InputDecoration(labelText: 'Mercado Pago • Client ID (opcional)')),
            const SizedBox(height: 9),
            TextField(controller: mpClientSecret, obscureText: true, decoration: InputDecoration(labelText: 'Mercado Pago • Client Secret (opcional)', helperText: ((snapshot.data?['payments'] as Map? ?? const {})['secret_status'] as Map? ?? const {})['mercado_pago_client_secret'] == true ? 'Já configurado. Deixe vazio para manter.' : null)),
            const SizedBox(height: 9),
            TextField(
              controller: mpWebhookSecret,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Mercado Pago • Assinatura secreta do Webhook',
                helperText: ((snapshot.data?['payments'] as Map? ?? const {})['secret_status'] as Map? ?? const {})['mercado_pago_webhook_secret'] == true
                    ? 'Já configurada. Deixe vazio para manter.'
                    : 'Use a assinatura secreta exibida em Suas integrações > Webhooks.',
              ),
            ),
            const SizedBox(height: 9),
            TextField(controller: mpNotificationUrl, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'URL pública da Function para webhook/notificação (opcional)', helperText: 'Para confirmação automática em segundo plano, informe a URL pública da Function e permita execução pública somente porque a Function valida a assinatura do Mercado Pago.')),
            const SizedBox(height: 9),
            TextField(controller: pixExpiration, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Pix expira em quantos minutos')),
            const SizedBox(height: 9),
            OutlinedButton.icon(
              onPressed: testingMp ? null : testMercadoPago,
              icon: testingMp
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.verified_user_outlined),
              label: Text(testingMp ? 'Testando Mercado Pago...' : 'Salvar e testar Mercado Pago'),
            ),
            const SizedBox(height: 20),
            const Text('Rachey Bot • Gemini / Gemma', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            const SizedBox(height: 4),
            SwitchListTile(contentPadding: EdgeInsets.zero, value: aiEnabled, onChanged: (value) => setState(() => aiEnabled = value), title: const Text('Ativar respostas por IA'), subtitle: const Text('Comandos /bot e @racheybot usam as chaves abaixo com fallback.')),
            TextField(controller: geminiApiKeys, obscureText: true, minLines: 1, maxLines: 6, decoration: InputDecoration(labelText: 'Chaves API Gemini', helperText: (((snapshot.data?['ai_bot'] as Map? ?? const {})['secret_status'] as Map? ?? const {})['gemini_api_keys'] as num? ?? 0) > 0 ? '${(((snapshot.data?['ai_bot'] as Map? ?? const {})['secret_status'] as Map? ?? const {})['gemini_api_keys'] as num).round()} chave(s) já configurada(s). Uma nova chave por linha substitui a lista.' : 'Uma chave por linha. A próxima é usada se a anterior falhar.')),
            const SizedBox(height: 9),
            TextField(controller: aiPrimaryModel, decoration: const InputDecoration(labelText: 'Modelo principal', helperText: 'Escolha na lista da sua chave ou informe um ID manualmente.')),
            const SizedBox(height: 7),
            OutlinedButton.icon(
              onPressed: loadingAiModels ? null : chooseAiModel,
              icon: loadingAiModels
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.manage_search_rounded),
              label: Text(loadingAiModels ? 'Buscando modelos...' : 'Buscar e escolher modelo disponível'),
            ),
            const SizedBox(height: 9),
            TextField(controller: aiFallbackModels, minLines: 2, maxLines: 6, decoration: const InputDecoration(labelText: 'Modelos de fallback', helperText: 'Um modelo por linha, na ordem de tentativa. Você pode misturar Gemini e Gemma.')),
            const SizedBox(height: 9),
            TextField(controller: aiTemperature, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Temperatura da IA (0 a 2)')),
            const SizedBox(height: 9),
            TextField(controller: aiSystemPrompt, minLines: 3, maxLines: 10, decoration: const InputDecoration(labelText: 'Instruções do bot', helperText: 'Personalize tom, regras e limites. O bot não recebe segredos do painel.')),
            const SizedBox(height: 9),
            OutlinedButton.icon(
              onPressed: testingAi ? null : testAiBot,
              icon: testingAi
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.smart_toy_outlined),
              label: Text(testingAi ? 'Testando IA...' : 'Salvar e testar Gemini / Gemma'),
            ),
            const SizedBox(height: 18),
            const Text(
              'Programa de indicação',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
            const SizedBox(height: 4),
            const Text('As recompensas só são creditadas quando a primeira compra do indicado é aprovada.', style: TextStyle(color: RacheyColors.gray, fontSize: 12)),
            const SizedBox(height: 9),
            Row(children: [
              Expanded(child: TextField(controller: referralClientCashback, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Cashback do indicado (R\$)'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: referralClientPoints, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Pontos do indicado'))),
            ]),
            const SizedBox(height: 9),
            Row(children: [
              Expanded(child: TextField(controller: referralReferrerCashback, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Cashback de quem indicou (R\$)'))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: referralReferrerPoints, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Pontos de quem indicou'))),
            ]),
            const SizedBox(height: 18),
            const Text(
              'Conteúdo legal',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: policy,
              minLines: 4,
              maxLines: 14,
              decoration: const InputDecoration(
                labelText: 'Política de privacidade',
              ),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: terms,
              minLines: 4,
              maxLines: 14,
              decoration: const InputDecoration(labelText: 'Termos de uso'),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Perguntas frequentes',
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
                  ),
                ),
                IconButton(
                  tooltip: 'Nova pergunta',
                  onPressed: editFaq,
                  icon: const Icon(Icons.add_circle_outline),
                ),
              ],
            ),
            if (existingFaq.isNotEmpty)
              Card(
                child: Column(
                  children: existingFaq.indexed
                      .map(
                        (entry) => Column(
                          children: [
                            ListTile(
                              title: Text('${entry.$2['title'] ?? 'Pergunta'}'),
                              subtitle: Text(
                                '${(entry.$2['data'] as Map? ?? const {})['answer'] ?? ''}',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              onTap: () => editFaq(entry.$2),
                              trailing: IconButton(
                                tooltip: 'Excluir',
                                onPressed: () => deleteFaq(entry.$2),
                                icon: const Icon(Icons.delete_outline),
                              ),
                            ),
                            if (entry.$1 != existingFaq.length - 1)
                              const Divider(height: 1),
                          ],
                        ),
                      )
                      .toList(),
                ),
              ),
            const SizedBox(height: 10),
            TextField(
              controller: faq,
              minLines: 3,
              maxLines: 10,
              decoration: const InputDecoration(
                labelText: 'Adicionar FAQ',
                helperText: 'Uma linha: pergunta|resposta',
              ),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: saving || progress != null ? null : save,
              icon: const Icon(Icons.save_outlined),
              label: Text(saving ? 'Salvando...' : 'Salvar configurações'),
            ),
          ],
        );
      },
    ),
  );
}

class AdminAutomationsPage extends StatefulWidget {
  const AdminAutomationsPage({required this.repository, super.key});
  final RacheyRepository repository;
  @override
  State<AdminAutomationsPage> createState() => _AdminAutomationsPageState();
}

class _AdminAutomationsPageState extends State<AdminAutomationsPage> {
  late Future<List<Map<String, dynamic>>> future;
  bool running = false;
  @override
  void initState() {
    super.initState();
    future = widget.repository.listModules('backup_run', limit: 100);
  }

  Future<void> refresh() async {
    setState(
      () => future = widget.repository.listModules('backup_run', limit: 100),
    );
    await future;
  }

  Future<void> runBackup() async {
    setState(() => running = true);
    try {
      await widget.repository.action('backup_now');
      await refresh();
      if (mounted) _toast(context, 'Backup concluído e registrado.');
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    } finally {
      if (mounted) setState(() => running = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Automações')),
    body: FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (_, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting)
          return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError)
          return _ErrorBody(error: snapshot.error!, onRetry: refresh);
        final rows = snapshot.data ?? const [];
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Card(
              child: Column(
                children: [
                  ListTile(
                    leading: Icon(
                      Icons.autorenew_rounded,
                      color: RacheyColors.primary,
                    ),
                    title: Text('Renovação automática'),
                    subtitle: Text(
                      'Executada diariamente pela Function agendada',
                    ),
                  ),
                  Divider(height: 1),
                  ListTile(
                    leading: Icon(
                      Icons.hourglass_top_rounded,
                      color: RacheyColors.primary,
                    ),
                    title: Text('Fila de espera e liberação'),
                    subtitle: Text(
                      'Avisa quando surge vaga; a entrega segue a regra da conta pronta ou liberação manual',
                    ),
                  ),
                  Divider(height: 1),
                  ListTile(
                    leading: Icon(
                      Icons.notifications_active_outlined,
                      color: RacheyColors.primary,
                    ),
                    title: Text('Vencimentos'),
                    subtitle: Text('2 dias antes, no dia e após vencer'),
                  ),
                  Divider(height: 1),
                  ListTile(
                    leading: Icon(
                      Icons.policy_outlined,
                      color: RacheyColors.primary,
                    ),
                    title: Text('Auditoria'),
                    subtitle: Text(
                      'Operações administrativas e sensíveis registradas',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: running ? null : runBackup,
              icon: const Icon(Icons.backup_outlined),
              label: Text(
                running ? 'Gerando backup...' : 'Executar backup agora',
              ),
            ),
            const SizedBox(height: 18),
            const Text(
              'Histórico de backups',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
            const SizedBox(height: 8),
            if (rows.isEmpty)
              const Card(
                child: ListTile(title: Text('Nenhum backup registrado ainda.')),
              )
            else
              ...rows.map(
                (row) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.cloud_done_outlined),
                    title: Text('${row['title'] ?? 'Backup'}'),
                    subtitle: Text(
                      '${_date('${row[r'$createdAt'] ?? ''}')} • ${row['status'] ?? ''}',
                    ),
                    trailing: Text(
                      '${(row['data'] as Map? ?? const {})['size'] ?? ''} bytes',
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    ),
  );
}

class AdminSubscriptionRequestsPage extends StatefulWidget {
  const AdminSubscriptionRequestsPage({required this.repository, super.key});
  final RacheyRepository repository;

  @override
  State<AdminSubscriptionRequestsPage> createState() =>
      _AdminSubscriptionRequestsPageState();
}

class _AdminSubscriptionRequestsPageState
    extends State<AdminSubscriptionRequestsPage> {
  late Future<List<Map<String, dynamic>>> future;

  @override
  void initState() {
    super.initState();
    future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() =>
      widget.repository.listModules('subscription_request', limit: 500);

  Future<void> refresh() async {
    setState(() => future = _load());
    await future;
  }

  Future<void> decide(Map<String, dynamic> row, bool approve) async {
    final reason = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(approve ? 'Aprovar troca?' : 'Recusar solicitação?'),
        content: TextField(
          controller: reason,
          minLines: 2,
          maxLines: 5,
          decoration: InputDecoration(
            labelText: approve ? 'Observação opcional' : 'Motivo da recusa',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(approve ? 'Aprovar' : 'Recusar'),
          ),
        ],
      ),
    );
    if (confirmed != true) {
      reason.dispose();
      return;
    }
    try {
      await widget.repository.action('subscription_request_update', {
        'row_id': row[r'$id'],
        'decision': approve ? 'approve' : 'reject',
        if (reason.text.trim().isNotEmpty) 'reason': reason.text.trim(),
      });
      await refresh();
      if (mounted)
        _toast(context, 'Solicitação atualizada e cliente notificado.');
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    } finally {
      reason.dispose();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Trocas de conta e tela')),
    body: RefreshIndicator(
      onRefresh: refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return _ErrorBody(error: snapshot.error!, onRetry: refresh);
          }
          final rows = snapshot.data ?? const [];
          if (rows.isEmpty) {
            return const _EmptyBody(
              icon: Icons.swap_horiz_rounded,
              text: 'Nenhuma troca solicitada.',
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: rows.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (_, index) {
              final row = rows[index];
              final data = row['data'] as Map? ?? const {};
              final pending = const {
                'aberta',
                'aguardando_vaga',
              }.contains(row['status']);
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          CircleAvatar(
                            child: Icon(
                              data['type'] == 'screen'
                                  ? Icons.screenshot_monitor_outlined
                                  : Icons.manage_accounts_outlined,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${row['title'] ?? 'Solicitação de troca'}',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                Text('Cliente: ${row['owner_id'] ?? ''}'),
                              ],
                            ),
                          ),
                          Chip(label: Text(_status('${row['status']}'))),
                        ],
                      ),
                      if ('${data['reason'] ?? ''}'.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Text('${data['reason']}'),
                      ],
                      if (pending) ...[
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => decide(row, false),
                                child: const Text('Recusar'),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: FilledButton(
                                onPressed: () => decide(row, true),
                                child: const Text('Aprovar troca'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class _ClientFileData {
  const _ClientFileData({
    required this.orders,
    required this.payments,
    required this.subscriptions,
    required this.tickets,
    required this.notes,
    required this.tags,
  });
  final List<Map<String, dynamic>> orders;
  final List<Map<String, dynamic>> payments;
  final List<Map<String, dynamic>> subscriptions;
  final List<Map<String, dynamic>> tickets;
  final List<Map<String, dynamic>> notes;
  final List<Map<String, dynamic>> tags;
}

class _FinanceData {
  const _FinanceData({required this.summary, required this.goals});
  final Map<String, dynamic> summary;
  final List<Map<String, dynamic>> goals;
}

class _CrmMetric extends StatelessWidget {
  const _CrmMetric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(13),
      child: Column(
        children: [
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontWeight: FontWeight.w900,
              color: RacheyColors.primary,
            ),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: RacheyColors.gray),
          ),
        ],
      ),
    ),
  );
}

class _FinanceMetric extends StatelessWidget {
  const _FinanceMetric({
    required this.label,
    required this.value,
    required this.color,
  });
  final String label;
  final int value;
  final Color color;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Text(
            _money(value),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontWeight: FontWeight.w900, color: color),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: RacheyColors.gray),
          ),
        ],
      ),
    ),
  );
}

class _MoneyBar extends StatelessWidget {
  const _MoneyBar({
    required this.label,
    required this.value,
    required this.max,
    required this.color,
  });
  final String label;
  final int value;
  final int max;
  final Color color;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 13),
    child: Column(
      children: [
        Row(
          children: [
            Expanded(child: Text(label)),
            Text(_money(value)),
          ],
        ),
        const SizedBox(height: 5),
        LinearProgressIndicator(value: value.abs() / max, color: color),
      ],
    ),
  );
}

class _Section extends StatelessWidget {
  const _Section({
    required this.title,
    required this.rows,
    required this.titleOf,
    required this.subtitleOf,
  });
  final String title;
  final List<Map<String, dynamic>> rows;
  final String Function(Map<String, dynamic>) titleOf;
  final String Function(Map<String, dynamic>) subtitleOf;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 18),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
        ),
        const SizedBox(height: 8),
        if (rows.isEmpty)
          const Card(child: ListTile(title: Text('Nenhum registro.')))
        else
          ...rows
              .take(20)
              .map(
                (row) => Card(
                  child: ListTile(
                    title: Text(titleOf(row)),
                    subtitle: Text(subtitleOf(row)),
                  ),
                ),
              ),
      ],
    ),
  );
}

class _ErrorBody extends StatelessWidget {
  const _ErrorBody({required this.error, required this.onRetry});
  final Object error;
  final Future<void> Function() onRetry;
  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const SizedBox(height: 130),
      const Icon(Icons.cloud_off_outlined, size: 54, color: RacheyColors.gray),
      const SizedBox(height: 10),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Text(_friendly(error), textAlign: TextAlign.center),
      ),
      const SizedBox(height: 10),
      Center(
        child: OutlinedButton(
          onPressed: onRetry,
          child: const Text('Tentar novamente'),
        ),
      ),
    ],
  );
}

class _EmptyBody extends StatelessWidget {
  const _EmptyBody({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const SizedBox(height: 150),
      Icon(icon, size: 54, color: RacheyColors.gray),
      const SizedBox(height: 10),
      Center(child: Text(text)),
    ],
  );
}

List<Map<String, dynamic>> _rows(Map<String, dynamic> value) =>
    (value['rows'] as List<dynamic>? ?? const [])
        .whereType<Map>()
        .map((row) => Map<String, dynamic>.from(row))
        .toList();

Future<bool> _textDialog(
  BuildContext context,
  String title,
  TextEditingController controller,
  String label,
) async =>
    await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          minLines: 2,
          maxLines: 6,
          decoration: InputDecoration(labelText: label),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Salvar'),
          ),
        ],
      ),
    ) ??
    false;

Future<bool> _textMoneyDialog(
  BuildContext context,
  String titleText,
  TextEditingController title,
  TextEditingController amount,
) async =>
    await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(titleText),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: title,
              decoration: const InputDecoration(labelText: 'Descrição *'),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: amount,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(labelText: 'Valor (R\$) *'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Salvar'),
          ),
        ],
      ),
    ) ??
    false;

void _toast(BuildContext context, String message) => ScaffoldMessenger.of(
  context,
).showSnackBar(SnackBar(content: Text(message)));
String _money(int cents) =>
    'R\$ ${(cents / 100).toStringAsFixed(2).replaceAll('.', ',')}';
String _status(String value) => value.replaceAll('_', ' ');
String _date(String raw) {
  final date = DateTime.tryParse(raw)?.toLocal();
  return date == null
      ? 'não informado'
      : '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
}

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
