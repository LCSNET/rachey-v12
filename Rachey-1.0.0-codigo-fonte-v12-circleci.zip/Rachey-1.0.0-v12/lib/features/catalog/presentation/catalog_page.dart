import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/widgets/rachey_ui.dart';
import 'package:rachey/data/models/rachey_document.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';

class CatalogPage extends StatefulWidget {
  const CatalogPage({
    required this.repository,
    required this.userId,
    super.key,
  });

  final RacheyRepository repository;
  final String userId;

  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  late Future<_CatalogData> _future;
  final List<_CartLine> _cart = [];
  String? _category;
  String _search = '';
  bool _favoritesOnly = false;

  int get _cartCount => _cart.fold(0, (sum, line) => sum + line.quantity);

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_CatalogData> _load() async {
    final values = await Future.wait<dynamic>([
      widget.repository.list(type: 'service'),
      widget.repository.list(type: 'category'),
      widget.repository.listModules('service_meta', limit: 500),
      widget.repository.listModules('category_meta', limit: 500),
      widget.repository.action('catalog_quotes'),
      widget.repository.listModules('favorite', limit: 500),
    ]);
    final services =
        (values[0] as List<RacheyDocument>)
            .where((item) => item.payload['active'] != false)
            .toList()
          ..sort(
            (a, b) => ((a.payload['order'] as num?) ?? 0).compareTo(
              (b.payload['order'] as num?) ?? 0,
            ),
          );
    final categories =
        (values[1] as List<RacheyDocument>)
            .where((item) => item.payload['ativo'] != false)
            .toList()
          ..sort(
            (a, b) => ((a.payload['ordem'] as num?) ?? 0).compareTo(
              (b.payload['ordem'] as num?) ?? 0,
            ),
          );
    return _CatalogData(
      services: services,
      categories: categories,
      serviceMetadata: values[2] as List<Map<String, dynamic>>,
      categoryMetadata: values[3] as List<Map<String, dynamic>>,
      stockQuotes: ((values[4] as Map<String, dynamic>)['rows'] as List<dynamic>? ?? const [])
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList(),
      favorites: values[5] as List<Map<String, dynamic>>,
    );
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Map<String, dynamic> _metadata(_CatalogData data, String serviceId) {
    final result = <String, dynamic>{};
    for (final row in data.serviceMetadata) {
      if (row['reference_id'] == serviceId) {
        result.addAll(Map<String, dynamic>.from(row['data'] as Map? ?? const {}));
        break;
      }
    }
    for (final quote in data.stockQuotes) {
      if ('${quote['service_id'] ?? ''}' == serviceId) {
        result['stock_quotes'] = quote['periods'];
        result['stock_available'] = quote['available'];
        break;
      }
    }
    return result;
  }

  bool _isFavorite(_CatalogData data, String serviceId) => data.favorites.any(
    (row) => '${row['reference_id'] ?? ''}' == serviceId,
  );

  Future<void> _toggleFavorite(_CatalogData data, RacheyDocument service) async {
    Map<String, dynamic>? current;
    for (final row in data.favorites) {
      if ('${row['reference_id'] ?? ''}' == service.id) {
        current = row;
        break;
      }
    }
    try {
      if (current != null) {
        await widget.repository.deleteModule('${current[r'$id']}');
      } else {
        await widget.repository.saveModule(
          kind: 'favorite',
          referenceId: service.id,
          title: '${service.payload['name'] ?? 'Serviço'}',
          status: 'ativo',
          data: {'service_id': service.id},
        );
      }
      await _refresh();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    }
  }

  Future<void> _details(
    _CatalogData data,
    RacheyDocument service,
    Map<String, dynamic> metadata,
  ) async {
    final periods = _periods(service, metadata);
    var selected = periods.first;
    var quantity = 1;
    final added = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (_, setSheetState) {
          final payload = service.payload;
          final faq = (metadata['faq'] as List? ?? const []);
          final compatibility =
              (metadata['compatibility'] as List? ?? const []);
          final benefits = (metadata['benefits'] as List? ?? const []);
          final related = data.services
              .where((item) => item.id != service.id && item.payload['category'] == service.payload['category'])
              .take(3)
              .toList();
          return SafeArea(
            top: false,
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                20,
                4,
                20,
                MediaQuery.viewInsetsOf(sheetContext).bottom + 26,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _ServiceHero(
                    repository: widget.repository,
                    service: service,
                    metadata: metadata,
                  ),
                  const SizedBox(height: 18),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          '${payload['name'] ?? 'Serviço'}',
                          style: Theme.of(context).textTheme.headlineSmall
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                      ),
                      if ((metadata['promotion_percent'] as num? ?? 0) > 0)
                        const Chip(
                          avatar: Icon(Icons.local_offer_outlined, size: 17),
                          label: Text('Promoção'),
                          backgroundColor: Color(0xFFFFE6D4),
                        ),
                    ],
                  ),
                  const SizedBox(height: 7),
                  Text(
                    '${payload['description'] ?? ''}',
                    style: const TextStyle(
                      color: RacheyColors.gray,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 7,
                    runSpacing: 7,
                    children: [
                      _InfoChip(
                        icon: Icons.category_outlined,
                        label: _serviceType(
                          '${metadata['service_type'] ?? 'subscription'}',
                        ),
                      ),
                      if ((metadata['cashback_percent'] as num? ?? 0) > 0)
                        _InfoChip(
                          icon: Icons.savings_outlined,
                          label: '${metadata['cashback_percent']}% cashback',
                        ),
                      if ((metadata['points'] as num? ?? 0) > 0)
                        _InfoChip(
                          icon: Icons.stars_outlined,
                          label: '${metadata['points']} pontos',
                        ),
                      _InfoChip(
                        icon: metadata['stock_enabled'] == true
                            ? Icons.inventory_2_outlined
                            : Icons.schedule_send_outlined,
                        label: metadata['stock_enabled'] == true
                            ? ((metadata['stock_quotes'] as List? ?? const []).any(
                                  (item) => item is Map && item['prorated'] == true,
                                )
                                ? 'Conta pronta • valor por dias restantes'
                                : 'Estoque por conta/tela')
                            : 'Prazo começa quando a equipe liberar',
                      ),
                    ],
                  ),
                  if (benefits.isNotEmpty) ...[
                    const SizedBox(height: 18),
                    const Text(
                      'Inclui',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 7),
                    ...benefits.map(
                      (item) => Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.check_circle,
                              size: 18,
                              color: RacheyColors.primary,
                            ),
                            const SizedBox(width: 8),
                            Expanded(child: Text('$item')),
                          ],
                        ),
                      ),
                    ),
                  ],
                  if (compatibility.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    const Text(
                      'Compatibilidade',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 7),
                    Wrap(
                      spacing: 6,
                      children: compatibility
                          .map((item) => Chip(label: Text('$item')))
                          .toList(),
                    ),
                  ],
                  const SizedBox(height: 18),
                  const Text(
                    'Escolha o período',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: periods
                        .map(
                          (period) => ChoiceChip(
                            label: Text(
                              '${period.label} • ${_money(period.priceCents)}',
                            ),
                            selected: selected.days == period.days,
                            onSelected: (_) =>
                                setSheetState(() => selected = period),
                          ),
                        )
                        .toList(),
                  ),
                  if (selected.prorated) ...[
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: RacheyColors.primary.withValues(alpha: .08),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(Icons.schedule_rounded, color: RacheyColors.primary),
                          const SizedBox(width: 9),
                          Expanded(
                            child: Text(
                              'Conta pronta: ${selected.effectiveDays} dias restantes por ${_money(selected.priceCents)}. O valor foi reduzido proporcionalmente e o vencimento acompanha a conta do estoque.',
                              style: const TextStyle(height: 1.35),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      const Text(
                        'Quantidade',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                      const Spacer(),
                      IconButton(
                        onPressed: quantity > 1
                            ? () => setSheetState(() => quantity--)
                            : null,
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      Text(
                        '$quantity',
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 18,
                        ),
                      ),
                      IconButton(
                        onPressed: quantity < 20
                            ? () => setSheetState(() => quantity++)
                            : null,
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ],
                  ),
                  if ('${metadata['observations'] ?? ''}'.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: RacheyColors.mint,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            Icons.info_outline,
                            color: RacheyColors.primary,
                          ),
                          const SizedBox(width: 9),
                          Expanded(child: Text('${metadata['observations']}')),
                        ],
                      ),
                    ),
                  ],
                  if (faq.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    ExpansionTile(
                      tilePadding: EdgeInsets.zero,
                      title: const Text(
                        'Perguntas frequentes',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                      children: faq.map((raw) {
                        final item = raw is Map ? raw : const {};
                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text('${item['question'] ?? item['q'] ?? ''}'),
                          subtitle: Text(
                            '${item['answer'] ?? item['a'] ?? ''}',
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                  if (related.isNotEmpty) ...[
                    const SizedBox(height: 18),
                    const Text('Você também pode gostar', style: TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 7,
                      runSpacing: 7,
                      children: related.map((item) => ActionChip(
                        avatar: const Icon(Icons.add_shopping_cart_outlined, size: 17),
                        label: Text('${item.payload['name'] ?? 'Serviço'}'),
                        onPressed: () {
                          Navigator.pop(sheetContext, false);
                          Future<void>.delayed(Duration.zero, () => _details(data, item, _metadata(data, item.id)));
                        },
                      )).toList(),
                    ),
                  ],
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: () => Navigator.pop(sheetContext, true),
                    icon: const Icon(Icons.add_shopping_cart_rounded),
                    label: Text(
                      'Adicionar • ${_money(selected.priceCents * quantity)}',
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
    if (added == true && mounted) {
      final matching = _cart
          .where(
            (line) =>
                line.service.id == service.id &&
                line.period.days == selected.days,
          )
          .toList();
      setState(() {
        if (matching.isEmpty) {
          _cart.add(
            _CartLine(
              service: service,
              metadata: metadata,
              period: selected,
              quantity: quantity,
            ),
          );
        } else {
          matching.first.quantity = (matching.first.quantity + quantity).clamp(
            1,
            20,
          );
        }
      });
      _toast('${service.payload['name']} adicionado ao carrinho.');
    }
  }

  Future<void> _openCart() async {
    if (_cart.isEmpty) {
      _toast('Seu carrinho está vazio.');
      return;
    }
    final completed = await Navigator.push<bool>(
      context,
      MaterialPageRoute<bool>(
        builder: (_) => _CartPage(
          repository: widget.repository,
          lines: _cart,
          onChanged: () => setState(() {}),
        ),
      ),
    );
    if (completed == true && mounted) setState(_cart.clear);
  }

  void _toast(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      toolbarHeight: 72,
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Catálogo'),
          Text(
            'Escolha, compare e assine',
            style: TextStyle(fontSize: 12, color: RacheyColors.gray),
          ),
        ],
      ),
      actions: [
        const RacheyThemeButton(),
        const SizedBox(width: 4),
        Badge(
          isLabelVisible: _cartCount > 0,
          label: Text('$_cartCount'),
          child: IconButton(
            tooltip: 'Carrinho',
            onPressed: _openCart,
            icon: const Icon(Icons.shopping_bag_outlined),
          ),
        ),
        const SizedBox(width: 8),
      ],
    ),
    floatingActionButton: _cartCount == 0
        ? null
        : FloatingActionButton.extended(
            onPressed: _openCart,
            icon: Badge(
              label: Text('$_cartCount'),
              child: const Icon(Icons.shopping_bag_rounded),
            ),
            label: Text(
              'Ver carrinho • ${_money(_cart.fold(0, (sum, line) => sum + line.period.priceCents * line.quantity))}',
            ),
          ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<_CatalogData>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const _CatalogSkeleton();
          }
          if (snapshot.hasError) {
            return ListView(
              children: [
                const SizedBox(height: 150),
                const Icon(
                  Icons.cloud_off_outlined,
                  size: 54,
                  color: RacheyColors.gray,
                ),
                const SizedBox(height: 12),
                Center(child: Text(_friendly(snapshot.error!))),
                const SizedBox(height: 10),
                Center(
                  child: OutlinedButton(
                    onPressed: _refresh,
                    child: const Text('Tentar novamente'),
                  ),
                ),
              ],
            );
          }
          final data = snapshot.data!;
          final services = data.services.where((service) {
            final categoryMatches =
                _category == null || service.payload['category'] == _category;
            final query = _search.toLowerCase();
            final text =
                '${service.payload['name']} ${service.payload['description']}'
                    .toLowerCase();
            final favoriteMatches = !_favoritesOnly || _isFavorite(data, service.id);
            return categoryMatches && favoriteMatches && (query.isEmpty || text.contains(query));
          }).toList();
          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(16, 8, 16, 14),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [RacheyColors.navy, RacheyColors.darkGreen],
                    ),
                    borderRadius: BorderRadius.circular(26),
                  ),
                  child: const Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RacheyStatusPill(
                              label: 'Compra rápida',
                              icon: Icons.bolt_rounded,
                              color: Color(0xFF8BE8BE),
                            ),
                            SizedBox(height: 12),
                            Text(
                              'Seu próximo plano está aqui',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -.5,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'Sem frete. Tudo pelo app.',
                              style: TextStyle(color: Colors.white70),
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        Icons.shopping_bag_rounded,
                        color: Colors.white24,
                        size: 74,
                      ),
                    ],
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: TextField(
                    onChanged: (value) => setState(() => _search = value),
                    decoration: const InputDecoration(
                      hintText: 'Buscar Netflix, VPN, Office...',
                      prefixIcon: Icon(Icons.search_rounded),
                    ),
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: FilterChip(
                      avatar: Icon(_favoritesOnly ? Icons.favorite : Icons.favorite_border, size: 18),
                      label: const Text('Favoritos'),
                      selected: _favoritesOnly,
                      onSelected: (value) => setState(() => _favoritesOnly = value),
                    ),
                  ),
                ),
              ),
              if (data.categories.isNotEmpty)
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 52,
                    child: ListView(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 5,
                      ),
                      scrollDirection: Axis.horizontal,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 7),
                          child: ChoiceChip(
                            label: const Text('Todos'),
                            selected: _category == null,
                            onSelected: (_) => setState(() => _category = null),
                          ),
                        ),
                        ...data.categories.map(
                          (item) => Padding(
                            padding: const EdgeInsets.only(right: 7),
                            child: ChoiceChip(
                              label: Text(
                                '${item.payload['nome'] ?? 'Categoria'}',
                              ),
                              selected: _category == item.id,
                              onSelected: (_) =>
                                  setState(() => _category = item.id),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              if (services.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.inventory_2_outlined,
                        size: 52,
                        color: RacheyColors.gray,
                      ),
                      SizedBox(height: 12),
                      Text('Nenhum serviço encontrado.'),
                    ],
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                  sliver: SliverGrid.builder(
                    gridDelegate:
                        const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 360,
                          childAspectRatio: .74,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                        ),
                    itemCount: services.length,
                    itemBuilder: (_, index) {
                      final service = services[index];
                      final metadata = _metadata(data, service.id);
                      final price = _periods(
                        service,
                        metadata,
                      ).first.priceCents;
                      return Card(
                        clipBehavior: Clip.antiAlias,
                        child: InkWell(
                          onTap: () => _details(data, service, metadata),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Expanded(
                                child: Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Hero(
                                      tag: 'service-${service.id}',
                                      child: _ServiceImage(
                                        repository: widget.repository,
                                        fileId:
                                            '${service.payload['image'] ?? metadata['image_file_id'] ?? ''}',
                                      ),
                                    ),
                                    if ((metadata['promotion_percent']
                                                as num? ??
                                            0) >
                                        0)
                                      Positioned(
                                        left: 12,
                                        top: 12,
                                        child: RacheyStatusPill(
                                          label:
                                              '-${(metadata['promotion_percent'] as num).round()}%',
                                          icon: Icons.local_offer_rounded,
                                          color: RacheyColors.promo,
                                        ),
                                      ),
                                    Positioned(
                                      right: 10,
                                      top: 10,
                                      child: Material(
                                        color: Theme.of(context).colorScheme.surface.withValues(alpha: .9),
                                        shape: const CircleBorder(),
                                        child: IconButton(
                                          tooltip: _isFavorite(data, service.id) ? 'Remover dos favoritos' : 'Adicionar aos favoritos',
                                          onPressed: () => _toggleFavorite(data, service),
                                          icon: Icon(
                                            _isFavorite(data, service.id) ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                                            color: _isFavorite(data, service.id) ? RacheyColors.promo : null,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(15),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${service.payload['name'] ?? 'Serviço'}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                        fontSize: 17,
                                      ),
                                    ),
                                    const SizedBox(height: 5),
                                    Text(
                                      '${service.payload['description'] ?? ''}',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: RacheyColors.gray,
                                      ),
                                    ),
                                    const SizedBox(height: 10),
                                    Text(
                                      'a partir de',
                                      style: Theme.of(
                                        context,
                                      ).textTheme.labelSmall,
                                    ),
                                    Text(
                                      _money(price),
                                      style: const TextStyle(
                                        color: RacheyColors.primary,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 19,
                                      ),
                                    ),
                                    const SizedBox(height: 12),
                                    SizedBox(
                                      width: double.infinity,
                                      child: FilledButton.icon(
                                        onPressed: () =>
                                            _details(data, service, metadata),
                                        style: FilledButton.styleFrom(
                                          minimumSize: const Size(0, 44),
                                        ),
                                        icon: const Icon(
                                          Icons.add_shopping_cart_rounded,
                                          size: 19,
                                        ),
                                        label: const Text('Ver planos'),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          );
        },
      ),
    ),
  );
}

class _CartPage extends StatefulWidget {
  const _CartPage({
    required this.repository,
    required this.lines,
    required this.onChanged,
  });

  final RacheyRepository repository;
  final List<_CartLine> lines;
  final VoidCallback onChanged;

  @override
  State<_CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<_CartPage> {
  final _coupon = TextEditingController();
  final _notes = TextEditingController();
  bool _checkingOut = false;
  bool _useCashback = false;
  bool _loadingCashback = true;
  int _cashbackBalance = 0;

  int get _subtotal => widget.lines.fold(
    0,
    (sum, line) => sum + line.period.priceCents * line.quantity,
  );
  int get _cashback => widget.lines.fold(0, (sum, line) {
    final percent =
        (line.metadata['cashback_percent'] as num?)?.toDouble() ?? 0;
    return sum +
        (line.period.priceCents * line.quantity * percent / 100).round();
  });
  int get _points => widget.lines.fold(
    0,
    (sum, line) =>
        sum +
        (((line.metadata['points'] as num?)?.round() ?? 0) * line.quantity),
  );
  int get _cashbackUse {
    if (!_useCashback || _subtotal <= 100) return 0;
    final maximum = _subtotal - 100;
    return _cashbackBalance < maximum ? _cashbackBalance : maximum;
  }

  @override
  void initState() {
    super.initState();
    _loadCashback();
  }

  Future<void> _loadCashback() async {
    try {
      final rows = await widget.repository.listModules(
        'loyalty_ledger',
        limit: 500,
      );
      final balance = rows
          .where(
            (row) => !const {'estornado', 'cancelado'}.contains(row['status']),
          )
          .fold<int>(
            0,
            (sum, row) => sum + ((row['amount_cents'] as num?)?.round() ?? 0),
          );
      if (mounted) {
        setState(() {
          _cashbackBalance = balance < 0 ? 0 : balance;
          _loadingCashback = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loadingCashback = false);
    }
  }

  @override
  void dispose() {
    _coupon.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _checkout() async {
    if (widget.lines.isEmpty || _checkingOut) return;
    setState(() => _checkingOut = true);
    try {
      final result = await widget.repository.action('checkout', {
        'coupon': _coupon.text.trim(),
        'use_cashback': _useCashback,
        'observacoes': _notes.text.trim(),
        'items': widget.lines
            .map(
              (line) => {
                'servico_id': line.service.id,
                'period_days': line.period.days,
                'quantidade': line.quantity,
              },
            )
            .toList(),
      });
      if (!mounted) return;
      if (result['waitlisted'] == true) {
        await showDialog<void>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            icon: const Icon(
              Icons.hourglass_top_rounded,
              color: RacheyColors.promo,
              size: 42,
            ),
            title: const Text('Lista de espera'),
            content: const Text(
              'Não há vagas suficientes agora. Sua solicitação entrou na fila e você será notificado quando surgir disponibilidade.',
            ),
            actions: [
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Entendi'),
              ),
            ],
          ),
        );
        if (mounted) Navigator.pop(context, true);
        return;
      }
      final paid = await Navigator.push<bool>(
        context,
        MaterialPageRoute<bool>(
          builder: (_) =>
              _PixPage(repository: widget.repository, checkout: result),
        ),
      );
      if (mounted && paid == true) Navigator.pop(context, true);
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted) setState(() => _checkingOut = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Carrinho')),
    body: widget.lines.isEmpty
        ? const Center(child: Text('Seu carrinho está vazio.'))
        : ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 190),
            children: [
              ...widget.lines.map(
                (line) => Card(
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 60,
                          height: 60,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: _ServiceImage(
                              repository: widget.repository,
                              fileId: '${line.service.payload['image'] ?? ''}',
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${line.service.payload['name']}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              Text(
                                '${line.period.label} • ${_money(line.period.priceCents)}',
                                style: const TextStyle(
                                  color: RacheyColors.gray,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Column(
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  visualDensity: VisualDensity.compact,
                                  onPressed: () => setState(() {
                                    if (line.quantity > 1) {
                                      line.quantity--;
                                    } else {
                                      widget.lines.remove(line);
                                    }
                                    widget.onChanged();
                                  }),
                                  icon: Icon(
                                    line.quantity == 1
                                        ? Icons.delete_outline
                                        : Icons.remove_circle_outline,
                                  ),
                                ),
                                Text(
                                  '${line.quantity}',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                IconButton(
                                  visualDensity: VisualDensity.compact,
                                  onPressed: line.quantity >= 20
                                      ? null
                                      : () => setState(() {
                                          line.quantity++;
                                          widget.onChanged();
                                        }),
                                  icon: const Icon(Icons.add_circle_outline),
                                ),
                              ],
                            ),
                            Text(
                              _money(line.period.priceCents * line.quantity),
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _coupon,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(
                  labelText: 'Cupom',
                  prefixIcon: Icon(Icons.sell_outlined),
                  helperText: 'O desconto é validado no servidor.',
                ),
              ),
              const SizedBox(height: 10),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                secondary: const Icon(Icons.savings_outlined),
                title: const Text('Usar cashback'),
                subtitle: Text(
                  _loadingCashback
                      ? 'Consultando saldo...'
                      : 'Disponível: ${_money(_cashbackBalance)}',
                ),
                value: _useCashback,
                onChanged: _loadingCashback || _cashbackBalance <= 0
                    ? null
                    : (value) => setState(() => _useCashback = value),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _notes,
                minLines: 2,
                maxLines: 5,
                decoration: const InputDecoration(
                  labelText: 'Observação (opcional)',
                ),
              ),
            ],
          ),
    bottomSheet: widget.lines.isEmpty
        ? null
        : SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                border: Border(
                  top: BorderSide(color: Theme.of(context).dividerColor),
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      const Text('Subtotal'),
                      const Spacer(),
                      Text(_money(_subtotal)),
                    ],
                  ),
                  if (_cashback > 0)
                    Row(
                      children: [
                        const Text(
                          'Cashback estimado',
                          style: TextStyle(color: RacheyColors.primary),
                        ),
                        const Spacer(),
                        Text(
                          _money(_cashback),
                          style: const TextStyle(color: RacheyColors.primary),
                        ),
                      ],
                    ),
                  if (_cashbackUse > 0)
                    Row(
                      children: [
                        const Text('Cashback utilizado'),
                        const Spacer(),
                        Text('- ${_money(_cashbackUse)}'),
                      ],
                    ),
                  if (_points > 0)
                    Row(
                      children: [
                        const Text('Pontos'),
                        const Spacer(),
                        Text('$_points'),
                      ],
                    ),
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: _checkingOut ? null : _checkout,
                    icon: const Icon(Icons.pix_rounded),
                    label: Text(
                      _checkingOut
                          ? 'Gerando Pix...'
                          : 'Ir para pagamento • ${_money(_subtotal - _cashbackUse)}',
                    ),
                  ),
                ],
              ),
            ),
          ),
  );
}

class _PixPage extends StatefulWidget {
  const _PixPage({required this.repository, required this.checkout});

  final RacheyRepository repository;
  final Map<String, dynamic> checkout;

  @override
  State<_PixPage> createState() => _PixPageState();
}

class _PixPageState extends State<_PixPage> {
  double? _progress;
  bool _sending = false;
  bool _checking = false;

  Future<void> _proof() async {
    final file = await NativeBridge.pickFile(
      mimeTypes: const ['image/*'],
    );
    if (file == null || !mounted) return;
    setState(() {
      _sending = true;
      _progress = 0;
    });
    try {
      final uploaded = await widget.repository.uploadFile(
        file: file,
        type: 'comprovante_pix',
        referenceId: '${widget.checkout[r'$id']}',
        onProgress: (value) {
          if (mounted) setState(() => _progress = value / 100);
        },
      );
      await widget.repository.action('submit_payment_proof', {
        'intent_id': widget.checkout['intent_id'] ?? widget.checkout[r'$id'],
        'file_id': uploaded.id,
      });
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(
            Icons.check_circle_rounded,
            color: RacheyColors.primary,
            size: 44,
          ),
          title: const Text('Pedido enviado'),
          content: const Text(
            'Pagamento e comprovante recebidos. Agora o pedido foi criado e entrou em análise.',
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Concluir'),
            ),
          ],
        ),
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted)
        setState(() {
          _sending = false;
          _progress = null;
        });
    }
  }

  Future<void> _verifyAutomaticPix() async {
    setState(() => _checking = true);
    try {
      final result = await widget.repository.action('check_automatic_pix', {
        'intent_id': widget.checkout['intent_id'] ?? widget.checkout[r'$id'],
      });
      if (!mounted) return;
      if (result['approved'] == true) {
        await showDialog<void>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            icon: const Icon(Icons.verified_rounded, color: RacheyColors.primary, size: 44),
            title: const Text('Pagamento confirmado'),
            content: const Text('O Mercado Pago confirmou seu Pix. Seu pedido já foi processado.'),
            actions: [FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Concluir'))],
          ),
        );
        if (mounted) Navigator.pop(context, true);
      } else {
        final status = '${result['status'] ?? 'pending'}';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(status == 'pending' ? 'Pagamento ainda pendente. Aguarde alguns segundos e tente novamente.' : 'Pagamento ainda não aprovado: $status')));
      }
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pix = widget.checkout['pix'] as Map?;
    final copy = '${pix?['copia_cola'] ?? ''}';
    final qr = '${pix?['qr_base64'] ?? ''}';
    final pixAvailable = copy.isNotEmpty || qr.isNotEmpty;
    final automatic = '${pix?['mode'] ?? pix?['provider'] ?? ''}' == 'mercado_pago';
    return Scaffold(
      appBar: AppBar(title: const Text('Pagamento Pix')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            '${widget.checkout['numero'] ?? 'Pagamento'}',
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20),
          ),
          const SizedBox(height: 8),
          Text(
            _money((widget.checkout['total_centavos'] as num?)?.round() ?? 0),
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 28,
              color: RacheyColors.primary,
            ),
          ),
          const SizedBox(height: 20),
          if (qr.isNotEmpty)
            Center(
              child: Container(
                width: 260,
                height: 260,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Image.memory(base64Decode(qr)),
              ),
            )
          else
            const Card(
              color: Color(0xFFFFE6D4),
              child: ListTile(
                leading: Icon(
                  Icons.warning_amber_rounded,
                  color: RacheyColors.promo,
                ),
                title: Text('Chave Pix ainda não configurada'),
                subtitle: Text(
                  'O pagamento não pode ser concluído sem uma chave Pix configurada. Nenhum pedido foi criado.',
                ),
              ),
            ),
          if (copy.isNotEmpty) ...[
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: copy));
                if (context.mounted)
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Pix Copia e Cola copiado.')),
                  );
              },
              icon: const Icon(Icons.copy_rounded),
              label: const Text('Copiar código Pix'),
            ),
          ],
          const SizedBox(height: 18),
          Text(
            automatic
                ? 'Este Pix foi gerado pelo Mercado Pago. Depois de pagar, toque em verificar pagamento; não é necessário enviar comprovante.'
                : 'O pedido só será criado e enviado à equipe depois que você pagar e anexar o comprovante.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: RacheyColors.gray),
          ),
          if (_progress != null) ...[
            const SizedBox(height: 16),
            LinearProgressIndicator(value: _progress),
            const SizedBox(height: 5),
            Text(
              'Enviando ${((_progress ?? 0) * 100).round()}%',
              textAlign: TextAlign.center,
            ),
          ],
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _sending || _checking || !pixAvailable ? null : (automatic ? _verifyAutomaticPix : _proof),
            icon: Icon(automatic ? Icons.verified_user_outlined : Icons.photo_library_outlined),
            label: Text(_checking ? 'Verificando...' : automatic ? 'Já paguei • verificar pagamento' : 'Enviar comprovante da galeria'),
          ),
          TextButton(
            onPressed: _sending ? null : () => Navigator.pop(context, false),
            child: const Text('Voltar sem criar o pedido'),
          ),
        ],
      ),
    );
  }
}

class _CatalogData {
  const _CatalogData({
    required this.services,
    required this.categories,
    required this.serviceMetadata,
    required this.categoryMetadata,
    required this.stockQuotes,
    required this.favorites,
  });

  final List<RacheyDocument> services;
  final List<RacheyDocument> categories;
  final List<Map<String, dynamic>> serviceMetadata;
  final List<Map<String, dynamic>> categoryMetadata;
  final List<Map<String, dynamic>> stockQuotes;
  final List<Map<String, dynamic>> favorites;
}

class _CartLine {
  _CartLine({
    required this.service,
    required this.metadata,
    required this.period,
    required this.quantity,
  });

  final RacheyDocument service;
  final Map<String, dynamic> metadata;
  final _Period period;
  int quantity;
}

class _Period {
  const _Period({
    required this.days,
    required this.label,
    required this.priceCents,
    this.effectiveDays,
    this.prorated = false,
    this.expiresAt,
    this.available,
  });

  final int days;
  final String label;
  final int priceCents;
  final int? effectiveDays;
  final bool prorated;
  final String? expiresAt;
  final int? available;
}

List<_Period> _periods(RacheyDocument service, Map<String, dynamic> metadata) {
  final base = _priceCents(service.payload);
  final raw = metadata['periods'] as List? ?? const [];
  final quoteRows = (metadata['stock_quotes'] as List? ?? const [])
      .whereType<Map>()
      .toList();
  Map? quoteFor(int days) {
    for (final quote in quoteRows) {
      if (((quote['days'] as num?)?.round() ?? -1) == days) return quote;
    }
    return null;
  }

  final result = raw.whereType<Map>().map((item) {
    final days = ((item['days'] as num?) ?? 30).round().clamp(1, 3650);
    final quote = quoteFor(days);
    final regularCents = ((item['price_cents'] as num?) ?? base).round().clamp(0, 100000000);
    final cents = ((quote?['price_cents'] as num?) ?? regularCents).round().clamp(0, 100000000);
    final effective = ((quote?['effective_days'] as num?) ?? days).round().clamp(1, 3650);
    final prorated = quote?['prorated'] == true;
    return _Period(
      days: days,
      label: '${quote?['label'] ?? item['label'] ?? '$days dias'}',
      priceCents: cents,
      effectiveDays: effective,
      prorated: prorated,
      expiresAt: quote?['expires_at']?.toString(),
      available: (quote?['available'] as num?)?.round(),
    );
  }).toList();
  if (result.isEmpty) {
    final days = switch ('${service.payload['periodicity'] ?? 'mensal'}') {
      'semanal' => 7,
      'quinzenal' => 15,
      'trimestral' => 90,
      'semestral' => 180,
      'anual' => 365,
      _ => 30,
    };
    final quote = quoteFor(days);
    result.add(_Period(
      days: days,
      label: '${quote?['label'] ?? '$days dias'}',
      priceCents: ((quote?['price_cents'] as num?) ?? base).round(),
      effectiveDays: ((quote?['effective_days'] as num?) ?? days).round(),
      prorated: quote?['prorated'] == true,
      expiresAt: quote?['expires_at']?.toString(),
      available: (quote?['available'] as num?)?.round(),
    ));
  }
  result.sort((a, b) => a.days.compareTo(b.days));
  return result;
}

class _ServiceHero extends StatelessWidget {
  const _ServiceHero({
    required this.repository,
    required this.service,
    required this.metadata,
  });

  final RacheyRepository repository;
  final RacheyDocument service;
  final Map<String, dynamic> metadata;

  @override
  Widget build(BuildContext context) {
    final banner = '${metadata['banner_file_id'] ?? ''}';
    final image =
        '${service.payload['image'] ?? metadata['image_file_id'] ?? ''}';
    return Hero(
      tag: 'service-${service.id}',
      child: SizedBox(
        height: 190,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: _ServiceImage(
            repository: repository,
            fileId: banner.isNotEmpty ? banner : image,
          ),
        ),
      ),
    );
  }
}

class _ServiceImage extends StatelessWidget {
  const _ServiceImage({required this.repository, required this.fileId});

  final RacheyRepository repository;
  final String fileId;

  @override
  Widget build(BuildContext context) {
    if (fileId.isEmpty) {
      return const ColoredBox(
        color: RacheyColors.mint,
        child: Center(
          child: Icon(
            Icons.subscriptions_rounded,
            size: 52,
            color: RacheyColors.primary,
          ),
        ),
      );
    }
    return FutureBuilder<Uint8List>(
      future: repository.imageFile(fileId, width: 1000, height: 700),
      builder: (_, snapshot) {
        if (snapshot.hasData)
          return Image.memory(snapshot.data!, fit: BoxFit.cover);
        if (snapshot.hasError) {
          return const ColoredBox(
            color: RacheyColors.mint,
            child: Center(
              child: Icon(
                Icons.broken_image_outlined,
                color: RacheyColors.primary,
              ),
            ),
          );
        }
        return const ColoredBox(
          color: RacheyColors.mint,
          child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
        );
      },
    );
  }
}

class _InfoChip extends StatelessWidget {
  const _InfoChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Chip(
    avatar: Icon(icon, size: 17, color: RacheyColors.primary),
    label: Text(label),
  );
}

class _CatalogSkeleton extends StatelessWidget {
  const _CatalogSkeleton();

  @override
  Widget build(BuildContext context) => _Shimmer(
    child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          height: 56,
          decoration: BoxDecoration(
            color: Colors.grey.withValues(alpha: .15),
            borderRadius: BorderRadius.circular(14),
          ),
        ),
        const SizedBox(height: 16),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: .7,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: List.generate(
            4,
            (_) => Container(
              decoration: BoxDecoration(
                color: Colors.grey.withValues(alpha: .13),
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
        ),
      ],
    ),
  );
}

class _Shimmer extends StatefulWidget {
  const _Shimmer({required this.child});

  final Widget child;

  @override
  State<_Shimmer> createState() => _ShimmerState();
}

class _ShimmerState extends State<_Shimmer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1350),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _controller,
    child: widget.child,
    builder: (context, child) {
      final offset = (_controller.value * 3) - 1.5;
      return ShaderMask(
        blendMode: BlendMode.srcATop,
        shaderCallback: (bounds) => LinearGradient(
          begin: Alignment(offset - 1, -.2),
          end: Alignment(offset + 1, .2),
          colors: const [
            Color(0xFFBFC6CC),
            Color(0xFFF7F9F8),
            Color(0xFFBFC6CC),
          ],
          stops: const [.2, .5, .8],
        ).createShader(bounds),
        child: child,
      );
    },
  );
}

int _priceCents(Map<String, dynamic> payload) =>
    ((payload['priceCents'] as num?) ??
            (((payload['price'] as num?) ?? 0) * 100))
        .round();

String _money(int cents) =>
    'R\$ ${(cents / 100).toStringAsFixed(2).replaceAll('.', ',')}';

String _serviceType(String value) => switch (value) {
  'full_account' => 'Conta inteira',
  'profile' => 'Perfil',
  'shared_screen' => 'Tela compartilhada',
  'license' => 'Licença',
  'code' => 'Código',
  _ => 'Assinatura',
};

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
