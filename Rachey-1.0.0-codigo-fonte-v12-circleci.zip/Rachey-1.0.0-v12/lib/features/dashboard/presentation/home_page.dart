import 'package:flutter/material.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/widgets/rachey_ui.dart';
import 'package:rachey/data/models/rachey_document.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/features/orders/presentation/orders_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({
    required this.name,
    required this.userId,
    required this.repository,
    required this.onNavigate,
    super.key,
  });

  final String name;
  final String userId;
  final RacheyRepository repository;
  final ValueChanged<int> onNavigate;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<_HomeData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_HomeData> _load() async {
    final values = await Future.wait<dynamic>([
      widget.repository.list(
        type: 'subscription',
        ownerId: widget.userId,
        limit: 200,
      ),
      widget.repository
          .action('app_settings')
          .catchError((_) => <String, dynamic>{}),
      widget.repository.list(type: 'service', limit: 200),
      widget.repository.listModules('service_meta', limit: 300),
    ]);
    final subscriptions =
        (values[0] as List<RacheyDocument>)
            .where((item) => item.status != 'cancelada')
            .toList()
          ..sort((a, b) => _expiration(a).compareTo(_expiration(b)));
    final services =
        (values[2] as List<RacheyDocument>)
            .where((item) => item.payload['active'] != false)
            .toList()
          ..sort((a, b) {
            final featuredA = a.payload['featured'] == true ? 0 : 1;
            final featuredB = b.payload['featured'] == true ? 0 : 1;
            if (featuredA != featuredB) return featuredA.compareTo(featuredB);
            return ((a.payload['order'] as num?) ?? 0).compareTo(
              (b.payload['order'] as num?) ?? 0,
            );
          });
    return _HomeData(
      subscriptions: subscriptions,
      settings: Map<String, dynamic>.from(values[1] as Map),
      services: services,
      serviceMetadata: (values[3] as List<Map<String, dynamic>>),
    );
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  void _orders() => Navigator.push<void>(
    context,
    MaterialPageRoute<void>(
      builder: (_) =>
          OrdersPage(repository: widget.repository, userId: widget.userId),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final firstName = widget.name.trim().isEmpty
        ? 'cliente'
        : widget.name.trim().split(RegExp(r'\s+')).first;
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 72,
        titleSpacing: 16,
        title: Row(
          children: [
            const RacheyBrandMark(size: 42),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Olá, $firstName',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    'O que você quer aproveitar hoje?',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          const RacheyThemeButton(),
          const SizedBox(width: 4),
          IconButton.filledTonal(
            tooltip: 'Grupo e avisos',
            onPressed: () => widget.onNavigate(2),
            icon: const Icon(Icons.groups_outlined, size: 21),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<_HomeData>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const _HomeSkeleton();
            }
            if (snapshot.hasError) {
              return _HomeError(error: snapshot.error!, onRetry: _refresh);
            }
            final data = snapshot.data!;
            final general = Map<String, dynamic>.from(
              data.settings['general'] as Map? ?? const {},
            );
            return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 112),
              children: [
                _SalesHero(
                  repository: widget.repository,
                  bannerId: '${general['banner_file_id'] ?? ''}',
                  onExplore: () => widget.onNavigate(1),
                ),
                const SizedBox(height: 22),
                _QuickActions(
                  onCatalog: () => widget.onNavigate(1),
                  onGroup: () => widget.onNavigate(2),
                  onOrders: _orders,
                  onSupport: () => widget.onNavigate(4),
                ),
                const SizedBox(height: 24),
                RacheySectionTitle(
                  title: 'Escolhidos para você',
                  subtitle: 'Planos disponíveis no catálogo agora',
                  action: TextButton(
                    onPressed: () => widget.onNavigate(1),
                    child: const Text('Ver todos'),
                  ),
                ),
                const SizedBox(height: 12),
                if (data.services.isEmpty)
                  _NoProducts(onTap: () => widget.onNavigate(1))
                else
                  SizedBox(
                    height: 252,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: data.services.take(8).length,
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemBuilder: (_, index) {
                        final service = data.services[index];
                        return _ProductCard(
                          repository: widget.repository,
                          service: service,
                          metadata: data.metaFor(service.id),
                          onTap: () => widget.onNavigate(1),
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 26),
                RacheySectionTitle(
                  title: 'Suas assinaturas',
                  subtitle: 'Acompanhe acesso, vencimento e renovação',
                  action: TextButton(
                    onPressed: () => widget.onNavigate(3),
                    child: const Text('Gerenciar'),
                  ),
                ),
                const SizedBox(height: 12),
                _SubscriptionOverview(
                  subscription: data.subscriptions.firstOrNull,
                  onTap: () => widget.onNavigate(3),
                  onShop: () => widget.onNavigate(1),
                ),
                const SizedBox(height: 24),
                const RacheySectionTitle(
                  title: 'Comprar ficou simples',
                  subtitle: 'Da escolha do plano até a liberação do acesso',
                ),
                const SizedBox(height: 12),
                const _PurchaseBenefits(),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _SalesHero extends StatelessWidget {
  const _SalesHero({
    required this.repository,
    required this.bannerId,
    required this.onExplore,
  });

  final RacheyRepository repository;
  final String bannerId;
  final VoidCallback onExplore;

  @override
  Widget build(BuildContext context) => SizedBox(
    height: 226,
    child: ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (bannerId.isNotEmpty)
            RacheyRemoteImage(
              repository: repository,
              fileId: bannerId,
              width: 1400,
              height: 700,
            )
          else
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [RacheyColors.navy, RacheyColors.darkGreen],
                ),
              ),
            ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.centerRight,
                end: Alignment.centerLeft,
                colors: [Colors.black12, Colors.black87],
              ),
            ),
          ),
          Positioned(
            right: -22,
            top: -30,
            child: Container(
              width: 150,
              height: 150,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: RacheyColors.primary.withValues(alpha: .30),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const RacheyStatusPill(
                  label: 'Assinaturas digitais',
                  icon: Icons.bolt_rounded,
                  color: Color(0xFF8BE8BE),
                ),
                const Spacer(),
                const Text(
                  'Mais entretenimento.\nMenos complicação.',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 27,
                    height: 1.03,
                    letterSpacing: -.8,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Escolha seu plano e acompanhe tudo pelo app.',
                  style: TextStyle(color: Colors.white70, fontSize: 13),
                ),
                const SizedBox(height: 14),
                FilledButton.icon(
                  onPressed: onExplore,
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: RacheyColors.darkGreen,
                    minimumSize: const Size(0, 44),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                  ),
                  icon: const Icon(Icons.shopping_bag_outlined, size: 19),
                  label: const Text('Explorar planos'),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

class _QuickActions extends StatelessWidget {
  const _QuickActions({
    required this.onCatalog,
    required this.onGroup,
    required this.onOrders,
    required this.onSupport,
  });

  final VoidCallback onCatalog;
  final VoidCallback onGroup;
  final VoidCallback onOrders;
  final VoidCallback onSupport;

  @override
  Widget build(BuildContext context) => Row(
    children: [
      _QuickAction(
        icon: Icons.storefront_rounded,
        label: 'Catálogo',
        onTap: onCatalog,
      ),
      _QuickAction(icon: Icons.groups_rounded, label: 'Grupo', onTap: onGroup),
      _QuickAction(
        icon: Icons.receipt_long_rounded,
        label: 'Pedidos',
        onTap: onOrders,
      ),
      _QuickAction(
        icon: Icons.support_agent_rounded,
        label: 'Suporte',
        onTap: onSupport,
      ),
    ],
  );
}

class _QuickAction extends StatelessWidget {
  const _QuickAction({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Expanded(
    child: Semantics(
      button: true,
      label: label,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Icon(icon, color: Theme.of(context).colorScheme.primary),
              ),
              const SizedBox(height: 7),
              Text(
                label,
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

class _ProductCard extends StatelessWidget {
  const _ProductCard({
    required this.repository,
    required this.service,
    required this.metadata,
    required this.onTap,
  });

  final RacheyRepository repository;
  final RacheyDocument service;
  final Map<String, dynamic> metadata;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final imageId =
        '${service.payload['image'] ?? metadata['image_file_id'] ?? ''}';
    final promotion = (metadata['promotion_percent'] as num?)?.round() ?? 0;
    final price = _startingPrice(service, metadata);
    return SizedBox(
      width: 184,
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    RacheyRemoteImage(
                      repository: repository,
                      fileId: imageId,
                      width: 700,
                      height: 500,
                    ),
                    if (promotion > 0)
                      Positioned(
                        left: 10,
                        top: 10,
                        child: RacheyStatusPill(
                          label: '-$promotion%',
                          icon: Icons.local_offer_rounded,
                          color: RacheyColors.promo,
                        ),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(13, 12, 13, 13),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${service.payload['name'] ?? 'Serviço'}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'A partir de ${_money(price)}',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SubscriptionOverview extends StatelessWidget {
  const _SubscriptionOverview({
    required this.subscription,
    required this.onTap,
    required this.onShop,
  });

  final RacheyDocument? subscription;
  final VoidCallback onTap;
  final VoidCallback onShop;

  @override
  Widget build(BuildContext context) {
    final item = subscription;
    if (item == null) {
      return Card(
        child: InkWell(
          onTap: onShop,
          borderRadius: BorderRadius.circular(24),
          child: const Padding(
            padding: EdgeInsets.all(20),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 25,
                  backgroundColor: RacheyColors.mint,
                  child: Icon(Icons.add_rounded, color: RacheyColors.primary),
                ),
                SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Encontre sua primeira assinatura',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'Compare os planos e escolha o ideal para você.',
                        style: TextStyle(color: RacheyColors.gray),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.arrow_forward_rounded),
              ],
            ),
          ),
        ),
      );
    }
    final due = _expiration(item);
    final days = due.difference(DateTime.now()).inDays;
    final urgent = days <= 2;
    final color = days < 0
        ? Theme.of(context).colorScheme.error
        : urgent
        ? RacheyColors.promo
        : RacheyColors.primary;
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: .13),
                  borderRadius: BorderRadius.circular(19),
                ),
                child: Icon(Icons.subscriptions_rounded, color: color),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${item.payload['serviceName'] ?? 'Assinatura'}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      days < 0
                          ? 'Venceu em ${_formatDate(due)}'
                          : 'Próximo vencimento em ${_formatDate(due)}',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              RacheyStatusPill(
                label: days < 0 ? '${days.abs()}d vencida' : '$days dias',
                color: color,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PurchaseBenefits extends StatelessWidget {
  const _PurchaseBenefits();

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        children: const [
          _Benefit(
            icon: Icons.search_rounded,
            title: '1. Escolha o plano',
            text: 'Veja períodos, benefícios e valor final antes de comprar.',
          ),
          Divider(height: 26),
          _Benefit(
            icon: Icons.pix_rounded,
            title: '2. Pague com Pix',
            text: 'Use o QR Code ou Pix Copia e Cola e envie o comprovante.',
          ),
          Divider(height: 26),
          _Benefit(
            icon: Icons.lock_open_rounded,
            title: '3. Receba seu acesso',
            text: 'Acompanhe o pedido e abra as credenciais pelo Cofre.',
          ),
        ],
      ),
    ),
  );
}

class _Benefit extends StatelessWidget {
  const _Benefit({required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: RacheyColors.mint,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Icon(icon, color: RacheyColors.darkGreen, size: 21),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text(
              text,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                height: 1.3,
              ),
            ),
          ],
        ),
      ),
    ],
  );
}

class _NoProducts extends StatelessWidget {
  const _NoProducts({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          const Icon(Icons.inventory_2_outlined, color: RacheyColors.gray),
          const SizedBox(width: 12),
          const Expanded(
            child: Text('O catálogo ainda não possui serviços ativos.'),
          ),
          IconButton(onPressed: onTap, icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
    ),
  );
}

class _HomeSkeleton extends StatelessWidget {
  const _HomeSkeleton();

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        height: 226,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(28),
        ),
      ),
      const SizedBox(height: 22),
      const LinearProgressIndicator(minHeight: 3),
    ],
  );
}

class _HomeError extends StatelessWidget {
  const _HomeError({required this.error, required this.onRetry});
  final Object error;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) => ListView(
    physics: const AlwaysScrollableScrollPhysics(),
    children: [
      const SizedBox(height: 140),
      Icon(
        Icons.cloud_off_outlined,
        size: 56,
        color: Theme.of(context).colorScheme.onSurfaceVariant,
      ),
      const SizedBox(height: 12),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30),
        child: Text(_friendly(error), textAlign: TextAlign.center),
      ),
      const SizedBox(height: 14),
      Center(
        child: OutlinedButton.icon(
          onPressed: onRetry,
          icon: const Icon(Icons.refresh_rounded),
          label: const Text('Tentar novamente'),
        ),
      ),
    ],
  );
}

class _HomeData {
  const _HomeData({
    required this.subscriptions,
    required this.settings,
    required this.services,
    required this.serviceMetadata,
  });

  final List<RacheyDocument> subscriptions;
  final Map<String, dynamic> settings;
  final List<RacheyDocument> services;
  final List<Map<String, dynamic>> serviceMetadata;

  Map<String, dynamic> metaFor(String serviceId) {
    for (final row in serviceMetadata) {
      if ('${row['reference_id'] ?? ''}' == serviceId) {
        return Map<String, dynamic>.from(row['data'] as Map? ?? const {});
      }
    }
    return const {};
  }
}

int _startingPrice(RacheyDocument service, Map<String, dynamic> metadata) {
  final periods = (metadata['periods'] as List? ?? const [])
      .whereType<Map>()
      .map((item) => (item['price_cents'] as num?)?.round() ?? 0)
      .where((value) => value > 0)
      .toList();
  if (periods.isNotEmpty) return periods.reduce((a, b) => a < b ? a : b);
  return ((service.payload['priceCents'] as num?) ?? 0).round();
}

DateTime _expiration(RacheyDocument item) =>
    DateTime.tryParse('${item.payload['expiresAt'] ?? ''}')?.toLocal() ??
    DateTime(2100);

String _formatDate(DateTime date) =>
    '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}';

String _money(int cents) =>
    'R\$ ${(cents / 100).toStringAsFixed(2).replaceAll('.', ',')}';

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
