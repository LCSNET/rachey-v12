import 'package:flutter/material.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/data/models/rachey_document.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/features/catalog/presentation/catalog_page.dart';
import 'package:rachey/features/support/presentation/support_page.dart';

class OrdersPage extends StatefulWidget {
  const OrdersPage({required this.repository, required this.userId, super.key});

  final RacheyRepository repository;
  final String userId;

  @override
  State<OrdersPage> createState() => _OrdersPageState();
}

class _OrdersPageState extends State<OrdersPage> {
  late Future<List<RacheyDocument>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<RacheyDocument>> _load() async {
    final rows = await widget.repository.list(
      type: 'order',
      ownerId: widget.userId,
    );
    rows.sort(
      (a, b) => (b.createdAt ?? DateTime(1970)).compareTo(
        a.createdAt ?? DateTime(1970),
      ),
    );
    return rows;
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Meus pedidos')),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<RacheyDocument>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return ListView(
              children: [
                const SizedBox(height: 150),
                const Icon(
                  Icons.cloud_off_outlined,
                  size: 54,
                  color: RacheyColors.gray,
                ),
                const SizedBox(height: 12),
                Center(child: Text(_friendly(snapshot.error!))),
              ],
            );
          }
          final items = snapshot.data ?? const [];
          if (items.isEmpty) {
            return ListView(
              children: const [
                SizedBox(height: 160),
                Icon(
                  Icons.receipt_long_outlined,
                  size: 54,
                  color: RacheyColors.gray,
                ),
                SizedBox(height: 12),
                Center(child: Text('Você ainda não fez nenhum pedido.')),
              ],
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 9),
            itemBuilder: (_, index) {
              final order = items[index];
              final payload = order.payload;
              final cents = (payload['total_centavos'] as num?)?.round() ?? 0;
              final color = _statusColor(order.status);
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () async {
                    await Navigator.push<void>(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => _OrderDetailsPage(
                          repository: widget.repository,
                          userId: widget.userId,
                          order: order,
                        ),
                      ),
                    );
                    await _refresh();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        CircleAvatar(
                          backgroundColor: color.withValues(alpha: .13),
                          child: Icon(_statusIcon(order.status), color: color),
                        ),
                        const SizedBox(width: 13),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${payload['numero'] ?? 'Pedido'}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${_status(order.status)} • ${_date(order.createdAt?.toIso8601String() ?? '')}',
                                style: const TextStyle(
                                  color: RacheyColors.gray,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              _money(cents),
                              style: const TextStyle(
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 5),
                            const Icon(Icons.chevron_right),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class _OrderDetailsPage extends StatefulWidget {
  const _OrderDetailsPage({
    required this.repository,
    required this.userId,
    required this.order,
  });

  final RacheyRepository repository;
  final String userId;
  final RacheyDocument order;

  @override
  State<_OrderDetailsPage> createState() => _OrderDetailsPageState();
}

class _OrderDetailsPageState extends State<_OrderDetailsPage> {
  late Future<_OrderData> _future;
  bool _uploading = false;
  double? _progress;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_OrderData> _load() async {
    final results = await Future.wait<dynamic>([
      widget.repository.list(
        type: 'order_item',
        ownerId: widget.userId,
        limit: 500,
      ),
      widget.repository.listModules(
        'order_timeline',
        referenceId: widget.order.id,
        limit: 100,
      ),
    ]);
    final items = (results[0] as List<RacheyDocument>)
        .where((item) => item.payload['pedido_id'] == widget.order.id)
        .toList();
    final timeline = results[1] as List<Map<String, dynamic>>
      ..sort(
        (a, b) => ((a['sort_order'] as num?) ?? 0).compareTo(
          (b['sort_order'] as num?) ?? 0,
        ),
      );
    return _OrderData(items: items, timeline: timeline);
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Future<void> _proof() async {
    final file = await NativeBridge.pickFile(
      mimeTypes: const ['image/*', 'application/pdf'],
    );
    if (file == null || !mounted) return;
    setState(() {
      _uploading = true;
      _progress = 0;
    });
    try {
      final uploaded = await widget.repository.uploadFile(
        file: file,
        type: 'comprovante_pix',
        referenceId: widget.order.id,
        onProgress: (value) {
          if (mounted) setState(() => _progress = value / 100);
        },
      );
      await widget.repository.action('submit_payment_proof', {
        'order_id': widget.order.id,
        'file_id': uploaded.id,
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Comprovante enviado para análise.')),
        );
        await _refresh();
      }
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted)
        setState(() {
          _uploading = false;
          _progress = null;
        });
    }
  }

  @override
  Widget build(BuildContext context) {
    final payload = widget.order.payload;
    final canSendProof = const {
      'aguardando_pagamento',
      'pagamento_recusado',
    }.contains(widget.order.status);
    return Scaffold(
      appBar: AppBar(title: Text('${payload['numero'] ?? 'Pedido'}')),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<_OrderData>(
          future: _future,
          builder: (_, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return ListView(
                children: [
                  const SizedBox(height: 150),
                  Center(child: Text(_friendly(snapshot.error!))),
                ],
              );
            }
            final data = snapshot.data!;
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [RacheyColors.navy, RacheyColors.darkGreen],
                    ),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _status(widget.order.status),
                        style: const TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        _money(
                          (payload['total_centavos'] as num?)?.round() ?? 0,
                        ),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 27,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        'Pagamento: ${payload['forma_pagamento'] ?? 'Pix'}',
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ],
                  ),
                ),
                if ('${payload['observacoes_admin'] ?? ''}'.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Card(
                    color: Theme.of(context).colorScheme.errorContainer,
                    child: ListTile(
                      leading: Icon(
                        Icons.info_outline,
                        color: Theme.of(context).colorScheme.error,
                      ),
                      title: const Text('Observação da análise'),
                      subtitle: Text('${payload['observacoes_admin']}'),
                    ),
                  ),
                ],
                const SizedBox(height: 20),
                const Text(
                  'Itens',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
                ),
                const SizedBox(height: 8),
                if (data.items.isEmpty)
                  const Card(
                    child: ListTile(
                      title: Text('Os itens estão sendo processados.'),
                    ),
                  )
                else
                  ...data.items.map((item) {
                    final p = item.payload;
                    return Card(
                      child: ListTile(
                        leading: const CircleAvatar(
                          child: Icon(Icons.subscriptions_outlined),
                        ),
                        title: Text('${p['nome_servico'] ?? 'Serviço'}'),
                        subtitle: Text(
                          '${p['quantidade'] ?? 1} × ${_money((p['preco_unitario_centavos'] as num?)?.round() ?? 0)}${'${p['observacoes'] ?? ''}'.isNotEmpty ? ' • ${p['observacoes']}' : ''}',
                        ),
                      ),
                    );
                  }),
                const SizedBox(height: 20),
                const Text(
                  'Timeline',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
                ),
                const SizedBox(height: 8),
                if (data.timeline.isEmpty)
                  const Card(
                    child: ListTile(
                      leading: Icon(Icons.schedule_outlined),
                      title: Text('Aguardando atualização do pedido.'),
                    ),
                  )
                else
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        children: data.timeline.indexed.map((entry) {
                          final index = entry.$1;
                          final row = entry.$2;
                          final detail = row['data'] as Map? ?? const {};
                          return IntrinsicHeight(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  children: [
                                    const CircleAvatar(
                                      radius: 10,
                                      backgroundColor: RacheyColors.primary,
                                      child: Icon(
                                        Icons.check,
                                        size: 13,
                                        color: Colors.white,
                                      ),
                                    ),
                                    if (index != data.timeline.length - 1)
                                      Expanded(
                                        child: Container(
                                          width: 2,
                                          color: RacheyColors.mint,
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.only(bottom: 20),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          '${row['title'] ?? 'Atualização'}',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        Text(
                                          _date(
                                            '${detail['at'] ?? row[r'$createdAt'] ?? ''}',
                                          ),
                                          style: const TextStyle(
                                            color: RacheyColors.gray,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                if (_progress != null) ...[
                  const SizedBox(height: 16),
                  LinearProgressIndicator(value: _progress),
                  const SizedBox(height: 6),
                  Text(
                    'Enviando ${((_progress ?? 0) * 100).round()}%',
                    textAlign: TextAlign.center,
                  ),
                ],
                if (data.items.isNotEmpty) ...[
                  const SizedBox(height: 18),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.push<void>(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => CatalogPage(repository: widget.repository, userId: widget.userId),
                      ),
                    ),
                    icon: const Icon(Icons.replay_rounded),
                    label: const Text('Comprar novamente'),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.push<void>(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => SupportPage(
                          repository: widget.repository,
                          userId: widget.userId,
                          orderId: widget.order.id,
                        ),
                      ),
                    ),
                    icon: const Icon(Icons.support_agent_outlined),
                    label: const Text('Suporte deste pedido'),
                  ),
                ],
                if (canSendProof) ...[
                  const SizedBox(height: 10),
                  FilledButton.icon(
                    onPressed: _uploading ? null : _proof,
                    icon: const Icon(Icons.upload_file_rounded),
                    label: Text(
                      widget.order.status == 'pagamento_recusado'
                          ? 'Reenviar comprovante'
                          : 'Enviar comprovante',
                    ),
                  ),
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}

class _OrderData {
  const _OrderData({required this.items, required this.timeline});
  final List<RacheyDocument> items;
  final List<Map<String, dynamic>> timeline;
}

Color _statusColor(String value) => switch (value) {
  'concluido' || 'aprovado' => RacheyColors.primary,
  'pagamento_recusado' || 'cancelado' => Colors.red,
  'aguardando_pagamento' => RacheyColors.promo,
  _ => Colors.blue,
};

IconData _statusIcon(String value) => switch (value) {
  'concluido' || 'aprovado' => Icons.check_circle_outline,
  'pagamento_recusado' || 'cancelado' => Icons.error_outline,
  'aguardando_pagamento' => Icons.pix_outlined,
  'pagamento_enviado' => Icons.upload_file_outlined,
  _ => Icons.pending_actions_outlined,
};

String _money(int cents) =>
    'R\$ ${(cents / 100).toStringAsFixed(2).replaceAll('.', ',')}';

String _status(String value) => switch (value) {
  'aguardando_pagamento' => 'Aguardando pagamento',
  'pagamento_enviado' => 'Pagamento enviado',
  'pagamento_recusado' => 'Pagamento não aprovado',
  'em_analise' => 'Em análise',
  'aprovado' => 'Aprovado',
  'em_processamento' => 'Preparando acesso',
  'concluido' => 'Concluído',
  'cancelado' => 'Cancelado',
  'estornado' => 'Estornado',
  _ => value.isEmpty ? 'Sem status' : value.replaceAll('_', ' '),
};

String _date(String raw) {
  final date = DateTime.tryParse(raw)?.toLocal();
  if (date == null) return 'data não informada';
  return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
}

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
