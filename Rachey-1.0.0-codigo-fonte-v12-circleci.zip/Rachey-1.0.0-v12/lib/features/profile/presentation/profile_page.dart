import 'dart:typed_data';

import 'package:appwrite/models.dart' as models;
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rachey/core/config/app_config.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/settings/app_preferences.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/widgets/rachey_ui.dart';
import 'package:rachey/data/models/rachey_document.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/features/auth/presentation/auth_cubit.dart';
import 'package:rachey/features/orders/presentation/orders_page.dart';
import 'package:rachey/features/profile/presentation/vault_page.dart';
import 'package:url_launcher/url_launcher.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({
    required this.repository,
    required this.userId,
    required this.preferences,
    super.key,
  });

  final RacheyRepository repository;
  final String userId;
  final AppPreferences preferences;

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  Future<_ProfileSnapshot>? _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_ProfileSnapshot> _load() async {
    final results = await Future.wait<dynamic>([
      widget.repository.list(type: 'profile', ownerId: widget.userId),
      widget.repository.listModules('profile_meta'),
    ]);
    final profiles = results[0] as List<RacheyDocument>;
    final metadata = results[1] as List<Map<String, dynamic>>;
    return _ProfileSnapshot(
      profile: profiles.isEmpty ? null : profiles.first,
      metadata: metadata.isEmpty ? null : metadata.first,
    );
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthCubit>().state;
    final signed = auth is AuthSignedIn ? auth : null;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Minha conta'),
        actions: const [RacheyThemeButton(), SizedBox(width: 6)],
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: FutureBuilder<_ProfileSnapshot>(
          future: _future,
          builder: (_, snapshot) {
            final data = snapshot.data;
            final base = data?.profile?.payload ?? const <String, dynamic>{};
            final meta = data?.metadata?['data'] as Map? ?? const {};
            final name = '${base['nome'] ?? signed?.name ?? 'Cliente'}';
            final photoId = '${base['foto_id'] ?? ''}';
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (snapshot.connectionState == ConnectionState.waiting)
                  const LinearProgressIndicator(minHeight: 2),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Row(
                      children: [
                        _ProfilePhoto(
                          repository: widget.repository,
                          fileId: photoId,
                          fallback: name,
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 19,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                signed?.email ?? '${base['email'] ?? ''}',
                                style: const TextStyle(
                                  color: RacheyColors.gray,
                                ),
                              ),
                              if ('${meta['city'] ?? ''}'.isNotEmpty)
                                Text(
                                  '${meta['city']}',
                                  style: const TextStyle(
                                    color: RacheyColors.gray,
                                  ),
                                ),
                            ],
                          ),
                        ),
                        IconButton(
                          tooltip: 'Editar perfil',
                          onPressed: signed == null
                              ? null
                              : () async {
                                  await Navigator.push<void>(
                                    context,
                                    MaterialPageRoute<void>(
                                      builder: (_) => _EditProfilePage(
                                        repository: widget.repository,
                                        user: signed,
                                        snapshot: data,
                                      ),
                                    ),
                                  );
                                  await _refresh();
                                },
                          icon: const Icon(Icons.edit_outlined),
                        ),
                      ],
                    ),
                  ),
                ),
                if (signed != null && !signed.emailVerified) ...[
                  const SizedBox(height: 10),
                  Card(
                    color: RacheyColors.promo.withValues(alpha: .12),
                    child: ListTile(
                      leading: const Icon(
                        Icons.mark_email_unread_outlined,
                        color: RacheyColors.promo,
                      ),
                      title: const Text('E-mail ainda não verificado'),
                      subtitle: const Text(
                        'Confirme seu endereço para reforçar a segurança da conta.',
                      ),
                      trailing: TextButton(
                        onPressed: () async {
                          try {
                            await context.read<AuthCubit>().sendVerification();
                            if (context.mounted)
                              _toast(context, 'E-mail de verificação enviado.');
                          } catch (error) {
                            if (context.mounted)
                              _toast(context, _friendly(error));
                          }
                        },
                        child: const Text('Enviar'),
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 12),
                Card(
                  child: Column(
                    children: [
                      _MenuTile(
                        icon: Icons.receipt_long_outlined,
                        title: 'Meus pedidos',
                        subtitle: 'Pagamento, comprovante e timeline',
                        onTap: () => Navigator.push<void>(
                          context,
                          MaterialPageRoute<void>(
                            builder: (_) => OrdersPage(
                              repository: widget.repository,
                              userId: widget.userId,
                            ),
                          ),
                        ),
                      ),
                      const Divider(height: 1),
                      _MenuTile(
                        icon: Icons.lock_outline_rounded,
                        title: 'Cofre de acessos',
                        subtitle: 'Credenciais liberadas e protegidas',
                        onTap: () => Navigator.push<void>(
                          context,
                          MaterialPageRoute<void>(
                            builder: (_) =>
                                VaultPage(repository: widget.repository),
                          ),
                        ),
                      ),
                      const Divider(height: 1),
                      _MenuTile(
                        icon: Icons.help_outline_rounded,
                        title: 'Central de ajuda',
                        subtitle: 'FAQ, WhatsApp, política e termos',
                        onTap: () => Navigator.push<void>(
                          context,
                          MaterialPageRoute<void>(
                            builder: (_) =>
                                _HelpPage(repository: widget.repository),
                          ),
                        ),
                      ),
                      const Divider(height: 1),
                      _MenuTile(
                        icon: Icons.workspace_premium_outlined,
                        title: 'Benefícios e fila de espera',
                        subtitle: 'Cashback, pontos e solicitações de vaga',
                        onTap: () => Navigator.push<void>(
                          context,
                          MaterialPageRoute<void>(
                            builder: (_) =>
                                _BenefitsPage(repository: widget.repository),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                Card(
                  child: Column(
                    children: [
                      _MenuTile(
                        icon: Icons.security_outlined,
                        title: 'Segurança',
                        subtitle: 'PIN, biometria e sessões ativas',
                        onTap: () => Navigator.push<void>(
                          context,
                          MaterialPageRoute<void>(
                            builder: (_) =>
                                _SecurityPage(preferences: widget.preferences),
                          ),
                        ),
                      ),
                      const Divider(height: 1),
                      _MenuTile(
                        icon: Icons.tune_rounded,
                        title: 'Preferências',
                        subtitle: 'Tema, idioma, notificações e sincronização',
                        onTap: () => Navigator.push<void>(
                          context,
                          MaterialPageRoute<void>(
                            builder: (_) => _SettingsPage(
                              repository: widget.repository,
                              preferences: widget.preferences,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                OutlinedButton.icon(
                  onPressed: () => context.read<AuthCubit>().logout(),
                  icon: const Icon(Icons.logout),
                  label: const Text('Sair da conta'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _ProfileSnapshot {
  const _ProfileSnapshot({required this.profile, required this.metadata});

  final RacheyDocument? profile;
  final Map<String, dynamic>? metadata;
}

class _EditProfilePage extends StatefulWidget {
  const _EditProfilePage({
    required this.repository,
    required this.user,
    required this.snapshot,
  });

  final RacheyRepository repository;
  final AuthSignedIn user;
  final _ProfileSnapshot? snapshot;

  @override
  State<_EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<_EditProfilePage> {
  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _username;
  late final TextEditingController _whatsApp;
  late final TextEditingController _city;
  late final TextEditingController _birthday;
  late final TextEditingController _cpf;
  String _groupIdentityMode = 'username';
  String? _photoId;
  double? _uploadProgress;
  bool _saving = false;

  Map<String, dynamic> get _base =>
      widget.snapshot?.profile?.payload ?? const <String, dynamic>{};
  Map<String, dynamic> get _meta => Map<String, dynamic>.from(
    widget.snapshot?.metadata?['data'] as Map? ?? const {},
  );

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: '${_base['nome'] ?? widget.user.name}');
    _phone = TextEditingController(text: '${_base['telefone'] ?? ''}');
    _username = TextEditingController(text: '${_meta['username'] ?? ''}');
    _groupIdentityMode = '${_meta['group_identity_mode'] ?? (_meta['username'] != null ? 'username' : 'phone')}';
    _whatsApp = TextEditingController(text: '${_meta['whatsapp'] ?? ''}');
    _city = TextEditingController(text: '${_meta['city'] ?? ''}');
    _birthday = TextEditingController(text: '${_meta['birthday'] ?? ''}');
    _cpf = TextEditingController();
    _photoId = '${_base['foto_id'] ?? ''}';
  }

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _username.dispose();
    _whatsApp.dispose();
    _city.dispose();
    _birthday.dispose();
    _cpf.dispose();
    super.dispose();
  }

  Future<void> _pickPhoto() async {
    final file = await NativeBridge.pickFile(mimeTypes: const ['image/*']);
    if (file == null || !mounted) return;
    setState(() => _uploadProgress = 0);
    try {
      final uploaded = await widget.repository.uploadFile(
        file: file,
        type: 'foto_perfil',
        onProgress: (value) {
          if (mounted) setState(() => _uploadProgress = value / 100);
        },
      );
      setState(() {
        _photoId = uploaded.id;
        _uploadProgress = null;
      });
    } catch (error) {
      if (mounted) {
        setState(() => _uploadProgress = null);
        _toast(context, _friendly(error));
      }
    }
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      _toast(context, 'Informe seu nome.');
      return;
    }
    final username = _username.text.trim().replaceFirst(RegExp(r'^@+'), '');
    if (_groupIdentityMode == 'username' && !RegExp(r'^[A-Za-z0-9._-]{2,32}$').hasMatch(username)) {
      _toast(context, 'Defina um nome de usuário com 2 a 32 letras, números, ponto, _ ou -.');
      return;
    }
    if (_groupIdentityMode == 'phone' && _phone.text.trim().isEmpty) {
      _toast(context, 'Informe seu telefone para usá-lo como identificação no grupo.');
      return;
    }
    setState(() => _saving = true);
    try {
      await widget.repository.action('upsert_profile', {
        'nome': _name.text.trim(),
        'telefone': _phone.text.trim(),
        if (_photoId?.isNotEmpty == true) 'foto_id': _photoId,
      });
      await widget.repository.saveModule(
        kind: 'profile_meta',
        rowId: widget.snapshot?.metadata?[r'$id']?.toString(),
        title: _name.text.trim(),
        data: {
          'whatsapp': _whatsApp.text.trim(),
          'username': username,
          'group_identity_mode': _groupIdentityMode,
          'city': _city.text.trim(),
          'birthday': _birthday.text.trim(),
          if (_cpf.text.trim().isNotEmpty) 'cpf': _cpf.text.trim(),
        },
        queueIfOffline: true,
      );
      if (mounted) Navigator.pop(context);
    } catch (error) {
      if (mounted) _toast(context, _friendly(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Dados pessoais')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Align(
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              _ProfilePhoto(
                repository: widget.repository,
                fileId: _photoId ?? '',
                fallback: _name.text,
                radius: 46,
              ),
              Positioned(
                right: -8,
                bottom: -6,
                child: IconButton.filled(
                  tooltip: 'Alterar foto',
                  onPressed: _uploadProgress == null ? _pickPhoto : null,
                  icon: const Icon(Icons.photo_camera_outlined),
                ),
              ),
            ],
          ),
        ),
        if (_uploadProgress != null) ...[
          const SizedBox(height: 18),
          LinearProgressIndicator(value: _uploadProgress),
          const SizedBox(height: 6),
          Text(
            'Enviando ${((_uploadProgress ?? 0) * 100).round()}%',
            textAlign: TextAlign.center,
          ),
        ],
        const SizedBox(height: 28),
        TextField(
          controller: _name,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(labelText: 'Nome *'),
        ),
        const SizedBox(height: 12),
        TextFormField(
          enabled: false,
          initialValue: widget.user.email,
          decoration: const InputDecoration(labelText: 'E-mail'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'Telefone'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _username,
          textCapitalization: TextCapitalization.none,
          autocorrect: false,
          decoration: const InputDecoration(
            labelText: 'Nome de usuário do grupo',
            prefixText: '@',
            helperText: 'Você pode mostrar @usuário ou seu telefone no Grupo Rachey.',
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          initialValue: _groupIdentityMode == 'phone' ? 'phone' : 'username',
          decoration: const InputDecoration(labelText: 'Mostrar no grupo como'),
          items: const [
            DropdownMenuItem(value: 'username', child: Text('Nome de usuário (@usuário)')),
            DropdownMenuItem(value: 'phone', child: Text('Número de telefone')),
          ],
          onChanged: (value) => setState(() => _groupIdentityMode = value ?? 'username'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _whatsApp,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'WhatsApp'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _city,
          decoration: const InputDecoration(labelText: 'Cidade'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _birthday,
          keyboardType: TextInputType.datetime,
          decoration: const InputDecoration(
            labelText: 'Nascimento',
            hintText: 'AAAA-MM-DD',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _cpf,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'CPF (opcional)',
            helperText:
                'O CPF é criptografado na Function e não fica salvo no aparelho.',
          ),
        ),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: _saving || _uploadProgress != null ? null : _save,
          icon: const Icon(Icons.save_outlined),
          label: Text(_saving ? 'Salvando...' : 'Salvar dados'),
        ),
      ],
    ),
  );
}

class _ProfilePhoto extends StatelessWidget {
  const _ProfilePhoto({
    required this.repository,
    required this.fileId,
    required this.fallback,
    this.radius = 31,
  });

  final RacheyRepository repository;
  final String fileId;
  final String fallback;
  final double radius;

  @override
  Widget build(BuildContext context) {
    if (fileId.isEmpty) {
      return CircleAvatar(
        radius: radius,
        backgroundColor: RacheyColors.mint,
        child: Text(
          fallback.trim().isEmpty ? 'R' : fallback.trim()[0].toUpperCase(),
          style: TextStyle(
            color: RacheyColors.darkGreen,
            fontWeight: FontWeight.w900,
            fontSize: radius * .72,
          ),
        ),
      );
    }
    return FutureBuilder<Uint8List>(
      future: repository.imageFile(
        fileId,
        width: (radius * 3).round(),
        height: (radius * 3).round(),
      ),
      builder: (_, snapshot) => CircleAvatar(
        radius: radius,
        backgroundColor: RacheyColors.mint,
        backgroundImage: snapshot.hasData ? MemoryImage(snapshot.data!) : null,
        child: snapshot.connectionState == ConnectionState.waiting
            ? const CircularProgressIndicator(strokeWidth: 2)
            : snapshot.hasData
            ? null
            : const Icon(Icons.person_outline),
      ),
    );
  }
}

class _SecurityPage extends StatefulWidget {
  const _SecurityPage({required this.preferences});

  final AppPreferences preferences;

  @override
  State<_SecurityPage> createState() => _SecurityPageState();
}

class _SecurityPageState extends State<_SecurityPage> {
  bool _hasPin = false;
  bool _loading = true;
  Future<List<models.Session>>? _sessions;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final hasPin = await NativeBridge.hasPin();
    if (!mounted) return;
    setState(() {
      _hasPin = hasPin;
      _loading = false;
      _sessions = context.read<AuthCubit>().sessions();
    });
  }

  Future<void> _configurePin() async {
    if (_hasPin) {
      final remove = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Remover o PIN?'),
          content: const Text('A sessão e o Cofre deixarão de pedir este PIN.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Remover'),
            ),
          ],
        ),
      );
      if (remove == true) {
        await NativeBridge.clearPin();
        await _reload();
      }
      return;
    }
    final first = TextEditingController();
    final confirm = TextEditingController();
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Criar PIN'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: first,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: 8,
              decoration: const InputDecoration(
                labelText: 'PIN de 4 a 8 números',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: confirm,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: 8,
              decoration: const InputDecoration(labelText: 'Confirmar PIN'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
    if (save == true) {
      if (!RegExp(r'^\d{4,8}$').hasMatch(first.text) ||
          first.text != confirm.text) {
        if (mounted)
          _toast(
            context,
            'Os PINs devem ser iguais e conter de 4 a 8 números.',
          );
      } else {
        await NativeBridge.setPin(first.text);
        await _reload();
      }
    }
    first.dispose();
    confirm.dispose();
  }

  Future<void> _setBiometrics(bool value) async {
    if (value) {
      final accepted = await NativeBridge.authenticate(
        reason: 'Confirme a biometria para proteger o Rachey',
      );
      if (!accepted) {
        if (mounted)
          _toast(context, 'Biometria não confirmada ou indisponível.');
        return;
      }
    }
    await widget.preferences.setBiometrics(value);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Segurança')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Column(
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.fingerprint_rounded),
                title: const Text('Biometria'),
                subtitle: const Text('Bloqueia a sessão e protege o Cofre'),
                value: widget.preferences.biometricsEnabled,
                onChanged: _loading ? null : _setBiometrics,
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.pin_outlined),
                title: Text(_hasPin ? 'PIN configurado' : 'Criar PIN'),
                subtitle: Text(
                  _hasPin
                      ? 'Toque para remover ou substituir'
                      : 'Proteção local criptografada pelo Android',
                ),
                trailing: const Icon(Icons.chevron_right),
                onTap: _loading ? null : _configurePin,
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const Text(
          'Sessões ativas',
          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
        ),
        const SizedBox(height: 10),
        FutureBuilder<List<models.Session>>(
          future: _sessions,
          builder: (_, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Card(
                child: Padding(
                  padding: EdgeInsets.all(28),
                  child: Center(child: CircularProgressIndicator()),
                ),
              );
            }
            if (snapshot.hasError) {
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.error_outline),
                  title: Text(_friendly(snapshot.error!)),
                ),
              );
            }
            final sessions = snapshot.data ?? const [];
            return Card(
              child: Column(
                children: sessions.indexed.map((entry) {
                  final index = entry.$1;
                  final session = entry.$2;
                  final device = [session.deviceBrand, session.deviceModel]
                      .where((value) => value.isNotEmpty && value != 'null')
                      .join(' ');
                  return Column(
                    children: [
                      ListTile(
                        leading: Icon(
                          session.current
                              ? Icons.smartphone_rounded
                              : Icons.devices_other_rounded,
                        ),
                        title: Text(
                          device.isEmpty
                              ? '${session.clientName} ${session.osName}'
                              : device,
                        ),
                        subtitle: Text(
                          '${session.countryName} • ${session.provider}${session.current ? ' • sessão atual' : ''}',
                        ),
                        trailing: session.current
                            ? const Icon(
                                Icons.check_circle,
                                color: RacheyColors.primary,
                              )
                            : IconButton(
                                tooltip: 'Encerrar sessão',
                                onPressed: () async {
                                  await context.read<AuthCubit>().deleteSession(
                                    session.$id,
                                  );
                                  await _reload();
                                },
                                icon: const Icon(Icons.logout),
                              ),
                      ),
                      if (index != sessions.length - 1)
                        const Divider(height: 1),
                    ],
                  );
                }).toList(),
              ),
            );
          },
        ),
      ],
    ),
  );
}

class _SettingsPage extends StatefulWidget {
  const _SettingsPage({required this.repository, required this.preferences});

  final RacheyRepository repository;
  final AppPreferences preferences;

  @override
  State<_SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<_SettingsPage> {
  bool _syncing = false;

  Future<void> _notifications(bool enabled) async {
    if (enabled) await NativeBridge.requestNotificationPermission();
    await widget.preferences.setLocalNotifications(enabled);
    if (mounted) setState(() {});
  }

  Future<void> _sync() async {
    setState(() => _syncing = true);
    final count = await widget.repository.syncPending();
    if (mounted) {
      setState(() => _syncing = false);
      _toast(context, '$count alteração(ões) sincronizada(s).');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Preferências')),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.palette_outlined),
                title: const Text('Tema'),
                trailing: DropdownButton<ThemeMode>(
                  value: widget.preferences.themeMode,
                  underline: const SizedBox.shrink(),
                  items: const [
                    DropdownMenuItem(
                      value: ThemeMode.system,
                      child: Text('Sistema'),
                    ),
                    DropdownMenuItem(
                      value: ThemeMode.light,
                      child: Text('Claro'),
                    ),
                    DropdownMenuItem(
                      value: ThemeMode.dark,
                      child: Text('Escuro'),
                    ),
                  ],
                  onChanged: (value) async {
                    if (value != null)
                      await widget.preferences.setThemeMode(value);
                  },
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.language_outlined),
                title: const Text('Idioma'),
                trailing: DropdownButton<String>(
                  value: widget.preferences.language,
                  underline: const SizedBox.shrink(),
                  items: const [
                    DropdownMenuItem(value: 'pt-BR', child: Text('Português')),
                    DropdownMenuItem(value: 'en-US', child: Text('English')),
                    DropdownMenuItem(value: 'es-ES', child: Text('Español')),
                  ],
                  onChanged: (value) async {
                    if (value != null)
                      await widget.preferences.setLanguage(value);
                  },
                ),
              ),
              const Divider(height: 1),
              SwitchListTile(
                secondary: const Icon(Icons.notifications_active_outlined),
                title: const Text('Notificações locais'),
                subtitle: const Text('Lembretes no aparelho quando permitido'),
                value: widget.preferences.localNotificationsEnabled,
                onChanged: _notifications,
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.sync_rounded),
                title: const Text('Sincronização offline'),
                subtitle: Text(
                  '${widget.repository.pendingSyncCount} alteração(ões) aguardando envio',
                ),
                trailing: _syncing
                    ? const SizedBox.square(
                        dimension: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.chevron_right),
                onTap: _syncing ? null : _sync,
              ),
              const Divider(height: 1),
              const ListTile(
                leading: Icon(Icons.apps_rounded),
                title: Text('Aplicativo'),
                subtitle: Text('${AppConfig.appName} ${AppConfig.version}'),
              ),
              const Divider(height: 1),
              const ListTile(
                leading: Icon(Icons.cloud_done_outlined),
                title: Text('Dados'),
                subtitle: Text('Appwrite Database, Storage e Functions'),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

class _HelpPage extends StatefulWidget {
  const _HelpPage({required this.repository});
  final RacheyRepository repository;

  @override
  State<_HelpPage> createState() => _HelpPageState();
}

class _HelpPageState extends State<_HelpPage> {
  late Future<_HelpData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_HelpData> _load() async {
    final values = await Future.wait<dynamic>([
      widget.repository.action('app_settings'),
      widget.repository.listModules('faq', limit: 200),
    ]);
    return _HelpData(
      settings: Map<String, dynamic>.from(values[0] as Map),
      faq: values[1] as List<Map<String, dynamic>>,
    );
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  Future<void> _open(String raw) async {
    final uri = Uri.tryParse(raw.trim());
    if (uri == null ||
        !await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) _toast(context, 'Não foi possível abrir este endereço.');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Central de ajuda')),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<_HelpData>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return ListView(
              children: [
                const SizedBox(height: 140),
                const Icon(
                  Icons.cloud_off_outlined,
                  size: 54,
                  color: RacheyColors.gray,
                ),
                const SizedBox(height: 10),
                Center(child: Text(_friendly(snapshot.error!))),
              ],
            );
          }
          final result = snapshot.data!;
          final general = result.settings['general'] as Map? ?? const {};
          final legal = result.settings['legal'] as Map? ?? const {};
          final whatsApp = '${general['whatsapp'] ?? ''}'.replaceAll(
            RegExp(r'[^0-9]'),
            '',
          );
          final socials = '${general['socials'] ?? ''}'
              .split('\n')
              .map((item) => item.trim())
              .where((item) => item.startsWith('http'))
              .toList();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (whatsApp.isNotEmpty)
                FilledButton.icon(
                  onPressed: () => _open(
                    'https://wa.me/$whatsApp?text=Olá%2C%20preciso%20de%20ajuda%20com%20o%20Rachey.',
                  ),
                  icon: const Icon(Icons.chat_outlined),
                  label: const Text('Falar pelo WhatsApp'),
                ),
              if (socials.isNotEmpty) ...[
                const SizedBox(height: 14),
                const Text(
                  'Redes sociais',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
                ),
                const SizedBox(height: 8),
                Card(
                  child: Column(
                    children: socials.indexed.map((entry) {
                      return Column(
                        children: [
                          ListTile(
                            leading: const Icon(Icons.public_outlined),
                            title: Text(entry.$2),
                            trailing: const Icon(Icons.open_in_new),
                            onTap: () => _open(entry.$2),
                          ),
                          if (entry.$1 != socials.length - 1)
                            const Divider(height: 1),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ],
              const SizedBox(height: 18),
              const Text(
                'Perguntas frequentes',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
              const SizedBox(height: 8),
              if (result.faq.isEmpty)
                const Card(
                  child: ListTile(
                    leading: Icon(Icons.help_outline),
                    title: Text('Nenhuma pergunta publicada.'),
                  ),
                )
              else
                Card(
                  child: Column(
                    children: result.faq
                        .map(
                          (row) => ExpansionTile(
                            title: Text('${row['title'] ?? 'Dúvida'}'),
                            childrenPadding: const EdgeInsets.fromLTRB(
                              16,
                              0,
                              16,
                              16,
                            ),
                            children: [
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  '${(row['data'] as Map? ?? const {})['answer'] ?? ''}',
                                ),
                              ),
                            ],
                          ),
                        )
                        .toList(),
                  ),
                ),
              const SizedBox(height: 18),
              Card(
                child: Column(
                  children: [
                    ExpansionTile(
                      leading: const Icon(Icons.privacy_tip_outlined),
                      title: const Text('Política de privacidade'),
                      childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            '${legal['policy'] ?? 'Conteúdo ainda não publicado.'}',
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 1),
                    ExpansionTile(
                      leading: const Icon(Icons.gavel_outlined),
                      title: const Text('Termos de uso'),
                      childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            '${legal['terms'] ?? 'Conteúdo ainda não publicado.'}',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    ),
  );
}

class _HelpData {
  const _HelpData({required this.settings, required this.faq});
  final Map<String, dynamic> settings;
  final List<Map<String, dynamic>> faq;
}

class _BenefitsPage extends StatefulWidget {
  const _BenefitsPage({required this.repository});

  final RacheyRepository repository;

  @override
  State<_BenefitsPage> createState() => _BenefitsPageState();
}

class _BenefitsPageState extends State<_BenefitsPage> {
  late Future<List<dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<dynamic>> _load() => Future.wait<dynamic>([
    widget.repository.listModules('loyalty_ledger'),
    widget.repository.listModules('waitlist'),
    widget.repository.action('referral_status'),
  ]);

  Future<void> _applyReferral() async {
    final controller = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Código de indicação'),
        content: TextField(
          controller: controller,
          textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(labelText: 'Código', hintText: 'RCH12345678'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Aplicar')),
        ],
      ),
    );
    final code = controller.text.trim();
    controller.dispose();
    if (ok != true || code.isEmpty || !mounted) return;
    try {
      await widget.repository.action('apply_referral', {'code': code});
      if (!mounted) return;
      setState(() => _future = _load());
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Código de indicação vinculado.')));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Benefícios e fila')),
    body: FutureBuilder<List<dynamic>>(
      future: _future,
      builder: (_, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text(_friendly(snapshot.error!)));
        }
        final ledger = ((snapshot.data?[0] as List<dynamic>?) ?? const [])
            .whereType<Map>()
            .map((row) => Map<String, dynamic>.from(row))
            .where(
              (row) =>
                  !const {'estornado', 'cancelado'}.contains(row['status']),
            )
            .toList();
        final waiting = ((snapshot.data?[1] as List<dynamic>?) ?? const [])
            .whereType<Map>()
            .map((row) => Map<String, dynamic>.from(row))
            .toList();
        final referral = Map<String, dynamic>.from(snapshot.data?[2] as Map? ?? const {});
        final referralClaim = referral['claim'] as Map?;
        final referralRewards = referral['rewards'] as Map? ?? const {};
        final cashback = ledger.fold<int>(
          0,
          (sum, row) => sum + ((row['amount_cents'] as num?)?.round() ?? 0),
        );
        final points = ledger.fold<int>(0, (sum, row) {
          final data = row['data'] as Map? ?? const {};
          return sum + ((data['points'] as num?)?.round() ?? 0);
        });
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                Expanded(
                  child: _Metric(
                    label: 'Cashback',
                    value: _money(cashback),
                    icon: Icons.savings_outlined,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _Metric(
                    label: 'Pontos',
                    value: '$points',
                    icon: Icons.stars_outlined,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(children: [Icon(Icons.group_add_outlined), SizedBox(width: 8), Text('Indique e ganhe', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17))]),
                    const SizedBox(height: 8),
                    const Text('Seu código', style: TextStyle(color: RacheyColors.gray, fontSize: 12)),
                    SelectableText('${referral['code'] ?? '-'}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
                    const SizedBox(height: 6),
                    Text('${referral['invited_count'] ?? 0} indicação(ões) • ${referral['rewarded_count'] ?? 0} confirmada(s)'),
                    if (((referralRewards['referrer_cashback_cents'] as num?)?.round() ?? 0) > 0 || ((referralRewards['referrer_points'] as num?)?.round() ?? 0) > 0)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text('Ao confirmar: ${_money((referralRewards['referrer_cashback_cents'] as num?)?.round() ?? 0)} + ${referralRewards['referrer_points'] ?? 0} ponto(s)', style: const TextStyle(color: RacheyColors.primary)),
                      ),
                    if (referralClaim == null) ...[
                      const SizedBox(height: 10),
                      OutlinedButton.icon(onPressed: _applyReferral, icon: const Icon(Icons.redeem_outlined), label: const Text('Tenho um código de indicação')),
                    ] else ...[
                      const SizedBox(height: 8),
                      Text('Código usado: ${(referralClaim['data'] as Map? ?? const {})['code'] ?? '-'} • ${_status('${referralClaim['status'] ?? ''}')}', style: const TextStyle(fontSize: 12, color: RacheyColors.gray)),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Lista de espera',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
            const SizedBox(height: 10),
            if (waiting.isEmpty)
              const Card(
                child: ListTile(
                  leading: Icon(Icons.event_available_outlined),
                  title: Text('Você não está em nenhuma fila.'),
                ),
              )
            else
              ...waiting.map(
                (row) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.hourglass_top_rounded),
                    title: Text('${row['title'] ?? 'Serviço'}'),
                    subtitle: Text(
                      'Status: ${_status('${row['status'] ?? ''}')}',
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 16),
            const Text(
              'Histórico de benefícios',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
            ),
            const SizedBox(height: 10),
            if (ledger.isEmpty)
              const Card(
                child: ListTile(
                  leading: Icon(Icons.workspace_premium_outlined),
                  title: Text('Nenhum benefício lançado ainda.'),
                ),
              )
            else
              ...ledger.map((row) {
                final data = row['data'] as Map? ?? const {};
                return Card(
                  child: ListTile(
                    title: Text('${row['title'] ?? 'Benefício'}'),
                    subtitle: Text('${data['points'] ?? 0} pontos'),
                    trailing: Text(
                      _money((row['amount_cents'] as num?)?.round() ?? 0),
                    ),
                  ),
                );
              }),
          ],
        );
      },
    ),
  );
}

class _Metric extends StatelessWidget {
  const _Metric({required this.label, required this.value, required this.icon});

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: RacheyColors.primary),
          const SizedBox(height: 12),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 21),
          ),
          Text(label, style: const TextStyle(color: RacheyColors.gray)),
        ],
      ),
    ),
  );
}

class _MenuTile extends StatelessWidget {
  const _MenuTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ListTile(
    leading: Icon(icon, color: RacheyColors.primary),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: Text(subtitle),
    trailing: const Icon(Icons.chevron_right),
    onTap: onTap,
  );
}

void _toast(BuildContext context, String message) => ScaffoldMessenger.of(
  context,
).showSnackBar(SnackBar(content: Text(message)));

String _money(int cents) =>
    'R\$ ${(cents / 100).toStringAsFixed(2).replaceAll('.', ',')}';

String _status(String value) => value.replaceAll('_', ' ');

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
