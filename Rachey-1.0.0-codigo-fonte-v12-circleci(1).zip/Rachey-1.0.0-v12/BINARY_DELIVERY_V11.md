# Entrega binária v11

O artefato Flutter v11 originalmente citado no Work não foi preservado na Biblioteca. Para recuperar uma entrega instalável nesta sessão, o APK release v9 preservado foi reconstruído como v11, mantendo os binários Flutter existentes e aplicando os patches Android necessários para o retorno OAuth e a confirmação segura; o `versionCode` foi elevado para 11 e o APK recebeu uma nova assinatura APK v2 válida.

O backend Function v11 informado pelo proprietário já está ativo no Appwrite. O código-fonte deste pacote contém também as correções Dart v11 completas (retomada controlada do Google, login administrativo sem espera de bootstrap, UX de aprovação/recusa, PIX e renovação). Uma futura compilação Flutter 3.44.8 a partir deste fonte incorpora essas correções Dart diretamente no AOT.

## Assinatura desta entrega
- Certificado público: `signing/Rachey-v11-signing-certificate.pem`
- A chave privada não é incluída no código-fonte.
- O backup privado é entregue separadamente e deve ser guardado em local seguro para assinar atualizações futuras.
