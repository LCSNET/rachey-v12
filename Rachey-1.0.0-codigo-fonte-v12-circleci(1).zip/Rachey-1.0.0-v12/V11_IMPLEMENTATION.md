# Rachey 1.0.0+11 — reconstrução do APK

Esta árvore reconstrói o estado final descrito no Work para a v11.

## Correções finais

- Android OAuth do Appwrite mantém `appwrite-callback-rachey` e, ao voltar do navegador, faz retomada controlada da sessão para atualizar a UI sem exigir fechar/reabrir o app.
- Login administrativo não fica bloqueado aguardando `bootstrap_schema`; a manutenção roda em segundo plano.
- Confirmação de ações administrativas aceita biometria ou credencial segura do aparelho (PIN/padrão/senha) em Android 10+ e usa a credencial do aparelho como fallback em versões anteriores.
- Aprovação exige comprovante no cliente e no backend.
- Recusa exige motivo, mostra cancelamento de segurança e atualiza a lista após o servidor confirmar.
- Recusa de renovação usa `renovacao_id`, sem tratar renovação como pedido.
- PIX manual só existe com chave real cadastrada pelo administrador; a Function não cria checkout se não houver configuração.
- O pedido só é persistido depois do envio de comprovante; antes disso existe apenas uma intenção de compra temporária.

## Backend

Segundo o histórico fornecido pelo proprietário, a Function v11 já está ativa no Appwrite na implantação `6a7abb2a720435bc47ae`. Este pacote preserva o código-fonte correspondente às correções reconstruídas, mas não executa novo deploy automaticamente.
