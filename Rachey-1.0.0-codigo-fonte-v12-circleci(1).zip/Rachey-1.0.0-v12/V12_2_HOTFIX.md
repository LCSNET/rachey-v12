# Rachey v12.2 hotfix

Versão do app: 1.0.2+14
Backend: 12.2

Correções:
- Corrige callbacks de setState que retornavam Future em telas de recarga.
- Corrige erro de salvar configurações no Admin.
- Adiciona preflight backend_info antes de enviar segredos de Mercado Pago/Gemini.
- Adiciona ações backend_info, test_mercado_pago, test_ai_bot e list_ai_models no backend v12.2.
- Migra automaticamente segredos legados salvos em data_json pela Function v11 para secret_ciphertext criptografado.
- Mantém callback OAuth appwrite-callback-rachey.
