# Build status — Rachey 1.0.0+11

## Fonte
- Package Android: `br.com.rachey.app`
- Flutter/Dart
- Appwrite: projeto `rachey`, database `rachey_db`, bucket `arquivos`
- Build number: `1.0.0+11`
- Callback Android Appwrite: `appwrite-callback-rachey`

## Correções finais v11
- retomada imediata da sessão Google após o retorno do navegador;
- login administrativo não bloqueado por `bootstrap_schema`;
- confirmação administrativa por biometria ou PIN/padrão/senha do aparelho;
- aprovação somente com comprovante;
- recusa com motivo obrigatório e atualização imediata da lista;
- recusa de renovação usando `renovacao_id` corretamente;
- PIX manual somente com chave real configurada;
- PIX automático somente quando o provedor real estiver configurado e responder com cobrança válida;
- pedido persistido somente após envio do comprovante.

## Backend
A Function v11 já havia sido ativada no Appwrite no Work informado pelo proprietário, implantação `6a7abb2a720435bc47ae`. Este pacote não tenta refazer esse deploy automaticamente.

## Validações do fonte desta entrega
- JavaScript/Appwrite Functions: `node --check`.
- Manifest Android: XML válido e callback conferido.
- Script de build: `bash -n build_release.sh`.
- Suíte de testes presente: 7 testes em `test/widget_test.dart`.

## Build Flutter reproduzível
Execute `./build_release.sh` em Flutter 3.44.8 + Java 17 para rodar:
1. `flutter pub get`
2. `flutter analyze`
3. `flutter test`
4. `flutter build apk --release`

O workflow `.github/workflows/build-android.yml` usa a mesma versão do Flutter.
