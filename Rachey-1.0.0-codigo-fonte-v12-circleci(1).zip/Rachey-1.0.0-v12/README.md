# Rachey 1.0.0+9

Aplicativo Flutter para venda e gerenciamento profissional de assinaturas
digitais, integrado ao projeto Appwrite `rachey`.

- Android: `br.com.rachey.app`
- Endpoint: `https://nyc.cloud.appwrite.io/v1`
- Database: `rachey_db`
- Storage: `arquivos`
- Function principal: `rachey_admin`
- Function agendada: `rachey_notifications`
- Equipe administrativa: `administradores`

O login usa exclusivamente Appwrite Authentication. A entrada no painel
administrativo depende da participação do usuário na equipe
`administradores`; os papéis `administrador`, `operador` e `financeiro` são
validados novamente pela Function em cada operação privilegiada.

O login social disponível no Android é somente o Google. O botão Apple foi
removido. A confirmação de e-mail e a recuperação de senha usam a ponte HTTPS
ativa em `https://rachey-auth.appwrite.network`; as URLs de verificação e
recuperação já estão configuradas como padrões seguros no aplicativo e no
build.

Credenciais de serviços e a chave Pix são criptografadas no servidor com
AES-256-GCM. A chave de criptografia permanece em uma variável secreta da
Function e nunca é incluída no APK. O Hive armazena apenas preferências, cache
não sensível e uma fila de sincronização.

## Módulos

O projeto contém autenticação, perfil, catálogo, serviços e períodos, estoque
por conta/tela com vencimento e preço proporcional, lista de espera, central de vencimentos, carrinho, Pix, pedidos e timeline, assinaturas,
cofre, CRM, Grupo Rachey, suporte com SLA, financeiro/COGS/lucro, relatórios PDF/XLSX, dashboard Hoje,
alertas, configurações, auditoria, cashback, fidelidade, indicação, favoritos, cupons avançados e backup.

O Grupo Rachey é o único centro de comunicação coletiva, acessível por clientes autenticados
e administradores: conversa com atualização automática, respostas, reações,
mensagens fixadas, aprovação prévia, modo somente admin,
modo lento, denúncias e moderação de membros. Imagens, vídeos, áudios e
documentos usam o Appwrite Storage apenas durante o prazo definido pelo admin
(7 dias por padrão) e podem ser salvos automaticamente em `Downloads/Rachey`
no Android. O banco guarda somente os metadados e a referência temporária do
arquivo, nunca os bytes da mídia.

Consulte `RACHEY_FEATURE_MATRIX.md` para o estado requisito por requisito e
para as integrações que dependem de credenciais externas.

## Compilar

```bash
flutter pub get
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter test
flutter build apk --release
flutter build appbundle --release
```

Para um build de produção, use `./build_release.sh`. As URLs do Appwrite Sites
já são aplicadas por padrão; `APPWRITE_EMAIL_VERIFICATION_URL` e
`APPWRITE_PASSWORD_RECOVERY_URL` permanecem disponíveis apenas para substituir
o domínio. Veja `deployment/AUTH_REDIRECT_SETUP.md`.

Sem `android/key.properties`, o build local usa a chave de depuração para gerar
um APK instalável. Para publicação, copie `android/key.properties.example` para
`android/key.properties`, informe a chave de upload da Play Store e mantenha
esse arquivo e o keystore fora do projeto.

O projeto não contém API key administrativa, senha, chave Pix nem chave de
assinatura de produção.


## Estoque pronto x liberação manual

A v8 não ativa automaticamente produtos criados na hora. Neles, o prazo começa somente quando a equipe libera a credencial. Uma conta pronta cadastrada no estoque pode, opcionalmente, ter vencimento real e preço proporcional; nesse caso a unidade/tela específica é reservada no Pix e liberada após a aprovação. Veja `IMPLEMENTATION_V8.md`.
