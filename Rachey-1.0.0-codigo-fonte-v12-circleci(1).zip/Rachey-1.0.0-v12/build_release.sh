#!/usr/bin/env bash
set -euo pipefail

APPWRITE_EMAIL_VERIFICATION_URL="${APPWRITE_EMAIL_VERIFICATION_URL:-https://rachey-auth.appwrite.network/verify.html}"
APPWRITE_PASSWORD_RECOVERY_URL="${APPWRITE_PASSWORD_RECOVERY_URL:-https://rachey-auth.appwrite.network/recovery.html}"

flutter --version
flutter pub get
flutter analyze
flutter test
flutter build apk --release \
  --dart-define=APPWRITE_ENDPOINT=https://nyc.cloud.appwrite.io/v1 \
  --dart-define=APPWRITE_PROJECT_ID=rachey \
  --dart-define=APPWRITE_DATABASE_ID=rachey_db \
  --dart-define=APPWRITE_BUCKET_ID=arquivos \
  --dart-define=APPWRITE_MAIN_FUNCTION_ID=rachey_admin \
  --dart-define=APPWRITE_EMAIL_VERIFICATION_URL="$APPWRITE_EMAIL_VERIFICATION_URL" \
  --dart-define=APPWRITE_PASSWORD_RECOVERY_URL="$APPWRITE_PASSWORD_RECOVERY_URL" \
  "${@}"
