# Auditoria técnica — Rachey 1.0.0+9

Data da revisão: 2026-08-10.

## Resultado

O ZIP contém código-fonte Flutter completo, projeto Android nativo e duas
Functions Appwrite. Não é apenas uma decompilação parcial. A integração usa o
projeto `rachey`, endpoint NYC, banco `rachey_db`, bucket `arquivos` e pacote
Android `br.com.rachey.app`.

## Correções desta revisão

- Apple removido e Google mantido como único login social;
- confirmação de e-mail processada antes da restauração da sessão;
- cadastro não ignora falha no envio do e-mail;
- URLs HTTPS de verificação e recuperação configuradas no código e no build;
- validação de `userId` e `secret` em links de confirmação/recuperação;
- páginas HTTPS com abertura automática e botão manual para voltar ao app;
- ponte HTTPS implantada no Appwrite Sites e registrada como plataforma Web;
- workflow Android corrigido para injetar as URLs de autenticação;
- campo de benefícios/itens inclusos do serviço passa a carregar e salvar;
- versão elevada para `1.0.0+9`.

## Requisitos críticos conferidos

- “Novo serviço” não consulta metadados sem `reference_id` e não abre mais o
  primeiro serviço existente;
- serviço aceita vários períodos e preços, por exemplo 7, 14 e 30 dias;
- checkout cria somente uma intenção temporária; pedido é persistido depois do
  envio de um comprovante autorizado;
- aprovação recusa pagamento sem comprovante;
- novo pedido com comprovante e novo ticket notificam administradores;
- análise administrativa mostra o arquivo do comprovante;
- exclusão definitiva remove dados vinculados e o usuário do Appwrite Auth;
- Grupo inclui mídia, áudio gravado, edição, enquetes, perguntas, sorteios,
  `@todos`, preferências de notificação, bot, denúncias, silêncio e banimento.

## Validações executadas

- integridade do ZIP original;
- 26 arquivos Dart e todos os imports locais encontrados;
- delimitadores consistentes nos 27 arquivos de `lib/` e `test/`;
- 37 ações literais chamadas pelo app encontradas no backend;
- XML Android e YAML válidos;
- `bash -n` no script de release;
- `node --check` em todo JavaScript das Functions;
- instalação limpa e importação das dependências das duas Functions;
- pacotes `.tar.gz` das Functions conferidos com os fontes;
- nenhum padrão de segredo privado embutido detectado;
- configurações do Appwrite conferidas no Console: Apple permanece desativado;
  Google aguarda as credenciais OAuth externas;
- site `rachey-auth.appwrite.network` publicado e plataforma Web cadastrada.

## Pendências externas

1. Habilitar Google com credenciais do Google
   Cloud. O Client Secret deve ser digitado somente no Appwrite, nunca no APK.
2. Publicar as Functions caso a versão presente no projeto Cloud seja anterior
   aos pacotes em `appwrite/dist/`.
3. Executar `flutter analyze`, `flutter test` e o build release. O ambiente desta
   auditoria não possui o SDK Flutter/Dart, portanto não deve ser declarado como
   compilado até essa etapa terminar em um ambiente Flutter 3.44.8.
