# Rachey v13 — implementação

Versão Flutter: **1.1.0+15**  
Backend mínimo: **rachey_admin 13.0**

## Grupo e Bot

- O Rachey Bot pode observar o grupo sem ser marcado.
- Consultas do bot usam dados atuais do Appwrite no momento da mensagem.
- Cliente: somente seus próprios pedidos, pagamentos, assinaturas e estoque público.
- Administrador: estoque, contas de estoque, pagamentos por status, tickets e compras recentes.
- Compras recentes informam se o cliente é recorrente e, quando disponível, o que foi comprado anteriormente.
- Comandos administrativos: `/status`, `/pausar`, `/dormir`, `/assumir`, `/abrir`, `/fechar`, `/mutar`, `/desmutar`, `/banir`, `/desbanir`, `/promo`, `/pv` e equivalentes naturais suportados.
- Permissões independentes para o bot apagar, mutar e banir.
- Promoções recorrentes e manutenção do grupo aberto são gravadas como `bot_task`.
- Administradores escolhidos no painel podem receber PV automático do bot para moderação, compras, renovações e tickets importantes.

## Mensagens privadas

- PV entre clientes, cliente/admin e admin/clientes conforme permissões do grupo.
- Conversas do bot com administradores selecionados.
- Fotos de perfil aparecem no PV.
- Imagens do PV abrem a galeria e têm permissões de Storage restritas aos dois participantes e administradores.

## Fotos de perfil

A foto opcional já armazenada em `perfis.foto_id` passa a aparecer no Grupo, tickets/respostas de suporte e mensagens privadas.

## Mensagens rápidas

O compositor do Grupo recebeu um atalho de mensagens pré-configuradas. O admin pode cadastrar escopos diferentes para clientes, administradores, todos do grupo ou suporte.

## PIX

- Mercado Pago: QR Code e Copia-e-Cola somente da API real.
- PIX manual: mostra somente a chave PIX real cadastrada e o recebedor, sem fabricar BR Code/QR local.
- Sem Mercado Pago e sem chave PIX manual, o botão de pagamento fica indisponível.

## Automação agendada

A Function `rachey_notifications` v13 processa `bot_task`. Configure a agenda da Function para **a cada 5 minutos** (`*/5 * * * *`). As próprias tarefas respeitam seus intervalos (ex.: promoção a cada 60 minutos).

## Banco de dados

Não é necessário criar tabela nova. PV, tarefas do bot e automações usam a tabela genérica existente `dados_rachey`, cujo campo `kind` é string.
