import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/widgets/rachey_ui.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';

class SupportPage extends StatefulWidget {
  const SupportPage({
    required this.repository,
    required this.userId,
    this.isAdmin = false,
    this.subscriptionId,
    this.orderId,
    super.key,
  });

  final RacheyRepository repository;
  final String userId;
  final bool isAdmin;
  final String? subscriptionId;
  final String? orderId;

  @override
  State<SupportPage> createState() => _SupportPageState();
}

class _SupportPageState extends State<SupportPage> {
  late Future<List<Map<String, dynamic>>> _future;
  String _filter = 'todos';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() =>
      widget.repository.listModules('support_ticket', limit: 300);

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Future<void> _newTicket() async {
    final title = TextEditingController();
    final description = TextEditingController();
    var priority = 'normal';
    var category = 'geral';
    PickedNativeFile? attachment;
    final create = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (_, setSheetState) => Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.viewInsetsOf(sheetContext).bottom + 24,
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Abrir chamado',
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: title,
                  decoration: const InputDecoration(labelText: 'Assunto *'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: description,
                  minLines: 4,
                  maxLines: 8,
                  decoration: const InputDecoration(
                    labelText: 'Descreva o problema *',
                  ),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: category,
                  decoration: const InputDecoration(labelText: 'Categoria'),
                  items: const [
                    DropdownMenuItem(value: 'geral', child: Text('Geral')),
                    DropdownMenuItem(value: 'acesso', child: Text('Acesso')),
                    DropdownMenuItem(
                      value: 'pagamento',
                      child: Text('Pagamento'),
                    ),
                    DropdownMenuItem(
                      value: 'renovacao',
                      child: Text('Renovação'),
                    ),
                    DropdownMenuItem(
                      value: 'tecnico',
                      child: Text('Problema técnico'),
                    ),
                  ],
                  onChanged: (value) =>
                      setSheetState(() => category = value ?? category),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: priority,
                  decoration: const InputDecoration(labelText: 'Prioridade'),
                  items: const [
                    DropdownMenuItem(value: 'baixa', child: Text('Baixa')),
                    DropdownMenuItem(value: 'normal', child: Text('Normal')),
                    DropdownMenuItem(value: 'alta', child: Text('Alta')),
                    DropdownMenuItem(value: 'urgente', child: Text('Urgente')),
                  ],
                  onChanged: (value) =>
                      setSheetState(() => priority = value ?? priority),
                ),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () async {
                    final file = await NativeBridge.pickFile(
                      mimeTypes: const [
                        'image/*',
                        'video/*',
                        'application/pdf',
                        'application/msword',
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                      ],
                    );
                    if (file != null) setSheetState(() => attachment = file);
                  },
                  icon: const Icon(Icons.attach_file_rounded),
                  label: Text(
                    attachment?.name ?? 'Anexar imagem, vídeo ou documento',
                  ),
                ),
                const SizedBox(height: 14),
                FilledButton(
                  onPressed: () => Navigator.pop(sheetContext, true),
                  child: const Text('Abrir chamado'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (create != true) {
      title.dispose();
      description.dispose();
      return;
    }
    if (title.text.trim().isEmpty || description.text.trim().isEmpty) {
      if (mounted) _toast('Informe o assunto e a descrição.');
      title.dispose();
      description.dispose();
      return;
    }
    if (!mounted) return;
    final uploadProgress = ValueNotifier<double?>(null);
    _blocking(uploadProgress);
    try {
      String? fileId;
      String? fileMime;
      if (attachment != null) {
        final uploaded = await widget.repository.uploadFile(
          file: attachment!,
          type: 'suporte',
          onProgress: (value) => uploadProgress.value = value / 100,
        );
        fileId = uploaded.id;
        fileMime = uploaded.mimeType;
      }
      await widget.repository.action('create_ticket', {
        'title': title.text.trim(),
        'description': description.text.trim(),
        'category': category,
        'priority': priority,
        if ((widget.subscriptionId ?? '').isNotEmpty) 'subscription_id': widget.subscriptionId,
        if ((widget.orderId ?? '').isNotEmpty) 'order_id': widget.orderId,
        if (fileId != null) 'file_id': fileId,
        if (fileMime != null) 'mime_type': fileMime,
      });
      if (mounted) Navigator.pop(context);
      await _refresh();
      if (mounted) _toast('Chamado aberto. A equipe foi notificada.');
    } catch (error) {
      if (mounted) {
        Navigator.pop(context);
        _toast(_friendly(error));
      }
    } finally {
      uploadProgress.dispose();
      title.dispose();
      description.dispose();
    }
  }

  void _blocking(ValueListenable<double?> progress) {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => Center(
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: ValueListenableBuilder<double?>(
              valueListenable: progress,
              builder: (_, value, __) => SizedBox(
                width: 230,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    LinearProgressIndicator(value: value),
                    const SizedBox(height: 12),
                    Text(
                      value == null
                          ? 'Criando chamado...'
                          : 'Enviando anexo ${(value * 100).round()}%',
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _toast(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.isAdmin ? 'Central de suporte' : 'Suporte Rachey'),
          Text(
            widget.isAdmin
                ? 'Fila da equipe e responsáveis'
                : 'Chamados e atendimento seguro',
            style: const TextStyle(fontSize: 12, color: RacheyColors.gray),
          ),
        ],
      ),
      actions: const [RacheyThemeButton(), SizedBox(width: 6)],
    ),
    floatingActionButton: widget.isAdmin
        ? null
        : FloatingActionButton.extended(
            onPressed: _newTicket,
            icon: const Icon(Icons.add_comment_outlined),
            label: const Text('Novo chamado'),
          ),
    body: Column(
      children: [
        SizedBox(
          height: 52,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            children:
                [
                      'todos',
                      'aberto',
                      'em_atendimento',
                      'aguardando_cliente',
                      'resolvido',
                      'fechado',
                    ]
                    .map(
                      (status) => Padding(
                        padding: const EdgeInsets.only(right: 7),
                        child: ChoiceChip(
                          label: Text(_status(status)),
                          selected: _filter == status,
                          onSelected: (_) => setState(() => _filter = status),
                        ),
                      ),
                    )
                    .toList(),
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: _refresh,
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _future,
              builder: (_, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return ListView(
                    children: [
                      const SizedBox(height: 150),
                      const Icon(
                        Icons.cloud_off_outlined,
                        size: 54,
                        color: RacheyColors.gray,
                      ),
                      const SizedBox(height: 12),
                      Center(child: Text(_friendly(snapshot.error!))),
                    ],
                  );
                }
                final items = (snapshot.data ?? const [])
                    .where(
                      (item) => _filter == 'todos' || item['status'] == _filter,
                    )
                    .toList();
                if (items.isEmpty) {
                  return ListView(
                    children: const [
                      SizedBox(height: 150),
                      Icon(
                        Icons.support_agent_rounded,
                        size: 58,
                        color: RacheyColors.primary,
                      ),
                      SizedBox(height: 14),
                      Center(child: Text('Nenhum chamado nesta situação.')),
                    ],
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, index) {
                    final ticket = items[index];
                    final data = ticket['data'] as Map? ?? const {};
                    final priority = '${data['priority'] ?? 'normal'}';
                    return Card(
                      child: ListTile(
                        contentPadding: const EdgeInsets.all(15),
                        leading: CircleAvatar(
                          backgroundColor: _priorityColor(
                            priority,
                          ).withValues(alpha: .14),
                          child: Icon(
                            Icons.support_agent_rounded,
                            color: _priorityColor(priority),
                          ),
                        ),
                        title: Text(
                          '${ticket['title'] ?? 'Chamado'}',
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Builder(builder: (_) {
                          final due = DateTime.tryParse('${ticket['due_at'] ?? ''}')?.toLocal();
                          final open = !const {'resolvido', 'fechado'}.contains('${ticket['status'] ?? ''}');
                          final overdue = due != null && open && due.isBefore(DateTime.now());
                          final sla = due == null ? '' : '${overdue ? ' • SLA ATRASADO' : ' • SLA até'} ${due.day.toString().padLeft(2, '0')}/${due.month.toString().padLeft(2, '0')} ${due.hour.toString().padLeft(2, '0')}:${due.minute.toString().padLeft(2, '0')}';
                          return Text('${_status('${ticket['status'] ?? ''}')} • ${_status(priority)}$sla${widget.isAdmin ? '\nCliente: ${ticket['owner_id'] ?? ''}' : ''}');
                        }),
                        isThreeLine: widget.isAdmin,
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () async {
                          await Navigator.push<void>(
                            context,
                            MaterialPageRoute<void>(
                              builder: (_) => _TicketPage(
                                repository: widget.repository,
                                ticket: ticket,
                                isAdmin: widget.isAdmin,
                              ),
                            ),
                          );
                          await _refresh();
                        },
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ),
      ],
    ),
  );
}

class _TicketPage extends StatefulWidget {
  const _TicketPage({
    required this.repository,
    required this.ticket,
    required this.isAdmin,
  });

  final RacheyRepository repository;
  final Map<String, dynamic> ticket;
  final bool isAdmin;

  @override
  State<_TicketPage> createState() => _TicketPageState();
}

class _TicketPageState extends State<_TicketPage> {
  final _message = TextEditingController();
  late Future<List<Map<String, dynamic>>> _future;
  PickedNativeFile? _attachment;
  bool _sending = false;
  double? _uploadProgress;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  @override
  void dispose() {
    _message.dispose();
    super.dispose();
  }

  Future<List<Map<String, dynamic>>> _load() => widget.repository.listModules(
    'support_message',
    parentId: '${widget.ticket[r'$id']}',
    limit: 500,
  );

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Future<void> _pick() async {
    final file = await NativeBridge.pickFile(
      mimeTypes: const [
        'image/*',
        'video/*',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      ],
    );
    if (file != null && mounted) setState(() => _attachment = file);
  }

  Future<void> _send() async {
    if (_message.text.trim().isEmpty && _attachment == null) return;
    setState(() => _sending = true);
    try {
      String? fileId;
      if (_attachment != null) {
        final uploaded = await widget.repository.uploadFile(
          file: _attachment!,
          type: 'suporte',
          onProgress: (value) {
            if (mounted) setState(() => _uploadProgress = value / 100);
          },
        );
        fileId = uploaded.id;
      }
      await widget.repository.action('reply_ticket', {
        'ticket_id': widget.ticket[r'$id'],
        'message': _message.text.trim(),
        if (fileId != null) 'file_id': fileId,
        if (_attachment != null) 'mime_type': _attachment!.mimeType,
      });
      _message.clear();
      _attachment = null;
      await _refresh();
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted) {
        setState(() {
          _sending = false;
          _uploadProgress = null;
        });
      }
    }
  }

  Future<void> _quickReply() async {
    try {
      final rows = await widget.repository.listModules('quick_reply', limit: 200);
      if (!mounted) return;
      if (rows.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nenhuma resposta rápida cadastrada.')),
        );
        return;
      }
      final selected = await showModalBottomSheet<Map<String, dynamic>>(
        context: context,
        showDragHandle: true,
        builder: (context) => SafeArea(
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.only(bottom: 12),
            children: [
              const ListTile(
                title: Text('Respostas rápidas', style: TextStyle(fontWeight: FontWeight.w900)),
              ),
              ...rows.map((row) => ListTile(
                leading: const Icon(Icons.quickreply_outlined),
                title: Text('${row['title'] ?? 'Resposta'}'),
                subtitle: Text(
                  '${(row['data'] as Map? ?? const {})['text'] ?? ''}',
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () => Navigator.pop(context, row),
              )),
            ],
          ),
        ),
      );
      if (selected != null) {
        _message.text = '${(selected['data'] as Map? ?? const {})['text'] ?? ''}';
        _message.selection = TextSelection.collapsed(offset: _message.text.length);
        if (mounted) setState(() {});
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
      }
    }
  }

  Future<void> _rate() async {
    var rating = 5;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (_, setLocalState) => AlertDialog(
          title: const Text('Avaliar atendimento'),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(5, (index) => IconButton(
              onPressed: () => setLocalState(() => rating = index + 1),
              icon: Icon(
                index < rating ? Icons.star_rounded : Icons.star_border_rounded,
                color: Colors.amber,
                size: 34,
              ),
            )),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Enviar')),
          ],
        ),
      ),
    );
    if (ok == true) {
      await widget.repository.action('rate_ticket', {
        'ticket_id': widget.ticket[r'$id'],
        'rating': rating,
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Obrigado pela avaliação.')),
        );
      }
    }
  }

  Future<void> _manage() async {
    final assigned = TextEditingController(
      text: '${widget.ticket['assigned_to'] ?? ''}',
    );
    var status = '${widget.ticket['status'] ?? 'aberto'}';
    var priority =
        '${(widget.ticket['data'] as Map? ?? const {})['priority'] ?? 'normal'}';
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setDialogState) => AlertDialog(
          title: const Text('Gerenciar chamado'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                initialValue: status,
                decoration: const InputDecoration(labelText: 'Status'),
                items: const [
                  DropdownMenuItem(value: 'aberto', child: Text('Aberto')),
                  DropdownMenuItem(
                    value: 'em_atendimento',
                    child: Text('Em atendimento'),
                  ),
                  DropdownMenuItem(
                    value: 'aguardando_cliente',
                    child: Text('Aguardando cliente'),
                  ),
                  DropdownMenuItem(
                    value: 'resolvido',
                    child: Text('Resolvido'),
                  ),
                  DropdownMenuItem(value: 'fechado', child: Text('Fechado')),
                ],
                onChanged: (value) =>
                    setDialogState(() => status = value ?? status),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                initialValue: priority,
                decoration: const InputDecoration(labelText: 'Prioridade'),
                items: const [
                  DropdownMenuItem(value: 'baixa', child: Text('Baixa')),
                  DropdownMenuItem(value: 'normal', child: Text('Normal')),
                  DropdownMenuItem(value: 'alta', child: Text('Alta')),
                  DropdownMenuItem(value: 'urgente', child: Text('Urgente')),
                ],
                onChanged: (value) =>
                    setDialogState(() => priority = value ?? priority),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: assigned,
                decoration: const InputDecoration(
                  labelText: 'Responsável (ID do usuário)',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
    if (save == true) {
      try {
        await widget.repository.action('update_ticket', {
          'ticket_id': widget.ticket[r'$id'],
          'status': status,
          'priority': priority,
          if (assigned.text.trim().isNotEmpty)
            'assigned_to': assigned.text.trim(),
        });
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(const SnackBar(content: Text('Chamado atualizado.')));
        }
      } catch (error) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(_friendly(error))));
        }
      }
    }
    assigned.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = widget.ticket['data'] as Map? ?? const {};
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.ticket['title'] ?? 'Chamado'}'),
        actions: [
          if (widget.isAdmin)
            IconButton(
              tooltip: 'Gerenciar chamado',
              onPressed: _manage,
              icon: const Icon(Icons.manage_accounts_outlined),
            ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: RacheyColors.mint,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${data['description'] ?? ''}'),
                const SizedBox(height: 8),
                Text(
                  '${_status('${data['category'] ?? 'geral'}')} • prioridade ${_status('${data['priority'] ?? 'normal'}')}',
                  style: const TextStyle(
                    fontSize: 12,
                    color: RacheyColors.gray,
                  ),
                ),
                if (DateTime.tryParse('${widget.ticket['due_at'] ?? ''}') != null) ...[
                  const SizedBox(height: 5),
                  Builder(builder: (_) {
                    final due = DateTime.parse('${widget.ticket['due_at']}').toLocal();
                    final open = !const {'resolvido', 'fechado'}.contains('${widget.ticket['status'] ?? ''}');
                    final overdue = open && due.isBefore(DateTime.now());
                    return Text(
                      '${overdue ? 'SLA atrasado' : 'SLA'}: ${due.day.toString().padLeft(2, '0')}/${due.month.toString().padLeft(2, '0')}/${due.year} ${due.hour.toString().padLeft(2, '0')}:${due.minute.toString().padLeft(2, '0')}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: overdue ? Colors.red : RacheyColors.darkGreen,
                      ),
                    );
                  }),
                ],
                if (!widget.isAdmin && const {'resolvido', 'fechado'}.contains('${widget.ticket['status'] ?? ''}')) ...[
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _rate,
                    icon: const Icon(Icons.star_outline_rounded),
                    label: Text(
                      (data['rating'] as num?) == null
                          ? 'Avaliar atendimento'
                          : 'Avaliação: ${data['rating']}/5',
                    ),
                  ),
                ],
                if ('${data['file_id'] ?? ''}'.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () async {
                      try {
                        final fileId = '${data['file_id']}';
                        final mime =
                            '${data['mime_type'] ?? 'application/octet-stream'}';
                        final bytes = await widget.repository.downloadFile(
                          fileId,
                        );
                        await NativeBridge.saveFile(
                          name: 'rachey-anexo-$fileId${_extension(mime)}',
                          mimeType: mime,
                          bytes: bytes,
                        );
                      } catch (error) {
                        if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(_friendly(error))),
                          );
                        }
                      }
                    },
                    icon: const Icon(Icons.download_outlined),
                    label: const Text('Baixar anexo inicial'),
                  ),
                ],
              ],
            ),
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refresh,
              child: FutureBuilder<List<Map<String, dynamic>>>(
                future: _future,
                builder: (_, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  final messages = snapshot.data ?? const [];
                  if (messages.isEmpty) {
                    return ListView(
                      children: const [
                        SizedBox(height: 100),
                        Center(child: Text('Aguardando a primeira resposta.')),
                      ],
                    );
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: messages.length,
                    itemBuilder: (_, index) {
                      final row = messages[index];
                      final content = row['data'] as Map? ?? const {};
                      final team = content['sender_role'] == 'equipe';
                      return Align(
                        alignment: team
                            ? Alignment.centerLeft
                            : Alignment.centerRight,
                        child: Container(
                          constraints: const BoxConstraints(maxWidth: 360),
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.all(13),
                          decoration: BoxDecoration(
                            color: team
                                ? Theme.of(context).cardColor
                                : RacheyColors.primary,
                            borderRadius: BorderRadius.circular(17),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: .05),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if ('${content['message'] ?? ''}'.isNotEmpty)
                                Text(
                                  '${content['message']}',
                                  style: TextStyle(
                                    color: team ? null : Colors.white,
                                  ),
                                ),
                              if ('${content['file_id'] ?? ''}'.isNotEmpty) ...[
                                const SizedBox(height: 7),
                                InkWell(
                                  onTap: () async {
                                    try {
                                      final fileId = '${content['file_id']}';
                                      final mime =
                                          '${content['mime_type'] ?? 'application/octet-stream'}';
                                      final bytes = await widget.repository
                                          .downloadFile(fileId);
                                      await NativeBridge.saveFile(
                                        name:
                                            'rachey-anexo-$fileId${_extension(mime)}',
                                        mimeType: mime,
                                        bytes: bytes,
                                      );
                                    } catch (error) {
                                      if (context.mounted) {
                                        ScaffoldMessenger.of(
                                          context,
                                        ).showSnackBar(
                                          SnackBar(
                                            content: Text(_friendly(error)),
                                          ),
                                        );
                                      }
                                    }
                                  },
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.attach_file_rounded,
                                        size: 17,
                                        color: team
                                            ? RacheyColors.primary
                                            : Colors.white,
                                      ),
                                      Text(
                                        ' Baixar anexo',
                                        style: TextStyle(
                                          color: team
                                              ? RacheyColors.primary
                                              : Colors.white,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ),
          if (_attachment != null)
            Container(
              color: RacheyColors.mint,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              child: Row(
                children: [
                  const Icon(Icons.attach_file_rounded, size: 18),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _attachment!.name,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  IconButton(
                    onPressed: () => setState(() => _attachment = null),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
          if (_uploadProgress != null)
            LinearProgressIndicator(value: _uploadProgress),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 7, 8, 10),
              child: Row(
                children: [
                  if (widget.isAdmin)
                    IconButton(
                      tooltip: 'Resposta rápida',
                      onPressed: _sending ? null : _quickReply,
                      icon: const Icon(Icons.quickreply_outlined),
                    ),
                  IconButton(
                    onPressed: _sending ? null : _pick,
                    icon: const Icon(Icons.attach_file_rounded),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _message,
                      minLines: 1,
                      maxLines: 4,
                      decoration: const InputDecoration(
                        hintText: 'Digite sua resposta',
                      ),
                    ),
                  ),
                  const SizedBox(width: 7),
                  IconButton.filled(
                    onPressed: _sending ? null : _send,
                    icon: _sending
                        ? const SizedBox.square(
                            dimension: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Color _priorityColor(String value) => switch (value) {
  'urgente' => Colors.red,
  'alta' => RacheyColors.promo,
  'baixa' => RacheyColors.gray,
  _ => RacheyColors.primary,
};

String _status(String value) {
  if (value == 'todos') return 'Todos';
  final text = value.replaceAll('_', ' ');
  return text.isEmpty
      ? 'Sem status'
      : '${text[0].toUpperCase()}${text.substring(1)}';
}

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');

String _extension(String mime) {
  if (mime.startsWith('image/jpeg')) return '.jpg';
  if (mime.startsWith('image/png')) return '.png';
  if (mime.startsWith('video/')) return '.mp4';
  if (mime == 'application/pdf') return '.pdf';
  if (mime.contains('wordprocessingml')) return '.docx';
  if (mime == 'application/msword') return '.doc';
  return '';
}
