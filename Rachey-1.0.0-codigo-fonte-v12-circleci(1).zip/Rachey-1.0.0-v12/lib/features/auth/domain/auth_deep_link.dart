enum AuthDeepLinkKind { verification, recovery }

class AuthDeepLink {
  const AuthDeepLink({
    required this.kind,
    required this.userId,
    required this.secret,
  });

  final AuthDeepLinkKind kind;
  final String userId;
  final String secret;

  static bool matches(String raw, AuthDeepLinkKind kind) {
    final uri = Uri.tryParse(raw);
    return uri?.scheme == 'rachey' &&
        uri?.host == 'auth' &&
        uri?.path == _path(kind);
  }

  static AuthDeepLink? tryParse(String raw) {
    final uri = Uri.tryParse(raw);
    if (uri?.scheme != 'rachey' || uri?.host != 'auth') return null;

    final kind = switch (uri?.path) {
      '/verify' => AuthDeepLinkKind.verification,
      '/recovery' => AuthDeepLinkKind.recovery,
      _ => null,
    };
    final userId = uri?.queryParameters['userId']?.trim() ?? '';
    final secret = uri?.queryParameters['secret']?.trim() ?? '';
    if (kind == null || userId.isEmpty || secret.isEmpty) return null;

    return AuthDeepLink(kind: kind, userId: userId, secret: secret);
  }

  static String _path(AuthDeepLinkKind kind) => switch (kind) {
    AuthDeepLinkKind.verification => '/verify',
    AuthDeepLinkKind.recovery => '/recovery',
  };
}
