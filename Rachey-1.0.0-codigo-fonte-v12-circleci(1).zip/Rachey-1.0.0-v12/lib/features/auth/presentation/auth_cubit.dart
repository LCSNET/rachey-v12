import 'dart:async';

import 'package:appwrite/appwrite.dart';
import 'package:appwrite/enums.dart' as appwrite_enums;
import 'package:appwrite/models.dart' as models;
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rachey/core/config/app_config.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/settings/app_preferences.dart';
import 'package:rachey/data/datasources/appwrite_gateway.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/features/auth/domain/auth_deep_link.dart';

sealed class AuthState {
  const AuthState();
}

class AuthLoading extends AuthState {
  const AuthLoading();
}

class AuthSignedOut extends AuthState {
  const AuthSignedOut();
}

class AuthRecoveryRequired extends AuthState {
  const AuthRecoveryRequired();
}

class AuthLocked extends AuthState {
  const AuthLocked(this.name);
  final String name;
}

class AuthSignedIn extends AuthState {
  const AuthSignedIn(
    this.userId,
    this.name,
    this.email, {
    required this.isAdmin,
    required this.roles,
    required this.emailVerified,
    required this.active,
  });

  final String userId;
  final String name;
  final String email;
  final bool isAdmin;
  final List<String> roles;
  final bool emailVerified;
  final bool active;

  bool get canManageFinance =>
      isAdmin &&
      (roles.isEmpty ||
          roles.any(
            (role) => const {
              'owner',
              'admin',
              'administrador',
              'finance',
              'financeiro',
            }.contains(role.toLowerCase()),
          ));

  bool get canOperate =>
      isAdmin &&
      (roles.isEmpty ||
          roles.any(
            (role) => const {
              'owner',
              'admin',
              'administrador',
              'operator',
              'operador',
            }.contains(role.toLowerCase()),
          ));

  bool get canConfigure =>
      isAdmin &&
      (roles.isEmpty ||
          roles.any(
            (role) => const {
              'owner',
              'admin',
              'administrador',
            }.contains(role.toLowerCase()),
          ));
}

class AuthFailure extends AuthState {
  const AuthFailure(this.message);
  final String message;
}

class AuthCubit extends Cubit<AuthState> {
  AuthCubit(this.gateway, this.repository, this.preferences)
    : super(const AuthLoading());

  final AppwriteGateway gateway;
  final RacheyRepository repository;
  final AppPreferences preferences;
  static const _requestTimeout = Duration(seconds: 15);

  AuthSignedIn? _lockedUser;
  String? _recoveryUserId;
  String? _recoverySecret;
  Timer? _notificationTimer;
  bool? _localNotificationPermission;
  final Set<String> _sessionLocalNotifications = {};
  bool _oauthInProgress = false;
  Future<bool>? _oauthRestoreTask;

  Future<void> restore() async {
    emit(const AuthLoading());
    final link = await NativeBridge.initialLink();
    if (link != null &&
        AuthDeepLink.matches(link, AuthDeepLinkKind.recovery)) {
      if (_captureRecovery(link)) {
        emit(const AuthRecoveryRequired());
      } else {
        _fail('O link de recuperação é inválido ou expirou.');
      }
      return;
    }
    // A confirmação precisa ser concluída antes de consultar a sessão. Assim o
    // link também funciona quando o aplicativo é aberto a frio e a sessão
    // local já expirou.
    if (link != null &&
        AuthDeepLink.matches(link, AuthDeepLinkKind.verification)) {
      try {
        await _completeEmailVerification(link);
      } on AppwriteException catch (error) {
        _fail(error.message ?? 'O link de verificação é inválido ou expirou.');
        return;
      } on FormatException catch (error) {
        _fail(error.message);
        return;
      }
    }
    try {
      final userTask = gateway.account.get().timeout(_requestTimeout);
      final meTask = repository.action('me').timeout(const Duration(seconds: 7));
      final user = await userTask;
      final signed = await _signedState(user, meTask: meTask);
      final protected =
          preferences.biometricsEnabled || await NativeBridge.hasPin();
      if (protected) {
        _lockedUser = signed;
        emit(AuthLocked(user.name));
      } else {
        await _finishSignIn(signed);
      }
    } catch (_) {
      if (!isClosed) emit(const AuthSignedOut());
    }
  }

  Future<void> processPendingLink() async {
    final link = await NativeBridge.initialLink();
    if (link == null || link.isEmpty) return;
    if (AuthDeepLink.matches(link, AuthDeepLinkKind.recovery)) {
      if (_captureRecovery(link)) {
        emit(const AuthRecoveryRequired());
      } else {
        _fail('O link de recuperação é inválido ou expirou.');
      }
      return;
    }
    if (AuthDeepLink.matches(link, AuthDeepLinkKind.verification)) {
      try {
        await _completeEmailVerification(link);
        await restore();
      } on AppwriteException catch (error) {
        _fail(error.message ?? 'O link de verificação é inválido ou expirou.');
      } on FormatException catch (error) {
        _fail(error.message);
      }
    }
  }

  /// Chamado quando o Android volta do navegador. O CallbackActivity do
  /// Appwrite entrega o OAuth ao plugin antes de esta tela ser retomada, mas a
  /// sessão pode levar alguns instantes para aparecer no SDK. As tentativas
  /// curtas abaixo evitam o comportamento antigo em que era preciso fechar e
  /// abrir o aplicativo para enxergar a conta já autenticada.
  Future<void> handleAppResumed() async {
    await processPendingLink();
    if (!_oauthInProgress ||
        state is AuthSignedIn ||
        state is AuthLocked ||
        state is AuthRecoveryRequired) {
      return;
    }
    await _restoreOAuthSession(showFailure: false);
  }

  Future<bool> _restoreOAuthSession({required bool showFailure}) {
    final current = _oauthRestoreTask;
    if (current != null) return current;
    final task = _restoreOAuthSessionImpl(showFailure: showFailure);
    _oauthRestoreTask = task;
    task.whenComplete(() {
      if (identical(_oauthRestoreTask, task)) _oauthRestoreTask = null;
    });
    return task;
  }

  Future<bool> _restoreOAuthSessionImpl({required bool showFailure}) async {
    Object? lastError;
    for (var attempt = 0; attempt < 8; attempt++) {
      try {
        final userTask = gateway.account
            .get()
            .timeout(const Duration(seconds: 6));
        final meTask = repository.action('me').timeout(const Duration(seconds: 6));
        final user = await userTask;
        final signed = await _signedState(user, meTask: meTask);
        final protected =
            preferences.biometricsEnabled || await NativeBridge.hasPin();
        if (protected) {
          _lockedUser = signed;
          if (!isClosed) emit(AuthLocked(user.name));
        } else {
          await _finishSignIn(signed);
        }
        return true;
      } catch (error) {
        lastError = error;
        if (attempt < 7) {
          await Future<void>.delayed(
            Duration(milliseconds: 250 + (attempt * 180)),
          );
        }
      }
    }
    if (showFailure && !isClosed) {
      final message = lastError is TimeoutException
          ? 'O Google autorizou a conta, mas o servidor demorou para concluir a sessão. Tente novamente.'
          : 'O Google autorizou a conta, mas não foi possível recuperar a sessão. Tente novamente.';
      _fail(message);
    }
    return false;
  }

  Future<AuthSignedIn> _signedState(
    models.User user, {
    Future<Map<String, dynamic>>? meTask,
  }) async {
    var isAdmin = false;
    var roles = <String>[];
    var active = true;
    try {
      final me = await (meTask ?? repository.action('me'))
          .timeout(const Duration(seconds: 7));
      isAdmin = me['isAdmin'] == true;
      roles = (me['roles'] as List<dynamic>? ?? const [])
          .map((role) => '$role')
          .toList();
      active = me['active'] != false;
    } catch (_) {
      try {
        final team = await gateway.teams
            .get(teamId: AppConfig.adminTeamId)
            .timeout(_requestTimeout);
        isAdmin = team.$id == AppConfig.adminTeamId;
      } catch (_) {
        isAdmin = false;
      }
    }
    return AuthSignedIn(
      user.$id,
      user.name,
      user.email,
      isAdmin: isAdmin,
      roles: roles,
      emailVerified: user.emailVerification,
      active: active,
    );
  }

  /// Após existir uma sessão válida, conta e permissões são consultadas em
  /// paralelo. Antes eram duas viagens de rede sequenciais no caminho crítico.
  Future<AuthSignedIn> _loadSignedStateAfterSession() async {
    final userTask = gateway.account.get().timeout(const Duration(seconds: 8));
    final meTask = repository.action('me').timeout(const Duration(seconds: 7));
    final user = await userTask;
    return _signedState(user, meTask: meTask);
  }

  Future<void> _finishSignIn(AuthSignedIn signed) async {
    if (!signed.active && !signed.isAdmin) {
      try {
        await gateway.account.deleteSession(sessionId: 'current');
      } catch (_) {}
      if (!isClosed) emit(const AuthFailure('Sua conta está desativada. Entre em contato com o suporte.'));
      return;
    }
    // A tela entra imediatamente. A manutenção do schema não pode atrasar o
    // login do administrador; se falhar, o próprio painel oferece reparo.
    if (!isClosed) emit(signed);
    if (signed.isAdmin) {
      unawaited(
        repository
            .action('bootstrap_schema')
            .timeout(const Duration(seconds: 20))
            .catchError((_) => <String, dynamic>{}),
      );
    }
    unawaited(
      repository
          .action('upsert_profile', {'nome': signed.name})
          .catchError((_) => <String, dynamic>{}),
    );
    unawaited(repository.syncPending());
    _startLocalNotifications(signed.userId);
  }

  void _startLocalNotifications(String userId) {
    _notificationTimer?.cancel();
    unawaited(_deliverLocalNotifications(userId));
    _notificationTimer = Timer.periodic(
      const Duration(minutes: 5),
      (_) => unawaited(_deliverLocalNotifications(userId)),
    );
  }

  Future<void> _deliverLocalNotifications(String userId) async {
    if (!preferences.localNotificationsEnabled) return;
    _localNotificationPermission ??=
        await NativeBridge.requestNotificationPermission();
    if (_localNotificationPermission != true) return;
    try {
      final seen = {
        ...preferences.localNotificationHistory(),
        ..._sessionLocalNotifications,
      };
      final notifications = await repository.list(
        type: 'notification',
        ownerId: userId,
        limit: 100,
      );
      final pending = notifications
          .where(
            (item) => item.payload['lida'] != true && !seen.contains(item.id),
          )
          .take(3)
          .toList();
      for (final item in pending) {
        await NativeBridge.showLocalNotification(
          id: item.id.hashCode & 0x7fffffff,
          title: '${item.payload['titulo'] ?? 'Rachey'}',
          body:
              '${item.payload['mensagem'] ?? 'Você tem uma nova atualização.'}',
        );
      }
      _sessionLocalNotifications.addAll(pending.map((item) => item.id));
      await preferences.markLocalNotifications(pending.map((item) => item.id));
    } catch (_) {
      // A notificação dentro do aplicativo continua disponível.
    }
  }

  Future<void> unlockWithBiometrics() async {
    final user = _lockedUser;
    if (user == null) return;
    final accepted = await NativeBridge.authenticate(
      reason: 'Desbloqueie sua sessão do Rachey',
    );
    if (accepted) {
      _lockedUser = null;
      await _finishSignIn(user);
    } else if (!isClosed) {
      emit(const AuthFailure('Não foi possível confirmar sua identidade.'));
      emit(AuthLocked(user.name));
    }
  }

  Future<bool> unlockWithPin(String pin) async {
    final user = _lockedUser;
    if (user == null) return false;
    final accepted = await NativeBridge.verifyPin(pin);
    if (accepted) {
      _lockedUser = null;
      await _finishSignIn(user);
    }
    return accepted;
  }

  Future<void> login(String email, String password) async {
    emit(const AuthLoading());
    try {
      await gateway.account
          .createEmailPasswordSession(email: email.trim(), password: password)
          .timeout(_requestTimeout);
      // Não chama restore() novamente: a sessão já foi criada e reler deep
      // links + sessão duplicava requisições e aumentava perceptivelmente o
      // tempo de entrada. Consultamos a conta uma única vez e liberamos a UI.
      final signed = await _loadSignedStateAfterSession();
      final protected = preferences.biometricsEnabled || await NativeBridge.hasPin();
      if (protected) {
        _lockedUser = signed;
        if (!isClosed) emit(AuthLocked(signed.name));
      } else {
        await _finishSignIn(signed);
      }
    } on AppwriteException catch (error) {
      _fail(error.message ?? 'Não foi possível entrar.');
    } on TimeoutException {
      _fail('O servidor demorou para responder. Tente novamente.');
    } catch (_) {
      _fail('Sem conexão com o servidor. Verifique sua internet.');
    }
  }

  Future<void> loginWithGoogle() async {
    emit(const AuthLoading());
    _oauthInProgress = true;
    try {
      await gateway.account.createOAuth2Session(
        provider: appwrite_enums.OAuthProvider.google,
      );
      // Em alguns aparelhos o callback fecha o navegador antes de a sessão
      // recém-criada ficar visível ao SDK. O lifecycle também chama a mesma
      // rotina enquanto o Future acima termina; a tarefa é deduplicada.
      if (state is! AuthSignedIn && state is! AuthLocked) {
        await _restoreOAuthSession(showFailure: true);
      }
    } on AppwriteException catch (error) {
      _fail(
        error.message ?? 'O login com Google ainda não está disponível no Appwrite.',
      );
    } on TimeoutException {
      _fail('O servidor demorou para concluir o login com Google. Tente novamente.');
    } catch (_) {
      _fail('Não foi possível concluir o login social.');
    } finally {
      _oauthInProgress = false;
    }
  }

  String _requireRedirect(String value, String purpose) {
    final raw = value.trim();
    final uri = Uri.tryParse(raw);
    if (raw.isEmpty || uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      throw StateError(
        'Configure a URL HTTPS de $purpose no build do Rachey e cadastre o hostname em Project > Platforms no Appwrite.',
      );
    }
    return raw;
  }

  Future<void> register(String name, String email, String password) async {
    emit(const AuthLoading());
    try {
      // Valide antes de criar a conta para nunca concluir um cadastro sem que
      // exista um destino HTTPS válido para o e-mail de confirmação.
      final verificationUrl = _requireRedirect(
        AppConfig.emailVerificationUrl,
        'verificação de e-mail',
      );
      await gateway.account
          .create(
            userId: ID.unique(),
            email: email.trim(),
            password: password,
            name: name.trim(),
          )
          .timeout(_requestTimeout);
      await gateway.account.createEmailPasswordSession(
        email: email.trim(),
        password: password,
      );
      await gateway.account.createEmailVerification(url: verificationUrl);
      final signed = await _loadSignedStateAfterSession();
      await _finishSignIn(signed);
    } on AppwriteException catch (error) {
      _fail(error.message ?? 'Não foi possível criar a conta.');
    } on TimeoutException {
      _fail('O servidor demorou para responder. Tente novamente.');
    } on StateError catch (error) {
      _fail(error.message);
    } catch (_) {
      _fail('Sem conexão com o servidor. Verifique sua internet.');
    }
  }

  Future<void> requestRecovery(String email) async {
    await gateway.account.createRecovery(
      email: email.trim(),
      url: _requireRedirect(AppConfig.passwordRecoveryUrl, 'recuperação de senha'),
    );
  }

  bool _captureRecovery(String raw) {
    final link = AuthDeepLink.tryParse(raw);
    if (link?.kind != AuthDeepLinkKind.recovery) return false;
    _recoveryUserId = link!.userId;
    _recoverySecret = link.secret;
    return true;
  }

  Future<void> completeRecovery(String password) async {
    final userId = _recoveryUserId;
    final secret = _recoverySecret;
    if (userId == null || secret == null) {
      _fail('O link de recuperação é inválido ou expirou.');
      return;
    }
    emit(const AuthLoading());
    try {
      await gateway.account.updateRecovery(
        userId: userId,
        secret: secret,
        password: password,
      );
      _recoveryUserId = null;
      _recoverySecret = null;
      emit(const AuthSignedOut());
    } on AppwriteException catch (error) {
      _fail(error.message ?? 'Não foi possível alterar a senha.');
    }
  }

  Future<void> sendVerification() => gateway.account.createEmailVerification(
    url: _requireRedirect(
      AppConfig.emailVerificationUrl,
      'verificação de e-mail',
    ),
  );

  Future<void> _completeEmailVerification(String raw) async {
    final link = AuthDeepLink.tryParse(raw);
    if (link?.kind != AuthDeepLinkKind.verification) {
      throw const FormatException(
        'O link de verificação é inválido ou expirou.',
      );
    }
    await gateway.account.updateEmailVerification(
      userId: link!.userId,
      secret: link.secret,
    );
  }

  Future<List<models.Session>> sessions() async {
    final result = await gateway.account.listSessions();
    return result.sessions;
  }

  Future<void> deleteSession(String sessionId) =>
      gateway.account.deleteSession(sessionId: sessionId);

  Future<void> logout() async {
    _notificationTimer?.cancel();
    try {
      await gateway.account
          .deleteSession(sessionId: 'current')
          .timeout(_requestTimeout);
    } catch (_) {
      // A interface sai da sessão mesmo quando a conexão termina antes.
    } finally {
      _lockedUser = null;
      if (!isClosed) emit(const AuthSignedOut());
    }
  }

  void _fail(String message) {
    if (!isClosed) emit(AuthFailure(message));
  }

  @override
  Future<void> close() {
    _notificationTimer?.cancel();
    return super.close();
  }
}
