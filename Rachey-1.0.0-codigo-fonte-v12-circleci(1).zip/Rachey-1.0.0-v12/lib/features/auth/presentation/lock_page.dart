import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/features/auth/presentation/auth_cubit.dart';

class LockPage extends StatefulWidget {
  const LockPage({required this.state, super.key});

  final AuthLocked state;

  @override
  State<LockPage> createState() => _LockPageState();
}

class _LockPageState extends State<LockPage> {
  final _pin = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _pin.dispose();
    super.dispose();
  }

  Future<void> _biometrics() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    await context.read<AuthCubit>().unlockWithBiometrics();
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _unlockPin() async {
    if (_pin.text.length < 4) {
      setState(() => _error = 'Digite seu PIN de 4 a 8 números.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final accepted = await context.read<AuthCubit>().unlockWithPin(_pin.text);
    if (!mounted) return;
    setState(() {
      _busy = false;
      if (!accepted) _error = 'PIN incorreto.';
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const CircleAvatar(
                      radius: 34,
                      backgroundColor: RacheyColors.mint,
                      child: Icon(
                        Icons.lock_person_rounded,
                        size: 34,
                        color: RacheyColors.primary,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      'Sessão protegida',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'Olá, ${widget.state.name}. Confirme sua identidade.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: RacheyColors.gray),
                    ),
                    const SizedBox(height: 24),
                    TextField(
                      controller: _pin,
                      obscureText: true,
                      keyboardType: TextInputType.number,
                      maxLength: 8,
                      textAlign: TextAlign.center,
                      onSubmitted: (_) => _unlockPin(),
                      decoration: const InputDecoration(
                        labelText: 'PIN',
                        counterText: '',
                        prefixIcon: Icon(Icons.pin_outlined),
                      ),
                    ),
                    if (_error != null) ...[
                      const SizedBox(height: 10),
                      Text(
                        _error!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                    ],
                    const SizedBox(height: 14),
                    FilledButton(
                      onPressed: _busy ? null : _unlockPin,
                      child: _busy
                          ? const SizedBox.square(
                              dimension: 22,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text('Desbloquear com PIN'),
                    ),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: _busy ? null : _biometrics,
                      icon: const Icon(Icons.fingerprint_rounded),
                      label: const Text('Usar biometria'),
                    ),
                    TextButton(
                      onPressed: _busy
                          ? null
                          : () => context.read<AuthCubit>().logout(),
                      child: const Text('Sair desta conta'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  );
}
