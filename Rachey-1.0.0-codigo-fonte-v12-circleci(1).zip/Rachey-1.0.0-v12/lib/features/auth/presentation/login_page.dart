import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/features/auth/presentation/auth_cubit.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _name = TextEditingController();
  final _confirmation = TextEditingController();
  bool _register = false;
  bool _hidden = true;
  String? _localError;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    _confirmation.dispose();
    super.dispose();
  }

  void _submit(AuthState state) {
    setState(() => _localError = null);
    if (state is AuthRecoveryRequired) {
      if (_password.text.length < 8) {
        setState(
          () => _localError = 'Use uma senha com pelo menos 8 caracteres.',
        );
      } else if (_password.text != _confirmation.text) {
        setState(() => _localError = 'As senhas não são iguais.');
      } else {
        context.read<AuthCubit>().completeRecovery(_password.text);
      }
      return;
    }
    if (!_email.text.contains('@') || _password.text.length < 8) {
      setState(
        () => _localError =
            'Informe um e-mail válido e uma senha de 8 caracteres.',
      );
      return;
    }
    if (_register && _name.text.trim().isEmpty) {
      setState(() => _localError = 'Informe seu nome.');
      return;
    }
    if (_register) {
      context.read<AuthCubit>().register(
        _name.text,
        _email.text,
        _password.text,
      );
    } else {
      context.read<AuthCubit>().login(_email.text, _password.text);
    }
  }

  Future<void> _forgotPassword() async {
    final controller = TextEditingController(text: _email.text);
    final send = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Recuperar senha'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.emailAddress,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'E-mail da conta',
            prefixIcon: Icon(Icons.alternate_email_rounded),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Enviar link'),
          ),
        ],
      ),
    );
    if (send != true || !mounted) {
      controller.dispose();
      return;
    }
    try {
      await context.read<AuthCubit>().requestRecovery(controller.text);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Se a conta existir, o Appwrite enviará o link de recuperação.',
            ),
          ),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
      }
    } finally {
      controller.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AuthCubit>().state;
    final recovery = state is AuthRecoveryRequired;
    final message =
        _localError ?? (state is AuthFailure ? state.message : null);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 460),
              child: AutofillGroup(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Hero(
                        tag: 'rachey-logo',
                        child: Container(
                          width: 72,
                          height: 72,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                RacheyColors.primary,
                                RacheyColors.darkGreen,
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: RacheyColors.primary.withValues(
                                  alpha: .25,
                                ),
                                blurRadius: 22,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: const Text(
                            'R',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              fontSize: 40,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 28),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 250),
                      child: Text(
                        recovery
                            ? 'Defina uma nova senha'
                            : _register
                            ? 'Crie sua conta'
                            : 'Bem-vindo ao Rachey',
                        key: ValueKey('$recovery-$_register'),
                        style: Theme.of(context).textTheme.headlineMedium
                            ?.copyWith(fontWeight: FontWeight.w900),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      recovery
                          ? 'O link foi validado pelo Appwrite. Use uma senha forte.'
                          : _register
                          ? 'Gerencie suas assinaturas, pagamentos e acessos com segurança.'
                          : 'Entre com sua conta de cliente ou administrador.',
                      style: const TextStyle(color: RacheyColors.gray),
                    ),
                    const SizedBox(height: 28),
                    if (_register && !recovery) ...[
                      TextField(
                        controller: _name,
                        autofillHints: const [AutofillHints.name],
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          labelText: 'Nome',
                          prefixIcon: Icon(Icons.person_outline_rounded),
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                    if (!recovery) ...[
                      TextField(
                        controller: _email,
                        autofillHints: const [AutofillHints.email],
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                          labelText: 'E-mail',
                          prefixIcon: Icon(Icons.alternate_email_rounded),
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                    TextField(
                      controller: _password,
                      autofillHints: [
                        recovery || _register
                            ? AutofillHints.newPassword
                            : AutofillHints.password,
                      ],
                      obscureText: _hidden,
                      textInputAction: recovery
                          ? TextInputAction.next
                          : TextInputAction.done,
                      onSubmitted: recovery ? null : (_) => _submit(state),
                      decoration: InputDecoration(
                        labelText: recovery ? 'Nova senha' : 'Senha',
                        prefixIcon: const Icon(Icons.lock_outline_rounded),
                        suffixIcon: IconButton(
                          tooltip: _hidden ? 'Mostrar senha' : 'Ocultar senha',
                          onPressed: () => setState(() => _hidden = !_hidden),
                          icon: Icon(
                            _hidden
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                          ),
                        ),
                      ),
                    ),
                    if (recovery) ...[
                      const SizedBox(height: 12),
                      TextField(
                        controller: _confirmation,
                        autofillHints: const [AutofillHints.newPassword],
                        obscureText: true,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => _submit(state),
                        decoration: const InputDecoration(
                          labelText: 'Confirmar nova senha',
                          prefixIcon: Icon(Icons.verified_user_outlined),
                        ),
                      ),
                    ],
                    if (!_register && !recovery)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: _forgotPassword,
                          child: const Text('Esqueci minha senha'),
                        ),
                      ),
                    if (message != null) ...[
                      const SizedBox(height: 8),
                      Semantics(
                        liveRegion: true,
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(
                              context,
                            ).colorScheme.errorContainer.withValues(alpha: .55),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            message,
                            style: TextStyle(
                              color: Theme.of(context).colorScheme.error,
                            ),
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 18),
                    FilledButton(
                      onPressed: () => _submit(state),
                      child: Text(
                        recovery
                            ? 'Salvar nova senha'
                            : _register
                            ? 'Criar conta'
                            : 'Entrar',
                      ),
                    ),
                    if (!recovery) ...[
                      const SizedBox(height: 18),
                      const Row(
                        children: [
                          Expanded(child: Divider()),
                          Padding(
                            padding: EdgeInsets.symmetric(horizontal: 12),
                            child: Text(
                              'ou continue com',
                              style: TextStyle(color: RacheyColors.gray),
                            ),
                          ),
                          Expanded(child: Divider()),
                        ],
                      ),
                      const SizedBox(height: 14),
                      OutlinedButton.icon(
                        onPressed: state is AuthLoading
                            ? null
                            : () => context
                                  .read<AuthCubit>()
                                  .loginWithGoogle(),
                        icon: const Text(
                          'G',
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 18,
                          ),
                        ),
                        label: const Text('Entrar com o Google'),
                      ),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: () => setState(() {
                          _register = !_register;
                          _localError = null;
                        }),
                        child: Text(
                          _register
                              ? 'Já tenho uma conta'
                              : 'Ainda não tenho conta',
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
