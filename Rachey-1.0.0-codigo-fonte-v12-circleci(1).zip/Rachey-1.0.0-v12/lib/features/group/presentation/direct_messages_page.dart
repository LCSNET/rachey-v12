import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';

class DirectMessagesPage extends StatefulWidget {
  const DirectMessagesPage({
    required this.repository,
    required this.userId,
    required this.isAdmin,
    super.key,
  });

  final RacheyRepository repository;
  final String userId;
  final bool isAdmin;

  @override
  State<DirectMessagesPage> createState() => _DirectMessagesPageState();
}

class _DirectMessagesPageState extends State<DirectMessagesPage> {
  Map<String, dynamic>? _state;
  Object? _error;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    unawaited(_load());
  }

  Future<void> _load() async {
    try {
      final data = await widget.repository.action('direct_action', {'operation': 'state'});
      if (!mounted) return;
      setState(() {
        _state = data;
        _error = null;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error;
        _loading = false;
      });
    }
  }

  List<Map<String, dynamic>> get _threads => (_state?['threads'] as List? ?? const [])
      .whereType<Map>()
      .map((row) => Map<String, dynamic>.from(row))
      .toList();

  List<Map<String, dynamic>> get _contacts => (_state?['contacts'] as List? ?? const [])
      .whereType<Map>()
      .map((row) => Map<String, dynamic>.from(row))
      .toList();

  Future<void> _newConversation() async {
    final selected = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const ListTile(
              title: Text('Nova mensagem privada', style: TextStyle(fontWeight: FontWeight.w900)),
              subtitle: Text('Escolha um participante ou administrador.'),
            ),
            ..._contacts.map((contact) => ListTile(
                  leading: _DirectAvatar(
                    repository: widget.repository,
                    fileId: '${contact['photo_id'] ?? ''}',
                    label: '${contact['name'] ?? 'Contato'}',
                  ),
                  title: Text('${contact['name'] ?? 'Contato'}'),
                  subtitle: contact['is_admin'] == true ? const Text('Administrador') : const Text('Participante'),
                  onTap: () => Navigator.pop(context, contact),
                )),
          ],
        ),
      ),
    );
    if (selected == null || !mounted) return;
    try {
      final opened = await widget.repository.action('direct_action', {
        'operation': 'open',
        'target_user_id': '${selected['user_id']}',
      });
      if (!mounted) return;
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => DirectChatPage(
            repository: widget.repository,
            userId: widget.userId,
            threadId: '${opened['thread_id']}',
            targetUserId: '${selected['user_id']}',
            title: '${selected['name'] ?? 'Conversa'}',
            photoId: '${selected['photo_id'] ?? ''}',
            botThread: false,
          ),
        ),
      );
      await _load();
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    }
  }

  Future<void> _openThread(Map<String, dynamic> thread) async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DirectChatPage(
          repository: widget.repository,
          userId: widget.userId,
          threadId: '${thread[r'$id']}',
          targetUserId: '${thread['contact_user_id']}',
          title: '${thread['contact_name'] ?? 'Conversa'}',
          photoId: '${thread['contact_photo_id'] ?? ''}',
          botThread: thread['bot_thread'] == true,
        ),
      ),
    );
    await _load();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Mensagens privadas')),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: _loading ? null : _newConversation,
          icon: const Icon(Icons.edit_outlined),
          label: const Text('Nova conversa'),
        ),
        body: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(_friendly(_error!), textAlign: TextAlign.center),
                        const SizedBox(height: 12),
                        FilledButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('Tentar novamente')),
                      ]),
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _load,
                    child: _threads.isEmpty
                        ? ListView(children: const [
                            SizedBox(height: 120),
                            Icon(Icons.forum_outlined, size: 56, color: RacheyColors.gray),
                            SizedBox(height: 12),
                            Center(child: Text('Nenhuma conversa privada ainda.')),
                          ])
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
                            itemCount: _threads.length,
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemBuilder: (_, index) {
                              final thread = _threads[index];
                              final unread = (thread['unread'] as num?)?.toInt() ?? 0;
                              return ListTile(
                                leading: _DirectAvatar(
                                  repository: widget.repository,
                                  fileId: '${thread['contact_photo_id'] ?? ''}',
                                  label: '${thread['contact_name'] ?? 'Contato'}',
                                  bot: thread['bot_thread'] == true,
                                ),
                                title: Text('${thread['contact_name'] ?? 'Contato'}', style: TextStyle(fontWeight: unread > 0 ? FontWeight.w900 : FontWeight.w700)),
                                subtitle: Text('${thread['last_message'] ?? ''}', maxLines: 1, overflow: TextOverflow.ellipsis),
                                trailing: unread > 0
                                    ? CircleAvatar(radius: 12, backgroundColor: RacheyColors.primary, child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)))
                                    : const Icon(Icons.chevron_right),
                                onTap: () => _openThread(thread),
                              );
                            },
                          ),
                  ),
      );
}

class DirectChatPage extends StatefulWidget {
  const DirectChatPage({
    required this.repository,
    required this.userId,
    required this.threadId,
    required this.targetUserId,
    required this.title,
    required this.photoId,
    required this.botThread,
    super.key,
  });

  final RacheyRepository repository;
  final String userId;
  final String threadId;
  final String targetUserId;
  final String title;
  final String photoId;
  final bool botThread;

  @override
  State<DirectChatPage> createState() => _DirectChatPageState();
}

class _DirectChatPageState extends State<DirectChatPage> {
  final _message = TextEditingController();
  final _scroll = ScrollController();
  Timer? _timer;
  List<Map<String, dynamic>> _messages = const [];
  bool _loading = true;
  bool _sending = false;
  Map<String, dynamic>? _attachment;

  @override
  void initState() {
    super.initState();
    unawaited(_load(scroll: true));
    _timer = Timer.periodic(const Duration(seconds: 4), (_) => unawaited(_load()));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _message.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load({bool scroll = false}) async {
    try {
      final data = await widget.repository.action('direct_action', {
        'operation': 'messages',
        'thread_id': widget.threadId,
      });
      if (!mounted) return;
      final rows = (data['messages'] as List? ?? const [])
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .toList();
      final changed = rows.length != _messages.length;
      setState(() {
        _messages = rows;
        _loading = false;
      });
      if (scroll || changed) _scrollToEnd();
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scroll.hasClients) return;
      _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 220), curve: Curves.easeOut);
    });
  }

  Future<void> _pickImage() async {
    final file = await NativeBridge.pickFile(mimeTypes: const ['image/*']);
    if (file == null || !mounted) return;
    try {
      final uploaded = await widget.repository.uploadFile(file: file, type: 'mensagem_privada');
      if (!mounted) return;
      setState(() => _attachment = {
            'file_id': uploaded.id,
            'name': uploaded.name,
            'mime_type': uploaded.mimeType,
            'size': uploaded.size,
          });
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    }
  }

  Future<void> _send() async {
    if (widget.botThread || _sending) return;
    final text = _message.text.trim();
    if (text.isEmpty && _attachment == null) return;
    setState(() => _sending = true);
    try {
      await widget.repository.action('direct_action', {
        'operation': 'send',
        'target_user_id': widget.targetUserId,
        'text': text,
        if (_attachment != null) 'attachment': _attachment,
      });
      _message.clear();
      setState(() => _attachment = null);
      await _load(scroll: true);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          titleSpacing: 4,
          title: Row(children: [
            _DirectAvatar(repository: widget.repository, fileId: widget.photoId, label: widget.title, bot: widget.botThread),
            const SizedBox(width: 10),
            Expanded(child: Text(widget.title, overflow: TextOverflow.ellipsis)),
          ]),
        ),
        body: Column(children: [
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.all(12),
                    itemCount: _messages.length,
                    itemBuilder: (_, index) {
                      final item = _messages[index];
                      final mine = '${item['sender_id'] ?? ''}' == widget.userId;
                      final bot = '${item['sender_role'] ?? ''}' == 'bot';
                      final attachment = item['attachment'] is Map ? Map<String, dynamic>.from(item['attachment']) : null;
                      return Align(
                        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              if (!mine) ...[
                                _DirectAvatar(repository: widget.repository, fileId: '${item['sender_photo_id'] ?? ''}', label: '${item['sender_name'] ?? 'Contato'}', bot: bot, radius: 15),
                                const SizedBox(width: 6),
                              ],
                              Flexible(
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                                  decoration: BoxDecoration(
                                    color: mine ? RacheyColors.mint : Theme.of(context).colorScheme.surfaceContainerHighest,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                    if (!mine) Text('${item['sender_name'] ?? 'Contato'}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                                    if ('${item['text'] ?? ''}'.isNotEmpty) Text('${item['text']}'),
                                    if (attachment != null && '${attachment['file_id'] ?? ''}'.isNotEmpty)
                                      Padding(
                                        padding: const EdgeInsets.only(top: 6),
                                        child: FutureBuilder<Uint8List>(
                                          future: widget.repository.imageFile('${attachment['file_id']}', width: 560, height: 560),
                                          builder: (_, snapshot) => snapshot.hasData
                                              ? ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(snapshot.data!, width: 220, fit: BoxFit.cover))
                                              : const SizedBox(width: 180, height: 90, child: Center(child: CircularProgressIndicator())),
                                        ),
                                      ),
                                  ]),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          if (_attachment != null)
            ListTile(
              dense: true,
              leading: const Icon(Icons.image_outlined),
              title: Text('${_attachment!['name'] ?? 'Imagem'}'),
              trailing: IconButton(onPressed: () => setState(() => _attachment = null), icon: const Icon(Icons.close)),
            ),
          if (widget.botThread)
            const SafeArea(top: false, child: Padding(padding: EdgeInsets.all(14), child: Text('Esta conversa é usada pelo Rachey Bot para avisos privados.', textAlign: TextAlign.center)))
          else
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
                child: Row(children: [
                  IconButton(onPressed: _sending ? null : _pickImage, tooltip: 'Galeria', icon: const Icon(Icons.photo_library_outlined)),
                  Expanded(child: TextField(controller: _message, minLines: 1, maxLines: 5, decoration: const InputDecoration(hintText: 'Mensagem privada'))),
                  const SizedBox(width: 6),
                  IconButton.filled(onPressed: _sending ? null : _send, icon: _sending ? const SizedBox.square(dimension: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send_rounded)),
                ]),
              ),
            ),
        ]),
      );
}

class _DirectAvatar extends StatelessWidget {
  const _DirectAvatar({required this.repository, required this.fileId, required this.label, this.bot = false, this.radius = 20});
  final RacheyRepository repository;
  final String fileId;
  final String label;
  final bool bot;
  final double radius;

  @override
  Widget build(BuildContext context) {
    if (bot) return CircleAvatar(radius: radius, backgroundColor: RacheyColors.mint, child: const Icon(Icons.smart_toy_outlined, color: RacheyColors.primary));
    if (fileId.isNotEmpty) {
      return FutureBuilder<Uint8List>(
        future: repository.imageFile(fileId, width: 160, height: 160),
        builder: (_, snapshot) => CircleAvatar(
          radius: radius,
          backgroundImage: snapshot.hasData ? MemoryImage(snapshot.data!) : null,
          child: snapshot.hasData ? null : Text(label.isEmpty ? '?' : label.characters.first.toUpperCase()),
        ),
      );
    }
    return CircleAvatar(radius: radius, child: Text(label.isEmpty ? '?' : label.characters.first.toUpperCase()));
  }
}

String _friendly(Object error) {
  final value = '$error'.replaceFirst('AppwriteException: ', '');
  return value.length > 260 ? '${value.substring(0, 260)}…' : value;
}
