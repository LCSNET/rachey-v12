import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/widgets/rachey_ui.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/features/group/presentation/direct_messages_page.dart';
import 'package:url_launcher/url_launcher.dart';

class GroupPage extends StatefulWidget {
  const GroupPage({
    required this.repository,
    required this.userId,
    this.isAdmin = false,
    super.key,
  });

  final RacheyRepository repository;
  final String userId;
  final bool isAdmin;

  @override
  State<GroupPage> createState() => _GroupPageState();
}

class _GroupPageState extends State<GroupPage> {
  final _message = TextEditingController();
  final _search = TextEditingController();
  final _scroll = ScrollController();
  final _attemptedDownloads = <String>{};
  Timer? _poller;
  Map<String, dynamic>? _state;
  Map<String, dynamic>? _attachment;
  Map<String, dynamic>? _replyingTo;
  Object? _error;
  bool _loading = true;
  bool _refreshing = false;
  bool _sending = false;
  bool _recording = false;
  bool _autoSaving = false;
  bool _searching = false;
  late bool _autoDownload;
  double? _uploadProgress;
  String _channel = 'todos';

  @override
  void initState() {
    super.initState();
    _autoDownload = widget.repository.groupAutoDownload;
    unawaited(_load(scrollToEnd: true));
    _poller = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!_refreshing && mounted) unawaited(_load(silent: true));
    });
  }

  @override
  void dispose() {
    _poller?.cancel();
    if (_recording) unawaited(NativeBridge.cancelAudioRecording());
    _message.dispose();
    _search.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load({bool silent = false, bool scrollToEnd = false}) async {
    if (_refreshing) return;
    _refreshing = true;
    if (!silent && mounted) setState(() => _loading = _state == null);
    try {
      final value = await widget.repository.action('group_action', {
        'operation': 'state',
      });
      if (!mounted) return;
      final previousCount = _messages.length;
      setState(() {
        _state = value;
        _error = null;
        _loading = false;
      });
      final shouldScroll = scrollToEnd || _messages.length > previousCount;
      if (shouldScroll) _scrollToEnd();
      if (_autoDownload) unawaited(_saveNewMedia());
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error;
        _loading = false;
      });
    } finally {
      _refreshing = false;
    }
  }

  List<Map<String, dynamic>> get _messages =>
      (_state?['messages'] as List<dynamic>? ?? const [])
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();

  List<Map<String, dynamic>> get _visibleMessages {
    final channelRows = _channel == 'todos'
        ? _messages
        : _messages.where((item) => '${item['channel'] ?? 'geral'}' == _channel).toList();
    final query = _search.text.trim().toLowerCase();
    if (query.isEmpty) return channelRows;
    return channelRows.where((item) {
      final special = item['special'] as Map? ?? const {};
      final haystack = [
        item['text'], item['sender_name'], item['channel'], item['message_type'],
        special['title'], special['prize'], special['message'], special['description'], special['location'],
      ].whereType<Object>().join(' ').toLowerCase();
      return haystack.contains(query);
    }).toList();
  }

  Map<String, dynamic> get _settings => Map<String, dynamic>.from(
    _state?['settings'] as Map? ?? const <String, dynamic>{},
  );

  List<Map<String, dynamic>> get _quickReplies =>
      (_state?['quick_replies'] as List<dynamic>? ?? const [])
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();

  List<Map<String, dynamic>> get _adminTargets =>
      (_state?['admin_targets'] as List<dynamic>? ?? const [])
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();

  Future<void> _pickQuickReply() async {
    if (_quickReplies.isEmpty) {
      _toast(widget.isAdmin
          ? 'Nenhuma mensagem pré-configurada para administradores.'
          : 'Nenhuma mensagem pré-configurada para clientes.');
      return;
    }
    final selected = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            ListTile(
              title: Text(widget.isAdmin ? 'Mensagens rápidas do administrador' : 'Mensagens rápidas do cliente', style: const TextStyle(fontWeight: FontWeight.w900)),
              subtitle: const Text('Toque para colocar a mensagem no campo de digitação.'),
            ),
            ..._quickReplies.map((row) => ListTile(
                  leading: const Icon(Icons.quickreply_outlined),
                  title: Text('${row['title'] ?? 'Mensagem'}'),
                  subtitle: Text('${row['text'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis),
                  onTap: () => Navigator.pop(context, row),
                )),
          ],
        ),
      ),
    );
    if (selected == null || !mounted) return;
    _message.text = '${selected['text'] ?? ''}';
    _message.selection = TextSelection.collapsed(offset: _message.text.length);
    setState(() {});
  }

  Future<void> _openDirectMessages() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => DirectMessagesPage(
          repository: widget.repository,
          userId: widget.userId,
          isAdmin: widget.isAdmin,
        ),
      ),
    );
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_scroll.hasClients) return;
      _scroll.animateTo(
        _scroll.position.maxScrollExtent,
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOut,
      );
    });
  }

  Future<void> _saveNewMedia() async {
    if (_autoSaving || !_autoDownload) return;
    _autoSaving = true;
    try {
      final downloaded = widget.repository.groupDownloadedFiles();
      for (final item in _messages) {
        if (!mounted || !_autoDownload) break;
        final attachment = item['attachment'];
        if (attachment is! Map) continue;
        final fileId = '${attachment['file_id'] ?? ''}';
        if (fileId.isEmpty ||
            downloaded.contains(fileId) ||
            _attemptedDownloads.contains(fileId)) {
          continue;
        }
        _attemptedDownloads.add(fileId);
        try {
          final bytes = await widget.repository.downloadFile(fileId);
          final saved = await NativeBridge.saveToDownloads(
            name: _safeFileName('${attachment['name'] ?? 'rachey-arquivo'}'),
            mimeType:
                '${attachment['mime_type'] ?? 'application/octet-stream'}',
            bytes: bytes,
          );
          if (saved) {
            downloaded.add(fileId);
            await widget.repository.markGroupFileDownloaded(fileId);
          }
        } catch (_) {
          // A mensagem continua disponível e o usuário pode tentar manualmente.
        }
      }
    } finally {
      _autoSaving = false;
    }
  }

  Future<void> _pickAttachment() async {
    final kind = await showModalBottomSheet<_AttachmentKind>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(
              title: Text(
                'Enviar mídia',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: Text(
                'O arquivo ficará no servidor por tempo limitado.',
              ),
            ),
            for (final kind in _AttachmentKind.values)
              ListTile(
                leading: Icon(kind.icon, color: RacheyColors.primary),
                title: Text(kind.label),
                onTap: () => Navigator.pop(context, kind),
              ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
    if (kind == null || !mounted) return;
    final file = await NativeBridge.pickFile(mimeTypes: [kind.mime]);
    if (file == null || !mounted) return;
    setState(() => _uploadProgress = 0);
    try {
      final uploaded = await widget.repository.uploadFile(
        file: file,
        type: kind.backendType,
        publicRead: true,
        onProgress: (value) {
          if (mounted) setState(() => _uploadProgress = value / 100);
        },
      );
      if (!mounted) return;
      setState(() {
        _attachment = {
          'file_id': uploaded.id,
          'type': kind.backendType,
          'name': uploaded.name,
          'mime_type': uploaded.mimeType,
          'size': uploaded.size,
        };
        _uploadProgress = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _uploadProgress = null);
      _toast(_friendly(error));
    }
  }

  Future<void> _toggleRecording() async {
    if (_sending) return;
    try {
      if (!_recording) {
        final started = await NativeBridge.startAudioRecording();
        if (!started || !mounted) return;
        setState(() {
          _recording = true;
        });
        return;
      }
      final file = await NativeBridge.stopAudioRecording();
      if (!mounted) return;
      setState(() {
        _recording = false;
      });
      if (file == null) return;
      setState(() => _uploadProgress = 0);
      final uploaded = await widget.repository.uploadFile(
        file: file,
        type: 'grupo_audio',
        publicRead: true,
        onProgress: (value) {
          if (mounted) setState(() => _uploadProgress = value / 100);
        },
      );
      if (!mounted) return;
      setState(() {
        _attachment = {
          'file_id': uploaded.id,
          'type': 'grupo_audio',
          'name': uploaded.name,
          'mime_type': uploaded.mimeType,
          'size': uploaded.size,
        };
        _uploadProgress = null;
      });
      _toast('Áudio gravado. Toque em enviar para publicar.');
    } catch (error) {
      if (mounted) {
        setState(() {
          _recording = false;
            _uploadProgress = null;
        });
        _toast(_friendly(error));
      }
    }
  }

  Future<void> _setNotifications() async {
    var current = '${(_state?['my_state'] as Map? ?? const {})['notifications'] ?? 'mentions'}';
    final selected = await showDialog<String>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: const Text('Notificações do grupo'),
        children: [
          for (final entry in const {
            'all': 'Todas as mensagens',
            'admins': 'Somente administradores',
            'mentions': 'Somente menções e @todos',
            'none': 'Silencioso',
          }.entries)
            RadioListTile<String>(
              value: entry.key,
              groupValue: current,
              title: Text(entry.value),
              onChanged: (value) => Navigator.pop(dialogContext, value),
            ),
        ],
      ),
    );
    if (selected == null) return;
    try {
      await widget.repository.action('group_action', {
        'operation': 'save_member_preferences',
        'notifications': selected,
      });
      await _load(silent: true);
      _toast('Preferência de notificações salva.');
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<void> _createAdminContent() async {
    final type = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(title: Text('Publicar no grupo', style: TextStyle(fontWeight: FontWeight.w900))),
            ListTile(leading: const Icon(Icons.poll_outlined), title: const Text('Enquete'), onTap: () => Navigator.pop(context, 'poll')),
            ListTile(leading: const Icon(Icons.help_outline_rounded), title: const Text('Pergunta'), onTap: () => Navigator.pop(context, 'question')),
            ListTile(leading: const Icon(Icons.campaign_outlined), title: const Text('Aviso'), onTap: () => Navigator.pop(context, 'announcement')),
            ListTile(leading: const Icon(Icons.event_outlined), title: const Text('Evento'), onTap: () => Navigator.pop(context, 'event')),
            ListTile(leading: const Icon(Icons.celebration_outlined), title: const Text('Sorteio'), onTap: () => Navigator.pop(context, 'raffle')),
            ListTile(leading: const Icon(Icons.alternate_email_rounded), title: const Text('Mensagem com @todos'), onTap: () { Navigator.pop(context); _message.text = '@todos '; }),
          ],
        ),
      ),
    );
    if (type == null || !mounted) return;
    try {
      if (type == 'question') {
        final controller = TextEditingController();
        final ok = await _textInputDialog('Nova pergunta', 'Pergunta para o grupo', controller);
        if (ok && controller.text.trim().isNotEmpty) {
          await widget.repository.action('group_action', {'operation': 'create_question', 'question': controller.text.trim()});
        }
        controller.dispose();
      } else if (type == 'poll') {
        final question = TextEditingController();
        final options = TextEditingController();
        final ok = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Nova enquete'),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: question, decoration: const InputDecoration(labelText: 'Pergunta')),
              const SizedBox(height: 10),
              TextField(controller: options, minLines: 3, maxLines: 7, decoration: const InputDecoration(labelText: 'Opções', helperText: 'Uma opção por linha')),
            ]),
            actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Publicar'))],
          ),
        );
        if (ok == true) {
          await widget.repository.action('group_action', {
            'operation': 'create_poll',
            'question': question.text.trim(),
            'options': options.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
          });
        }
        question.dispose(); options.dispose();
      } else if (type == 'announcement') {
        final title = TextEditingController(text: 'Aviso da equipe');
        final message = TextEditingController();
        var notifyAll = true;
        final ok = await showDialog<bool>(
          context: context,
          builder: (context) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
            title: const Text('Novo aviso'),
            content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: title, decoration: const InputDecoration(labelText: 'Título')),
              const SizedBox(height: 10),
              TextField(controller: message, minLines: 3, maxLines: 10, decoration: const InputDecoration(labelText: 'Mensagem *')),
              SwitchListTile(contentPadding: EdgeInsets.zero, value: notifyAll, onChanged: (v) => setLocal(() => notifyAll = v), title: const Text('Notificar todos')),
            ])),
            actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Publicar'))],
          )),
        );
        if (ok == true && message.text.trim().isNotEmpty) {
          await widget.repository.action('group_action', {'operation': 'create_announcement', 'title': title.text.trim(), 'message': message.text.trim(), 'notify_all': notifyAll, 'pinned': true});
        }
        title.dispose(); message.dispose();
      } else if (type == 'event') {
        final title = TextEditingController();
        final description = TextEditingController();
        final location = TextEditingController();
        DateTime? startsAt;
        DateTime? endsAt;
        var notifyAll = true;
        Future<DateTime?> pickDateTime(DateTime? current) async {
          final now = DateTime.now();
          final date = await showDatePicker(context: context, firstDate: DateTime(now.year, now.month, now.day), lastDate: DateTime(now.year + 3), initialDate: current ?? now.add(const Duration(days: 1)));
          if (date == null || !mounted) return null;
          final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(current ?? now.add(const Duration(hours: 1))));
          if (time == null) return null;
          return DateTime(date.year, date.month, date.day, time.hour, time.minute);
        }
        final ok = await showDialog<bool>(
          context: context,
          builder: (context) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(
            title: const Text('Novo evento'),
            content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: title, decoration: const InputDecoration(labelText: 'Título *')),
              const SizedBox(height: 10),
              TextField(controller: description, minLines: 2, maxLines: 7, decoration: const InputDecoration(labelText: 'Descrição')),
              const SizedBox(height: 10),
              TextField(controller: location, decoration: const InputDecoration(labelText: 'Local/link (opcional)')),
              const SizedBox(height: 10),
              ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.event_available_rounded), title: Text(startsAt == null ? 'Selecionar início *' : _formatDateTime(startsAt!)), onTap: () async { final value = await pickDateTime(startsAt); if (value != null) setLocal(() => startsAt = value); }),
              ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.event_busy_rounded), title: Text(endsAt == null ? 'Selecionar término (opcional)' : _formatDateTime(endsAt!)), onTap: () async { final value = await pickDateTime(endsAt); if (value != null) setLocal(() => endsAt = value); }),
              SwitchListTile(contentPadding: EdgeInsets.zero, value: notifyAll, onChanged: (v) => setLocal(() => notifyAll = v), title: const Text('Notificar todos')),
            ])),
            actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: startsAt == null ? null : () => Navigator.pop(context, true), child: const Text('Publicar'))],
          )),
        );
        if (ok == true && startsAt != null && title.text.trim().isNotEmpty) {
          await widget.repository.action('group_action', {'operation': 'create_event', 'title': title.text.trim(), 'description': description.text.trim(), 'location': location.text.trim(), 'starts_at': startsAt!.toUtc().toIso8601String(), if (endsAt != null) 'ends_at': endsAt!.toUtc().toIso8601String(), 'notify_all': notifyAll});
        }
        title.dispose(); description.dispose(); location.dispose();
      } else if (type == 'raffle') {
        final title = TextEditingController(text: 'Sorteio Rachey');
        final prize = TextEditingController();
        DateTime? endAt;
        final serviceId = TextEditingController();
        final minDays = TextEditingController(text: '0');
        final winners = TextEditingController(text: '1');
        var activeOnly = false;
        final ok = await showDialog<bool>(
          context: context,
          builder: (context) => StatefulBuilder(
            builder: (context, setLocalState) => AlertDialog(
              title: const Text('Novo sorteio'),
              content: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextField(controller: title, decoration: const InputDecoration(labelText: 'Título')),
                  const SizedBox(height: 10),
                  TextField(controller: prize, decoration: const InputDecoration(labelText: 'Prêmio *')),
                  const SizedBox(height: 10),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.event_rounded),
                    title: Text(endAt == null ? 'Selecionar data e hora do término *' : _formatDateTime(endAt!)),
                    onTap: () async {
                      final now = DateTime.now();
                      final date = await showDatePicker(context: context, firstDate: DateTime(now.year, now.month, now.day), lastDate: DateTime(now.year + 3), initialDate: endAt ?? now.add(const Duration(days: 1)));
                      if (date == null || !mounted) return;
                      final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(endAt ?? now.add(const Duration(hours: 1))));
                      if (time == null) return;
                      setLocalState(() => endAt = DateTime(date.year, date.month, date.day, time.hour, time.minute));
                    },
                  ),
                  const SizedBox(height: 10),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: activeOnly,
                    onChanged: (value) => setLocalState(() => activeOnly = value),
                    title: const Text('Somente assinantes ativos'),
                  ),
                  TextField(controller: serviceId, decoration: const InputDecoration(labelText: 'ID do serviço exigido (opcional)')),
                  const SizedBox(height: 10),
                  TextField(controller: minDays, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Mínimo de dias já ativo')),
                  const SizedBox(height: 10),
                  TextField(controller: winners, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantidade de ganhadores')),
                ]),
              ),
              actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: endAt == null ? null : () => Navigator.pop(context, true), child: const Text('Publicar'))],
            ),
          ),
        );
        if (ok == true && endAt != null) {
          await widget.repository.action('group_action', {
            'operation': 'create_raffle', 'title': title.text.trim(), 'prize': prize.text.trim(),
            if (endAt != null) 'end_at': endAt!.toUtc().toIso8601String(),
            'active_subscription_only': activeOnly,
            if (serviceId.text.trim().isNotEmpty) 'service_id': serviceId.text.trim(),
            'min_active_days': int.tryParse(minDays.text.trim()) ?? 0,
            'winners_count': int.tryParse(winners.text.trim()) ?? 1,
          });
        }
        title.dispose(); prize.dispose(); serviceId.dispose(); minDays.dispose(); winners.dispose();
      }
      await _load(silent: true, scrollToEnd: true);
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<bool> _textInputDialog(String title, String label, TextEditingController controller) async =>
      await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(title),
          content: TextField(controller: controller, minLines: 2, maxLines: 6, decoration: InputDecoration(labelText: label)),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Publicar'))],
        ),
      ) ?? false;

  Future<void> _specialAction(String operation, Map<String, dynamic> item, [Map<String, dynamic> extra = const {}]) async {
    try {
      await widget.repository.action('group_action', {'operation': operation, 'row_id': item[r'$id'], ...extra});
      await _load(silent: true);
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<void> _send() async {
    if (_sending) return;
    final text = _message.text.trim();
    if (text.isEmpty && _attachment == null) return;
    setState(() => _sending = true);
    try {
      final response = await widget.repository.action('group_action', {
        'operation': 'send',
        'text': text,
        'channel': _channel == 'todos' ? 'geral' : _channel,
        if (_attachment != null) 'attachment': _attachment,
        if (_replyingTo != null) 'reply_to': _replyingTo![r'$id'],
      });
      _message.clear();
      setState(() {
        _attachment = null;
        _replyingTo = null;
      });
      if (response['status'] == 'pendente') {
        _toast('Mensagem enviada para aprovação.');
      }
      await _load(silent: true, scrollToEnd: true);
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _download(Map<dynamic, dynamic> attachment) async {
    final fileId = '${attachment['file_id'] ?? ''}';
    if (fileId.isEmpty) return;
    _toast('Preparando o arquivo…');
    try {
      final bytes = await widget.repository.downloadFile(fileId);
      final saved = await NativeBridge.saveFile(
        name: _safeFileName('${attachment['name'] ?? 'rachey-arquivo'}'),
        mimeType: '${attachment['mime_type'] ?? 'application/octet-stream'}',
        bytes: bytes,
      );
      if (saved) {
        await widget.repository.markGroupFileDownloaded(fileId);
        if (mounted) _toast('Arquivo salvo no dispositivo.');
      }
    } catch (error) {
      if (mounted) _toast('A mídia expirou ou não pôde ser baixada.');
    }
  }

  Future<void> _messageAction(String action, Map<String, dynamic> item) async {
    if (action == 'reply') {
      setState(() => _replyingTo = item);
      return;
    }
    if (action == 'edit') {
      final controller = TextEditingController(text: '${item['text'] ?? ''}');
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Editar mensagem'),
          content: TextField(
            controller: controller,
            minLines: 2,
            maxLines: 6,
            autofocus: true,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      );
      if (confirmed == true) {
        await _runAction('edit', item, {'text': controller.text.trim()});
      }
      controller.dispose();
      return;
    }
    if (action == 'report') {
      final controller = TextEditingController();
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Denunciar mensagem'),
          content: TextField(
            controller: controller,
            minLines: 2,
            maxLines: 5,
            decoration: const InputDecoration(labelText: 'Motivo'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Enviar'),
            ),
          ],
        ),
      );
      if (confirmed == true) {
        await _runAction('report', item, {
          'reason': controller.text.trim().isEmpty
              ? 'Conteúdo inadequado'
              : controller.text.trim(),
        });
        _toast('Denúncia enviada à moderação.');
      }
      controller.dispose();
      return;
    }
    if (action == 'mute' || action == 'ban') {
      await _runModeration(action, item);
      return;
    }
    await _runAction(action, item, {
      if (action == 'pin') 'pinned': item['pinned'] != true,
    });
  }

  Future<void> _runAction(
    String operation,
    Map<String, dynamic> item, [
    Map<String, dynamic> extra = const {},
  ]) async {
    try {
      await widget.repository.action('group_action', {
        'operation': operation,
        'row_id': item[r'$id'],
        ...extra,
      });
      await _load(silent: true);
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<void> _runModeration(
    String moderation,
    Map<String, dynamic> item,
  ) async {
    final target = '${item['owner_id'] ?? ''}';
    if (target.isEmpty) return;
    try {
      await widget.repository.action('group_action', {
        'operation': 'moderate_member',
        'moderation': moderation,
        'target_user_id': target,
        if (moderation == 'mute') 'minutes': 60,
      });
      _toast(
        moderation == 'ban'
            ? 'Membro removido e bloqueado.'
            : 'Membro silenciado por 1 hora.',
      );
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<void> _react(Map<String, dynamic> item, String emoji) async {
    await _runAction('react', item, {'emoji': emoji});
  }

  Future<void> _openOptions() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SwitchListTile(
                secondary: const Icon(Icons.download_for_offline_outlined),
                title: const Text('Salvar mídias automaticamente'),
                subtitle: const Text(
                  'Salva em Downloads/Rachey neste aparelho.',
                ),
                value: _autoDownload,
                onChanged: (value) async {
                  setState(() => _autoDownload = value);
                  setSheetState(() {});
                  await widget.repository.setGroupAutoDownload(value);
                  if (value) unawaited(_saveNewMedia());
                },
              ),
              ListTile(
                leading: const Icon(Icons.notifications_active_outlined),
                title: const Text('Notificações do grupo'),
                subtitle: Text(_notificationLabel('${(_state?['my_state'] as Map? ?? const {})['notifications'] ?? 'mentions'}')),
                onTap: () { Navigator.pop(context); unawaited(_setNotifications()); },
              ),
              ListTile(
                leading: const Icon(Icons.refresh_rounded),
                title: const Text('Atualizar mensagens'),
                onTap: () {
                  Navigator.pop(context);
                  unawaited(_load());
                },
              ),
              if (widget.isAdmin)
                ListTile(
                  leading: const Icon(
                    Icons.admin_panel_settings_outlined,
                    color: RacheyColors.primary,
                  ),
                  title: const Text('Controles do grupo'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () {
                    Navigator.pop(context);
                    unawaited(_openAdminSettings());
                  },
                ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openAdminSettings() async {
    var mode = '${_settings['mode'] ?? 'todos'}';
    final groupName = TextEditingController(text: '${_settings['name'] ?? 'Grupo Rachey'}');
    final description = TextEditingController(text: '${_settings['description'] ?? ''}');
    final blockedTerms = TextEditingController(text: (_settings['bot_blocked_terms'] as List? ?? const []).join(', '));
    final rulesText = TextEditingController(text: '${_settings['rules_text'] ?? ''}');
    var imageId = '${_settings['image_file_id'] ?? ''}'.isEmpty ? null : '${_settings['image_file_id']}';
    var announceSubscriptions = _settings['announce_subscriptions'] == true;
    var renewalReminders = _settings['renewal_reminders'] == true;
    var botEnabled = _settings['bot_enabled'] == true;
    var botAutoDelete = _settings['bot_auto_delete'] != false;
    var botReplyAdmin = _settings['bot_reply_admin_mention'] != false;
    var botAlertAdmin = _settings['bot_alert_admin'] != false;
    var botCreateTicket = _settings['bot_create_ticket_on_admin_mention'] != false;
    var botAutoMute = _settings['bot_auto_mute'] != false;
    var botAutoBan = _settings['bot_auto_ban'] == true;
    var botPassiveObserver = _settings['bot_passive_observer'] != false;
    var botAutoReplyClients = _settings['bot_auto_reply_clients'] != false;
    var botCanMute = _settings['bot_can_mute'] == true;
    var botCanBan = _settings['bot_can_ban'] == true;
    var botCanDelete = _settings['bot_can_delete'] != false;
    var botAdminCommands = _settings['bot_admin_commands'] != false;
    var botNaturalAdminCommands = _settings['bot_natural_admin_commands'] != false;
    var allowMemberDm = _settings['allow_member_dm'] != false;
    var allowClientAdminDm = _settings['allow_client_admin_dm'] != false;
    final privateAdmins = <String>{...(_settings['bot_private_admin_ids'] as List? ?? const []).map((e) => '$e')};
    var allowLinks = _settings['allow_links'] != false;
    var allowImages = _settings['allow_images'] != false;
    var allowVideos = _settings['allow_videos'] != false;
    var allowAudio = _settings['allow_audio'] != false;
    var allowDocuments = _settings['allow_documents'] != false;
    var retention = (_settings['media_retention_days'] as num?)?.round() ?? 7;
    var slowMode = (_settings['slow_mode_seconds'] as num?)?.round() ?? 0;
    final save = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setLocalState) => SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(
              20,
              4,
              20,
              MediaQuery.viewInsetsOf(context).bottom + 24,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Text(
                  'Controles do grupo',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  '${_state?['open_reports'] ?? 0} denúncia(s) aguardando análise',
                  style: const TextStyle(color: RacheyColors.gray),
                ),
                const SizedBox(height: 18),
                TextField(controller: groupName, decoration: const InputDecoration(labelText: 'Nome do grupo')),
                const SizedBox(height: 10),
                TextField(controller: description, minLines: 2, maxLines: 5, decoration: const InputDecoration(labelText: 'Descrição do grupo')),
                const SizedBox(height: 10),
                TextField(controller: rulesText, minLines: 2, maxLines: 8, decoration: const InputDecoration(labelText: 'Regras do grupo', helperText: 'O comando /regras do Rachey Bot usa este texto.')),
                const SizedBox(height: 10),
                OutlinedButton.icon(
                  onPressed: () async {
                    final file = await NativeBridge.pickFile(mimeTypes: const ['image/*']);
                    if (file == null) return;
                    try {
                      final uploaded = await widget.repository.uploadFile(file: file, type: 'grupo_imagem', publicRead: true);
                      setLocalState(() => imageId = uploaded.id);
                    } catch (error) { if (mounted) _toast(_friendly(error)); }
                  },
                  icon: const Icon(Icons.photo_camera_outlined),
                  label: Text(imageId == null ? 'Definir imagem do grupo' : 'Trocar imagem do grupo'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: mode,
                  decoration: const InputDecoration(
                    labelText: 'Quem pode conversar',
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'todos',
                      child: Text('Todos os membros'),
                    ),
                    DropdownMenuItem(
                      value: 'somente_admin',
                      child: Text('Somente administradores'),
                    ),
                    DropdownMenuItem(
                      value: 'aprovacao',
                      child: Text('Mensagens sob aprovação'),
                    ),
                    DropdownMenuItem(
                      value: 'fechado',
                      child: Text('Grupo temporariamente fechado'),
                    ),
                  ],
                  onChanged: (value) =>
                      setLocalState(() => mode = value ?? mode),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  initialValue: slowMode,
                  decoration: const InputDecoration(labelText: 'Modo lento'),
                  items: const [
                    DropdownMenuItem(value: 0, child: Text('Desativado')),
                    DropdownMenuItem(value: 10, child: Text('10 segundos')),
                    DropdownMenuItem(value: 30, child: Text('30 segundos')),
                    DropdownMenuItem(value: 60, child: Text('1 minuto')),
                    DropdownMenuItem(value: 300, child: Text('5 minutos')),
                  ],
                  onChanged: (value) =>
                      setLocalState(() => slowMode = value ?? 0),
                ),
                const SizedBox(height: 8),
                const ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    Icons.verified_user_outlined,
                    color: RacheyColors.primary,
                  ),
                  title: Text('Acesso de clientes e administradores'),
                  subtitle: Text(
                    'Todo cliente autenticado pode visualizar o grupo.',
                  ),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: allowLinks,
                  onChanged: (value) => setLocalState(() => allowLinks = value),
                  title: const Text('Permitir links'),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: allowMemberDm,
                  onChanged: (value) => setLocalState(() => allowMemberDm = value),
                  title: const Text('Permitir mensagens privadas entre participantes'),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: allowClientAdminDm,
                  onChanged: (value) => setLocalState(() => allowClientAdminDm = value),
                  title: const Text('Permitir clientes chamarem administradores no PV'),
                ),
                const Text(
                  'Tipos de arquivo permitidos',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
                Wrap(
                  spacing: 6,
                  children: [
                    FilterChip(
                      label: const Text('Imagens'),
                      selected: allowImages,
                      onSelected: (value) =>
                          setLocalState(() => allowImages = value),
                    ),
                    FilterChip(
                      label: const Text('Vídeos'),
                      selected: allowVideos,
                      onSelected: (value) =>
                          setLocalState(() => allowVideos = value),
                    ),
                    FilterChip(
                      label: const Text('Áudios'),
                      selected: allowAudio,
                      onSelected: (value) =>
                          setLocalState(() => allowAudio = value),
                    ),
                    FilterChip(
                      label: const Text('Documentos'),
                      selected: allowDocuments,
                      onSelected: (value) =>
                          setLocalState(() => allowDocuments = value),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  'Excluir mídias do servidor após $retention dia(s)',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                Slider(
                  value: retention.toDouble(),
                  min: 1,
                  max: 30,
                  divisions: 29,
                  label: '$retention dias',
                  onChanged: (value) =>
                      setLocalState(() => retention = value.round()),
                ),
                const Divider(height: 28),
                SwitchListTile(contentPadding: EdgeInsets.zero, value: announceSubscriptions, onChanged: (v) => setLocalState(() => announceSubscriptions = v), title: const Text('Mostrar novas assinaturas no grupo'), subtitle: const Text('Ex.: Fulano acabou de assinar Serviço • 30 dias.')),
                SwitchListTile(contentPadding: EdgeInsets.zero, value: renewalReminders, onChanged: (v) => setLocalState(() => renewalReminders = v), title: const Text('Lembrar vencimentos dentro do grupo'), subtitle: const Text('O aviso é privado: somente o cliente alvo e os administradores conseguem vê-lo.')),
                SwitchListTile(contentPadding: EdgeInsets.zero, value: botEnabled, onChanged: (v) => setLocalState(() => botEnabled = v), title: const Text('Rachey Bot'), subtitle: const Text('Moderação automática e assistência a menções dos admins.')),
                if (botEnabled) ...[
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botPassiveObserver, onChanged: (v) => setLocalState(() => botPassiveObserver = v), title: const Text('Observar o grupo sem precisar ser marcado'), subtitle: const Text('O bot acompanha perguntas sobre estoque, compras, pagamentos, assinaturas e suporte.')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botAutoReplyClients, onChanged: (v) => setLocalState(() => botAutoReplyClients = v), title: const Text('Responder clientes proativamente')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botAdminCommands, onChanged: (v) => setLocalState(() => botAdminCommands = v), title: const Text('Aceitar comandos dos administradores'), subtitle: const Text('/status, /pausar, /dormir, /assumir, /mutar, /banir, /promo, /pv...')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botNaturalAdminCommands, onChanged: (v) => setLocalState(() => botNaturalAdminCommands = v), title: const Text('Entender comandos em linguagem natural')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botCanDelete, onChanged: (v) => setLocalState(() => botCanDelete = v), title: const Text('Bot pode remover mensagens')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botCanMute, onChanged: (v) => setLocalState(() => botCanMute = v), title: const Text('Bot pode mutar participantes')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botCanBan, onChanged: (v) => setLocalState(() => botCanBan = v), title: const Text('Bot pode banir participantes')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botAutoDelete, onChanged: (v) => setLocalState(() => botAutoDelete = v), title: const Text('Apagar mensagens não autorizadas')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botReplyAdmin, onChanged: (v) => setLocalState(() => botReplyAdmin = v), title: const Text('Responder quando marcarem @admin')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botAlertAdmin, onChanged: (v) => setLocalState(() => botAlertAdmin = v), title: const Text('Avisar administradores quando necessário')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botCreateTicket, onChanged: (v) => setLocalState(() => botCreateTicket = v), title: const Text('Criar ticket ao marcar @admin'), subtitle: const Text('Transforma a solicitação do grupo em atendimento rastreável.')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botAutoMute, onChanged: (v) => setLocalState(() => botAutoMute = v), title: const Text('Silenciar reincidência automaticamente'), subtitle: const Text('Só atua se “Bot pode mutar” também estiver ligado.')),
                  SwitchListTile(contentPadding: EdgeInsets.zero, value: botAutoBan, onChanged: (v) => setLocalState(() => botAutoBan = v), title: const Text('Banir reincidência grave automaticamente'), subtitle: const Text('Só atua se “Bot pode banir” também estiver ligado.')),
                  if (_adminTargets.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    const Text('Administradores que o bot pode chamar no PV', style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: _adminTargets.map((admin) {
                        final id = '${admin['user_id']}';
                        return FilterChip(
                          label: Text('${admin['name'] ?? id}'),
                          selected: privateAdmins.contains(id),
                          onSelected: (selected) => setLocalState(() { if (selected) { privateAdmins.add(id); } else { privateAdmins.remove(id); } }),
                        );
                      }).toList(),
                    ),
                  ],
                  const SizedBox(height: 8),
                  TextField(controller: blockedTerms, minLines: 2, maxLines: 5, decoration: const InputDecoration(labelText: 'Termos bloqueados pelo bot', helperText: 'Separe por vírgulas')),
                ],
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: () => Navigator.pop(context, true),
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('Salvar controles'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    final groupNameValue = groupName.text.trim();
    final descriptionValue = description.text.trim();
    final rulesValue = rulesText.text.trim();
    final blockedTermsValue = blockedTerms.text
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    groupName.dispose();
    description.dispose();
    blockedTerms.dispose();
    rulesText.dispose();
    if (save != true || !mounted) return;
    try {
      await widget.repository.action('group_action', {
        'operation': 'save_settings',
        'name': groupNameValue,
        'description': descriptionValue,
        'rules_text': rulesValue,
        'image_file_id': imageId,
        'announce_subscriptions': announceSubscriptions,
        'renewal_reminders': renewalReminders,
        'bot_enabled': botEnabled,
        'bot_auto_delete': botAutoDelete,
        'bot_reply_admin_mention': botReplyAdmin,
        'bot_alert_admin': botAlertAdmin,
        'bot_create_ticket_on_admin_mention': botCreateTicket,
        'bot_auto_mute': botAutoMute,
        'bot_auto_ban': botAutoBan,
        'bot_passive_observer': botPassiveObserver,
        'bot_auto_reply_clients': botAutoReplyClients,
        'bot_can_mute': botCanMute,
        'bot_can_ban': botCanBan,
        'bot_can_delete': botCanDelete,
        'bot_admin_commands': botAdminCommands,
        'bot_natural_admin_commands': botNaturalAdminCommands,
        'bot_private_admin_ids': privateAdmins.toList(),
        'allow_member_dm': allowMemberDm,
        'allow_client_admin_dm': allowClientAdminDm,
        'bot_mute_after': 3,
        'bot_ban_after': 5,
        'bot_blocked_terms': blockedTermsValue,
        'mode': mode,
        'active_subscribers_only': false,
        'slow_mode_seconds': slowMode,
        'media_retention_days': retention,
        'allow_links': allowLinks,
        'allow_images': allowImages,
        'allow_videos': allowVideos,
        'allow_audio': allowAudio,
        'allow_documents': allowDocuments,
      });
      await _load(silent: true);
      _toast('Controles do grupo atualizados.');
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  void _toast(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) {
    final pinned = _messages.where((item) => item['pinned'] == true).lastOrNull;
    final visibleMessages = _visibleMessages;
    final allowed = _state?['allowed'] == true;
    final canSend = _state?['can_send'] == true;
    final darkMode = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      backgroundColor: darkMode
          ? const Color(0xFF091522)
          : const Color(0xFFEFF7F3),
      appBar: AppBar(
        titleSpacing: 4,
        title: Row(
          children: [
            _GroupAvatar(repository: widget.repository, fileId: '${_settings['image_file_id'] ?? ''}'),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${_settings['name'] ?? 'Grupo Rachey'}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    _modeLabel('${_settings['mode'] ?? 'todos'}'),
                    style: const TextStyle(
                      fontSize: 11,
                      color: RacheyColors.gray,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          if (widget.isAdmin)
            IconButton(tooltip: 'Publicar conteúdo', onPressed: _createAdminContent, icon: const Icon(Icons.add_circle_outline_rounded)),
          IconButton(tooltip: _searching ? 'Fechar busca' : 'Buscar no grupo', onPressed: () => setState(() { _searching = !_searching; if (!_searching) _search.clear(); }), icon: Icon(_searching ? Icons.close_rounded : Icons.search_rounded)),
          IconButton(tooltip: 'Mensagens privadas', onPressed: _openDirectMessages, icon: const Icon(Icons.forum_outlined)),
          const RacheyThemeButton(),
          IconButton(
            tooltip: 'Opções do grupo',
            onPressed: _openOptions,
            icon: const Icon(Icons.more_vert_rounded),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null && _state == null
          ? _ErrorState(message: _friendly(_error!), onRetry: _load)
          : !allowed
          ? _LockedState(
              message:
                  '${_state?['reason'] ?? 'Este grupo não está disponível para sua conta.'}',
              onRetry: _load,
            )
          : Column(
              children: [
                if (_searching)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                    child: TextField(
                      controller: _search,
                      autofocus: true,
                      onChanged: (_) => setState(() {}),
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search_rounded),
                        hintText: 'Buscar mensagens, avisos, eventos...',
                        suffixIcon: _search.text.isEmpty ? null : IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.clear_rounded)),
                      ),
                    ),
                  ),
                if (pinned != null)
                  Material(
                    color: RacheyColors.mint,
                    child: InkWell(
                      onTap: () {},
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 9,
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.push_pin_rounded,
                              color: RacheyColors.darkGreen,
                              size: 18,
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: Text(
                                '${pinned['text'] ?? 'Mensagem fixada'}',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: RacheyColors.navy,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                SizedBox(
                  height: 52,
                  child: ListView(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    children: const {
                      'todos': 'Todos',
                      'geral': 'Geral',
                      'promocoes': 'Promoções',
                      'suporte': 'Suporte',
                      'sorteios': 'Sorteios',
                      'avisos': 'Avisos',
                    }.entries.map((entry) => Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: ChoiceChip(
                        label: Text(entry.value),
                        selected: _channel == entry.key,
                        onSelected: (_) => setState(() => _channel = entry.key),
                      ),
                    )).toList(),
                  ),
                ),
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: _load,
                    child: visibleMessages.isEmpty
                        ? ListView(
                            children: const [
                              SizedBox(height: 150),
                              Icon(
                                Icons.waving_hand_rounded,
                                size: 54,
                                color: RacheyColors.primary,
                              ),
                              SizedBox(height: 12),
                              Center(
                                child: Text(
                                  'Nenhuma mensagem neste canal ainda.',
                                ),
                              ),
                            ],
                          )
                        : ListView.builder(
                            controller: _scroll,
                            padding: const EdgeInsets.fromLTRB(10, 12, 10, 16),
                            itemCount: visibleMessages.length,
                            itemBuilder: (context, index) {
                              final item = visibleMessages[index];
                              return _MessageBubble(
                                repository: widget.repository,
                                item: item,
                                isMine: item['owner_id'] == widget.userId,
                                isAdminViewer: widget.isAdmin,
                                onAttachment: _download,
                                onAction: (action) =>
                                    _messageAction(action, item),
                                onReact: (emoji) => _react(item, emoji),
                                onSpecial: (operation, extra) => _specialAction(operation, item, extra),
                              );
                            },
                          ),
                  ),
                ),
                if (_replyingTo != null)
                  _ComposerNotice(
                    icon: Icons.reply_rounded,
                    title: 'Respondendo a ${_replyingTo!['sender_name']}',
                    detail: '${_replyingTo!['text'] ?? 'Mídia'}',
                    onClose: () => setState(() => _replyingTo = null),
                  ),
                if (_attachment != null)
                  _ComposerNotice(
                    icon: Icons.attach_file_rounded,
                    title: '${_attachment!['name']}',
                    detail: _fileSize(_attachment!['size']),
                    onClose: () => setState(() => _attachment = null),
                  ),
                if (_uploadProgress != null)
                  LinearProgressIndicator(value: _uploadProgress),
                _Composer(
                  controller: _message,
                  enabled: canSend && !_sending,
                  reason: '${_state?['reason'] ?? ''}',
                  sending: _sending,
                  onQuickReply: _pickQuickReply,
                  onAttach: _pickAttachment,
                  onRecord: _toggleRecording,
                  recording: _recording,
                  onSend: _send,
                ),
              ],
            ),
    );
  }
}

class _MessageBubble extends StatelessWidget {
  const _MessageBubble({
    required this.repository,
    required this.item,
    required this.isMine,
    required this.isAdminViewer,
    required this.onAttachment,
    required this.onAction,
    required this.onReact,
    required this.onSpecial,
  });

  final RacheyRepository repository;
  final Map<String, dynamic> item;
  final bool isMine;
  final bool isAdminViewer;
  final ValueChanged<Map<dynamic, dynamic>> onAttachment;
  final ValueChanged<String> onAction;
  final ValueChanged<String> onReact;
  final Future<void> Function(String operation, Map<String, dynamic> extra) onSpecial;

  @override
  Widget build(BuildContext context) {
    final adminMessage = item['sender_role'] == 'admin';
    final bubbleTextColor = adminMessage
        ? Colors.white
        : isMine
        ? RacheyColors.navy
        : Theme.of(context).colorScheme.onSurface;
    final attachment = item['attachment'];
    final pending = item['status'] == 'pendente';
    final reactions = Map<String, dynamic>.from(
      item['reactions'] as Map? ?? const {},
    );
    return Align(
      alignment: isMine ? Alignment.centerRight : Alignment.centerLeft,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: MediaQuery.sizeOf(context).width * 0.82,
        ),
        child: Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Material(
            color: isMine
                ? RacheyColors.mint
                : adminMessage
                ? RacheyColors.navy
                : Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(17),
              topRight: const Radius.circular(17),
              bottomLeft: Radius.circular(isMine ? 17 : 4),
              bottomRight: Radius.circular(isMine ? 4 : 17),
            ),
            elevation: 0.8,
            child: InkWell(
              borderRadius: BorderRadius.circular(17),
              onLongPress: () => _showMessageMenu(context),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 9, 8, 7),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _GroupMemberAvatar(
                          repository: repository,
                          fileId: '${item['sender_photo_id'] ?? ''}',
                          label: '${item['sender_name'] ?? 'Membro'}',
                          bot: item['sender_role'] == 'bot',
                        ),
                        const SizedBox(width: 6),
                        Flexible(
                          child: Text(
                            '${item['sender_name'] ?? 'Membro'}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: adminMessage
                                  ? RacheyColors.mint
                                  : isMine
                                  ? RacheyColors.darkGreen
                                  : Theme.of(context).colorScheme.primary,
                              fontSize: 12,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        if (adminMessage) ...[
                          const SizedBox(width: 4),
                          const Icon(
                            Icons.verified_rounded,
                            size: 14,
                            color: RacheyColors.mint,
                          ),
                        ],
                      ],
                    ),
                    if (pending)
                      const Padding(
                        padding: EdgeInsets.only(top: 4),
                        child: Text(
                          'Aguardando aprovação',
                          style: TextStyle(
                            color: RacheyColors.promo,
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    if ('${item['reply_to'] ?? ''}'.isNotEmpty)
                      Container(
                        margin: const EdgeInsets.only(top: 6),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 5,
                        ),
                        decoration: BoxDecoration(
                          color: adminMessage
                              ? Colors.white.withValues(alpha: 0.10)
                              : RacheyColors.primary.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          'Resposta a uma mensagem',
                          style: TextStyle(fontSize: 11),
                        ),
                      ),
                    if ('${item['text'] ?? ''}'.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      _LinkifiedSelectableText(
                        text: '${item['text']}',
                        style: TextStyle(color: bubbleTextColor, height: 1.28),
                      ),
                    ],
                    if ('${item['message_type'] ?? 'message'}' != 'message') ...[
                      const SizedBox(height: 8),
                      _SpecialMessageContent(item: item, isAdminViewer: isAdminViewer, onAction: onSpecial),
                    ],
                    if (attachment is Map) ...[
                      const SizedBox(height: 7),
                      _AttachmentTile(
                        repository: repository,
                        attachment: attachment,
                        dark: adminMessage,
                        onTap: () => onAttachment(attachment),
                      ),
                    ],
                    const SizedBox(height: 4),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (item['edited'] == true)
                          Text(
                            'editada • ',
                            style: TextStyle(
                              fontSize: 10,
                              color: adminMessage
                                  ? Colors.white70
                                  : RacheyColors.gray,
                            ),
                          ),
                        Text(
                          _time('${item[r'$createdAt'] ?? ''}'),
                          style: TextStyle(
                            fontSize: 10,
                            color: adminMessage
                                ? Colors.white70
                                : RacheyColors.gray,
                          ),
                        ),
                        if (isMine) ...[
                          const SizedBox(width: 3),
                          Icon(
                            Icons.done_all_rounded,
                            size: 14,
                            color: adminMessage
                                ? RacheyColors.mint
                                : RacheyColors.primary,
                          ),
                        ],
                      ],
                    ),
                    if (reactions.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: Wrap(
                          spacing: 4,
                          children: reactions.entries
                              .map(
                                (entry) => ActionChip(
                                  visualDensity: VisualDensity.compact,
                                  label: Text('${entry.key} ${entry.value}'),
                                  onPressed: () => onReact(entry.key),
                                ),
                              )
                              .toList(),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showMessageMenu(BuildContext context) async {
    final value = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 54,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                scrollDirection: Axis.horizontal,
                children: ['👍', '❤️', '😂', '🎉', '😮']
                    .map(
                      (emoji) => IconButton(
                        onPressed: () => Navigator.pop(context, 'emoji:$emoji'),
                        icon: Text(emoji, style: const TextStyle(fontSize: 24)),
                      ),
                    )
                    .toList(),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.reply_rounded),
              title: const Text('Responder'),
              onTap: () => Navigator.pop(context, 'reply'),
            ),
            if (isMine)
              ListTile(
                leading: const Icon(Icons.edit_outlined),
                title: const Text('Editar'),
                onTap: () => Navigator.pop(context, 'edit'),
              ),
            if (isMine || isAdminViewer)
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.red),
                title: const Text('Excluir'),
                onTap: () => Navigator.pop(context, 'delete'),
              ),
            if (!isMine && !isAdminViewer)
              ListTile(
                leading: const Icon(Icons.flag_outlined),
                title: const Text('Denunciar'),
                onTap: () => Navigator.pop(context, 'report'),
              ),
            if (isAdminViewer) ...[
              if (item['status'] == 'pendente')
                ListTile(
                  leading: const Icon(
                    Icons.check_circle_outline,
                    color: RacheyColors.primary,
                  ),
                  title: const Text('Aprovar mensagem'),
                  onTap: () => Navigator.pop(context, 'approve'),
                ),
              ListTile(
                leading: const Icon(Icons.push_pin_outlined),
                title: Text(
                  item['pinned'] == true ? 'Desafixar' : 'Fixar mensagem',
                ),
                onTap: () => Navigator.pop(context, 'pin'),
              ),
              if (!isMine) ...[
                ListTile(
                  leading: const Icon(Icons.volume_off_outlined),
                  title: const Text('Silenciar membro por 1 hora'),
                  onTap: () => Navigator.pop(context, 'mute'),
                ),
                ListTile(
                  leading: const Icon(Icons.block, color: Colors.red),
                  title: const Text('Remover e bloquear membro'),
                  onTap: () => Navigator.pop(context, 'ban'),
                ),
              ],
            ],
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
    if (value == null) return;
    if (value.startsWith('emoji:')) {
      onReact(value.substring(6));
    } else {
      onAction(value);
    }
  }
}

class _AttachmentTile extends StatelessWidget {
  const _AttachmentTile({
    required this.repository,
    required this.attachment,
    required this.dark,
    required this.onTap,
  });

  final RacheyRepository repository;
  final Map<dynamic, dynamic> attachment;
  final bool dark;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final type = '${attachment['type'] ?? ''}';
    final fileId = '${attachment['file_id'] ?? ''}';
    if (type == 'grupo_imagem' && fileId.isNotEmpty) {
      return InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: FutureBuilder<Uint8List>(
            future: repository.imageFile(fileId, width: 900, height: 900),
            builder: (context, snapshot) => Container(
              constraints: const BoxConstraints(minHeight: 120, maxHeight: 260),
              color: RacheyColors.mint,
              child: snapshot.hasData
                  ? Image.memory(snapshot.data!, fit: BoxFit.cover)
                  : snapshot.hasError
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Imagem expirada • toque para tentar baixar',
                          style: TextStyle(color: RacheyColors.navy),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : const Center(child: CircularProgressIndicator()),
            ),
          ),
        ),
      );
    }
    final icon = switch (type) {
      'grupo_video' => Icons.play_circle_outline_rounded,
      'grupo_audio' => Icons.graphic_eq_rounded,
      _ => Icons.description_outlined,
    };
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(11),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: dark
              ? Colors.white.withValues(alpha: 0.10)
              : RacheyColors.primary.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(11),
        ),
        child: Row(
          children: [
            Icon(icon, color: dark ? Colors.white : RacheyColors.primary),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${attachment['name'] ?? 'Arquivo'}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: dark ? Colors.white : null,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    '${_fileSize(attachment['size'])} • toque para salvar',
                    style: TextStyle(
                      color: dark ? Colors.white70 : RacheyColors.gray,
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.download_rounded,
              color: dark ? Colors.white : RacheyColors.primary,
            ),
          ],
        ),
      ),
    );
  }
}

class _GroupAvatar extends StatelessWidget {
  const _GroupAvatar({required this.repository, required this.fileId});
  final RacheyRepository repository;
  final String fileId;
  @override
  Widget build(BuildContext context) {
    if (fileId.isEmpty) return const CircleAvatar(radius: 19, backgroundColor: RacheyColors.primary, child: Icon(Icons.groups_rounded, color: Colors.white, size: 21));
    return FutureBuilder<Uint8List>(
      future: repository.imageFile(fileId, width: 120, height: 120),
      builder: (_, snapshot) => CircleAvatar(
        radius: 19,
        backgroundColor: RacheyColors.primary,
        backgroundImage: snapshot.hasData ? MemoryImage(snapshot.data!) : null,
        child: snapshot.hasData ? null : const Icon(Icons.groups_rounded, color: Colors.white, size: 21),
      ),
    );
  }
}


class _LinkifiedSelectableText extends StatelessWidget {
  const _LinkifiedSelectableText({required this.text, this.style});
  final String text;
  final TextStyle? style;

  @override
  Widget build(BuildContext context) {
    final regex = RegExp(r'((?:https?://|www\.)[^\s<>]+)', caseSensitive: false);
    final spans = <InlineSpan>[];
    var cursor = 0;
    for (final match in regex.allMatches(text)) {
      if (match.start > cursor) spans.add(TextSpan(text: text.substring(cursor, match.start), style: style));
      final raw = match.group(0)!;
      final trailing = RegExp(r'[.,;:!?)]*$').firstMatch(raw)?.group(0) ?? '';
      final clean = trailing.isEmpty ? raw : raw.substring(0, raw.length - trailing.length);
      spans.add(WidgetSpan(
        alignment: PlaceholderAlignment.baseline,
        baseline: TextBaseline.alphabetic,
        child: InkWell(
          onTap: () async {
            final target = clean.startsWith('www.') ? 'https://$clean' : clean;
            final uri = Uri.tryParse(target);
            if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
          },
          child: Text(clean, style: (style ?? const TextStyle()).copyWith(color: Theme.of(context).colorScheme.primary, decoration: TextDecoration.underline, decorationColor: Theme.of(context).colorScheme.primary)),
        ),
      ));
      if (trailing.isNotEmpty) spans.add(TextSpan(text: trailing, style: style));
      cursor = match.end;
    }
    if (cursor < text.length) spans.add(TextSpan(text: text.substring(cursor), style: style));
    return SelectableText.rich(TextSpan(children: spans, style: style));
  }
}

class _SpecialMessageContent extends StatelessWidget {
  const _SpecialMessageContent({required this.item, required this.isAdminViewer, required this.onAction});
  final Map<String, dynamic> item;
  final bool isAdminViewer;
  final Future<void> Function(String operation, Map<String, dynamic> extra) onAction;
  @override
  Widget build(BuildContext context) {
    final type = '${item['message_type'] ?? ''}';
    final special = Map<String, dynamic>.from(item['special'] as Map? ?? const {});
    if (type == 'poll') {
      final options = (special['options'] as List? ?? const []).map((e) => '$e').toList();
      final votes = (special['votes'] as List? ?? const []).map((e) => (e as num?)?.round() ?? 0).toList();
      final mine = (special['my_vote'] as num?)?.round();
      final closed = special['end_at'] != null && (DateTime.tryParse('${special['end_at']}')?.isBefore(DateTime.now()) ?? false);
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if ('${special['end_at'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 6), child: Text('${closed ? 'Encerrada' : 'Encerra'}: ${_formatIso('${special['end_at']}')}', style: const TextStyle(fontSize: 11, color: RacheyColors.gray))),
        for (var i = 0; i < options.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 5),
            child: OutlinedButton.icon(
              onPressed: closed ? null : () => onAction('poll_vote', {'option': i}),
              icon: Icon(mine == i ? Icons.radio_button_checked : Icons.radio_button_off, size: 18),
              label: Row(children: [Expanded(child: Text(options[i])), Text('${i < votes.length ? votes[i] : 0}')]),
            ),
          ),
      ]);
    }
    if (type == 'raffle') {
      final winnerNames = (special['winner_names'] as List? ?? const []).map((e) => '$e').where((e) => e.isNotEmpty).toList();
      final winner = '${special['winner_name'] ?? ''}';
      final eligibility = Map<String, dynamic>.from(special['eligibility'] as Map? ?? const {});
      final minActiveDays = (eligibility['min_active_days'] as num?)?.round() ?? 0;
      final ruleParts = <String>[
        if (eligibility['active_subscription_only'] == true) 'assinatura ativa',
        if ('${eligibility['service_id'] ?? ''}'.isNotEmpty) 'serviço específico',
        if (minActiveDays > 0) 'mín. $minActiveDays dias ativo',
      ];
      return Card(
        margin: EdgeInsets.zero,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('🎁 ${special['prize'] ?? 'Prêmio'}', style: const TextStyle(fontWeight: FontWeight.w900)),
            Text('${special['entries'] ?? 0} participante(s) • ${special['winners_count'] ?? 1} ganhador(es)', style: const TextStyle(fontSize: 12)),
            if (ruleParts.isNotEmpty) Text('Regras: ${ruleParts.join(' • ')}', style: const TextStyle(fontSize: 11, color: RacheyColors.gray)),
            if ('${special['end_at'] ?? ''}'.isNotEmpty) Text('Encerra: ${_formatIso('${special['end_at']}')}', style: const TextStyle(fontSize: 11)),
            const SizedBox(height: 6),
            if (winnerNames.isNotEmpty) Text('🏆 ${winnerNames.join(', ')}', style: const TextStyle(fontWeight: FontWeight.w900))
            else if (winner.isNotEmpty) Text('🏆 Vencedor: $winner', style: const TextStyle(fontWeight: FontWeight.w900))
            else if (isAdminViewer) FilledButton.tonal(onPressed: () => onAction('raffle_draw', const {}), child: const Text('Realizar sorteio'))
            else FilledButton.tonal(onPressed: special['joined'] == true ? null : () => onAction('raffle_join', const {}), child: Text(special['joined'] == true ? 'Participando ✓' : 'Participar')),
          ]),
        ),
      );
    }

    if (type == 'announcement') {
      return Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: Colors.amber.withValues(alpha: .14), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.amber.withValues(alpha: .45))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('📣 ${special['title'] ?? item['text'] ?? 'Aviso'}', style: const TextStyle(fontWeight: FontWeight.w900)),
          if ('${special['message'] ?? ''}'.isNotEmpty) ...[const SizedBox(height: 4), _LinkifiedSelectableText(text: '${special['message']}', style: const TextStyle(height: 1.25))],
        ]),
      );
    }
    if (type == 'event') {
      return Card(
        margin: EdgeInsets.zero,
        child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('📅 ${special['title'] ?? item['text'] ?? 'Evento'}', style: const TextStyle(fontWeight: FontWeight.w900)),
          if ('${special['starts_at'] ?? ''}'.isNotEmpty) Text('Início: ${_formatIso('${special['starts_at']}')}', style: const TextStyle(fontSize: 12)),
          if ('${special['ends_at'] ?? ''}'.isNotEmpty) Text('Término: ${_formatIso('${special['ends_at']}')}', style: const TextStyle(fontSize: 12)),
          if ('${special['location'] ?? ''}'.isNotEmpty) ...[const SizedBox(height: 4), _LinkifiedSelectableText(text: 'Local: ${special['location']}', style: const TextStyle(fontSize: 12))],
          if ('${special['description'] ?? ''}'.isNotEmpty) ...[const SizedBox(height: 5), _LinkifiedSelectableText(text: '${special['description']}', style: const TextStyle(fontSize: 12))],
        ])),
      );
    }
    if (type == 'coupon') {
      return Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: RacheyColors.primary.withValues(alpha: .08), borderRadius: BorderRadius.circular(10)),
        child: Row(children: [const Icon(Icons.sell_outlined), const SizedBox(width: 8), Expanded(child: Text('Cupom: ${special['code'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.w900)))]),
      );
    }
    if (type == 'question') return const Row(children: [Icon(Icons.help_outline_rounded, size: 18), SizedBox(width: 6), Text('Pergunta da administração', style: TextStyle(fontWeight: FontWeight.w800))]);
    if (type == 'subscription_notice') return const Row(children: [Icon(Icons.celebration_rounded, size: 18), SizedBox(width: 6), Text('Nova assinatura', style: TextStyle(fontWeight: FontWeight.w800))]);
    return const SizedBox.shrink();
  }
}

class _GroupMemberAvatar extends StatelessWidget {
  const _GroupMemberAvatar({required this.repository, required this.fileId, required this.label, this.bot = false});
  final RacheyRepository repository;
  final String fileId;
  final String label;
  final bool bot;

  @override
  Widget build(BuildContext context) {
    if (bot) {
      return const CircleAvatar(
        radius: 13,
        backgroundColor: RacheyColors.mint,
        child: Icon(Icons.smart_toy_outlined, size: 15, color: RacheyColors.primary),
      );
    }
    if (fileId.isNotEmpty) {
      return FutureBuilder<Uint8List>(
        future: repository.imageFile(fileId, width: 96, height: 96),
        builder: (_, snapshot) => CircleAvatar(
          radius: 13,
          backgroundImage: snapshot.hasData ? MemoryImage(snapshot.data!) : null,
          child: snapshot.hasData ? null : Text(label.isEmpty ? '?' : label.characters.first.toUpperCase(), style: const TextStyle(fontSize: 10)),
        ),
      );
    }
    return CircleAvatar(radius: 13, child: Text(label.isEmpty ? '?' : label.characters.first.toUpperCase(), style: const TextStyle(fontSize: 10)));
  }
}

class _Composer extends StatelessWidget {
  const _Composer({
    required this.controller,
    required this.enabled,
    required this.reason,
    required this.sending,
    required this.onQuickReply,
    required this.onAttach,
    required this.onRecord,
    required this.recording,
    required this.onSend,
  });

  final TextEditingController controller;
  final bool enabled;
  final String reason;
  final bool sending;
  final VoidCallback onQuickReply;
  final VoidCallback onAttach;
  final VoidCallback onRecord;
  final bool recording;
  final VoidCallback onSend;

  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).scaffoldBackgroundColor,
    elevation: 8,
    child: SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 7),
        child: enabled
            ? Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    tooltip: 'Mensagens prontas',
                    onPressed: onQuickReply,
                    icon: const Icon(Icons.quickreply_outlined),
                  ),
                  IconButton(
                    tooltip: 'Anexar mídia',
                    onPressed: onAttach,
                    icon: const Icon(Icons.attach_file_rounded),
                  ),
                  IconButton(
                    tooltip: recording ? 'Parar gravação' : 'Gravar áudio agora',
                    onPressed: onRecord,
                    color: recording ? Colors.red : null,
                    icon: Icon(recording ? Icons.stop_circle_outlined : Icons.mic_none_rounded),
                  ),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 5,
                      textCapitalization: TextCapitalization.sentences,
                      decoration: const InputDecoration(
                        hintText: 'Mensagem',
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 7),
                  IconButton.filled(
                    tooltip: 'Enviar',
                    onPressed: sending ? null : onSend,
                    icon: sending
                        ? const SizedBox.square(
                            dimension: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.send_rounded),
                  ),
                ],
              )
            : Row(
                children: [
                  const Icon(Icons.lock_outline, color: RacheyColors.gray),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      reason.isEmpty
                          ? 'O envio está desativado pela administração.'
                          : reason,
                      style: const TextStyle(color: RacheyColors.gray),
                    ),
                  ),
                ],
              ),
      ),
    ),
  );
}

class _ComposerNotice extends StatelessWidget {
  const _ComposerNotice({
    required this.icon,
    required this.title,
    required this.detail,
    required this.onClose,
  });

  final IconData icon;
  final String title;
  final String detail;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) => Material(
    color: RacheyColors.mint,
    child: Padding(
      padding: const EdgeInsets.fromLTRB(14, 7, 6, 7),
      child: Row(
        children: [
          Icon(icon, size: 19, color: RacheyColors.darkGreen),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                Text(
                  detail,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11),
                ),
              ],
            ),
          ),
          IconButton(onPressed: onClose, icon: const Icon(Icons.close)),
        ],
      ),
    ),
  );
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.message, required this.onRetry});
  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.cloud_off_outlined, size: 54),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh),
            label: const Text('Tentar novamente'),
          ),
        ],
      ),
    ),
  );
}

class _LockedState extends StatelessWidget {
  const _LockedState({required this.message, required this.onRetry});
  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircleAvatar(
                radius: 31,
                backgroundColor: RacheyColors.mint,
                child: Icon(
                  Icons.lock_outline_rounded,
                  color: RacheyColors.primary,
                  size: 32,
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'Grupo exclusivo',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 7),
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: onRetry,
                child: const Text('Verificar novamente'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

enum _AttachmentKind {
  image('Imagem', Icons.image_outlined, 'image/*', 'grupo_imagem'),
  video('Vídeo', Icons.video_library_outlined, 'video/*', 'grupo_video'),
  audio('Áudio', Icons.audio_file_outlined, 'audio/*', 'grupo_audio'),
  document(
    'Documento',
    Icons.description_outlined,
    'application/*',
    'grupo_documento',
  );

  const _AttachmentKind(this.label, this.icon, this.mime, this.backendType);
  final String label;
  final IconData icon;
  final String mime;
  final String backendType;
}

String _modeLabel(String mode) => switch (mode) {
  'somente_admin' => 'Somente administradores',
  'aprovacao' => 'Mensagens sob aprovação',
  'fechado' => 'Grupo fechado',
  _ => 'Conversa liberada',
};

String _fileSize(dynamic raw) {
  final bytes = raw is num ? raw.toInt() : int.tryParse('$raw') ?? 0;
  if (bytes >= 1024 * 1024) {
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
  if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
  return '$bytes B';
}

String _safeFileName(String value) => value
    .replaceAll(RegExp(r'[\\/:*?"<>|]'), '_')
    .replaceAll(RegExp(r'\s+'), ' ')
    .trim();


String _formatDateTime(DateTime value) {
  final d = value.toLocal();
  String two(int v) => v.toString().padLeft(2, '0');
  return '${two(d.day)}/${two(d.month)}/${d.year} às ${two(d.hour)}:${two(d.minute)}';
}

String _formatIso(String raw) {
  final value = DateTime.tryParse(raw);
  return value == null ? raw : _formatDateTime(value);
}

String _time(String raw) {
  final date = DateTime.tryParse(raw)?.toLocal();
  if (date == null) return '';
  final now = DateTime.now();
  final hour = date.hour.toString().padLeft(2, '0');
  final minute = date.minute.toString().padLeft(2, '0');
  if (date.year == now.year && date.month == now.month && date.day == now.day) {
    return '$hour:$minute';
  }
  return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')} $hour:$minute';
}

String _friendly(Object error) {
  final value = '$error'.replaceFirst('AppwriteException: ', '');
  return value.length > 240 ? '${value.substring(0, 240)}…' : value;
}

String _notificationLabel(String value) => switch (value) {
  'all' => 'Todas as mensagens',
  'admins' => 'Somente administradores',
  'none' => 'Silencioso',
  _ => 'Somente menções e @todos',
};
