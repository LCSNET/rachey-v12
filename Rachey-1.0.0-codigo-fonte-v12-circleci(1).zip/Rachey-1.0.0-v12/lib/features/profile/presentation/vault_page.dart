import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';

class VaultPage extends StatefulWidget {
  const VaultPage({required this.repository, super.key});

  final RacheyRepository repository;

  @override
  State<VaultPage> createState() => _VaultPageState();
}

class _VaultPageState extends State<VaultPage> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final data = await widget.repository.action('list_credentials');
    return (data['rows'] as List<dynamic>? ?? const [])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Future<bool> _confirmIdentity() async {
    if (await NativeBridge.authenticate(
      reason: 'Confirme sua identidade para abrir o Cofre',
    )) {
      return true;
    }
    if (!await NativeBridge.hasPin() || !mounted) return false;
    final controller = TextEditingController();
    final entered = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('PIN do Cofre'),
        content: TextField(
          controller: controller,
          autofocus: true,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 8,
          decoration: const InputDecoration(labelText: 'PIN'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Confirmar'),
          ),
        ],
      ),
    );
    final valid =
        entered == true && await NativeBridge.verifyPin(controller.text);
    controller.dispose();
    return valid;
  }

  Future<void> _reveal(Map<String, dynamic> item) async {
    if (!await _confirmIdentity()) {
      if (mounted) _toast('Identidade não confirmada.');
      return;
    }
    if (!mounted) return;
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      final clear = await widget.repository.action('reveal_credential', {
        'credentialId': item[r'$id'],
      });
      if (!mounted) return;
      Navigator.pop(context);
      await showDialog<void>(
        context: context,
        builder: (_) => _CredentialDialog(
          identifier: '${clear['identificador'] ?? ''}',
          secret: '${clear['segredo'] ?? ''}',
          profile: '${clear['perfil'] ?? ''}',
          secondaryPin: '${clear['secondary_pin'] ?? ''}',
        ),
      );
    } catch (error) {
      if (!mounted) return;
      Navigator.pop(context);
      _toast(_friendly(error));
    }
  }

  void _toast(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Cofre de acessos'),
      actions: [
        IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh)),
      ],
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return ListView(
              children: [
                const SizedBox(height: 150),
                const Icon(
                  Icons.cloud_off_outlined,
                  size: 54,
                  color: RacheyColors.gray,
                ),
                const SizedBox(height: 12),
                Center(child: Text(_friendly(snapshot.error!))),
              ],
            );
          }
          final items = snapshot.data ?? const [];
          if (items.isEmpty) {
            return ListView(
              children: const [
                SizedBox(height: 150),
                Icon(
                  Icons.lock_outline_rounded,
                  size: 56,
                  color: RacheyColors.primary,
                ),
                SizedBox(height: 12),
                Center(child: Text('Nenhuma credencial foi liberada ainda.')),
                SizedBox(height: 6),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 30),
                  child: Text(
                    'O acesso só aparece após a aprovação e a liberação.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: RacheyColors.gray),
                  ),
                ),
              ],
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, index) {
              final item = items[index];
              final active = item['status'] == 'ativa';
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: CircleAvatar(
                    backgroundColor: active
                        ? RacheyColors.mint
                        : Theme.of(context).colorScheme.errorContainer,
                    child: Icon(
                      active ? Icons.key_rounded : Icons.lock_clock_outlined,
                      color: active
                          ? RacheyColors.primary
                          : Theme.of(context).colorScheme.error,
                    ),
                  ),
                  title: Text(
                    '${item['identificador_mascarado'] ?? 'Credencial protegida'}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text('Status: ${item['status'] ?? 'indisponível'}'),
                  trailing: FilledButton.tonal(
                    onPressed: active ? () => _reveal(item) : null,
                    child: const Text('Abrir'),
                  ),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class _CredentialDialog extends StatefulWidget {
  const _CredentialDialog({
    required this.identifier,
    required this.secret,
    required this.profile,
    required this.secondaryPin,
  });

  final String identifier;
  final String secret;
  final String profile;
  final String secondaryPin;

  @override
  State<_CredentialDialog> createState() => _CredentialDialogState();
}

class _CredentialDialogState extends State<_CredentialDialog> {
  bool _showSecret = false;

  Future<void> _copy(String value, String label) async {
    await Clipboard.setData(ClipboardData(text: value));
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('$label copiado.')));
    }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    icon: const Icon(
      Icons.shield_outlined,
      color: RacheyColors.primary,
      size: 38,
    ),
    title: const Text('Credencial protegida'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Não compartilhe estes dados. Esta visualização foi registrada na auditoria.',
            style: TextStyle(color: RacheyColors.gray),
          ),
          const SizedBox(height: 16),
          _SecretRow(
            label: 'Login',
            value: widget.identifier,
            onCopy: () => _copy(widget.identifier, 'Login'),
          ),
          const SizedBox(height: 10),
          _SecretRow(
            label: 'Senha',
            value: _showSecret ? widget.secret : '••••••••••••',
            onCopy: () => _copy(widget.secret, 'Senha'),
            onToggle: () => setState(() => _showSecret = !_showSecret),
            visible: _showSecret,
          ),
          if (widget.profile.isNotEmpty) ...[
            const SizedBox(height: 10),
            _SecretRow(label: 'Perfil/Tela', value: widget.profile),
          ],
          if (widget.secondaryPin.isNotEmpty &&
              widget.secondaryPin != 'null') ...[
            const SizedBox(height: 10),
            _SecretRow(
              label: 'PIN do serviço',
              value: widget.secondaryPin,
              onCopy: () => _copy(widget.secondaryPin, 'PIN'),
            ),
          ],
        ],
      ),
    ),
    actions: [
      FilledButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Fechar'),
      ),
    ],
  );
}

class _SecretRow extends StatelessWidget {
  const _SecretRow({
    required this.label,
    required this.value,
    this.onCopy,
    this.onToggle,
    this.visible = false,
  });

  final String label;
  final String value;
  final VoidCallback? onCopy;
  final VoidCallback? onToggle;
  final bool visible;

  @override
  Widget build(BuildContext context) => DecoratedBox(
    decoration: BoxDecoration(
      color: RacheyColors.mint,
      borderRadius: BorderRadius.circular(12),
    ),
    child: ListTile(
      title: Text(
        label,
        style: const TextStyle(fontSize: 12, color: RacheyColors.gray),
      ),
      subtitle: SelectableText(
        value,
        style: const TextStyle(
          fontWeight: FontWeight.w800,
          color: RacheyColors.navy,
        ),
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (onToggle != null)
            IconButton(
              tooltip: visible ? 'Ocultar' : 'Mostrar',
              onPressed: onToggle,
              icon: Icon(
                visible
                    ? Icons.visibility_off_outlined
                    : Icons.visibility_outlined,
              ),
            ),
          if (onCopy != null)
            IconButton(
              tooltip: 'Copiar',
              onPressed: onCopy,
              icon: const Icon(Icons.copy_rounded),
            ),
        ],
      ),
    ),
  );
}

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
