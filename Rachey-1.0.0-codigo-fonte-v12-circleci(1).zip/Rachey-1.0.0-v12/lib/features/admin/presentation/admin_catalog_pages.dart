import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/widgets/rachey_ui.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';

class AdvancedAdminDashboardPage extends StatefulWidget {
  const AdvancedAdminDashboardPage({
    required this.repository,
    required this.canManageFinance,
    this.onServices,
    this.onOrders,
    this.onPayments,
    super.key,
  });

  final RacheyRepository repository;
  final bool canManageFinance;
  final VoidCallback? onServices;
  final VoidCallback? onOrders;
  final VoidCallback? onPayments;

  @override
  State<AdvancedAdminDashboardPage> createState() =>
      _AdvancedAdminDashboardPageState();
}

class _AdvancedAdminDashboardPageState
    extends State<AdvancedAdminDashboardPage> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = widget.repository.action('dashboard');
  }

  Future<void> _refresh() async {
    setState(() {
      _future = widget.repository.action('dashboard');
    });
    await _future;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Painel administrativo'),
          Text(
            'Dados consolidados pelo Appwrite',
            style: TextStyle(fontSize: 12, color: RacheyColors.gray),
          ),
        ],
      ),
      actions: [
        const RacheyThemeButton(),
        IconButton(
          onPressed: _refresh,
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError)
            return _ErrorView(error: snapshot.error!, onRetry: _refresh);
          final data = snapshot.data ?? const {};
          final revenue = (data['revenue_cents'] as num?)?.round() ?? 0;
          final expenses = (data['expense_cents'] as num?)?.round() ?? 0;
          final cogs = (data['cogs_cents'] as num?)?.round() ?? 0;
          final profit = (data['profit_cents'] as num?)?.round() ?? 0;
          final todayRevenue = (data['today_revenue_cents'] as num?)?.round() ?? 0;
          final actions = (data['actions'] as List<dynamic>? ?? const [])
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .toList();
          final orderStatuses = Map<String, dynamic>.from(
            data['order_statuses'] as Map? ?? const {},
          );
          final maxStatus = orderStatuses.values.fold<num>(
            1,
            (max, value) => (value as num) > max ? value : max,
          );
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (widget.canManageFinance)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [RacheyColors.navy, RacheyColors.darkGreen],
                    ),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Row(
                    children: [
                      const CircleAvatar(
                        backgroundColor: Colors.white24,
                        child: Icon(
                          Icons.insights_rounded,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Lucro acumulado',
                              style: TextStyle(color: Colors.white70),
                            ),
                            Text(
                              _money(profit),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 25,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(
                        Icons.trending_up_rounded,
                        color: Colors.white,
                      ),
                    ],
                  ),
                )
              else
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: RacheyColors.navy,
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: const Row(
                    children: [
                      CircleAvatar(
                        backgroundColor: Colors.white24,
                        child: Icon(
                          Icons.admin_panel_settings_rounded,
                          color: Colors.white,
                        ),
                      ),
                      SizedBox(width: 14),
                      Expanded(
                        child: Text(
                          'Painel operacional Rachey',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              const SizedBox(height: 14),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.46,
                mainAxisSpacing: 9,
                crossAxisSpacing: 9,
                children: [
                  _DashboardMetric(
                    label: 'Clientes',
                    value: '${data['clients'] ?? 0}',
                    icon: Icons.people_outline,
                  ),
                  _DashboardMetric(
                    label: 'Pedidos',
                    value: '${data['orders'] ?? 0}',
                    icon: Icons.receipt_long_outlined,
                  ),
                  _DashboardMetric(
                    label: 'Assinaturas',
                    value: '${data['subscriptions'] ?? 0}',
                    icon: Icons.subscriptions_outlined,
                  ),
                  _DashboardMetric(
                    label: 'Renovações (7d)',
                    value: '${data['upcoming_renewals'] ?? 0}',
                    icon: Icons.autorenew_rounded,
                  ),
                  if (widget.canManageFinance)
                    _DashboardMetric(
                      label: 'Receitas',
                      value: _money(revenue),
                      icon: Icons.arrow_upward_rounded,
                      color: RacheyColors.primary,
                    ),
                  if (widget.canManageFinance)
                    _DashboardMetric(
                      label: 'Despesas',
                      value: _money(expenses),
                      icon: Icons.arrow_downward_rounded,
                      color: RacheyColors.promo,
                    ),
                ],
              ),
              const SizedBox(height: 20),
              const Text(
                'Hoje',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Wrap(
                    spacing: 18,
                    runSpacing: 14,
                    children: [
                      if (widget.canManageFinance)
                        _TodayIndicator(
                          icon: Icons.payments_outlined,
                          label: 'Faturamento',
                          value: _money(todayRevenue),
                        ),
                      _TodayIndicator(
                        icon: Icons.verified_outlined,
                        label: 'Pagamentos',
                        value: '${data['pending_payments'] ?? 0} para analisar',
                      ),
                      _TodayIndicator(
                        icon: Icons.support_agent_outlined,
                        label: 'Tickets',
                        value: '${data['open_tickets'] ?? 0} abertos',
                      ),
                      _TodayIndicator(
                        icon: Icons.event_outlined,
                        label: 'Vencimentos',
                        value: '${(data['expirations'] as Map? ?? const {})['two_days'] ?? 0} em até 2 dias',
                      ),
                    ],
                  ),
                ),
              ),
              if (widget.canManageFinance) ...[
                const SizedBox(height: 10),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.inventory_2_outlined),
                    title: const Text('Custo dos produtos/serviços'),
                    subtitle: const Text('Usado no cálculo do lucro líquido'),
                    trailing: Text(_money(cogs), style: const TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
              if (actions.isNotEmpty) ...[
                const SizedBox(height: 18),
                const Text(
                  'Ação necessária',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
                ),
                const SizedBox(height: 8),
                Card(
                  child: Column(
                    children: actions.map((item) {
                      final high = item['severity'] == 'high';
                      final type = '${item['type'] ?? ''}';
                      final callback = switch (type) {
                        'payments' => widget.onPayments,
                        'release' => widget.onOrders,
                        'expirations' => widget.onOrders,
                        _ => null,
                      };
                      return ListTile(
                        leading: Icon(
                          high ? Icons.error_outline_rounded : Icons.warning_amber_rounded,
                          color: high ? RacheyColors.promo : Colors.amber.shade700,
                        ),
                        title: Text('${item['label'] ?? 'Ação pendente'}'),
                        subtitle: Text('${item['count'] ?? 0} item(ns)'),
                        trailing: callback == null ? null : const Icon(Icons.chevron_right),
                        onTap: callback,
                      );
                    }).toList(),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              const Text(
                'Pedidos por status',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(17),
                  child: orderStatuses.isEmpty
                      ? const Text(
                          'Nenhum pedido registrado.',
                          style: TextStyle(color: RacheyColors.gray),
                        )
                      : Column(
                          children: orderStatuses.entries
                              .map(
                                (entry) => Padding(
                                  padding: const EdgeInsets.only(bottom: 12),
                                  child: Column(
                                    children: [
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(_status(entry.key)),
                                          ),
                                          Text(
                                            '${entry.value}',
                                            style: const TextStyle(
                                              fontWeight: FontWeight.w900,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 5),
                                      LinearProgressIndicator(
                                        value: (entry.value as num) / maxStatus,
                                      ),
                                    ],
                                  ),
                                ),
                              )
                              .toList(),
                        ),
                ),
              ),
              if (widget.onServices != null ||
                  widget.onOrders != null ||
                  widget.onPayments != null) ...[
                const SizedBox(height: 18),
                const Text(
                  'Ações rápidas',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
                ),
                const SizedBox(height: 9),
                Card(
                  child: Column(
                    children: [
                      if (widget.onServices != null)
                        ListTile(
                          leading: const Icon(Icons.add_business_rounded),
                          title: const Text('Cadastrar serviço'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: widget.onServices,
                        ),
                      if (widget.onServices != null &&
                          (widget.onOrders != null ||
                              widget.onPayments != null))
                        const Divider(height: 1),
                      if (widget.onOrders != null)
                        ListTile(
                          leading: const Icon(Icons.fact_check_outlined),
                          title: const Text('Analisar pedidos'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: widget.onOrders,
                        ),
                      if (widget.onOrders != null && widget.onPayments != null)
                        const Divider(height: 1),
                      if (widget.onPayments != null)
                        ListTile(
                          leading: const Icon(Icons.verified_outlined),
                          title: const Text('Aprovar pagamentos'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: widget.onPayments,
                        ),
                    ],
                  ),
                ),
              ],
            ],
          );
        },
      ),
    ),
  );
}

class AdminCategoriesPage extends StatefulWidget {
  const AdminCategoriesPage({required this.repository, super.key});

  final RacheyRepository repository;

  @override
  State<AdminCategoriesPage> createState() => _AdminCategoriesPageState();
}

class _AdminCategoriesPageState extends State<AdminCategoriesPage> {
  late Future<_CategoryData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_CategoryData> _load() async {
    final values = await Future.wait([
      widget.repository.adminList('categorias', limit: 500),
      widget.repository.action('module_list', {
        'kind': 'category_meta',
        'limit': 500,
      }),
    ]);
    final rows = _rows(values[0])
      ..sort(
        (a, b) =>
            ((a['ordem'] as num?) ?? 0).compareTo((b['ordem'] as num?) ?? 0),
      );
    return _CategoryData(rows: rows, metadata: _rows(values[1]));
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Map<String, dynamic>? _meta(_CategoryData data, String id) {
    for (final item in data.metadata) {
      if (item['reference_id'] == id) return item;
    }
    return null;
  }

  Future<void> _edit(
    _CategoryData data, [
    Map<String, dynamic>? current,
  ]) async {
    final name = TextEditingController(text: '${current?['nome'] ?? ''}');
    final slug = TextEditingController(text: '${current?['slug'] ?? ''}');
    final description = TextEditingController(
      text: '${current?['descricao'] ?? ''}',
    );
    final icon = TextEditingController(
      text:
          '${_meta(data, '${current?[r'$id'] ?? ''}')?['data']?['icon'] ?? ''}',
    );
    var active = current?['ativo'] != false;
    String? imageId = '${current?['imagem_file_id'] ?? ''}'.isEmpty
        ? null
        : '${current?['imagem_file_id']}';
    String? bannerId =
        '${_meta(data, '${current?[r'$id'] ?? ''}')?['data']?['banner_file_id'] ?? ''}'
            .isEmpty
        ? null
        : '${_meta(data, '${current?[r'$id'] ?? ''}')?['data']?['banner_file_id']}';
    double? progress;
    final save = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (_, setSheetState) => SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.viewInsetsOf(sheetContext).bottom + 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                current == null ? 'Nova categoria' : 'Editar categoria',
                style: Theme.of(
                  context,
                ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 14),
              TextField(
                controller: name,
                decoration: const InputDecoration(labelText: 'Nome *'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: slug,
                decoration: const InputDecoration(
                  labelText: 'Slug',
                  hintText: 'streaming-e-video',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: description,
                minLines: 2,
                maxLines: 5,
                decoration: const InputDecoration(labelText: 'Descrição'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: icon,
                decoration: const InputDecoration(
                  labelText: 'Ícone Material',
                  hintText: 'movie_outlined',
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: progress == null
                          ? () async {
                              final file = await NativeBridge.pickFile(
                                mimeTypes: const ['image/*'],
                              );
                              if (file == null) return;
                              setSheetState(() => progress = 0);
                              try {
                                final uploaded = await widget.repository
                                    .uploadFile(
                                      file: file,
                                      type: 'categoria_imagem',
                                      publicRead: true,
                                      onProgress: (value) => setSheetState(
                                        () => progress = value / 100,
                                      ),
                                    );
                                setSheetState(() {
                                  imageId = uploaded.id;
                                  progress = null;
                                });
                              } catch (error) {
                                setSheetState(() => progress = null);
                                if (sheetContext.mounted)
                                  ScaffoldMessenger.of(
                                    sheetContext,
                                  ).showSnackBar(
                                    SnackBar(content: Text(_friendly(error))),
                                  );
                              }
                            }
                          : null,
                      icon: const Icon(Icons.image_outlined),
                      label: Text(imageId == null ? 'Imagem' : 'Imagem pronta'),
                    ),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: progress == null
                          ? () async {
                              final file = await NativeBridge.pickFile(
                                mimeTypes: const ['image/*'],
                              );
                              if (file == null) return;
                              setSheetState(() => progress = 0);
                              try {
                                final uploaded = await widget.repository
                                    .uploadFile(
                                      file: file,
                                      type: 'categoria_banner',
                                      publicRead: true,
                                      onProgress: (value) => setSheetState(
                                        () => progress = value / 100,
                                      ),
                                    );
                                setSheetState(() {
                                  bannerId = uploaded.id;
                                  progress = null;
                                });
                              } catch (error) {
                                setSheetState(() => progress = null);
                              }
                            }
                          : null,
                      icon: const Icon(Icons.panorama_outlined),
                      label: Text(
                        bannerId == null ? 'Banner' : 'Banner pronto',
                      ),
                    ),
                  ),
                ],
              ),
              if (progress != null) ...[
                const SizedBox(height: 7),
                LinearProgressIndicator(value: progress),
              ],
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Categoria ativa'),
                value: active,
                onChanged: (value) => setSheetState(() => active = value),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: progress == null
                    ? () => Navigator.pop(sheetContext, true)
                    : null,
                child: const Text('Salvar categoria'),
              ),
            ],
          ),
        ),
      ),
    );
    if (save == true && name.text.trim().isNotEmpty) {
      try {
        final response = await widget.repository.adminCrud(
          table: 'categorias',
          operation: current == null ? 'create' : 'update',
          rowId: current?[r'$id']?.toString(),
          data: {
            'nome': name.text.trim(),
            'slug': slug.text.trim().isEmpty
                ? _slug(name.text)
                : _slug(slug.text),
            'descricao': description.text.trim(),
            if (imageId != null) 'imagem_file_id': imageId,
            'ordem': current?['ordem'] ?? data.rows.length,
            'ativo': active,
          },
        );
        final id = '${response[r'$id'] ?? current?[r'$id'] ?? ''}';
        final metadata = _meta(data, id);
        await widget.repository.saveModule(
          kind: 'category_meta',
          rowId: metadata?[r'$id']?.toString(),
          referenceId: id,
          title: name.text.trim(),
          data: {
            'icon': icon.text.trim(),
            if (bannerId != null) 'banner_file_id': bannerId,
          },
        );
        await _refresh();
      } catch (error) {
        if (mounted) _toast(_friendly(error));
      }
    }
    name.dispose();
    slug.dispose();
    description.dispose();
    icon.dispose();
  }

  Future<void> _delete(_CategoryData data, Map<String, dynamic> item) async {
    final confirmed = await _confirm(
      context,
      'Excluir categoria?',
      'Serviços relacionados devem ser reclassificados.',
    );
    if (!confirmed) return;
    try {
      final meta = _meta(data, '${item[r'$id']}');
      if (meta != null) await widget.repository.deleteModule('${meta[r'$id']}');
      await widget.repository.adminCrud(
        table: 'categorias',
        operation: 'delete',
        rowId: '${item[r'$id']}',
      );
      await _refresh();
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<void> _reorder(_CategoryData data, int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) newIndex--;
    final rows = List<Map<String, dynamic>>.from(data.rows);
    final moved = rows.removeAt(oldIndex);
    rows.insert(newIndex, moved);
    setState(
      () => _future = Future.value(
        _CategoryData(rows: rows, metadata: data.metadata),
      ),
    );
    try {
      await Future.wait(
        rows.indexed.map(
          (entry) => widget.repository.adminCrud(
            table: 'categorias',
            operation: 'update',
            rowId: '${entry.$2[r'$id']}',
            data: {'ordem': entry.$1},
          ),
        ),
      );
      await _refresh();
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  void _toast(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Categorias')),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () async {
        final data = await _future;
        if (mounted) await _edit(data);
      },
      icon: const Icon(Icons.add),
      label: const Text('Nova'),
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<_CategoryData>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorView(error: snapshot.error!, onRetry: _refresh);
          final data = snapshot.data!;
          if (data.rows.isEmpty)
            return const _EmptyView(
              icon: Icons.category_outlined,
              text: 'Nenhuma categoria cadastrada.',
            );
          return ReorderableListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            itemCount: data.rows.length,
            onReorder: (oldIndex, newIndex) =>
                _reorder(data, oldIndex, newIndex),
            itemBuilder: (_, index) {
              final item = data.rows[index];
              return Card(
                key: ValueKey(item[r'$id']),
                child: ListTile(
                  leading: CircleAvatar(child: Text('${index + 1}')),
                  title: Text(
                    '${item['nome'] ?? 'Categoria'}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text('${item['descricao'] ?? ''}'),
                  onTap: () => _edit(data, item),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        onPressed: () => _delete(data, item),
                        icon: const Icon(Icons.delete_outline),
                      ),
                      const Icon(Icons.drag_handle_rounded),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class AdminServiceEditorPage extends StatefulWidget {
  const AdminServiceEditorPage({
    required this.repository,
    this.current,
    super.key,
  });

  final RacheyRepository repository;
  final Map<String, dynamic>? current;

  @override
  State<AdminServiceEditorPage> createState() => _AdminServiceEditorPageState();
}

class _AdminServiceEditorPageState extends State<AdminServiceEditorPage> {
  late final TextEditingController _name;
  late final TextEditingController _description;
  late final TextEditingController _price;
  late final TextEditingController _promotion;
  late final TextEditingController _cashback;
  late final TextEditingController _points;
  late final TextEditingController _compatibility;
  late final TextEditingController _benefits;
  late final TextEditingController _observations;
  late final TextEditingController _faq;
  final List<Map<String, dynamic>> _periodDrafts = [];
  late final TextEditingController _order;
  Future<_ServiceEditorData>? _future;
  String? _categoryId;
  String _type = 'subscription';
  String _releaseMode = 'manual';
  bool _stockEnabled = false;
  bool _active = true;
  bool _featured = false;
  String? _imageId;
  String? _bannerId;
  double? _progress;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final current = widget.current;
    _name = TextEditingController(text: '${current?['nome'] ?? ''}');
    _description = TextEditingController(
      text: '${current?['descricao'] ?? ''}',
    );
    _price = TextEditingController(text: current?['valor']?.toString() ?? '');
    _promotion = TextEditingController();
    _cashback = TextEditingController();
    _points = TextEditingController();
    _compatibility = TextEditingController();
    _benefits = TextEditingController();
    _observations = TextEditingController();
    _faq = TextEditingController();
    _order = TextEditingController(text: '${current?['ordem'] ?? 0}');
    _categoryId = '${current?['categoria_id'] ?? ''}'.isEmpty
        ? null
        : '${current?['categoria_id']}';
    _active = current?['ativo'] != false;
    _featured = current?['dsetaque'] == true;
    _imageId = '${current?['imagem_file_id'] ?? ''}'.isEmpty
        ? null
        : '${current?['imagem_file_id']}';
    _future = _load();
  }

  Future<_ServiceEditorData> _load() async {
    // Em "Novo serviço" nunca consulta metadados sem reference_id. Antes,
    // essa consulta retornava o primeiro service_meta do banco e preenchia o
    // formulário novo com um serviço existente.
    final categories = await widget.repository.adminList('categorias', limit: 500);
    Map<String, dynamic>? metadata;
    if (widget.current != null) {
      final response = await widget.repository.action('module_list', {
        'kind': 'service_meta',
        'reference_id': widget.current![r'$id'],
        'limit': 20,
      });
      final metadataRows = _rows(response);
      metadata = metadataRows.isEmpty ? null : metadataRows.first;
    }
    final data = Map<String, dynamic>.from(
      metadata?['data'] as Map? ?? const {},
    );
    _type = '${data['service_type'] ?? 'subscription'}';
    _releaseMode = '${data['release_mode'] ?? 'manual'}';
    _stockEnabled = data['stock_enabled'] == true;
    _promotion.text = '${data['promotion_percent'] ?? ''}';
    _cashback.text = '${data['cashback_percent'] ?? ''}';
    _points.text = '${data['points'] ?? ''}';
    _benefits.text = (data['benefits'] as List? ?? const []).join('\n');
    _compatibility.text = (data['compatibility'] as List? ?? const []).join(
      '\n',
    );
    _observations.text = '${data['observations'] ?? ''}';
    _faq.text = (data['faq'] as List? ?? const [])
        .whereType<Map>()
        .map((item) => '${item['question'] ?? ''}|${item['answer'] ?? ''}')
        .join('\n');
    _periodDrafts
      ..clear()
      ..addAll((data['periods'] as List? ?? const []).whereType<Map>().map((item) => {
        'days': (item['days'] as num?)?.round() ?? 30,
        'label': '${item['label'] ?? ''}',
        'price_cents': (item['price_cents'] as num?)?.round() ?? 0,
        'cost_cents': (item['cost_cents'] as num?)?.round() ?? 0,
      }));
    _bannerId = '${data['banner_file_id'] ?? ''}'.isEmpty
        ? null
        : '${data['banner_file_id']}';
    if (mounted) setState(() {});
    return _ServiceEditorData(categories: _rows(categories), metadata: metadata);
  }

  @override
  void dispose() {
    for (final controller in [
      _name,
      _description,
      _price,
      _promotion,
      _cashback,
      _points,
      _compatibility,
      _benefits,
      _observations,
      _faq,
      _order,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _upload(bool banner) async {
    final file = await NativeBridge.pickFile(mimeTypes: const ['image/*']);
    if (file == null || !mounted) return;
    setState(() => _progress = 0);
    try {
      final uploaded = await widget.repository.uploadFile(
        file: file,
        type: banner ? 'servico_banner' : 'servico_imagem',
        publicRead: true,
        onProgress: (value) {
          if (mounted) setState(() => _progress = value / 100);
        },
      );
      setState(() {
        if (banner) {
          _bannerId = uploaded.id;
        } else {
          _imageId = uploaded.id;
        }
        _progress = null;
      });
    } catch (error) {
      if (mounted) {
        setState(() => _progress = null);
        _toast(_friendly(error));
      }
    }
  }

  List<Map<String, dynamic>> _parsePeriods() {
    final rows = _periodDrafts
        .where((item) => ((item['days'] as num?)?.round() ?? 0) > 0)
        .map((item) => {
              'days': (item['days'] as num).round(),
              'label': '${item['label'] ?? ''}'.trim().isEmpty
                  ? '${(item['days'] as num).round()} dias'
                  : '${item['label']}'.trim(),
              'price_cents': ((item['price_cents'] as num?) ?? 0).round(),
              'cost_cents': ((item['cost_cents'] as num?) ?? 0).round(),
            })
        .toList();
    rows.sort((a, b) => (a['days'] as int).compareTo(b['days'] as int));
    return rows;
  }

  Future<void> _editPeriod([int? index]) async {
    final current = index == null ? null : _periodDrafts[index];
    final days = TextEditingController(text: '${current?['days'] ?? 30}');
    final label = TextEditingController(text: '${current?['label'] ?? ''}');
    final price = TextEditingController(text: (((current?['price_cents'] as num?) ?? 0) / 100).toStringAsFixed(2));
    final cost = TextEditingController(text: (((current?['cost_cents'] as num?) ?? 0) / 100).toStringAsFixed(2));
    final selected = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(index == null ? 'Adicionar período' : 'Editar período'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [7, 14, 30, 60, 90, 180, 365]
                  .map((value) => ActionChip(label: Text('$value dias'), onPressed: () {
                        days.text = '$value';
                        if (label.text.trim().isEmpty || RegExp(r'^\d+ dias$').hasMatch(label.text.trim())) label.text = '$value dias';
                      }))
                  .toList(),
            ),
            const SizedBox(height: 12),
            TextField(controller: days, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Duração em dias *')),
            const SizedBox(height: 10),
            TextField(controller: label, decoration: const InputDecoration(labelText: 'Rótulo', hintText: 'Ex.: Mensal, 30 dias')),
            const SizedBox(height: 10),
            TextField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Valor de venda (R\$) *')),
            const SizedBox(height: 10),
            TextField(controller: cost, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Custo (R\$)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );
    if (selected == true) {
      final parsedDays = int.tryParse(days.text.trim());
      final parsedPrice = double.tryParse(price.text.trim().replaceAll(',', '.'));
      final parsedCost = double.tryParse(cost.text.trim().replaceAll(',', '.')) ?? 0;
      if (parsedDays == null || parsedDays <= 0 || parsedPrice == null || parsedPrice < 0 || parsedCost < 0) {
        _toast('Informe duração e valores válidos.');
      } else {
        final row = <String, dynamic>{
          'days': parsedDays,
          'label': label.text.trim().isEmpty ? '$parsedDays dias' : label.text.trim(),
          'price_cents': (parsedPrice * 100).round(),
          'cost_cents': (parsedCost * 100).round(),
        };
        setState(() {
          if (index == null) _periodDrafts.add(row); else _periodDrafts[index] = row;
          _periodDrafts.sort((a, b) => ((a['days'] as num?) ?? 0).compareTo((b['days'] as num?) ?? 0));
        });
      }
    }
    days.dispose(); label.dispose(); price.dispose(); cost.dispose();
  }

  List<Map<String, dynamic>> _parseFaq() {
    return _faq.text
        .split('\n')
        .map((line) => line.split('|'))
        .where((parts) => parts.length >= 2)
        .map(
          (parts) => {
            'question': parts.first.trim(),
            'answer': parts.sublist(1).join('|').trim(),
          },
        )
        .where(
          (row) => row['question']!.isNotEmpty && row['answer']!.isNotEmpty,
        )
        .toList();
  }

  Future<void> _save(_ServiceEditorData data) async {
    if (_name.text.trim().isEmpty) {
      _toast('Informe o nome do serviço.');
      return;
    }
    final periods = _parsePeriods();
    if (periods.isEmpty) {
      _toast('Adicione pelo menos um período com tempo e valor.');
      return;
    }
    final typedPrice = double.tryParse(_price.text.trim().replaceAll(',', '.'));
    final price = typedPrice ?? (((periods.first['price_cents'] as num?) ?? 0) / 100);
    if (price < 0) {
      _toast('Informe preços válidos.');
      return;
    }
    setState(() => _saving = true);
    try {
      final previousCents = ((widget.current?['preco_centavos'] as num?) ?? 0)
          .round();
      final newCents = (price * 100).round();
      final response = await widget.repository.adminCrud(
        table: 'servicos',
        operation: widget.current == null ? 'create' : 'update',
        rowId: widget.current?[r'$id']?.toString(),
        data: {
          'nome': _name.text.trim(),
          'descricao': _description.text.trim(),
          'valor': price,
          'preco_centavos': newCents,
          'periodicidade': periods.first['days'] == 365
              ? 'anual'
              : 'personalizado',
          'ativo': _active,
          'categoria_id': _categoryId,
          if (_imageId != null) 'imagem_file_id': _imageId,
          'dsetaque': _featured,
          'ordem': int.tryParse(_order.text) ?? 0,
        },
      );
      final id = '${response[r'$id'] ?? widget.current?[r'$id'] ?? ''}';
      await widget.repository.saveModule(
        kind: 'service_meta',
        rowId: data.metadata?[r'$id']?.toString(),
        referenceId: id,
        title: _name.text.trim(),
        data: {
          'service_type': _type,
          'release_mode': _releaseMode,
          'stock_enabled': _stockEnabled,
          'promotion_percent':
              double.tryParse(_promotion.text.replaceAll(',', '.')) ?? 0,
          'cashback_percent':
              double.tryParse(_cashback.text.replaceAll(',', '.')) ?? 0,
          'points': int.tryParse(_points.text) ?? 0,
          'benefits': _benefits.text
              .split('\n')
              .map((value) => value.trim())
              .where((value) => value.isNotEmpty)
              .toList(),
          'compatibility': _compatibility.text
              .split('\n')
              .map((value) => value.trim())
              .where((value) => value.isNotEmpty)
              .toList(),
          'observations': _observations.text.trim(),
          'faq': _parseFaq(),
          'periods': periods,
          if (_bannerId != null) 'banner_file_id': _bannerId,
          if (_imageId != null) 'image_file_id': _imageId,
        },
      );
      if (widget.current != null && previousCents != newCents) {
        await widget.repository.saveModule(
          kind: 'price_history',
          referenceId: id,
          title: _name.text.trim(),
          amountCents: newCents,
          data: {
            'previous_cents': previousCents,
            'new_cents': newCents,
            'changed_at': DateTime.now().toUtc().toIso8601String(),
          },
        );
      }
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _toast(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.current == null ? 'Novo serviço' : 'Editar serviço'),
    ),
    body: FutureBuilder<_ServiceEditorData>(
      future: _future,
      builder: (_, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting)
          return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError)
          return _ErrorView(
            error: snapshot.error!,
            onRetry: () async {
              setState(() {
                _future = _load();
              });
            },
          );
        final data = snapshot.data!;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            if (_imageId != null || _bannerId != null)
              SizedBox(
                height: 180,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: _StorageImage(
                    repository: widget.repository,
                    fileId: _bannerId ?? _imageId!,
                  ),
                ),
              ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _progress == null ? () => _upload(false) : null,
                    icon: const Icon(Icons.image_outlined),
                    label: Text(_imageId == null ? 'Imagem' : 'Trocar imagem'),
                  ),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _progress == null ? () => _upload(true) : null,
                    icon: const Icon(Icons.panorama_outlined),
                    label: Text(_bannerId == null ? 'Banner' : 'Trocar banner'),
                  ),
                ),
              ],
            ),
            if (_progress != null) ...[
              const SizedBox(height: 8),
              LinearProgressIndicator(value: _progress),
              Text(
                '${((_progress ?? 0) * 100).round()}%',
                textAlign: TextAlign.center,
              ),
            ],
            const SizedBox(height: 12),
            TextField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'Nome *'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _description,
              minLines: 3,
              maxLines: 7,
              decoration: const InputDecoration(labelText: 'Descrição'),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String?>(
              initialValue:
                  data.categories.any((item) => item[r'$id'] == _categoryId)
                  ? _categoryId
                  : null,
              decoration: const InputDecoration(labelText: 'Categoria'),
              items: data.categories
                  .map(
                    (item) => DropdownMenuItem<String?>(
                      value: '${item[r'$id']}',
                      child: Text('${item['nome'] ?? 'Categoria'}'),
                    ),
                  )
                  .toList(),
              onChanged: (value) => setState(() => _categoryId = value),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _price,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(
                labelText: 'Preço base (R\$) — opcional',
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _promotion,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Promoção %'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _cashback,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Cashback %'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _points,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Pontos'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: _type,
              decoration: const InputDecoration(labelText: 'Tipo de serviço'),
              items: const [
                DropdownMenuItem(
                  value: 'full_account',
                  child: Text('Conta inteira'),
                ),
                DropdownMenuItem(value: 'profile', child: Text('Perfil')),
                DropdownMenuItem(
                  value: 'shared_screen',
                  child: Text('Tela compartilhada'),
                ),
                DropdownMenuItem(value: 'license', child: Text('Licença')),
                DropdownMenuItem(value: 'code', child: Text('Código')),
                DropdownMenuItem(
                  value: 'subscription',
                  child: Text('Assinatura'),
                ),
                DropdownMenuItem(
                  value: 'combo',
                  child: Text('Combo / pacote'),
                ),
              ],
              onChanged: (value) => setState(() => _type = value ?? _type),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: _releaseMode,
              decoration: const InputDecoration(labelText: 'Liberação'),
              items: const [
                DropdownMenuItem(
                  value: 'automatic',
                  child: Text('Usar estoque pronto quando houver'),
                ),
                DropdownMenuItem(
                  value: 'manual',
                  child: Text('Criar/liberar manualmente após aprovação'),
                ),
              ],
              onChanged: (value) =>
                  setState(() => _releaseMode = value ?? _releaseMode),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Controlar estoque inteligente'),
              value: _stockEnabled,
              onChanged: (value) => setState(() => _stockEnabled = value),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Serviço ativo'),
              value: _active,
              onChanged: (value) => setState(() => _active = value),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Destaque no catálogo'),
              value: _featured,
              onChanged: (value) => setState(() => _featured = value),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Row(children: [
                    const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Períodos e valores *', style: TextStyle(fontWeight: FontWeight.w900)),
                      Text('Escolha o tempo e informe o valor de cada opção.', style: TextStyle(fontSize: 12, color: RacheyColors.gray)),
                    ])),
                    IconButton.filledTonal(tooltip: 'Adicionar período', onPressed: _editPeriod, icon: const Icon(Icons.add_rounded)),
                  ]),
                  if (_periodDrafts.isEmpty)
                    const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('Nenhum período cadastrado.', textAlign: TextAlign.center, style: TextStyle(color: RacheyColors.gray)))
                  else
                    ..._periodDrafts.indexed.map((entry) {
                      final item = entry.$2;
                      final value = ((item['price_cents'] as num? ?? 0) / 100).toStringAsFixed(2).replaceAll('.', ',');
                      final costValue = ((item['cost_cents'] as num? ?? 0) / 100).toStringAsFixed(2).replaceAll('.', ',');
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.schedule_rounded, color: RacheyColors.primary),
                        title: Text('${item['label'] ?? '${item['days']} dias'} • R\$ $value', style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text('${item['days']} dias • custo R\$ $costValue'),
                        onTap: () => _editPeriod(entry.$1),
                        trailing: IconButton(tooltip: 'Excluir período', onPressed: () => setState(() => _periodDrafts.removeAt(entry.$1)), icon: const Icon(Icons.delete_outline_rounded)),
                      );
                    }),
                ]),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _benefits,
              minLines: 2,
              maxLines: 8,
              decoration: const InputDecoration(
                labelText: 'Itens/benefícios inclusos',
                helperText: 'Um por linha. Use também para montar combos.',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _compatibility,
              minLines: 2,
              maxLines: 6,
              decoration: const InputDecoration(
                labelText: 'Compatibilidade',
                helperText: 'Um item por linha',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _observations,
              minLines: 2,
              maxLines: 6,
              decoration: const InputDecoration(labelText: 'Observações'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _faq,
              minLines: 3,
              maxLines: 10,
              decoration: const InputDecoration(
                labelText: 'FAQ',
                helperText: 'Uma linha: pergunta|resposta',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _order,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Ordem no catálogo'),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: _saving || _progress != null
                  ? null
                  : () => _save(data),
              icon: const Icon(Icons.save_outlined),
              label: Text(_saving ? 'Salvando...' : 'Salvar serviço'),
            ),
          ],
        );
      },
    ),
  );
}

class AdminInventoryPage extends StatefulWidget {
  const AdminInventoryPage({required this.repository, super.key});

  final RacheyRepository repository;

  @override
  State<AdminInventoryPage> createState() => _AdminInventoryPageState();
}

class _AdminInventoryPageState extends State<AdminInventoryPage> {
  late Future<_InventoryData> _future;
  String? _serviceId;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_InventoryData> _load() async {
    final values = await Future.wait([
      widget.repository.adminList('servicos', limit: 500),
      widget.repository.action('module_list', {
        'kind': 'inventory_account',
        'limit': 500,
      }),
      widget.repository.action('module_list', {
        'kind': 'inventory_slot',
        'limit': 500,
      }),
    ]);
    return _InventoryData(
      services: _rows(values[0]),
      accounts: _rows(values[1]),
      slots: _rows(values[2]),
    );
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Future<void> _addAccount(_InventoryData data) async {
    final service =
        _serviceId ??
        (data.services.isEmpty ? null : '${data.services.first[r'$id']}');
    if (service == null) return;
    final label = TextEditingController();
    final login = TextEditingController();
    final password = TextEditingController();
    final pin = TextEditingController();
    final slots = TextEditingController(text: '1');
    var autoRelease = false;
    var prorate = false;
    DateTime? expiry;
    final expiryText = TextEditingController();
    var hidden = true;
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setDialogState) => AlertDialog(
          title: const Text('Adicionar conta ao estoque'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: label,
                  decoration: const InputDecoration(
                    labelText: 'Identificação (ex.: Conta 01)',
                  ),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: login,
                  decoration: const InputDecoration(labelText: 'Identificador / login *'),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: password,
                  obscureText: hidden,
                  decoration: InputDecoration(
                    labelText: 'Senha / código / segredo *',
                    suffixIcon: IconButton(
                      onPressed: () => setDialogState(() => hidden = !hidden),
                      icon: Icon(
                        hidden
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: pin,
                  decoration: const InputDecoration(
                    labelText: 'PIN secundário (opcional)',
                  ),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: slots,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Telas/vagas da conta',
                    helperText: 'Use mais de 1 para conta compartilhada; cada vaga é vendida separadamente.',
                  ),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: expiryText,
                  readOnly: true,
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: dialogContext,
                      initialDate: expiry ?? DateTime.now().add(const Duration(days: 30)),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 3650)),
                    );
                    if (picked != null) {
                      setDialogState(() {
                        expiry = DateTime(picked.year, picked.month, picked.day, 23, 59, 59);
                        expiryText.text = '${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}';
                      });
                    }
                  },
                  decoration: InputDecoration(
                    labelText: 'Vencimento da conta pronta',
                    helperText: 'Obrigatório para preço proporcional. É o vencimento real da conta-mãe.',
                    suffixIcon: expiry == null ? const Icon(Icons.calendar_month_outlined) : IconButton(
                      onPressed: () => setDialogState(() { expiry = null; expiryText.clear(); prorate = false; }),
                      icon: const Icon(Icons.clear_rounded),
                    ),
                  ),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Preço proporcional aos dias restantes'),
                  subtitle: const Text('Ex.: R\$ 20/30 dias com 18 dias restantes = R\$ 12. A conta é liberada automaticamente após aprovar o pagamento.'),
                  value: prorate,
                  onChanged: expiry == null ? null : (value) => setDialogState(() {
                    prorate = value;
                    if (value) autoRelease = true;
                  }),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Conta pronta: liberar após aprovação'),
                  subtitle: const Text('Só vale para esta conta do estoque. Produtos sem uma conta pronta continuam com liberação manual.'),
                  value: autoRelease,
                  onChanged: prorate ? null : (value) => setDialogState(() => autoRelease = value),
                ),
                const Text(
                  'Login, senha e PIN são criptografados na Function antes de chegar ao banco.',
                  style: TextStyle(fontSize: 12, color: RacheyColors.gray),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Adicionar'),
            ),
          ],
        ),
      ),
    );
    if (save == true &&
        login.text.trim().isNotEmpty &&
        password.text.isNotEmpty) {
      try {
        await widget.repository.action('inventory_save_account', {
          'service_id': service,
          'label': label.text.trim(),
          'login': login.text.trim(),
          'password': password.text,
          'secondary_pin': pin.text,
          'slots': int.tryParse(slots.text) ?? 1,
          'auto_release': autoRelease,
          'prorate_enabled': prorate,
          if (expiry != null) 'expires_at': expiry!.toUtc().toIso8601String(),
          'service_type': (int.tryParse(slots.text) ?? 1) > 1
              ? 'shared_screen'
              : 'full_account',
        });
        await _refresh();
      } catch (error) {
        if (mounted) _toast(_friendly(error));
      }
    }
    login.clear();
    password.clear();
    pin.clear();
    label.dispose();
    login.dispose();
    password.dispose();
    pin.dispose();
    slots.dispose();
    expiryText.dispose();
  }

  Future<void> _reveal(Map<String, dynamic> account) async {
    final accepted = await NativeBridge.authenticate(
      reason: 'Confirme sua identidade para visualizar o estoque',
    );
    if (!accepted || !mounted) return;
    try {
      final secret = await widget.repository.action('inventory_reveal', {
        'account_id': account[r'$id'],
      });
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text('${account['title'] ?? 'Conta'}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _SecretValue(label: 'Login', value: '${secret['login'] ?? ''}'),
              const SizedBox(height: 8),
              _SecretValue(
                label: 'Senha',
                value: '${secret['password'] ?? ''}',
              ),
              if ('${secret['secondary_pin'] ?? ''}'.isNotEmpty) ...[
                const SizedBox(height: 8),
                _SecretValue(label: 'PIN', value: '${secret['secondary_pin']}'),
              ],
            ],
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Fechar'),
            ),
          ],
        ),
      );
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<void> _editAccount(Map<String, dynamic> account) async {
    final data = account['data'] as Map? ?? const {};
    final label = TextEditingController(text: '${account['title'] ?? ''}');
    final login = TextEditingController();
    final password = TextEditingController();
    final pin = TextEditingController();
    var autoRelease = data['auto_release'] == true;
    var prorate = data['prorate_enabled'] == true;
    DateTime? expiry = DateTime.tryParse('${data['expires_at'] ?? ''}')?.toLocal();
    final expiryText = TextEditingController(
      text: expiry == null ? '' : '${expiry.day.toString().padLeft(2, '0')}/${expiry.month.toString().padLeft(2, '0')}/${expiry.year}',
    );
    var hidden = true;
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setDialogState) => AlertDialog(
          title: const Text('Editar conta de estoque'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: label,
                  decoration: const InputDecoration(labelText: 'Identificação'),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: login,
                  decoration: const InputDecoration(
                    labelText: 'Novo login',
                    helperText: 'Deixe vazio para manter o atual',
                  ),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: password,
                  obscureText: hidden,
                  decoration: InputDecoration(
                    labelText: 'Nova senha',
                    helperText: 'Deixe vazia para manter a atual',
                    suffixIcon: IconButton(
                      onPressed: () => setDialogState(() => hidden = !hidden),
                      icon: Icon(
                        hidden
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: pin,
                  decoration: const InputDecoration(
                    labelText: 'Novo PIN secundário',
                    helperText: 'Deixe vazio para manter o atual',
                  ),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: expiryText,
                  readOnly: true,
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: dialogContext,
                      initialDate: expiry ?? DateTime.now().add(const Duration(days: 30)),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(const Duration(days: 3650)),
                    );
                    if (picked != null) {
                      setDialogState(() {
                        expiry = DateTime(picked.year, picked.month, picked.day, 23, 59, 59);
                        expiryText.text = '${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}';
                      });
                    }
                  },
                  decoration: InputDecoration(
                    labelText: 'Vencimento real da conta',
                    suffixIcon: expiry == null ? const Icon(Icons.calendar_month_outlined) : IconButton(
                      onPressed: () => setDialogState(() { expiry = null; expiryText.clear(); prorate = false; }),
                      icon: const Icon(Icons.clear_rounded),
                    ),
                  ),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Preço proporcional'),
                  subtitle: const Text('Reduz preço e duração de cada vaga conforme os dias restantes da conta.'),
                  value: prorate,
                  onChanged: expiry == null ? null : (value) => setDialogState(() {
                    prorate = value;
                    if (value) autoRelease = true;
                  }),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Conta pronta: liberar após aprovação'),
                  value: autoRelease,
                  onChanged: prorate ? null : (value) => setDialogState(() => autoRelease = value),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
    if (save == true) {
      try {
        await widget.repository.action('inventory_update_account', {
          'account_id': account[r'$id'],
          'label': label.text.trim(),
          if (login.text.trim().isNotEmpty) 'login': login.text.trim(),
          if (password.text.isNotEmpty) 'password': password.text,
          if (pin.text.isNotEmpty) 'secondary_pin': pin.text,
          'auto_release': autoRelease,
          'prorate_enabled': prorate,
          'expires_at': expiry?.toUtc().toIso8601String(),
        });
        await _refresh();
      } catch (error) {
        if (mounted) _toast(_friendly(error));
      }
    }
    login.clear();
    password.clear();
    pin.clear();
    label.dispose();
    login.dispose();
    password.dispose();
    pin.dispose();
    expiryText.dispose();
  }

  Future<void> _deleteAccount(Map<String, dynamic> account) async {
    final confirmed = await _confirm(
      context,
      'Excluir esta conta?',
      'A exclusão só será aceita se todas as vagas estiverem livres.',
    );
    if (!confirmed) return;
    try {
      await widget.repository.action('inventory_delete_account', {
        'account_id': account[r'$id'],
      });
      await _refresh();
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<void> _release(Map<String, dynamic> slot) async {
    final confirmed = await _confirm(
      context,
      'Liberar esta vaga?',
      'O cliente atual perderá a ocupação e a primeira pessoa da fila será notificada.',
    );
    if (!confirmed) return;
    try {
      await widget.repository.action('inventory_release_slot', {
        'slot_id': slot[r'$id'],
      });
      await _refresh();
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  void _toast(String message) => ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Estoque inteligente')),
    body: FutureBuilder<_InventoryData>(
      future: _future,
      builder: (_, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting)
          return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError)
          return _ErrorView(error: snapshot.error!, onRetry: _refresh);
        final data = snapshot.data!;
        _serviceId ??= data.services.isEmpty
            ? null
            : '${data.services.first[r'$id']}';
        final accounts = data.accounts
            .where(
              (row) => _serviceId == null || row['reference_id'] == _serviceId,
            )
            .toList();
        final slots = data.slots
            .where(
              (row) => _serviceId == null || row['reference_id'] == _serviceId,
            )
            .toList();
        final free = slots.where((row) => row['status'] == 'livre').length;
        return RefreshIndicator(
          onRefresh: _refresh,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            children: [
              DropdownButtonFormField<String>(
                initialValue: _serviceId,
                decoration: const InputDecoration(labelText: 'Serviço'),
                items: data.services
                    .map(
                      (item) => DropdownMenuItem(
                        value: '${item[r'$id']}',
                        child: Text('${item['nome'] ?? 'Serviço'}'),
                      ),
                    )
                    .toList(),
                onChanged: (value) => setState(() => _serviceId = value),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _SmallMetric(
                      label: 'Contas',
                      value: '${accounts.length}',
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _SmallMetric(
                      label: 'Vagas',
                      value: '${slots.length}',
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _SmallMetric(
                      label: 'Livres',
                      value: '$free',
                      color: RacheyColors.primary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: data.services.isEmpty
                    ? null
                    : () => _addAccount(data),
                icon: const Icon(Icons.add),
                label: const Text('Adicionar conta'),
              ),
              const SizedBox(height: 18),
              if (accounts.isEmpty)
                const Card(
                  child: ListTile(
                    leading: Icon(Icons.inventory_2_outlined),
                    title: Text('Nenhuma conta neste estoque.'),
                  ),
                )
              else
                ...accounts.map((account) {
                  final accountSlots = slots
                      .where((slot) => slot['parent_id'] == account[r'$id'])
                      .toList();
                  return Card(
                    child: ExpansionTile(
                      leading: const CircleAvatar(
                        child: Icon(Icons.account_box_outlined),
                      ),
                      title: Text(
                        '${account['title'] ?? 'Conta'}',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      subtitle: Builder(
                        builder: (_) {
                          final accountData = account['data'] as Map? ?? const {};
                          final expires = DateTime.tryParse('${accountData['expires_at'] ?? ''}')?.toLocal();
                          final remaining = expires == null ? null : expires.difference(DateTime.now()).inDays + 1;
                          final availability = '${accountSlots.where((slot) => slot['status'] == 'livre').length}/${accountSlots.length} vagas livres';
                          final details = <String>[
                            availability,
                            if (expires != null) 'vence ${expires.day.toString().padLeft(2, '0')}/${expires.month.toString().padLeft(2, '0')}/${expires.year}',
                            if (remaining != null) '${remaining < 0 ? 0 : remaining} dias restantes',
                            if (accountData['prorate_enabled'] == true) 'preço proporcional',
                            if (accountData['auto_release'] == true) 'liberação automática desta conta',
                          ];
                          return Text(details.join(' • '));
                        },
                      ),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) {
                          if (value == 'reveal') _reveal(account);
                          if (value == 'edit') _editAccount(account);
                          if (value == 'delete') _deleteAccount(account);
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(
                            value: 'reveal',
                            child: Text('Visualizar credenciais'),
                          ),
                          PopupMenuItem(
                            value: 'edit',
                            child: Text('Editar conta'),
                          ),
                          PopupMenuItem(
                            value: 'delete',
                            child: Text('Excluir conta'),
                          ),
                        ],
                      ),
                      children: accountSlots.map((slot) {
                        final content = slot['data'] as Map? ?? const {};
                        final occupied = slot['status'] != 'livre';
                        return ListTile(
                          leading: Icon(
                            occupied
                                ? Icons.person_rounded
                                : Icons.event_seat_outlined,
                            color: occupied
                                ? RacheyColors.promo
                                : RacheyColors.primary,
                          ),
                          title: Text(
                            '${content['label'] ?? slot['title'] ?? 'Vaga'}',
                          ),
                          subtitle: Text(
                            '${_status('${slot['status'] ?? ''}')}${slot['owner_id'] != null ? ' • cliente ${slot['owner_id']}' : ''}',
                          ),
                          trailing: occupied
                              ? TextButton(
                                  onPressed: () => _release(slot),
                                  child: const Text('Liberar'),
                                )
                              : const Icon(
                                  Icons.check_circle,
                                  color: RacheyColors.primary,
                                ),
                        );
                      }).toList(),
                    ),
                  );
                }),
            ],
          ),
        );
      },
    ),
  );
}

class _CategoryData {
  const _CategoryData({required this.rows, required this.metadata});
  final List<Map<String, dynamic>> rows;
  final List<Map<String, dynamic>> metadata;
}

class _ServiceEditorData {
  const _ServiceEditorData({required this.categories, required this.metadata});
  final List<Map<String, dynamic>> categories;
  final Map<String, dynamic>? metadata;
}

class _InventoryData {
  const _InventoryData({
    required this.services,
    required this.accounts,
    required this.slots,
  });
  final List<Map<String, dynamic>> services;
  final List<Map<String, dynamic>> accounts;
  final List<Map<String, dynamic>> slots;
}

class _TodayIndicator extends StatelessWidget {
  const _TodayIndicator({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 150,
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 20, color: RacheyColors.primary),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 12, color: RacheyColors.gray)),
              const SizedBox(height: 2),
              Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      ],
    ),
  );
}

class _DashboardMetric extends StatelessWidget {
  const _DashboardMetric({
    required this.label,
    required this.value,
    required this.icon,
    this.color = RacheyColors.primary,
  });
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 7),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontWeight: FontWeight.w900,
              fontSize: 20,
              color: color,
            ),
          ),
          Text(label, style: const TextStyle(color: RacheyColors.gray)),
        ],
      ),
    ),
  );
}

class _SmallMetric extends StatelessWidget {
  const _SmallMetric({
    required this.label,
    required this.value,
    this.color = RacheyColors.navy,
  });
  final String label;
  final String value;
  final Color color;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(13),
      child: Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
          Text(label, style: const TextStyle(color: RacheyColors.gray)),
        ],
      ),
    ),
  );
}

class _StorageImage extends StatelessWidget {
  const _StorageImage({required this.repository, required this.fileId});
  final RacheyRepository repository;
  final String fileId;

  @override
  Widget build(BuildContext context) => FutureBuilder<Uint8List>(
    future: repository.imageFile(fileId, width: 1000, height: 700),
    builder: (_, snapshot) {
      if (snapshot.hasData)
        return Image.memory(snapshot.data!, fit: BoxFit.cover);
      if (snapshot.hasError)
        return const Center(child: Icon(Icons.broken_image_outlined));
      return const Center(child: CircularProgressIndicator());
    },
  );
}

class _SecretValue extends StatefulWidget {
  const _SecretValue({required this.label, required this.value});
  final String label;
  final String value;
  @override
  State<_SecretValue> createState() => _SecretValueState();
}

class _SecretValueState extends State<_SecretValue> {
  bool visible = false;
  @override
  Widget build(BuildContext context) => ListTile(
    tileColor: RacheyColors.mint,
    title: Text(widget.label),
    subtitle: SelectableText(visible ? widget.value : '••••••••••'),
    trailing: IconButton(
      onPressed: () => setState(() => visible = !visible),
      icon: Icon(visible ? Icons.visibility_off : Icons.visibility),
    ),
  );
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.error, required this.onRetry});
  final Object error;
  final Future<void> Function() onRetry;
  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const SizedBox(height: 130),
      const Icon(Icons.cloud_off_outlined, size: 54, color: RacheyColors.gray),
      const SizedBox(height: 10),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Text(_friendly(error), textAlign: TextAlign.center),
      ),
      const SizedBox(height: 10),
      Center(
        child: OutlinedButton(
          onPressed: onRetry,
          child: const Text('Tentar novamente'),
        ),
      ),
    ],
  );
}

class _EmptyView extends StatelessWidget {
  const _EmptyView({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const SizedBox(height: 150),
      Icon(icon, size: 54, color: RacheyColors.gray),
      const SizedBox(height: 10),
      Center(child: Text(text)),
    ],
  );
}

List<Map<String, dynamic>> _rows(Map<String, dynamic> value) =>
    (value['rows'] as List<dynamic>? ?? const [])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();

Future<bool> _confirm(
  BuildContext context,
  String title,
  String message,
) async =>
    await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Confirmar'),
          ),
        ],
      ),
    ) ??
    false;

String _slug(String value) => value
    .trim()
    .toLowerCase()
    .replaceAll(RegExp(r'[^a-z0-9]+'), '-')
    .replaceAll(RegExp(r'^-|-$'), '');

String _money(int cents) =>
    'R\$ ${(cents / 100).toStringAsFixed(2).replaceAll('.', ',')}';
String _status(String value) => value.replaceAll('_', ' ');
String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
