import 'package:flutter/material.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';

class AdminExpirationCenterPage extends StatefulWidget {
  const AdminExpirationCenterPage({required this.repository, super.key});
  final RacheyRepository repository;

  @override
  State<AdminExpirationCenterPage> createState() => _AdminExpirationCenterPageState();
}

class _AdminExpirationCenterPageState extends State<AdminExpirationCenterPage> {
  late Future<List<Map<String, dynamic>>> _future;
  String _filter = 'all';

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final response = await widget.repository.adminList('assinaturas', limit: 500);
    final rows = (response['rows'] as List<dynamic>? ?? const [])
        .whereType<Map>()
        .map((row) => Map<String, dynamic>.from(row))
        .toList();
    rows.sort((a, b) {
      if (a['status'] == 'aguardando_liberacao' && b['status'] != 'aguardando_liberacao') return -1;
      if (b['status'] == 'aguardando_liberacao' && a['status'] != 'aguardando_liberacao') return 1;
      final da = DateTime.tryParse('${a['data_vencimento'] ?? ''}') ?? DateTime(2999);
      final db = DateTime.tryParse('${b['data_vencimento'] ?? ''}') ?? DateTime(2999);
      return da.compareTo(db);
    });
    return rows;
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  int? _days(Map<String, dynamic> row) {
    if (row['status'] == 'aguardando_liberacao') return null;
    final due = DateTime.tryParse('${row['data_vencimento'] ?? ''}')?.toLocal();
    if (due == null) return null;
    final today = DateTime.now();
    final a = DateTime(today.year, today.month, today.day);
    final b = DateTime(due.year, due.month, due.day);
    return b.difference(a).inDays;
  }

  bool _matchesFor(Map<String, dynamic> row, String filter) {
    if (filter == 'all') return true;
    if (filter == 'waiting') return row['status'] == 'aguardando_liberacao';
    final days = _days(row);
    if (days == null) return false;
    return switch (filter) {
      'today' => days == 0,
      '2d' => days >= 0 && days <= 2,
      '7d' => days >= 0 && days <= 7,
      'expired' => days < 0,
      _ => true,
    };
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Central de vencimentos'),
          Text('Priorize liberações e renovações', style: TextStyle(fontSize: 11, color: RacheyColors.gray)),
        ],
      ),
      actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh_rounded))],
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return ListView(children: [const SizedBox(height: 120), Center(child: Text('${snapshot.error}'))]);
          final all = snapshot.data ?? const [];
          int count(String filter) => all.where((row) => _matchesFor(row, filter)).length;
          final rows = all.where((row) => _matchesFor(row, _filter)).toList();
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 90),
            children: [
              Wrap(
                spacing: 7,
                runSpacing: 7,
                children: {
                  'all': 'Todas (${all.length})',
                  'waiting': 'Liberar (${count('waiting')})',
                  'today': 'Hoje (${count('today')})',
                  '2d': 'Até 2 dias (${count('2d')})',
                  '7d': 'Até 7 dias (${count('7d')})',
                  'expired': 'Vencidas (${count('expired')})',
                }.entries.map((entry) => ChoiceChip(
                  label: Text(entry.value),
                  selected: _filter == entry.key,
                  onSelected: (_) => setState(() => _filter = entry.key),
                )).toList(),
              ),
              const SizedBox(height: 14),
              if (rows.isEmpty)
                const Card(child: ListTile(leading: Icon(Icons.event_available_outlined), title: Text('Nada exige atenção neste filtro.')))
              else
                ...rows.map((row) {
                  final days = _days(row);
                  final waiting = row['status'] == 'aguardando_liberacao';
                  final due = DateTime.tryParse('${row['data_vencimento'] ?? ''}')?.toLocal();
                  final label = waiting
                      ? 'Aguardando liberação — os dias ainda não começaram'
                      : days == null
                          ? 'Sem vencimento válido'
                          : days < 0
                              ? 'Vencida há ${-days} dia(s)'
                              : days == 0
                                  ? 'Vence hoje'
                                  : 'Vence em $days dia(s)';
                  final color = waiting || (days != null && days <= 2) ? RacheyColors.promo : RacheyColors.primary;
                  return Card(
                    child: ListTile(
                      leading: CircleAvatar(backgroundColor: color.withValues(alpha: .12), child: Icon(waiting ? Icons.lock_clock_outlined : Icons.event_outlined, color: color)),
                      title: Text('${row['nome_servico'] ?? 'Assinatura'}', style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: Text('$label\nCliente: ${row['user_id'] ?? '-'}${due == null || waiting ? '' : ' • ${due.day.toString().padLeft(2, '0')}/${due.month.toString().padLeft(2, '0')}/${due.year}'}'),
                      isThreeLine: true,
                      trailing: Icon(Icons.circle, size: 11, color: color),
                    ),
                  );
                }),
            ],
          );
        },
      ),
    ),
  );
}

class AdminQuickRepliesPage extends StatefulWidget {
  const AdminQuickRepliesPage({required this.repository, super.key});
  final RacheyRepository repository;

  @override
  State<AdminQuickRepliesPage> createState() => _AdminQuickRepliesPageState();
}

class _AdminQuickRepliesPageState extends State<AdminQuickRepliesPage> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = widget.repository.listModules('quick_reply', limit: 200);
  }

  Future<void> _refresh() async {
    setState(() {
      _future = widget.repository.listModules('quick_reply', limit: 200);
    });
    await _future;
  }

  Future<void> _edit([Map<String, dynamic>? row]) async {
    final title = TextEditingController(text: '${row?['title'] ?? ''}');
    final text = TextEditingController(text: '${(row?['data'] as Map? ?? const {})['text'] ?? ''}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(row == null ? 'Nova resposta rápida' : 'Editar resposta rápida'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Atalho/título *')),
          const SizedBox(height: 10),
          TextField(controller: text, minLines: 3, maxLines: 8, decoration: const InputDecoration(labelText: 'Mensagem *')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Salvar')),
        ],
      ),
    );
    if (ok == true && title.text.trim().isNotEmpty && text.text.trim().isNotEmpty) {
      await widget.repository.saveModule(
        kind: 'quick_reply', rowId: row?[r'$id']?.toString(), title: title.text.trim(), status: 'ativo',
        data: {'text': text.text.trim()},
      );
      await _refresh();
    }
    title.dispose(); text.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Respostas rápidas')),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Nova')),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return ListView(children: [const SizedBox(height: 100), Center(child: Text('${snapshot.error}'))]);
          final rows = snapshot.data ?? const [];
          if (rows.isEmpty) return const Center(child: Text('Nenhuma resposta rápida cadastrada.'));
          return ListView(padding: const EdgeInsets.all(16), children: rows.map((row) {
            final text = '${(row['data'] as Map? ?? const {})['text'] ?? ''}';
            return Card(child: ListTile(
              leading: const Icon(Icons.quickreply_outlined),
              title: Text('${row['title'] ?? 'Resposta'}', style: const TextStyle(fontWeight: FontWeight.w900)),
              subtitle: Text(text, maxLines: 3, overflow: TextOverflow.ellipsis),
              onTap: () => _edit(row),
              trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { await widget.repository.deleteModule('${row[r'$id']}'); await _refresh(); }),
            ));
          }).toList());
        },
      ),
    ),
  );
}
