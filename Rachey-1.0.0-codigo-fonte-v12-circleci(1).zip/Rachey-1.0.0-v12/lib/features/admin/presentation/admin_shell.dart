import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/widgets/rachey_ui.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/features/admin/presentation/admin_business_pages.dart';
import 'package:rachey/features/admin/presentation/admin_catalog_pages.dart';
import 'package:rachey/features/admin/presentation/admin_operations_pages.dart';
import 'package:rachey/features/auth/presentation/auth_cubit.dart';
import 'package:rachey/features/group/presentation/group_page.dart';
import 'package:rachey/features/support/presentation/support_page.dart';

class AdminShell extends StatefulWidget {
  const AdminShell({required this.user, required this.repository, super.key});

  final AuthSignedIn user;
  final RacheyRepository repository;

  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  int _index = 0;
  late final int? _servicesIndex;
  late final int? _ordersIndex;
  late final int? _groupIndex;
  late final int _pageCount;
  late final List<Widget?> _pages;

  @override
  void initState() {
    super.initState();
    var nextIndex = 1;
    _servicesIndex = widget.user.canOperate ? nextIndex++ : null;
    _ordersIndex = widget.user.canOperate ? nextIndex++ : null;
    _groupIndex = widget.user.canOperate ? nextIndex++ : null;
    nextIndex++; // Gestão
    _pageCount = nextIndex;
    _pages = List<Widget?>.filled(_pageCount, null);
    // No login administrativo só o dashboard é criado. As áreas pesadas,
    // principalmente o Grupo, são inicializadas apenas quando forem abertas.
    _pages[0] = _createPage(0);
  }

  Widget _createPage(int index) {
    if (index == 0) {
      return AdvancedAdminDashboardPage(
        repository: widget.repository,
        canManageFinance: widget.user.canManageFinance,
        onServices: _servicesIndex == null
            ? null
            : () => _select(_servicesIndex!),
        onOrders: _ordersIndex == null
            ? null
            : () => _select(_ordersIndex!),
        onPayments: !widget.user.canManageFinance
            ? null
            : () => Navigator.push<void>(
                context,
                MaterialPageRoute<void>(
                  builder: (_) => _AdminPayments(repository: widget.repository),
                ),
              ),
      );
    }
    if (_servicesIndex == index) {
      return _AdminServices(repository: widget.repository);
    }
    if (_ordersIndex == index) {
      return _AdminOrders(repository: widget.repository);
    }
    if (_groupIndex == index) {
      return GroupPage(
        repository: widget.repository,
        userId: widget.user.userId,
        isAdmin: true,
      );
    }
    return _AdminMore(user: widget.user, repository: widget.repository);
  }

  void _select(int value) {
    if (value < 0 || value >= _pageCount) return;
    _pages[value] ??= _createPage(value);
    setState(() => _index = value);
  }

  @override
  Widget build(BuildContext context) {
    final destinations = <NavigationDestination>[
      const NavigationDestination(
        icon: Icon(Icons.dashboard_outlined),
        selectedIcon: Icon(Icons.dashboard),
        label: 'Painel',
      ),
      if (_servicesIndex != null)
        const NavigationDestination(
          icon: Icon(Icons.sell_outlined),
          selectedIcon: Icon(Icons.sell),
          label: 'Catálogo',
        ),
      if (_ordersIndex != null)
        const NavigationDestination(
          icon: Icon(Icons.receipt_long_outlined),
          selectedIcon: Icon(Icons.receipt_long),
          label: 'Pedidos',
        ),
      if (_groupIndex != null)
        const NavigationDestination(
          icon: Icon(Icons.groups_outlined),
          selectedIcon: Icon(Icons.groups_rounded),
          label: 'Grupo',
        ),
      const NavigationDestination(
        icon: Icon(Icons.grid_view_outlined),
        selectedIcon: Icon(Icons.grid_view_rounded),
        label: 'Gestão',
      ),
    ];
    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: List.generate(
          _pageCount,
          (value) => _pages[value] ?? const SizedBox.shrink(),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        height: 72,
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        selectedIndex: _index,
        onDestinationSelected: _select,
        destinations: destinations,
      ),
    );
  }
}

class _AdminOverview extends StatefulWidget {
  const _AdminOverview({required this.repository, required this.onNavigate});
  final RacheyRepository repository;
  final ValueChanged<int> onNavigate;

  @override
  State<_AdminOverview> createState() => _AdminOverviewState();
}

class _AdminOverviewState extends State<_AdminOverview> {
  late Future<Map<String, int>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<Map<String, int>> _load() async {
    final values = await Future.wait([
      widget.repository.adminList('perfis', limit: 1),
      widget.repository.adminList('servicos', limit: 1),
      widget.repository.adminList('pedidos', limit: 1),
      widget.repository.adminList('pagamentos', limit: 1),
      widget.repository.adminList('assinaturas', limit: 1),
    ]);
    return {
      'Clientes': (values[0]['total'] as num?)?.round() ?? 0,
      'Serviços': (values[1]['total'] as num?)?.round() ?? 0,
      'Pedidos': (values[2]['total'] as num?)?.round() ?? 0,
      'Pagamentos': (values[3]['total'] as num?)?.round() ?? 0,
      'Assinaturas': (values[4]['total'] as num?)?.round() ?? 0,
    };
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Painel administrativo'),
          Text(
            'Acesso validado pela equipe administradores',
            style: TextStyle(fontSize: 11, color: RacheyColors.gray),
          ),
        ],
      ),
      actions: [
        IconButton(
          onPressed: _refresh,
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<Map<String, int>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return _ErrorList(
              message: _friendly(snapshot.error!),
              onRetry: _refresh,
            );
          }
          final values = snapshot.data ?? const {};
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [RacheyColors.navy, RacheyColors.darkGreen],
                  ),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: const Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.white24,
                      child: Icon(
                        Icons.admin_panel_settings_rounded,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Admin Rachey',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 19,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'Operações protegidas e registradas em auditoria.',
                            style: TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.65,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                children: values.entries
                    .map(
                      (entry) => Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                '${entry.value}',
                                style: const TextStyle(
                                  fontSize: 25,
                                  fontWeight: FontWeight.w900,
                                  color: RacheyColors.primary,
                                ),
                              ),
                              Text(
                                entry.key,
                                style: const TextStyle(
                                  color: RacheyColors.gray,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
              const SizedBox(height: 18),
              const Text(
                'Ações rápidas',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
              const SizedBox(height: 10),
              Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.add_business_rounded),
                      title: const Text('Cadastrar serviço'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => widget.onNavigate(1),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.fact_check_outlined),
                      title: const Text('Analisar pedidos'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => widget.onNavigate(2),
                    ),
                    const Divider(height: 1),
                    ListTile(
                      leading: const Icon(Icons.verified_outlined),
                      title: const Text('Aprovar pagamentos'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => widget.onNavigate(3),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    ),
  );
}

class _AdminServices extends StatefulWidget {
  const _AdminServices({required this.repository});
  final RacheyRepository repository;

  @override
  State<_AdminServices> createState() => _AdminServicesState();
}

class _AdminServicesState extends State<_AdminServices> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async =>
      _rows(await widget.repository.adminList('servicos'));

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Future<void> _edit([Map<String, dynamic>? current]) async {
    await Navigator.push<bool>(
      context,
      MaterialPageRoute<bool>(
        builder: (_) => AdminServiceEditorPage(
          repository: widget.repository,
          current: current,
        ),
      ),
    );
    await _refresh();
  }

  // ignore: unused_element
  Future<void> _legacyEdit([Map<String, dynamic>? current]) async {
    final name = TextEditingController(text: '${current?['nome'] ?? ''}');
    final description = TextEditingController(
      text: '${current?['descricao'] ?? ''}',
    );
    final price = TextEditingController(
      text: current?['valor']?.toString() ?? '',
    );
    final order = TextEditingController(
      text: current?['ordem']?.toString() ?? '0',
    );
    var periodicity = '${current?['periodicidade'] ?? 'mensal'}';
    var active = current?['ativo'] != false;
    var featured = current?['dsetaque'] == true;
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setDialogState) => AlertDialog(
          title: Text(current == null ? 'Novo serviço' : 'Editar serviço'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(labelText: 'Nome *'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: description,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'Descrição'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: price,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: const InputDecoration(labelText: 'Valor (R\$) *'),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  initialValue: periodicity,
                  decoration: const InputDecoration(labelText: 'Periodicidade'),
                  items: const [
                    DropdownMenuItem(value: 'mensal', child: Text('Mensal')),
                    DropdownMenuItem(
                      value: 'trimestral',
                      child: Text('Trimestral'),
                    ),
                    DropdownMenuItem(
                      value: 'semestral',
                      child: Text('Semestral'),
                    ),
                    DropdownMenuItem(value: 'anual', child: Text('Anual')),
                    DropdownMenuItem(value: 'ouro', child: Text('Ouro')),
                  ],
                  onChanged: (value) =>
                      setDialogState(() => periodicity = value ?? periodicity),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: order,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Ordem'),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Ativo'),
                  value: active,
                  onChanged: (value) => setDialogState(() => active = value),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Destaque'),
                  value: featured,
                  onChanged: (value) => setDialogState(() => featured = value),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Salvar'),
            ),
          ],
        ),
      ),
    );
    final parsedPrice = double.tryParse(price.text.trim().replaceAll(',', '.'));
    if (save == true && (name.text.trim().isEmpty || parsedPrice == null)) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Informe nome e valor válidos.')),
        );
    } else if (save == true) {
      await _busy(
        () => widget.repository.adminCrud(
          table: 'servicos',
          operation: current == null ? 'create' : 'update',
          rowId: current?[r'$id']?.toString(),
          data: {
            'nome': name.text.trim(),
            if (description.text.trim().isNotEmpty)
              'descricao': description.text.trim(),
            'valor': parsedPrice,
            'preco_centavos': (parsedPrice! * 100).round(),
            'periodicidade': periodicity,
            'ativo': active,
            'dsetaque': featured,
            'ordem': int.tryParse(order.text) ?? 0,
          },
        ),
      );
    }
    name.dispose();
    description.dispose();
    price.dispose();
    order.dispose();
  }

  Future<void> _delete(Map<String, dynamic> item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Excluir serviço?'),
        content: Text(
          'O serviço “${item['nome']}” será removido. Esta ação será auditada.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await _busy(
        () => widget.repository.adminCrud(
          table: 'servicos',
          operation: 'delete',
          rowId: '${item[r'$id']}',
        ),
      );
    }
  }

  Future<void> _busy(Future<Object?> Function() task) async {
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      await task();
      if (!mounted) return;
      Navigator.pop(context);
      await _refresh();
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Operação concluída e auditada.')),
        );
    } catch (error) {
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(_friendly(error))));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Catálogo'),
      actions: const [RacheyThemeButton(), SizedBox(width: 6)],
    ),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () => _edit(),
      icon: const Icon(Icons.add),
      label: const Text('Novo'),
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorList(
              message: _friendly(snapshot.error!),
              onRetry: _refresh,
            );
          final items = snapshot.data ?? const [];
          if (items.isEmpty)
            return _EmptyList(
              icon: Icons.sell_outlined,
              message: 'Nenhum serviço cadastrado.',
            );
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            itemCount: items.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (_, index) {
              final item = items[index];
              final value = (item['valor'] as num?)?.toDouble() ?? 0;
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(14),
                  leading: SizedBox.square(
                    dimension: 52,
                    child: RacheyRemoteImage(
                      repository: widget.repository,
                      fileId: '${item['imagem_file_id'] ?? ''}',
                      borderRadius: BorderRadius.circular(15),
                      fallbackIcon: item['ativo'] == false
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                    ),
                  ),
                  title: Text(
                    '${item['nome'] ?? 'Serviço'}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    'R\$ ${value.toStringAsFixed(2).replaceAll('.', ',')} • ${item['periodicidade'] ?? ''}',
                  ),
                  onTap: () => _edit(item),
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) =>
                        value == 'edit' ? _edit(item) : _delete(item),
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'edit', child: Text('Editar')),
                      PopupMenuItem(value: 'delete', child: Text('Excluir')),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class _AdminOrders extends StatefulWidget {
  const _AdminOrders({required this.repository});
  final RacheyRepository repository;

  @override
  State<_AdminOrders> createState() => _AdminOrdersState();
}

class _AdminOrdersState extends State<_AdminOrders> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async =>
      _rows(await widget.repository.adminList('pedidos'));
  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Future<Map<String, dynamic>> _reviewData(Map<String, dynamic> item) async {
    final orderId = '${item[r'$id']}';
    final values = await Future.wait<dynamic>([
      widget.repository.adminList('itens_pedido', limit: 100, filters: {'pedido_id': orderId}),
      widget.repository.listModules('payment_meta', parentId: orderId, limit: 10),
      widget.repository.adminList('perfis', limit: 1, filters: {'user_id': '${item['user_id'] ?? ''}'}),
    ]);
    final metadata = values[1] as List<Map<String, dynamic>>;
    return {
      'items': _rows(values[0] as Map<String, dynamic>),
      'payment_id': metadata.isEmpty ? null : metadata.first['reference_id'],
      'profile': _rows(values[2] as Map<String, dynamic>).firstOrNull,
    };
  }

  Future<void> _openOrderProof(Map<String, dynamic> item) async {
    final fileId = '${item['comprovante_file_id'] ?? ''}';
    if (fileId.isEmpty) {
      _toast('Este pedido não possui comprovante.');
      return;
    }
    try {
      final metadata = await widget.repository.adminList(
        'arquivos_metadata',
        limit: 1,
        filters: {'file_id': fileId},
      );
      final rows = _rows(metadata);
      final row = rows.isEmpty ? const <String, dynamic>{} : rows.first;
      final mime = '${row['mime_type'] ?? 'application/octet-stream'}';
      final name = '${row['nome_original'] ?? 'comprovante-$fileId'}';
      final bytes = await widget.repository.downloadFile(fileId);
      if (!mounted) return;
      if (mime.startsWith('image/')) {
        await showDialog<void>(
          context: context,
          builder: (dialogContext) => Dialog(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 680, maxHeight: 820),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AppBar(
                    automaticallyImplyLeading: false,
                    title: const Text('Comprovante do pedido'),
                    actions: [
                      IconButton(
                        tooltip: 'Salvar',
                        onPressed: () => NativeBridge.saveFile(name: name, mimeType: mime, bytes: bytes),
                        icon: const Icon(Icons.download_outlined),
                      ),
                      IconButton(
                        tooltip: 'Fechar',
                        onPressed: () => Navigator.pop(dialogContext),
                        icon: const Icon(Icons.close_rounded),
                      ),
                    ],
                  ),
                  Flexible(
                    child: InteractiveViewer(
                      minScale: .5,
                      maxScale: 5,
                      child: Image.memory(bytes, fit: BoxFit.contain),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      } else {
        await NativeBridge.saveFile(name: name, mimeType: mime, bytes: bytes);
        if (mounted) _toast('Comprovante salvo para visualização.');
      }
    } catch (error) {
      if (mounted) _toast(_friendly(error));
    }
  }

  Future<void> _update(Map<String, dynamic> item) async {
    final orderId = '${item[r'$id']}';
    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('Analisar ${item['numero'] ?? 'pedido'}'),
        content: SizedBox(
          width: 560,
          child: FutureBuilder<Map<String, dynamic>>(
            future: _reviewData(item),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SizedBox(height: 180, child: Center(child: CircularProgressIndicator()));
              }
              if (snapshot.hasError) return Text(_friendly(snapshot.error!));
              final data = snapshot.data ?? const <String, dynamic>{};
              final profile = data['profile'] as Map<String, dynamic>?;
              final items = (data['items'] as List<Map<String, dynamic>>? ?? const []);
              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _ReviewLine('Cliente', '${profile?['nome'] ?? item['user_id'] ?? '-'}'),
                    if ('${profile?['telefone'] ?? ''}'.isNotEmpty)
                      _ReviewLine('Telefone', '${profile?['telefone']}'),
                    _ReviewLine('Status', _status('${item['status'] ?? ''}')),
                    _ReviewLine('Pagamento', '${item['forma_pagamento'] ?? 'pix'}'.toUpperCase()),
                    _ReviewLine('Total', _money(((item['total_centavos'] as num?) ?? 0).round())),
                    const Divider(height: 26),
                    const Text('Itens', style: TextStyle(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    for (final orderItem in items)
                      ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.sell_outlined),
                        title: Text('${orderItem['nome_servico'] ?? 'Serviço'}'),
                        subtitle: Text('${orderItem['quantidade'] ?? 1}x • ${_periodFromDetails(orderItem['lhes'])}'),
                        trailing: Text(_money(((orderItem['subtotal_centavos'] as num?) ?? 0).round())),
                      ),
                    const SizedBox(height: 8),
                    FilledButton.tonalIcon(
                      onPressed: () => _openOrderProof(item),
                      icon: const Icon(Icons.receipt_long_outlined),
                      label: Text('${item['comprovante_file_id'] ?? ''}'.isEmpty ? 'Sem comprovante' : 'Ver comprovante'),
                    ),
                    if ('${item['observacoes_cliente'] ?? ''}'.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text('Observação: ${item['observacoes_cliente']}'),
                    ],
                  ],
                ),
              );
            },
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Fechar')),
          OutlinedButton.icon(
            onPressed: () => Navigator.pop(dialogContext, 'reject'),
            icon: const Icon(Icons.close_rounded),
            label: const Text('Recusar'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(dialogContext, 'approve'),
            icon: const Icon(Icons.check_rounded),
            label: const Text('Aprovar'),
          ),
        ],
      ),
    );
    if (result == null) return;
    if (result == 'approve' && '${item['comprovante_file_id'] ?? ''}'.isEmpty) {
      _toast('Abra/receba um comprovante antes de aprovar este pedido.');
      return;
    }

    String? rejectionReason;
    if (result == 'reject') {
      final reason = TextEditingController();
      final confirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Recusar pagamento'),
          content: TextField(
            controller: reason,
            minLines: 2,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: 'Motivo obrigatório',
              hintText: 'Ex.: comprovante ilegível ou valor incorreto',
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Confirmar recusa')),
          ],
        ),
      );
      rejectionReason = reason.text.trim();
      reason.dispose();
      if (confirm != true) return;
      if (rejectionReason.isEmpty) {
        _toast('Informe o motivo da recusa para o cliente.');
        return;
      }
    }

    final authenticated = await NativeBridge.authenticate(
      reason: result == 'approve' ? 'Confirme para aprovar este pagamento' : 'Confirme para recusar este pagamento',
    );
    if (!mounted) return;
    if (!authenticated) {
      _toast('Confirmação de segurança cancelada. Nenhuma alteração foi feita.');
      return;
    }

    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      final data = await _reviewData(item);
      final paymentId = '${data['payment_id'] ?? ''}';
      if (paymentId.isEmpty) throw StateError('Pagamento relacionado não encontrado.');
      if (result == 'approve') {
        await widget.repository.action('approve_payment', {'payment_id': paymentId, 'pedido_id': orderId});
      } else {
        await widget.repository.action('reject_payment', {
          'payment_id': paymentId,
          'reason': rejectionReason,
        });
      }
      if (mounted) Navigator.pop(context);
      await _refresh();
      if (mounted) {
        _toast(result == 'approve'
            ? 'Pagamento aprovado e cliente notificado.'
            : 'Pagamento recusado e cliente notificado.');
      }
    } catch (error) {
      if (mounted) {
        Navigator.pop(context);
        _toast(_friendly(error));
      }
    }
  }

  void _toast(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Pedidos'),
      actions: const [RacheyThemeButton(), SizedBox(width: 6)],
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorList(
              message: _friendly(snapshot.error!),
              onRetry: _refresh,
            );
          final items = snapshot.data ?? const [];
          if (items.isEmpty)
            return _EmptyList(
              icon: Icons.receipt_long_outlined,
              message: 'Nenhum pedido recebido.',
            );
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (_, index) {
              final item = items[index];
              final total = ((item['total_centavos'] as num?) ?? 0).round();
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(15),
                  leading: const CircleAvatar(
                    child: Icon(Icons.shopping_bag_outlined),
                  ),
                  title: Text(
                    '${item['numero'] ?? 'Pedido'}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    '${_status('${item['status'] ?? ''}')} • ${_money(total)}',
                  ),
                  trailing: const Icon(Icons.fact_check_outlined),
                  onTap: () => _update(item),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

String _periodFromDetails(dynamic raw) {
  try {
    if (raw is String && raw.trim().startsWith('{')) {
      final decoded = jsonDecode(raw);
      if (decoded is Map) return '${decoded['period_label'] ?? '${decoded['period_days'] ?? 30} dias'}';
    }
  } catch (_) {}
  return 'Período informado no pedido';
}

class _ReviewLine extends StatelessWidget {
  const _ReviewLine(this.label, this.value);
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 105, child: Text(label, style: const TextStyle(color: RacheyColors.gray))),
        Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w700))),
      ],
    ),
  );
}

class _AdminPayments extends StatefulWidget {
  const _AdminPayments({required this.repository});
  final RacheyRepository repository;

  @override
  State<_AdminPayments> createState() => _AdminPaymentsState();
}

class _AdminPaymentsState extends State<_AdminPayments> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async =>
      _rows(await widget.repository.adminList('pagamentos'));
  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Future<void> _approve(Map<String, dynamic> item) async {
    if ('${item['comprovante_id'] ?? ''}'.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Não é possível aprovar sem comprovante.')),
      );
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Aprovar pagamento?'),
        content: Text(
          'Valor: R\$ ${((item['valor'] as num?) ?? 0).toStringAsFixed(2).replaceAll('.', ',')}\nO cliente será notificado automaticamente.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Aprovar'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    if (!mounted) return;
    final authenticated = await NativeBridge.authenticate(
      reason: 'Confirme sua identidade para aprovar este pagamento',
    );
    if (!mounted) return;
    if (!authenticated) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Confirmação de segurança cancelada. Nenhuma alteração foi feita.')),
      );
      return;
    }
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    try {
      await widget.repository.action('approve_payment', {
        'payment_id': item[r'$id'],
      });
      if (!mounted) return;
      Navigator.pop(context);
      await _refresh();
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Pagamento aprovado e cliente notificado.'),
          ),
        );
    } catch (error) {
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(_friendly(error))));
    }
  }

  Future<void> _proof(Map<String, dynamic> item) async {
    final fileId = '${item['comprovante_id'] ?? ''}';
    if (fileId.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Este pagamento ainda não possui comprovante.'),
        ),
      );
      return;
    }
    try {
      final metadata = await widget.repository.adminList(
        'arquivos_metadata',
        limit: 1,
        filters: {'file_id': fileId},
      );
      final rows = _rows(metadata);
      final row = rows.isEmpty ? const <String, dynamic>{} : rows.first;
      final mime = '${row['mime_type'] ?? 'application/octet-stream'}';
      final name = '${row['nome_original'] ?? 'comprovante-$fileId'}';
      final bytes = await widget.repository.downloadFile(fileId);
      if (!mounted) return;
      if (mime.startsWith('image/')) {
        await showDialog<void>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Comprovante Pix'),
            content: InteractiveViewer(child: Image.memory(bytes)),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('Fechar'),
              ),
              FilledButton.icon(
                onPressed: () => NativeBridge.saveFile(
                  name: name,
                  mimeType: mime,
                  bytes: bytes,
                ),
                icon: const Icon(Icons.download_outlined),
                label: const Text('Salvar'),
              ),
            ],
          ),
        );
      } else {
        await NativeBridge.saveFile(name: name, mimeType: mime, bytes: bytes);
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Pagamentos'),
      actions: const [RacheyThemeButton(), SizedBox(width: 6)],
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorList(
              message: _friendly(snapshot.error!),
              onRetry: _refresh,
            );
          final items = snapshot.data ?? const [];
          if (items.isEmpty)
            return _EmptyList(
              icon: Icons.payments_outlined,
              message: 'Nenhum pagamento registrado.',
            );
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (_, index) {
              final item = items[index];
              final pending = const {
                'pendente',
                'aguardando',
                'em_analise',
              }.contains(item['status']);
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(15),
                  leading: CircleAvatar(
                    child: Icon(
                      pending ? Icons.schedule_rounded : Icons.verified_rounded,
                    ),
                  ),
                  title: Text(
                    'R\$ ${((item['valor'] as num?) ?? 0).toStringAsFixed(2).replaceAll('.', ',')}',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: Text(
                    '${item['forma_pagamento'] ?? 'Pagamento'} • ${item['status'] ?? ''}${'${item['comprovante_id'] ?? ''}'.isNotEmpty ? '\nToque para revisar o comprovante' : ''}',
                  ),
                  isThreeLine: '${item['comprovante_id'] ?? ''}'.isNotEmpty,
                  onTap: '${item['comprovante_id'] ?? ''}'.isEmpty
                      ? null
                      : () => _proof(item),
                  trailing: pending
                      ? PopupMenuButton<String>(
                          onSelected: (value) async {
                            if (value == 'approve') {
                              await _approve(item);
                            } else {
                              final reason = TextEditingController();
                              final confirmed = await showDialog<bool>(
                                context: context,
                                builder: (dialogContext) => AlertDialog(
                                  title: const Text('Recusar pagamento'),
                                  content: TextField(
                                    controller: reason,
                                    minLines: 2,
                                    maxLines: 5,
                                    decoration: const InputDecoration(
                                      labelText: 'Motivo para o cliente',
                                    ),
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(dialogContext, false),
                                      child: const Text('Cancelar'),
                                    ),
                                    FilledButton(
                                      onPressed: () =>
                                          Navigator.pop(dialogContext, true),
                                      child: const Text('Recusar'),
                                    ),
                                  ],
                                ),
                              );
                              if (confirmed == true) {
                                final rejectionReason = reason.text.trim();
                                if (rejectionReason.isEmpty) {
                                  reason.dispose();
                                  if (mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Informe o motivo da recusa para o cliente.')),
                                    );
                                  }
                                  return;
                                }
                                final authenticated = await NativeBridge.authenticate(
                                  reason: 'Confirme sua identidade para recusar este pagamento',
                                );
                                if (!mounted) {
                                  reason.dispose();
                                  return;
                                }
                                if (!authenticated) {
                                  reason.dispose();
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Confirmação de segurança cancelada. Nenhuma alteração foi feita.')),
                                  );
                                  return;
                                }
                                showDialog<void>(
                                  context: context,
                                  barrierDismissible: false,
                                  builder: (_) => const Center(child: CircularProgressIndicator()),
                                );
                                try {
                                  await widget.repository.action('reject_payment', {
                                    'payment_id': item[r'$id'],
                                    'reason': rejectionReason,
                                  });
                                  if (mounted) Navigator.pop(context);
                                  await _refresh();
                                  if (mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Pagamento recusado e cliente notificado.')),
                                    );
                                  }
                                } catch (error) {
                                  if (mounted) {
                                    Navigator.pop(context);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text(_friendly(error))),
                                    );
                                  }
                                }
                              }
                              reason.dispose();
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                              value: 'approve',
                              child: Text('Aprovar'),
                            ),
                            PopupMenuItem(
                              value: 'reject',
                              child: Text('Recusar'),
                            ),
                          ],
                        )
                      : const Icon(
                          Icons.check_circle,
                          color: RacheyColors.primary,
                        ),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class _AdminMore extends StatelessWidget {
  const _AdminMore({required this.user, required this.repository});
  final AuthSignedIn user;
  final RacheyRepository repository;

  void _open(BuildContext context, String table, String title) {
    Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) =>
            _AdminRecords(repository: repository, table: table, title: title),
      ),
    );
  }

  void _push(BuildContext context, Widget page) {
    Navigator.push<void>(
      context,
      MaterialPageRoute<void>(builder: (_) => page),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Central de gestão'),
      actions: const [RacheyThemeButton(), SizedBox(width: 6)],
    ),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: const CircleAvatar(
              child: Icon(Icons.admin_panel_settings_rounded),
            ),
            title: Text(
              user.name,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
            subtitle: Text('${user.email}\nEquipe: administradores'),
            isThreeLine: true,
          ),
        ),
        if (user.canOperate) ...[
          const SizedBox(height: 10),
          const _SectionLabel('Catálogo e operações'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.category_outlined),
                  title: const Text('Categorias'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _push(
                    context,
                    AdminCategoriesPage(repository: repository),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.inventory_2_outlined),
                  title: const Text('Estoque inteligente'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _push(
                    context,
                    AdminInventoryPage(repository: repository),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.event_busy_outlined),
                  title: const Text('Central de vencimentos'),
                  subtitle: const Text('Liberações, hoje, próximos dias e vencidas'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _push(context, AdminExpirationCenterPage(repository: repository)),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.hourglass_top_rounded),
                  title: const Text('Lista de espera'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () =>
                      _push(context, AdminWaitlistPage(repository: repository)),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.swap_horiz_rounded),
                  title: const Text('Trocas de conta e tela'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _push(
                    context,
                    AdminSubscriptionRequestsPage(repository: repository),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.sell_outlined),
                  title: const Text('Cupons'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () =>
                      _push(context, AdminCouponsPage(repository: repository)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          const _SectionLabel('Relacionamento'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.contact_page_outlined),
                  title: const Text('CRM de clientes'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () =>
                      _push(context, AdminCrmPage(repository: repository)),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.support_agent_outlined),
                  title: const Text('Tickets de suporte'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _push(
                    context,
                    SupportPage(
                      repository: repository,
                      userId: user.userId,
                      isAdmin: true,
                    ),
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.quickreply_outlined),
                  title: const Text('Respostas rápidas'),
                  subtitle: const Text('Modelos para acelerar o suporte'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _push(context, AdminQuickRepliesPage(repository: repository)),
                ),


              ],
            ),
          ),
        ],
        if (user.canManageFinance) ...[
          const SizedBox(height: 14),
          const _SectionLabel('Gestão'),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.fact_check_outlined),
                  title: const Text('Aprovar pagamentos'),
                  subtitle: const Text('Comprovantes pendentes e recusas'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () =>
                      _push(context, _AdminPayments(repository: repository)),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.account_balance_wallet_outlined),
                  title: const Text('Financeiro e relatórios'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () =>
                      _push(context, AdminFinancePage(repository: repository)),
                ),
                if (user.canConfigure) ...[
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.tune_rounded),
                    title: const Text('Configurações do Rachey'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _push(
                      context,
                      AdminSettingsPage(repository: repository),
                    ),
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.auto_mode_outlined),
                    title: const Text('Automações e backups'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _push(
                      context,
                      AdminAutomationsPage(repository: repository),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
        if (user.canOperate || user.canConfigure) ...[
          const SizedBox(height: 14),
          const _SectionLabel('Registros e segurança'),
          Card(
            child: Column(
              children: [
                if (user.canOperate) ...[
                  ListTile(
                    leading: const Icon(Icons.subscriptions_outlined),
                    title: const Text('Assinaturas e credenciais'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _open(context, 'assinaturas', 'Assinaturas'),
                  ),

                ],
                if (user.canOperate && user.canConfigure)
                  const Divider(height: 1),
                if (user.canConfigure)
                  ListTile(
                    leading: const Icon(Icons.policy_outlined),
                    title: const Text('Auditoria'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _open(context, 'auditoria', 'Auditoria'),
                  ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 18),
        OutlinedButton.icon(
          onPressed: () => context.read<AuthCubit>().logout(),
          icon: const Icon(Icons.logout),
          label: const Text('Sair do painel'),
        ),
      ],
    ),
  );
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(4, 2, 4, 7),
    child: Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
    ),
  );
}

class _AdminRecords extends StatefulWidget {
  const _AdminRecords({
    required this.repository,
    required this.table,
    required this.title,
  });
  final RacheyRepository repository;
  final String table;
  final String title;

  @override
  State<_AdminRecords> createState() => _AdminRecordsState();
}

class _AdminRecordsState extends State<_AdminRecords> {
  late Future<List<Map<String, dynamic>>> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<List<Map<String, dynamic>>> _load() async =>
      _rows(await widget.repository.adminList(widget.table));
  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  Future<void> _act(Map<String, dynamic> item) async {
    if (widget.table == 'assinaturas') {
      await _releaseCredential(item);
    } else if (widget.table == 'mensagens') {
      await _reply(item);
    }
  }

  Future<void> _releaseCredential(Map<String, dynamic> item) async {
    final identifier = TextEditingController();
    final secret = TextEditingController();
    final expiry = TextEditingController(
      text: '${item['data_vencimento'] ?? ''}',
    );
    var hidden = true;
    final save = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (_, setDialogState) => AlertDialog(
          title: Text(
            'Liberar acesso • ${item['nome_servico'] ?? 'Assinatura'}',
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: identifier,
                decoration: const InputDecoration(
                  labelText: 'Login/identificador',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: secret,
                obscureText: hidden,
                decoration: InputDecoration(
                  labelText: 'Senha/segredo',
                  suffixIcon: IconButton(
                    onPressed: () => setDialogState(() => hidden = !hidden),
                    icon: Icon(
                      hidden
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: expiry,
                decoration: const InputDecoration(labelText: 'Expira em (ISO)'),
              ),
              const SizedBox(height: 10),
              const Text(
                'A credencial será criptografada pela Function. O APK nunca a salva localmente.',
                style: TextStyle(fontSize: 12, color: RacheyColors.gray),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Criptografar e liberar'),
            ),
          ],
        ),
      ),
    );
    if (save == true &&
        identifier.text.trim().isNotEmpty &&
        secret.text.isNotEmpty) {
      final authenticated = await NativeBridge.authenticate(
        reason: 'Confirme sua identidade para liberar esta credencial',
      );
      if (!authenticated || !mounted) {
        identifier.dispose();
        secret.clear();
        secret.dispose();
        expiry.dispose();
        return;
      }
      try {
        await widget.repository.action('release_credential', {
          'cliente_id': item['user_id'],
          'servico_id': item['servico_id'],
          'assinatura_id': item[r'$id'],
          'identificador': identifier.text.trim(),
          'segredo': secret.text,
          if (expiry.text.trim().isNotEmpty) 'expira_em': expiry.text.trim(),
        });
        if (mounted)
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Credencial criptografada e liberada.'),
            ),
          );
      } catch (error) {
        if (mounted)
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(_friendly(error))));
      }
    }
    identifier.dispose();
    secret.clear();
    secret.dispose();
    expiry.dispose();
  }

  Future<void> _reply(Map<String, dynamic> item) async {
    final controller = TextEditingController();
    final send = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Responder cliente'),
        content: TextField(
          controller: controller,
          minLines: 3,
          maxLines: 6,
          decoration: const InputDecoration(labelText: 'Mensagem'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Enviar'),
          ),
        ],
      ),
    );
    if (send == true && controller.text.trim().isNotEmpty) {
      try {
        await widget.repository.action('create_message', {
          'cliente_id': item['cliente_id'],
          'texto': controller.text.trim(),
          'tipo': 'texto',
        });
        await _refresh();
      } catch (error) {
        if (mounted)
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(_friendly(error))));
      }
    }
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title)),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting)
            return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError)
            return _ErrorList(
              message: _friendly(snapshot.error!),
              onRetry: _refresh,
            );
          final items = snapshot.data ?? const [];
          if (items.isEmpty)
            return _EmptyList(
              icon: Icons.inbox_outlined,
              message: 'Nenhum registro encontrado.',
            );
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (_, index) {
              final item = items[index];
              final actionable =
                  widget.table == 'assinaturas' || widget.table == 'mensagens';
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(15),
                  leading: CircleAvatar(child: Icon(_tableIcon(widget.table))),
                  title: Text(
                    _recordTitle(widget.table, item),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    _recordSubtitle(widget.table, item),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: actionable ? const Icon(Icons.chevron_right) : null,
                  onTap: actionable ? () => _act(item) : null,
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class _EmptyList extends StatelessWidget {
  const _EmptyList({required this.icon, required this.message});
  final IconData icon;
  final String message;

  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const SizedBox(height: 160),
      Icon(icon, size: 54, color: RacheyColors.gray),
      const SizedBox(height: 12),
      Center(child: Text(message)),
    ],
  );
}

class _ErrorList extends StatelessWidget {
  const _ErrorList({required this.message, required this.onRetry});
  final String message;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) => ListView(
    children: [
      const SizedBox(height: 130),
      const Icon(Icons.cloud_off_outlined, size: 54, color: RacheyColors.gray),
      const SizedBox(height: 12),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Text(message, textAlign: TextAlign.center),
      ),
      const SizedBox(height: 14),
      Center(
        child: OutlinedButton.icon(
          onPressed: onRetry,
          icon: const Icon(Icons.refresh),
          label: const Text('Tentar novamente'),
        ),
      ),
    ],
  );
}

List<Map<String, dynamic>> _rows(Map<String, dynamic> response) =>
    (response['rows'] as List<dynamic>? ?? const [])
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();

IconData _tableIcon(String table) => switch (table) {
  'perfis' => Icons.person_outline,
  'assinaturas' => Icons.subscriptions_outlined,
  'mensagens' => Icons.chat_bubble_outline,
  'notificacoes' => Icons.notifications_outlined,
  'auditoria' => Icons.policy_outlined,
  _ => Icons.description_outlined,
};

String _recordTitle(String table, Map<String, dynamic> item) => switch (table) {
  'perfis' => '${item['nome'] ?? item['email'] ?? 'Cliente'}',
  'assinaturas' => '${item['nome_servico'] ?? 'Assinatura'}',
  'mensagens' => '${item['texto'] ?? 'Arquivo enviado'}',
  'notificacoes' => '${item['titulo'] ?? 'Notificação'}',
  'auditoria' => '${item['acao'] ?? 'Ação'}',
  _ => '${item[r'$id'] ?? 'Registro'}',
};

String _recordSubtitle(
  String table,
  Map<String, dynamic> item,
) => switch (table) {
  'perfis' =>
    '${item['email'] ?? ''} • ${item['tipo'] ?? ''} • ${item['ativo'] == false ? 'inativo' : 'ativo'}',
  'assinaturas' =>
    '${item['status'] ?? ''} • vence em ${_shortDate('${item['data_vencimento'] ?? ''}')} • toque para liberar acesso',
  'mensagens' => 'Cliente: ${item['cliente_id'] ?? ''} • toque para responder',
  'notificacoes' =>
    '${item['mensagem'] ?? ''} • ${item['lida'] == true ? 'lida' : 'não lida'}',
  'auditoria' =>
    '${item['ator_tipo'] ?? ''} • ${item['entidade'] ?? ''} • ${item['sucesso'] == true ? 'sucesso' : 'falha'}',
  _ => '',
};

String _shortDate(String raw) {
  final date = DateTime.tryParse(raw)?.toLocal();
  return date == null
      ? 'não informado'
      : '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
}

String _money(int cents) =>
    'R\$ ${(cents / 100).toStringAsFixed(2).replaceAll('.', ',')}';

String _status(String value) => value.replaceAll('_', ' ');

String _friendly(Object error) =>
    error.toString().replaceFirst(RegExp(r'^.*?Exception:\s*'), '');
