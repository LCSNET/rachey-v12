import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:rachey/core/platform/native_bridge.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/widgets/rachey_ui.dart';
import 'package:rachey/data/models/rachey_document.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/features/profile/presentation/vault_page.dart';
import 'package:rachey/features/support/presentation/support_page.dart';

class SubscriptionsPage extends StatefulWidget {
  const SubscriptionsPage({
    required this.repository,
    required this.userId,
    super.key,
  });

  final RacheyRepository repository;
  final String userId;

  @override
  State<SubscriptionsPage> createState() => _SubscriptionsPageState();
}

class _SubscriptionsPageState extends State<SubscriptionsPage> {
  late Future<_SubscriptionData> _future;

  @override
  void initState() {
    super.initState();
    _future = _load();
  }

  Future<_SubscriptionData> _load() async {
    final values = await Future.wait<dynamic>([
      widget.repository.list(
        type: 'subscription',
        ownerId: widget.userId,
        limit: 500,
      ),
      widget.repository.list(
        type: 'renewal',
        ownerId: widget.userId,
        limit: 500,
      ),
      widget.repository.listModules('service_meta', limit: 500),
      widget.repository.listModules('subscription_request', limit: 500),
    ]);
    final subscriptions = values[0] as List<RacheyDocument>
      ..sort((a, b) => _expiration(a).compareTo(_expiration(b)));
    return _SubscriptionData(
      subscriptions: subscriptions,
      renewals: values[1] as List<RacheyDocument>,
      serviceMetadata: values[2] as List<Map<String, dynamic>>,
      requests: values[3] as List<Map<String, dynamic>>,
    );
  }

  Future<void> _refresh() async {
    setState(() {
      _future = _load();
    });
    await _future;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Assinaturas'),
      actions: [
        const RacheyThemeButton(),
        IconButton(
          tooltip: 'Cofre',
          onPressed: () => Navigator.push<void>(
            context,
            MaterialPageRoute<void>(
              builder: (_) => VaultPage(repository: widget.repository),
            ),
          ),
          icon: const Icon(Icons.lock_outline),
        ),
      ],
    ),
    body: RefreshIndicator(
      onRefresh: _refresh,
      child: FutureBuilder<_SubscriptionData>(
        future: _future,
        builder: (_, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return ListView(
              children: [
                const SizedBox(height: 150),
                const Icon(
                  Icons.cloud_off_outlined,
                  size: 54,
                  color: RacheyColors.gray,
                ),
                const SizedBox(height: 12),
                Center(child: Text(_friendly(snapshot.error!))),
              ],
            );
          }
          final data = snapshot.data!;
          if (data.subscriptions.isEmpty) {
            return ListView(
              children: const [
                SizedBox(height: 160),
                Icon(
                  Icons.subscriptions_outlined,
                  size: 54,
                  color: RacheyColors.gray,
                ),
                SizedBox(height: 12),
                Center(child: Text('Você ainda não possui assinaturas.')),
              ],
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: data.subscriptions.length,
            separatorBuilder: (_, __) => const SizedBox(height: 9),
            itemBuilder: (_, index) {
              final item = data.subscriptions[index];
              final payload = item.payload;
              final days = _daysLeft(item);
              final color = days < 0
                  ? Colors.red
                  : days <= 2
                  ? RacheyColors.promo
                  : RacheyColors.primary;
              return Card(
                child: InkWell(
                  borderRadius: BorderRadius.circular(20),
                  onTap: () async {
                    await Navigator.push<void>(
                      context,
                      MaterialPageRoute<void>(
                        builder: (_) => _SubscriptionDetailsPage(
                          repository: widget.repository,
                          userId: widget.userId,
                          subscription: item,
                          metadata: data.metaFor(
                            '${payload['productId'] ?? ''}',
                          ),
                          renewals: data.renewals
                              .where(
                                (row) =>
                                    row.payload['assinatura_id'] == item.id,
                              )
                              .toList(),
                          requests: data.requests
                              .where((row) => row['reference_id'] == item.id)
                              .toList(),
                        ),
                      ),
                    );
                    await _refresh();
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(17),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 25,
                          backgroundColor: color.withValues(alpha: .14),
                          child: Icon(
                            Icons.subscriptions_rounded,
                            color: color,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${payload['serviceName'] ?? 'Assinatura'}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 17,
                                ),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                '${_label(item.status)} • vence em ${_date('${payload['expiresAt'] ?? ''}')}',
                                style: const TextStyle(
                                  color: RacheyColors.gray,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Column(
                          children: [
                            Text(
                              days < 0
                                  ? '${days.abs()}d atrasada'
                                  : '$days dias',
                              style: TextStyle(
                                color: color,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 6),
                            const Icon(Icons.chevron_right),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    ),
  );
}

class _SubscriptionDetailsPage extends StatefulWidget {
  const _SubscriptionDetailsPage({
    required this.repository,
    required this.userId,
    required this.subscription,
    required this.metadata,
    required this.renewals,
    required this.requests,
  });

  final RacheyRepository repository;
  final String userId;
  final RacheyDocument subscription;
  final Map<String, dynamic> metadata;
  final List<RacheyDocument> renewals;
  final List<Map<String, dynamic>> requests;

  @override
  State<_SubscriptionDetailsPage> createState() =>
      _SubscriptionDetailsPageState();
}

class _SubscriptionDetailsPageState extends State<_SubscriptionDetailsPage> {
  bool _busy = false;
  late bool _automatic;

  @override
  void initState() {
    super.initState();
    _automatic = widget.subscription.payload['automaticRenewal'] == true;
  }

  List<_RenewPeriod> get _periods {
    final raw = widget.metadata['periods'] as List? ?? const [];
    final values = raw
        .whereType<Map>()
        .map(
          (item) => _RenewPeriod(
            days: ((item['days'] as num?) ?? 30).round(),
            label: '${item['label'] ?? '${item['days'] ?? 30} dias'}',
            priceCents:
                ((item['price_cents'] as num?) ??
                        ((widget.subscription.payload['price'] as num? ?? 0) *
                            100))
                    .round(),
          ),
        )
        .toList();
    if (values.isEmpty) {
      values.add(
        _RenewPeriod(
          days: 30,
          label: '30 dias',
          priceCents:
              ((widget.subscription.payload['price'] as num? ?? 0) * 100)
                  .round(),
        ),
      );
    }
    return values;
  }

  Future<void> _renew() async {
    var selected = _periods.first;
    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (_, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 26),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Renovar assinatura',
                style: Theme.of(
                  context,
                ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 14),
              ..._periods.map(
                (period) => RadioListTile<_RenewPeriod>(
                  value: period,
                  groupValue: selected,
                  onChanged: (value) =>
                      setSheetState(() => selected = value ?? selected),
                  title: Text(period.label),
                  secondary: Text(
                    _money(period.priceCents),
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
              const Text(
                'Em contas prontas com vencimento, o valor final é recalculado antes do Pix conforme os dias que ainda cabem na conta.',
                style: TextStyle(fontSize: 12, color: RacheyColors.gray),
              ),
              const SizedBox(height: 10),
              FilledButton(
                onPressed: () => Navigator.pop(sheetContext, true),
                child: const Text('Gerar Pix da renovação'),
              ),
            ],
          ),
        ),
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _busy = true);
    try {
      final result = await widget.repository.action('renew_subscription', {
        'subscription_id': widget.subscription.id,
        'period_days': selected.days,
      });
      if (!mounted) return;
      await Navigator.push<void>(
        context,
        MaterialPageRoute<void>(
          builder: (_) =>
              _RenewalPixPage(repository: widget.repository, renewal: result),
        ),
      );
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggle(bool value) async {
    setState(() {
      _busy = true;
      _automatic = value;
    });
    try {
      await widget.repository.action('toggle_auto_renewal', {
        'subscription_id': widget.subscription.id,
        'enabled': value,
      });
    } catch (error) {
      if (mounted) {
        setState(() => _automatic = !value);
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _requestChange(String type) async {
    final alreadyOpen = widget.requests.any((row) {
      final data = row['data'] as Map? ?? const {};
      return data['type'] == type &&
          const {'aberta', 'aguardando_vaga'}.contains(row['status']);
    });
    if (alreadyOpen) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Já existe uma solicitação em análise.')),
      );
      return;
    }
    final notes = TextEditingController();
    final send = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          type == 'account'
              ? 'Solicitar troca de conta'
              : 'Solicitar troca de tela',
        ),
        content: TextField(
          controller: notes,
          minLines: 3,
          maxLines: 6,
          decoration: const InputDecoration(labelText: 'Explique o motivo'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Enviar solicitação'),
          ),
        ],
      ),
    );
    if (send == true) {
      try {
        await widget.repository.saveModule(
          kind: 'subscription_request',
          referenceId: widget.subscription.id,
          title: type == 'account' ? 'Troca de conta' : 'Troca de tela',
          status: 'aberta',
          data: {'type': type, 'reason': notes.text.trim()},
        );
        if (mounted)
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Solicitação enviada à equipe.')),
          );
      } catch (error) {
        if (mounted)
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(_friendly(error))));
      }
    }
    notes.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final payload = widget.subscription.payload;
    final days = _daysLeft(widget.subscription);
    return Scaffold(
      appBar: AppBar(title: Text('${payload['serviceName'] ?? 'Assinatura'}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [RacheyColors.navy, RacheyColors.darkGreen],
              ),
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.calendar_month_outlined, color: Colors.white),
                const SizedBox(height: 24),
                Text(
                  days < 0
                      ? 'Vencida há ${days.abs()} dias'
                      : '$days dias restantes',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 24,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  'Vencimento em ${_date('${payload['expiresAt'] ?? ''}')}',
                  style: const TextStyle(color: Colors.white70),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.event_available_outlined),
                  title: const Text('Início'),
                  trailing: Text(_date('${payload['startedAt'] ?? ''}')),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.payments_outlined),
                  title: const Text('Valor'),
                  trailing: Text(
                    'R\$ ${((payload['price'] as num?) ?? 0).toStringAsFixed(2).replaceAll('.', ',')}',
                  ),
                ),
                const Divider(height: 1),
                SwitchListTile(
                  secondary: const Icon(Icons.autorenew_rounded),
                  title: const Text('Renovação automática'),
                  subtitle: const Text('Gera a renovação antes do vencimento'),
                  value: _automatic,
                  onChanged: _busy ? null : _toggle,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _renew,
            icon: const Icon(Icons.autorenew_rounded),
            label: const Text('Renovar / ampliar período'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => Navigator.push<void>(
              context,
              MaterialPageRoute<void>(
                builder: (_) => VaultPage(repository: widget.repository),
              ),
            ),
            icon: const Icon(Icons.lock_open_outlined),
            label: const Text('Abrir Cofre'),
          ),
          const SizedBox(height: 18),
          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.swap_horiz_rounded),
                  title: const Text('Trocar conta'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _requestChange('account'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.screenshot_monitor_outlined),
                  title: const Text('Trocar tela/perfil'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _requestChange('screen'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.support_agent_outlined),
                  title: const Text('Abrir suporte'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push<void>(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => SupportPage(
                        repository: widget.repository,
                        userId: widget.userId,
                        subscriptionId: widget.subscription.id,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Histórico de renovações',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
          ),
          const SizedBox(height: 8),
          if (widget.renewals.isEmpty)
            const Card(
              child: ListTile(
                leading: Icon(Icons.history),
                title: Text('Nenhuma renovação registrada.'),
              ),
            )
          else
            ...widget.renewals.map(
              (row) => Card(
                child: ListTile(
                  leading: const Icon(Icons.history_rounded),
                  title: Text(
                    '${_date('${row.payload['data_anterior'] ?? ''}')} → ${_date('${row.payload['nova_data'] ?? ''}')}',
                  ),
                  subtitle: Text(_label(row.status)),
                  trailing: Text(
                    'R\$ ${((row.payload['valor'] as num?) ?? 0).toStringAsFixed(2).replaceAll('.', ',')}',
                  ),
                ),
              ),
            ),
          const SizedBox(height: 16),
          const Text(
            'Solicitações',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
          ),
          const SizedBox(height: 8),
          if (widget.requests.isEmpty)
            const Card(
              child: ListTile(
                leading: Icon(Icons.task_alt_outlined),
                title: Text('Nenhuma solicitação em aberto.'),
              ),
            )
          else
            ...widget.requests.map(
              (row) => Card(
                child: ListTile(
                  title: Text('${row['title'] ?? 'Solicitação'}'),
                  subtitle: Text(_label('${row['status'] ?? ''}')),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _RenewalPixPage extends StatefulWidget {
  const _RenewalPixPage({required this.repository, required this.renewal});

  final RacheyRepository repository;
  final Map<String, dynamic> renewal;

  @override
  State<_RenewalPixPage> createState() => _RenewalPixPageState();
}

class _RenewalPixPageState extends State<_RenewalPixPage> {
  bool _uploading = false;
  bool _checking = false;
  double? _progress;

  Future<void> _proof() async {
    final file = await NativeBridge.pickFile(
      mimeTypes: const ['image/*'],
    );
    if (file == null || !mounted) return;
    setState(() {
      _uploading = true;
      _progress = 0;
    });
    try {
      final upload = await widget.repository.uploadFile(
        file: file,
        type: 'comprovante_renovacao',
        referenceId: '${widget.renewal['renewal_id']}',
        onProgress: (value) {
          if (mounted) setState(() => _progress = value / 100);
        },
      );
      await widget.repository.action('submit_payment_proof', {
        'payment_id': widget.renewal['payment_id'],
        'renewal_id': widget.renewal['renewal_id'],
        'file_id': upload.id,
      });
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          icon: const Icon(
            Icons.check_circle,
            color: RacheyColors.primary,
            size: 42,
          ),
          title: const Text('Comprovante enviado'),
          content: const Text('A renovação será aplicada após a aprovação.'),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Concluir'),
            ),
          ],
        ),
      );
      if (mounted) Navigator.pop(context);
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted)
        setState(() {
          _uploading = false;
          _progress = null;
        });
    }
  }

  Future<void> _verifyAutomaticPix() async {
    setState(() => _checking = true);
    try {
      final result = await widget.repository.action('check_automatic_pix', {'payment_id': widget.renewal['payment_id']});
      if (!mounted) return;
      if (result['approved'] == true) {
        await showDialog<void>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            icon: const Icon(Icons.verified_rounded, color: RacheyColors.primary, size: 42),
            title: const Text('Renovação confirmada'),
            content: const Text('O Mercado Pago confirmou o Pix e a renovação já foi aplicada.'),
            actions: [FilledButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Concluir'))],
          ),
        );
        if (mounted) Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pagamento ainda pendente. Aguarde alguns segundos e tente novamente.')));
      }
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_friendly(error))));
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pix = widget.renewal['pix'] as Map?;
    final qr = '${pix?['qr_base64'] ?? ''}';
    final copy = '${pix?['copia_cola'] ?? ''}';
    final automatic = '${pix?['mode'] ?? pix?['provider'] ?? ''}' == 'mercado_pago';
    final priceCents = (widget.renewal['price_cents'] as num?)?.round() ?? ((pix?['amount_cents'] as num?)?.round() ?? 0);
    final effectiveDays = (widget.renewal['effective_days'] as num?)?.round();
    final prorated = widget.renewal['prorated'] == true;
    return Scaffold(
      appBar: AppBar(title: const Text('Pix da renovação')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: ListTile(
              leading: const Icon(Icons.receipt_long_outlined),
              title: Text('Valor da renovação: ${_money(priceCents)}'),
              subtitle: effectiveDays == null
                  ? null
                  : Text(prorated ? '$effectiveDays dia(s) disponíveis • valor proporcional' : '$effectiveDays dia(s)'),
            ),
          ),
          const SizedBox(height: 12),
          if (qr.isNotEmpty)
            Center(
              child: Container(
                width: 260,
                height: 260,
                padding: const EdgeInsets.all(10),
                color: Colors.white,
                child: Image.memory(base64Decode(qr)),
              ),
            )
          else
            const Card(
              child: ListTile(
                leading: Icon(Icons.warning_amber),
                title: Text('Pix ainda não configurado pelo administrador.'),
              ),
            ),
          if (copy.isNotEmpty) ...[
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: () => Clipboard.setData(ClipboardData(text: copy)),
              icon: const Icon(Icons.copy),
              label: const Text('Copiar Pix Copia e Cola'),
            ),
          ],
          if (_progress != null) ...[
            const SizedBox(height: 18),
            LinearProgressIndicator(value: _progress),
            const SizedBox(height: 6),
            Text(
              'Enviando ${((_progress ?? 0) * 100).round()}%',
              textAlign: TextAlign.center,
            ),
          ],
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: _uploading || _checking || (qr.isEmpty && copy.isEmpty) ? null : (automatic ? _verifyAutomaticPix : _proof),
            icon: Icon(automatic ? Icons.verified_user_outlined : Icons.photo_library_outlined),
            label: Text(_checking ? 'Verificando...' : automatic ? 'Já paguei • verificar pagamento' : 'Enviar comprovante da galeria'),
          ),
        ],
      ),
    );
  }
}

class _SubscriptionData {
  const _SubscriptionData({
    required this.subscriptions,
    required this.renewals,
    required this.serviceMetadata,
    required this.requests,
  });

  final List<RacheyDocument> subscriptions;
  final List<RacheyDocument> renewals;
  final List<Map<String, dynamic>> serviceMetadata;
  final List<Map<String, dynamic>> requests;

  Map<String, dynamic> metaFor(String serviceId) {
    for (final row in serviceMetadata) {
      if (row['reference_id'] == serviceId) {
        return Map<String, dynamic>.from(row['data'] as Map? ?? const {});
      }
    }
    return const {};
  }
}

class _RenewPeriod {
  const _RenewPeriod({
    required this.days,
    required this.label,
    required this.priceCents,
  });
  final int days;
  final String label;
  final int priceCents;
}

int _daysLeft(RacheyDocument item) {
  final due = _expiration(item);
  final now = DateTime.now();
  return DateTime(
    due.year,
    due.month,
    due.day,
  ).difference(DateTime(now.year, now.month, now.day)).inDays;
}

DateTime _expiration(RacheyDocument item) =>
    DateTime.tryParse('${item.payload['expiresAt'] ?? ''}')?.toLocal() ??
    DateTime(1970);

String _label(String value) => switch (value) {
  'ativa' => 'Ativa',
  'vencendo' => 'Vencendo',
  'vencida' => 'Vencida',
  'cancelada' => 'Cancelada',
  'aguardando_pagamento' => 'Aguardando pagamento',
  'confirmada' => 'Confirmada',
  'aberta' => 'Aberta',
  _ => value.isEmpty ? 'Sem status' : value.replaceAll('_', ' '),
};

String _date(String raw) {
  final date = DateTime.tryParse(raw)?.toLocal();
  if (date == null) return 'não informada';
  return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
}

String _money(int cents) =>
    'R\$ ${(cents / 100).toStringAsFixed(2).replaceAll('.', ',')}';

String _friendly(Object error) => error
    .toString()
    .replaceFirst(RegExp(r'^.*?Exception:\s*'), '')
    .replaceFirst('AppwriteException: ', '');
