import 'dart:typed_data';

import 'package:flutter/services.dart';

class PickedNativeFile {
  const PickedNativeFile({
    required this.path,
    required this.name,
    required this.mimeType,
    required this.size,
  });

  final String path;
  final String name;
  final String mimeType;
  final int size;

  factory PickedNativeFile.fromMap(Map<Object?, Object?> value) =>
      PickedNativeFile(
        path: '${value['path'] ?? ''}',
        name: '${value['name'] ?? 'arquivo'}',
        mimeType: '${value['mimeType'] ?? 'application/octet-stream'}',
        size: (value['size'] as num?)?.round() ?? 0,
      );
}

abstract final class NativeBridge {
  static const _channel = MethodChannel('br.com.rachey.app/native');

  static Future<bool> authenticate({
    String reason = 'Confirme sua identidade para continuar',
  }) async =>
      await _channel.invokeMethod<bool>('authenticate', {'reason': reason}) ??
      false;

  static Future<bool> hasPin() async =>
      await _channel.invokeMethod<bool>('hasPin') ?? false;

  static Future<void> setPin(String pin) =>
      _channel.invokeMethod<void>('setPin', {'pin': pin});

  static Future<bool> verifyPin(String pin) async =>
      await _channel.invokeMethod<bool>('verifyPin', {'pin': pin}) ?? false;

  static Future<void> clearPin() => _channel.invokeMethod<void>('clearPin');

  static Future<PickedNativeFile?> pickFile({
    List<String> mimeTypes = const ['*/*'],
  }) async {
    final value = await _channel.invokeMapMethod<Object?, Object?>('pickFile', {
      'mimeTypes': mimeTypes,
    });
    return value == null ? null : PickedNativeFile.fromMap(value);
  }

  static Future<bool> startAudioRecording() async =>
      await _channel.invokeMethod<bool>('startAudioRecording') ?? false;

  static Future<PickedNativeFile?> stopAudioRecording() async {
    final value = await _channel.invokeMapMethod<Object?, Object?>('stopAudioRecording');
    return value == null ? null : PickedNativeFile.fromMap(value);
  }

  static Future<void> cancelAudioRecording() =>
      _channel.invokeMethod<void>('cancelAudioRecording');

  static Future<String?> initialLink() =>
      _channel.invokeMethod<String>('initialLink');

  static Future<bool> requestNotificationPermission() async =>
      await _channel.invokeMethod<bool>('requestNotifications') ?? false;

  static Future<void> showLocalNotification({
    required int id,
    required String title,
    required String body,
  }) => _channel.invokeMethod<void>('showNotification', {
    'id': id,
    'title': title,
    'body': body,
  });

  static Future<bool> saveFile({
    required String name,
    required String mimeType,
    required Uint8List bytes,
  }) async =>
      await _channel.invokeMethod<bool>('saveFile', {
        'name': name,
        'mimeType': mimeType,
        'bytes': bytes,
      }) ??
      false;

  static Future<bool> saveToDownloads({
    required String name,
    required String mimeType,
    required Uint8List bytes,
  }) async =>
      await _channel.invokeMethod<bool>('saveToDownloads', {
        'name': name,
        'mimeType': mimeType,
        'bytes': bytes,
      }) ??
      false;
}
