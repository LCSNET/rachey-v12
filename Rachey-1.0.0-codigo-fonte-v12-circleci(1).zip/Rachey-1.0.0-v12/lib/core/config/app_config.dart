abstract final class AppConfig {
  static const appName = 'Rachey';
  static const packageName = 'br.com.rachey.app';
  static const version = '1.0.0+11';

  // Configuração já existente no Appwrite do Rachey. O app não provisiona backend.
  static const endpoint = String.fromEnvironment(
    'APPWRITE_ENDPOINT',
    defaultValue: 'https://nyc.cloud.appwrite.io/v1',
  );
  static const projectId = String.fromEnvironment(
    'APPWRITE_PROJECT_ID',
    defaultValue: 'rachey',
  );
  static const databaseId = String.fromEnvironment(
    'APPWRITE_DATABASE_ID',
    defaultValue: 'rachey_db',
  );

  static const profilesTableId = 'perfis';
  static const adminTeamId = 'administradores';
  static const categoriesTableId = 'categorias';
  static const servicesTableId = 'servicos';
  static const cartsTableId = 'carrinhos';
  static const cartItemsTableId = 'itens_carrinho';
  static const ordersTableId = 'pedidos';
  static const orderItemsTableId = 'itens_pedido';
  static const subscriptionsTableId = 'assinaturas';
  static const renewalsTableId = 'renovacoes';
  static const paymentsTableId = 'pagamentos';
  static const notificationsTableId = 'notificacoes';
  static const messagesTableId = 'mensagens';
  static const filesMetadataTableId = 'arquivos_metadata';
  static const auditTableId = 'auditoria';
  static const accessCredentialsTableId = 'credenciais_acesso';
  static const modulesTableId = 'dados_rachey';
  static const storageBucketId = String.fromEnvironment(
    'APPWRITE_BUCKET_ID',
    defaultValue: 'arquivos',
  );

  static const mainFunctionId = String.fromEnvironment(
    'APPWRITE_MAIN_FUNCTION_ID',
    defaultValue: 'rachey_admin',
  );
  static const notificationsFunctionId = 'rachey_notifications';

  static const authCallbackUrl = 'rachey://auth/oauth';
  // Appwrite exige que estes redirects usem um hostname cadastrado em
  // Project > Platforms. A página HTTPS deve apenas repassar userId/secret
  // para os deep links rachey://auth/verify e rachey://auth/recovery.
  static const emailVerificationUrl = String.fromEnvironment(
    'APPWRITE_EMAIL_VERIFICATION_URL',
    defaultValue: 'https://rachey-auth.appwrite.network/verify.html',
  );
  static const passwordRecoveryUrl = String.fromEnvironment(
    'APPWRITE_PASSWORD_RECOVERY_URL',
    defaultValue: 'https://rachey-auth.appwrite.network/recovery.html',
  );
}
