import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:hive_ce/hive.dart';

class AppPreferences extends ChangeNotifier {
  Box<String>? _box;
  ThemeMode _themeMode = ThemeMode.system;
  String _language = 'pt-BR';
  bool _biometricsEnabled = false;
  bool _localNotificationsEnabled = true;

  ThemeMode get themeMode => _themeMode;
  String get language => _language;
  bool get biometricsEnabled => _biometricsEnabled;
  bool get localNotificationsEnabled => _localNotificationsEnabled;

  Future<void> attach(Box<String> box) async {
    _box = box;
    _themeMode = switch (box.get('preference.theme')) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };
    _language = box.get('preference.language') ?? 'pt-BR';
    _biometricsEnabled = box.get('preference.biometrics') == 'true';
    _localNotificationsEnabled =
        box.get('preference.local_notifications') != 'false';
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode value) async {
    _themeMode = value;
    notifyListeners();
    await _box?.put('preference.theme', value.name);
  }

  Future<void> setLanguage(String value) async {
    _language = value;
    notifyListeners();
    await _box?.put('preference.language', value);
  }

  Future<void> setBiometrics(bool value) async {
    _biometricsEnabled = value;
    notifyListeners();
    await _box?.put('preference.biometrics', '$value');
  }

  Future<void> setLocalNotifications(bool value) async {
    _localNotificationsEnabled = value;
    notifyListeners();
    await _box?.put('preference.local_notifications', '$value');
  }

  Set<String> localNotificationHistory() {
    try {
      final raw = _box?.get('notifications.local_seen');
      if (raw == null || raw.isEmpty) return <String>{};
      return (jsonDecode(raw) as List<dynamic>).map((item) => '$item').toSet();
    } catch (_) {
      return <String>{};
    }
  }

  Future<void> markLocalNotifications(Iterable<String> ids) async {
    final values = {...localNotificationHistory(), ...ids}.toList();
    final bounded = values.length <= 300
        ? values
        : values.sublist(values.length - 300);
    await _box?.put('notifications.local_seen', jsonEncode(bounded));
  }
}

class AppPreferencesScope extends InheritedNotifier<AppPreferences> {
  const AppPreferencesScope({
    required AppPreferences preferences,
    required super.child,
    super.key,
  }) : super(notifier: preferences);

  static AppPreferences of(BuildContext context) {
    final scope = context
        .dependOnInheritedWidgetOfExactType<AppPreferencesScope>();
    assert(scope != null, 'AppPreferencesScope não encontrado.');
    return scope!.notifier!;
  }
}
