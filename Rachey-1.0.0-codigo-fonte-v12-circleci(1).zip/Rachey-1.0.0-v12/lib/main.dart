import 'dart:async';

import 'package:flutter/material.dart';
import 'package:hive_ce_flutter/hive_flutter.dart';
import 'package:rachey/app/rachey_app.dart';
import 'package:rachey/data/datasources/appwrite_gateway.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/core/settings/app_preferences.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  final gateway = AppwriteGateway();
  final repository = RacheyRepository(gateway);
  final preferences = AppPreferences();

  // A primeira tela precisa ser desenhada imediatamente. Cache é uma melhoria
  // offline, portanto uma falha nele nunca pode impedir o aplicativo de abrir.
  runApp(
    RacheyApp(
      gateway: gateway,
      repository: repository,
      preferences: preferences,
    ),
  );
  unawaited(_prepareCache(repository, preferences));
}

Future<void> _prepareCache(
  RacheyRepository repository,
  AppPreferences preferences,
) async {
  try {
    await Hive.initFlutter().timeout(const Duration(seconds: 8));
    final cache = await Hive.openBox<String>(
      'rachey_cache_v2',
    ).timeout(const Duration(seconds: 8));
    repository.attachCache(cache);
    await preferences.attach(cache);
    unawaited(repository.syncPending());
  } catch (error, stackTrace) {
    // O app continua online mesmo quando o armazenamento local está indisponível.
    FlutterError.reportError(
      FlutterErrorDetails(
        exception: error,
        stack: stackTrace,
        library: 'Rachey startup',
        context: ErrorDescription('inicializando o cache offline'),
      ),
    );
  }
}
