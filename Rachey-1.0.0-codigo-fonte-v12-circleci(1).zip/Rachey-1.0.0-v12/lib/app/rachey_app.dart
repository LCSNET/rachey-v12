import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:rachey/core/theme/rachey_theme.dart';
import 'package:rachey/core/settings/app_preferences.dart';
import 'package:rachey/data/datasources/appwrite_gateway.dart';
import 'package:rachey/data/repositories/rachey_repository.dart';
import 'package:rachey/features/admin/presentation/admin_shell.dart';
import 'package:rachey/features/auth/presentation/auth_cubit.dart';
import 'package:rachey/features/auth/presentation/login_page.dart';
import 'package:rachey/features/auth/presentation/lock_page.dart';
import 'package:rachey/features/catalog/presentation/catalog_page.dart';
import 'package:rachey/features/group/presentation/group_page.dart';
import 'package:rachey/features/dashboard/presentation/home_page.dart';
import 'package:rachey/features/profile/presentation/profile_page.dart';
import 'package:rachey/features/subscriptions/presentation/subscriptions_page.dart';
import 'package:rachey/features/support/presentation/support_page.dart';

class RacheyApp extends StatelessWidget {
  const RacheyApp({
    required this.gateway,
    required this.repository,
    required this.preferences,
    super.key,
  });

  final AppwriteGateway gateway;
  final RacheyRepository repository;
  final AppPreferences preferences;

  @override
  Widget build(BuildContext context) => BlocProvider(
    create: (_) => AuthCubit(gateway, repository, preferences)..restore(),
    child: AnimatedBuilder(
      animation: preferences,
      builder: (_, __) => AppPreferencesScope(
        preferences: preferences,
        child: MaterialApp(
          title: 'Rachey',
          debugShowCheckedModeBanner: false,
          theme: RacheyTheme.light(),
          darkTheme: RacheyTheme.dark(),
          themeMode: preferences.themeMode,
          locale: Locale.fromSubtags(
            languageCode: preferences.language.split('-').first,
            countryCode: preferences.language.contains('-')
                ? preferences.language.split('-').last
                : null,
          ),
          builder: (context, child) =>
              _AuthLifecycle(child: child ?? const SizedBox.shrink()),
          home: BlocBuilder<AuthCubit, AuthState>(
            builder: (_, state) {
              if (state is AuthLoading) return const _Splash();
              if (state is AuthLocked) return LockPage(state: state);
              if (state is! AuthSignedIn) return const LoginPage();
              if (state.isAdmin) {
                return AdminShell(user: state, repository: repository);
              }
              return _Shell(
                user: state,
                repository: repository,
                preferences: preferences,
              );
            },
          ),
        ),
      ),
    ),
  );
}

class _AuthLifecycle extends StatefulWidget {
  const _AuthLifecycle({required this.child});
  final Widget child;

  @override
  State<_AuthLifecycle> createState() => _AuthLifecycleState();
}

class _AuthLifecycleState extends State<_AuthLifecycle>
    with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      context.read<AuthCubit>().handleAppResumed();
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}

class _Splash extends StatelessWidget {
  const _Splash();
  @override
  Widget build(BuildContext context) => const Scaffold(
    body: Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 34,
            backgroundColor: RacheyColors.primary,
            child: Text(
              'R',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 36,
              ),
            ),
          ),
          SizedBox(height: 20),
          CircularProgressIndicator(),
        ],
      ),
    ),
  );
}

class _Shell extends StatefulWidget {
  const _Shell({
    required this.user,
    required this.repository,
    required this.preferences,
  });

  final AuthSignedIn user;
  final RacheyRepository repository;
  final AppPreferences preferences;

  @override
  State<_Shell> createState() => _ShellState();
}

class _ShellState extends State<_Shell> {
  int index = 0;
  late final List<Widget?> _pages;

  @override
  void initState() {
    super.initState();
    // Só a Home é criada no login. As áreas pesadas (Grupo, Catálogo,
    // Assinaturas, Suporte e Conta) passam a carregar sob demanda.
    _pages = List<Widget?>.filled(6, null);
    _pages[0] = _createPage(0);
  }

  Widget _createPage(int value) => switch (value) {
    0 => HomePage(
        name: widget.user.name,
        userId: widget.user.userId,
        repository: widget.repository,
        onNavigate: _select,
      ),
    1 => CatalogPage(repository: widget.repository, userId: widget.user.userId),
    2 => GroupPage(repository: widget.repository, userId: widget.user.userId),
    3 => SubscriptionsPage(repository: widget.repository, userId: widget.user.userId),
    4 => SupportPage(repository: widget.repository, userId: widget.user.userId),
    _ => ProfilePage(
        repository: widget.repository,
        userId: widget.user.userId,
        preferences: widget.preferences,
      ),
  };

  void _select(int value) {
    if (_pages[value] == null) _pages[value] = _createPage(value);
    setState(() => index = value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: index,
        children: List.generate(6, (value) => _pages[value] ?? const SizedBox.shrink()),
      ),
      bottomNavigationBar: NavigationBar(
        height: 72,
        labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
        selectedIndex: index,
        onDestinationSelected: _select,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Início',
          ),
          NavigationDestination(
            icon: Icon(Icons.storefront_outlined),
            selectedIcon: Icon(Icons.storefront),
            label: 'Catálogo',
          ),
          NavigationDestination(
            icon: Icon(Icons.groups_outlined),
            selectedIcon: Icon(Icons.groups_rounded),
            label: 'Grupo',
          ),
          NavigationDestination(
            icon: Icon(Icons.subscriptions_outlined),
            selectedIcon: Icon(Icons.subscriptions),
            label: 'Assinaturas',
          ),
          NavigationDestination(
            icon: Icon(Icons.support_agent_outlined),
            selectedIcon: Icon(Icons.support_agent),
            label: 'Suporte',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Conta',
          ),
        ],
      ),
    );
  }
}
