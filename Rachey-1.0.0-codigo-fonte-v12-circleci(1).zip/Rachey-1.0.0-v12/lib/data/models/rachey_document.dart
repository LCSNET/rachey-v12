import 'dart:convert';

class RacheyDocument {
  const RacheyDocument({
    required this.id,
    required this.type,
    required this.ownerId,
    required this.status,
    required this.search,
    required this.payload,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String type;
  final String ownerId;
  final String status;
  final String search;
  final Map<String, dynamic> payload;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  static Map<String, dynamic> _json(Map<String, dynamic> row) {
    for (final key in const [
      'dados_json',
      'dados',
      'payload',
      'data_json',
      'json',
      'metadata_json',
    ]) {
      final raw = row[key];
      if (raw is String && raw.isNotEmpty) {
        try {
          final value = jsonDecode(raw);
          if (value is Map) return Map<String, dynamic>.from(value);
        } catch (_) {}
      } else if (raw is Map) {
        return Map<String, dynamic>.from(raw);
      }
    }
    return <String, dynamic>{};
  }

  factory RacheyDocument.fromExistingRow(
    String type,
    String id,
    Map<String, dynamic> row,
  ) {
    final saved = _json(row);
    final p = <String, dynamic>{...saved};
    String owner =
        (row['cliente_id'] ??
                row['user_id'] ??
                row['usuario_id'] ??
                saved['userId'] ??
                '')
            .toString();
    String status = (row['status'] ?? saved['status'] ?? '').toString();

    if (type == 'service') {
      final cents = row['preco_centavos'];
      final value = row['valor'] ?? saved['price'] ?? 0;
      p.addAll({
        'name': row['nome'] ?? saved['name'] ?? '',
        'category': row['categoria_id'] ?? saved['category'] ?? '',
        'description': row['descricao'] ?? saved['description'] ?? '',
        'image': row['imagem_file_id'] ?? saved['image'] ?? '',
        'emoji': row['emoji'] ?? saved['emoji'] ?? '✨',
        'active': row['ativo'] ?? saved['active'] ?? true,
        'featured': row['dsetaque'] ?? saved['featured'] ?? false,
        'periodicity': row['periodicidade'] ?? saved['periodicity'] ?? 'mensal',
        'price': cents is num ? cents / 100 : value,
        'priceCents': cents is num
            ? cents.round()
            : ((value is num ? value : num.tryParse('$value')) ?? 0) * 100,
        'order': row['ordem'] ?? saved['order'] ?? 0,
        'plans': _decode(row['planos_json'], saved['plans'] ?? const []),
        'benefits': _decode(
          row['beneficios_json'],
          saved['benefits'] ?? const [],
        ),
        'rating': row['avaliacao'] ?? saved['rating'] ?? 0,
      });
    } else if (type == 'subscription') {
      p.addAll({
        'userId': owner,
        'orderId': row['pedido_id'] ?? saved['orderId'] ?? '',
        'productId': row['servico_id'] ?? saved['productId'] ?? '',
        'serviceName': row['nome_servico'] ?? saved['serviceName'] ?? '',
        'accountId': row['conta_id'] ?? saved['accountId'] ?? '',
        'planId': row['plano_id'] ?? saved['planId'] ?? '',
        'startedAt': row['data_inicio'] ?? saved['startedAt'] ?? '',
        'expiresAt': row['data_vencimento'] ?? saved['expiresAt'] ?? '',
        'price': row['valor'] ?? saved['price'] ?? 0,
        'automaticRenewal':
            row['renovacao_automatica'] ?? saved['automaticRenewal'] ?? false,
        'observacoes': row['observacoes'] ?? saved['observacoes'] ?? '',
        'profile': row['perfil'] ?? saved['profile'] ?? '',
        'instructions': row['instrucoes'] ?? saved['instructions'] ?? '',
      });
    } else {
      p.addAll(
        Map<String, dynamic>.fromEntries(
          row.entries.where((entry) => !entry.key.startsWith(r'$')),
        ),
      );
    }

    return RacheyDocument(
      id: id,
      type: type,
      ownerId: owner,
      status: status,
      search: (p['name'] ?? p['title'] ?? p['numero'] ?? '')
          .toString()
          .toLowerCase(),
      payload: p,
      createdAt: DateTime.tryParse(
        (row[r'$createdAt'] ?? row['criado_em'] ?? '').toString(),
      ),
      updatedAt: DateTime.tryParse(
        (row[r'$updatedAt'] ?? row['atualizado_em'] ?? '').toString(),
      ),
    );
  }

  factory RacheyDocument.fromCache(String id, Map<String, dynamic> data) =>
      RacheyDocument(
        id: id,
        type: data['type'] as String? ?? '',
        ownerId: data['ownerId'] as String? ?? '',
        status: data['status'] as String? ?? '',
        search: data['search'] as String? ?? '',
        payload: Map<String, dynamic>.from(data['payload'] as Map? ?? const {}),
        createdAt: DateTime.tryParse(data['createdAt'] as String? ?? ''),
        updatedAt: DateTime.tryParse(data['updatedAt'] as String? ?? ''),
      );

  Map<String, dynamic> toCacheData() => {
    'type': type,
    'ownerId': ownerId,
    'status': status,
    'search': search,
    'payload': payload,
    'createdAt': createdAt?.toIso8601String(),
    'updatedAt': updatedAt?.toIso8601String(),
  };

  static dynamic _decode(dynamic raw, dynamic fallback) {
    if (raw == null) return fallback;
    if (raw is! String) return raw;
    try {
      return jsonDecode(raw);
    } catch (_) {
      return fallback;
    }
  }
}
