import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:appwrite/appwrite.dart';
import 'package:appwrite/models.dart' as models;
import 'package:hive_ce/hive.dart';
import 'package:rachey/core/config/app_config.dart';
import 'package:rachey/data/datasources/appwrite_gateway.dart';
import 'package:rachey/data/models/rachey_document.dart';
import 'package:rachey/core/platform/native_bridge.dart';

class RacheyUpload {
  const RacheyUpload({
    required this.id,
    required this.name,
    required this.mimeType,
    required this.size,
  });

  final String id;
  final String name;
  final String mimeType;
  final int size;
}

class RacheyRepository {
  RacheyRepository(this.gateway, [Box<String>? cache]) : _cache = cache;

  final AppwriteGateway gateway;
  Box<String>? _cache;
  Timer? _syncTimer;
  bool _syncing = false;
  final Map<String, Future<Uint8List>> _imageRequests = {};

  static const _cacheableModules = {
    'category_meta',
    'service_meta',
    'faq',
    'app_setting_public',
  };

  void attachCache(Box<String> cache) {
    _cache = cache;
    _syncTimer?.cancel();
    _syncTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (pendingSyncCount > 0) unawaited(syncPending());
    });
  }

  String _key(String type, String ownerId) => '$type::$ownerId';

  String? _tableFor(String type) => switch (type) {
    'profile' => AppConfig.profilesTableId,
    'category' => AppConfig.categoriesTableId,
    'service' => AppConfig.servicesTableId,
    'cart' => AppConfig.cartsTableId,
    'cart_item' => AppConfig.cartItemsTableId,
    'order' => AppConfig.ordersTableId,
    'order_item' => AppConfig.orderItemsTableId,
    'subscription' => AppConfig.subscriptionsTableId,
    'renewal' => AppConfig.renewalsTableId,
    'payment' => AppConfig.paymentsTableId,
    'notification' => AppConfig.notificationsTableId,
    'message' => AppConfig.messagesTableId,
    'audit' => AppConfig.auditTableId,
    'credential' => AppConfig.accessCredentialsTableId,
    'module' => AppConfig.modulesTableId,
    _ => null,
  };

  String? _ownerColumn(String type) => switch (type) {
    'profile' => 'user_id',
    'cart' ||
    'cart_item' ||
    'order' ||
    'order_item' ||
    'subscription' ||
    'renewal' ||
    'payment' ||
    'notification' => 'user_id',
    'message' || 'credential' => 'cliente_id',
    _ => null,
  };

  Future<List<RacheyDocument>> list({
    required String type,
    String? ownerId,
    int limit = 100,
  }) async {
    final table = _tableFor(type);
    if (table == null) return const [];
    final queries = <String>[Query.limit(limit)];
    final ownerColumn = _ownerColumn(type);
    if (ownerId != null && ownerId.isNotEmpty && ownerColumn != null) {
      queries.add(Query.equal(ownerColumn, ownerId));
    }
    try {
      final result = await gateway.tablesDB
          .listRows(
            databaseId: AppConfig.databaseId,
            tableId: table,
            queries: queries,
            total: false,
            ttl: 0,
          )
          .timeout(const Duration(seconds: 12));
      final docs = result.rows
          .map(
            (r) => RacheyDocument.fromExistingRow(type, r.$id, {
              ...r.data,
              r'$createdAt': r.$createdAt,
              r'$updatedAt': r.$updatedAt,
            }),
          )
          .toList();
      final cache = _cache;
      if (type != 'credential' && cache != null) {
        try {
          await cache.put(
            _key(type, ownerId ?? '*'),
            jsonEncode(
              docs.map((e) => {'id': e.id, ...e.toCacheData()}).toList(),
            ),
          );
        } catch (_) {
          // A resposta online continua válida mesmo se o cache falhar.
        }
      }
      return docs;
    } catch (_) {
      try {
        final data = await action(
          ownerId == null && (type == 'service' || type == 'category')
              ? 'catalog_list'
              : 'client_list',
          {'table': table, 'limit': limit},
        );
        final rows = (data['rows'] as List<dynamic>? ?? const [])
            .whereType<Map>()
            .map((row) {
              final map = Map<String, dynamic>.from(row);
              final id = (map.remove(r'$id') ?? '').toString();
              return RacheyDocument.fromExistingRow(type, id, map);
            })
            .toList();
        if (type != 'credential' && _cache != null) {
          await _cache!.put(
            _key(type, ownerId ?? '*'),
            jsonEncode(
              rows.map((e) => {'id': e.id, ...e.toCacheData()}).toList(),
            ),
          );
        }
        return rows;
      } catch (_) {
        return type == 'credential' ? const [] : _cached(type, ownerId ?? '*');
      }
    }
  }

  List<RacheyDocument> _cached(String type, String ownerId) {
    final cache = _cache;
    if (cache == null) return const [];
    try {
      final raw = cache.get(_key(type, ownerId));
      if (raw == null || raw.isEmpty) return const [];
      final list = jsonDecode(raw) as List<dynamic>;
      return list.map((e) {
        final m = Map<String, dynamic>.from(e as Map);
        return RacheyDocument.fromCache(m.remove('id') as String, m);
      }).toList();
    } catch (_) {
      return const [];
    }
  }

  Future<models.Execution> privileged(String body) {
    if (AppConfig.mainFunctionId.isEmpty) {
      throw AppwriteException(
        'Function administrativa não configurada no backend atual.',
      );
    }
    return gateway.functions.createExecution(
      functionId: AppConfig.mainFunctionId,
      body: body,
      xasync: false,
    );
  }

  Future<Map<String, dynamic>> action(
    String name, [
    Map<String, dynamic> parameters = const {},
  ]) async {
    final execution = await privileged(
      jsonEncode({'action': name, ...parameters}),
    ).timeout(const Duration(seconds: 25));
    final decoded = jsonDecode(execution.responseBody);
    if (decoded is! Map) {
      throw const FormatException('Resposta inválida do servidor.');
    }
    final response = Map<String, dynamic>.from(decoded);
    if (response['ok'] != true) {
      final code = response['code']?.toString() ?? '';
      final message = response['message']?.toString() ??
          'Não foi possível concluir a operação.';
      if (code == 'unknown_action' || message.contains('Ação desconhecida')) {
        throw AppwriteException(
          'A Function do Appwrite está desatualizada para este recurso. '
          'Implante a Function rachey_admin v12 antes de testar Mercado Pago ou Gemini/Gemma.',
        );
      }
      throw AppwriteException(message);
    }
    final data = response['data'];
    if (data is Map) return Map<String, dynamic>.from(data);
    return <String, dynamic>{'value': data};
  }

  Future<List<Map<String, dynamic>>> listModules(
    String kind, {
    String? ownerId,
    String? parentId,
    String? referenceId,
    String? status,
    int limit = 100,
  }) async {
    final cacheKey = [
      'module',
      kind,
      ownerId ?? '*',
      parentId ?? '*',
      referenceId ?? '*',
      status ?? '*',
      '$limit',
    ].join('::');
    try {
      final data = await action('module_list', {
        'kind': kind,
        if (ownerId != null) 'owner_id': ownerId,
        if (parentId != null) 'parent_id': parentId,
        if (referenceId != null) 'reference_id': referenceId,
        if (status != null) 'status': status,
        'limit': limit,
      });
      final rows = (data['rows'] as List<dynamic>? ?? const [])
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .toList();
      if (_cacheableModules.contains(kind) && _cache != null) {
        final safeRows = rows
            .map(
              (row) => Map<String, dynamic>.from(row)
                ..remove('owner_id')
                ..remove('created_by')
                ..remove('assigned_to'),
            )
            .toList();
        await _cache!.put(cacheKey, jsonEncode(safeRows));
      }
      return rows;
    } catch (_) {
      if (!_cacheableModules.contains(kind) || _cache == null) rethrow;
      try {
        final raw = _cache!.get(cacheKey);
        if (raw == null || raw.isEmpty) rethrow;
        return (jsonDecode(raw) as List<dynamic>)
            .whereType<Map>()
            .map((row) => Map<String, dynamic>.from(row))
            .toList();
      } catch (_) {
        rethrow;
      }
    }
  }

  Future<Map<String, dynamic>> saveModule({
    required String kind,
    required Map<String, dynamic> data,
    String? rowId,
    String? ownerId,
    String? parentId,
    String? referenceId,
    String? externalKey,
    String? title,
    String? status,
    int? sortOrder,
    int? amountCents,
    DateTime? dueAt,
    bool queueIfOffline = false,
  }) async {
    final parameters = <String, dynamic>{
      'kind': kind,
      'data': data,
      if (rowId != null) 'rowId': rowId,
      if (ownerId != null) 'owner_id': ownerId,
      if (parentId != null) 'parent_id': parentId,
      if (referenceId != null) 'reference_id': referenceId,
      if (externalKey != null) 'external_key': externalKey,
      if (title != null) 'title': title,
      if (status != null) 'status': status,
      if (sortOrder != null) 'sort_order': sortOrder,
      if (amountCents != null) 'amount_cents': amountCents,
      if (dueAt != null) 'due_at': dueAt.toUtc().toIso8601String(),
    };
    try {
      return await action('module_upsert', parameters);
    } catch (_) {
      if (!queueIfOffline) rethrow;
      await queueAction('module_upsert', parameters);
      return {'queued': true};
    }
  }

  Future<void> deleteModule(String rowId) async {
    await action('module_delete', {'rowId': rowId});
  }

  Future<void> queueAction(String name, Map<String, dynamic> parameters) async {
    const forbidden = {
      'checkout',
      'reveal_credential',
      'release_credential',
      'approve_payment',
      'submit_payment_proof',
      'inventory_save_account',
    };
    if (forbidden.contains(name)) {
      throw StateError('Esta operação precisa de conexão com o servidor.');
    }
    final cache = _cache;
    if (cache == null) {
      throw StateError('A fila offline ainda não está disponível.');
    }
    final pending = _pendingActions();
    final mutationId =
        '${DateTime.now().microsecondsSinceEpoch}-${pending.length}';
    pending.add({
      'id': mutationId,
      'name': name,
      'parameters': {...parameters, 'client_mutation_id': mutationId},
      'createdAt': DateTime.now().toUtc().toIso8601String(),
    });
    await cache.put('sync.pending', jsonEncode(pending));
  }

  List<Map<String, dynamic>> _pendingActions() {
    final raw = _cache?.get('sync.pending');
    if (raw == null || raw.isEmpty) return [];
    try {
      return (jsonDecode(raw) as List<dynamic>)
          .whereType<Map>()
          .map((item) => Map<String, dynamic>.from(item))
          .toList();
    } catch (_) {
      return [];
    }
  }

  int get pendingSyncCount => _pendingActions().length;

  bool get groupAutoDownload =>
      _cache?.get('preference.group_auto_download') != 'false';

  Future<void> setGroupAutoDownload(bool value) async {
    await _cache?.put('preference.group_auto_download', '$value');
  }

  Set<String> groupDownloadedFiles() {
    try {
      final raw = _cache?.get('group.downloaded_files');
      if (raw == null || raw.isEmpty) return <String>{};
      return (jsonDecode(raw) as List<dynamic>).map((item) => '$item').toSet();
    } catch (_) {
      return <String>{};
    }
  }

  Future<void> markGroupFileDownloaded(String fileId) async {
    final values = {...groupDownloadedFiles(), fileId}.toList();
    final bounded = values.length <= 1000
        ? values
        : values.sublist(values.length - 1000);
    await _cache?.put('group.downloaded_files', jsonEncode(bounded));
  }

  Future<int> syncPending() async {
    if (_syncing) return 0;
    final cache = _cache;
    if (cache == null) return 0;
    _syncing = true;
    final pending = _pendingActions();
    var completed = 0;
    try {
      for (final item in List<Map<String, dynamic>>.from(pending)) {
        try {
          await action(
            '${item['name']}',
            Map<String, dynamic>.from(item['parameters'] as Map? ?? const {}),
          );
          pending.removeWhere((candidate) => candidate['id'] == item['id']);
          completed++;
          await cache.put('sync.pending', jsonEncode(pending));
        } catch (_) {
          break;
        }
      }
    } finally {
      _syncing = false;
    }
    return completed;
  }

  Future<RacheyUpload> uploadFile({
    required PickedNativeFile file,
    required String type,
    String? referenceId,
    bool publicRead = false,
    void Function(double progress)? onProgress,
  }) async {
    if (file.size > 50 * 1024 * 1024) {
      try {
        final stagedFile = File(file.path);
        if (await stagedFile.exists()) await stagedFile.delete();
      } catch (_) {}
      throw AppwriteException('O arquivo excede o limite de 50 MB.');
    }
    try {
      final user = await gateway.account.get();
      final id = ID.unique();
      final sharedRead = publicRead || type.startsWith('grupo_');
      final created = await gateway.storage.createFile(
        bucketId: AppConfig.storageBucketId,
        fileId: id,
        file: InputFile.fromPath(
          path: file.path,
          filename: file.name,
          contentType: file.mimeType,
        ),
        permissions: [
          Permission.read(Role.user(user.$id)),
          Permission.update(Role.user(user.$id)),
          Permission.delete(Role.user(user.$id)),
          if (sharedRead) Permission.read(Role.users()),
        ],
        onProgress: (progress) => onProgress?.call(progress.progress),
      );
      try {
        await action('register_file', {
          'file_id': created.$id,
          'tipo': type,
          'referencia_id': referenceId,
          'nome_original': file.name,
          'mime_type': file.mimeType,
          'tamanho_bytes': file.size,
          'public_read': publicRead,
        });
      } catch (_) {
        try {
          await gateway.storage.deleteFile(
            bucketId: AppConfig.storageBucketId,
            fileId: created.$id,
          );
        } catch (_) {}
        rethrow;
      }
      return RacheyUpload(
        id: created.$id,
        name: file.name,
        mimeType: file.mimeType,
        size: file.size,
      );
    } finally {
      try {
        final stagedFile = File(file.path);
        if (await stagedFile.exists()) await stagedFile.delete();
      } catch (_) {
        // O cache temporário do Android também é limpo pelo sistema.
      }
    }
  }

  Future<Uint8List> downloadFile(String fileId) => gateway.storage
      .getFileDownload(bucketId: AppConfig.storageBucketId, fileId: fileId);

  Future<Uint8List> previewFile(
    String fileId, {
    int width = 800,
    int height = 800,
  }) => gateway.storage.getFilePreview(
    bucketId: AppConfig.storageBucketId,
    fileId: fileId,
    width: width,
    height: height,
  );

  Future<Uint8List> imageFile(
    String fileId, {
    int width = 800,
    int height = 800,
  }) async {
    final key = '$fileId@$width:$height';
    final existing = _imageRequests[key];
    if (existing != null) return existing;
    final request = () async {
      try {
        return await previewFile(fileId, width: width, height: height);
      } catch (_) {
        return downloadFile(fileId);
      }
    }();
    _imageRequests[key] = request;
    try {
      return await request;
    } catch (_) {
      _imageRequests.remove(key);
      rethrow;
    }
  }

  void evictImage(String fileId) {
    _imageRequests.removeWhere((key, _) => key.startsWith('$fileId@'));
  }

  Future<Map<String, dynamic>> adminList(
    String table, {
    int limit = 100,
    Map<String, dynamic>? filters,
  }) {
    final parameters = <String, dynamic>{'table': table, 'limit': limit};
    if (filters != null) parameters['filters'] = filters;
    return action('admin_list', parameters);
  }

  Future<Map<String, dynamic>> adminCrud({
    required String table,
    required String operation,
    String? rowId,
    Map<String, dynamic> data = const {},
  }) {
    final parameters = <String, dynamic>{
      'table': table,
      'operation': operation,
      'data': data,
    };
    if (rowId != null) parameters['rowId'] = rowId;
    return action('admin_crud', parameters);
  }
}
