import 'package:appwrite/appwrite.dart';
import 'package:rachey/core/config/app_config.dart';

class AppwriteGateway {
  AppwriteGateway() {
    client = Client()
      ..setEndpoint(AppConfig.endpoint)
      ..setProject(AppConfig.projectId);
  }

  late final Client client;
  late final Account account = Account(client);
  late final TablesDB tablesDB = TablesDB(client);
  late final Storage storage = Storage(client);
  late final Teams teams = Teams(client);
  late final Functions functions = Functions(client);
}
