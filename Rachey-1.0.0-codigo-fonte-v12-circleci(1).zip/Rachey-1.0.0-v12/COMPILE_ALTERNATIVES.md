# Compilação do Rachey

## GitHub Actions (recomendado)
1. Envie este projeto para um repositório GitHub.
2. Abra Actions > Build Rachey Android > Run workflow.
3. O workflow instala Flutter 3.44.8 e Java 17, restaura o wrapper Gradle, executa `flutter analyze`, `flutter test` e `flutter build apk --release`.
4. Baixe o artefato `Rachey-1.0.0-v11-apk`.

Variáveis opcionais do repositório:
- APPWRITE_EMAIL_VERIFICATION_URL (substitui a URL padrão, deve ser HTTPS)
- APPWRITE_PASSWORD_RECOVERY_URL (substitui a URL padrão, deve ser HTTPS)
- APPWRITE_ENDPOINT
- APPWRITE_PROJECT_ID
- APPWRITE_DATABASE_ID
- APPWRITE_BUCKET_ID
- APPWRITE_MAIN_FUNCTION_ID

Sem essas duas substituições, o workflow usa a ponte já publicada em
`https://rachey-auth.appwrite.network`.

Nenhuma API key administrativa deve ser adicionada ao app ou às variáveis de build.

## Build offline neste ambiente
Também é possível compilar sem rede se forem fornecidos como arquivos:
- SDK Flutter Linux estável completo;
- Android SDK com platform/build-tools compatíveis;
- cache Pub das dependências ou os pacotes `.tar.gz` necessários;
- distribuição Gradle compatível com o wrapper do projeto ou cache correspondente.

Com esses arquivos montados localmente, o build pode ser executado sem acesso externo.
