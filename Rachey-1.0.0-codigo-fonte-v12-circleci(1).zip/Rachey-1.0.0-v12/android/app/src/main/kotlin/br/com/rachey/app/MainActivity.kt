package br.com.rachey.app

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.hardware.biometrics.BiometricPrompt
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.CancellationSignal
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.GCMParameterSpec

class MainActivity : FlutterActivity() {
    private val channelName = "br.com.rachey.app/native"
    private val prefsName = "rachey_secure"
    private val keyAlias = "rachey_pin_key"
    private val pickRequest = 4101
    private val saveRequest = 4102
    private val credentialRequest = 4103
    private val notificationRequest = 4104
    private val audioRequest = 4105
    private var pendingResult: MethodChannel.Result? = null
    private var pendingSaveBytes: ByteArray? = null
    private var lastLink: String? = null
    private var audioRecorder: MediaRecorder? = null
    private var audioOutput: File? = null

    private fun pinLockedUntil(): Long = getPreferences(Context.MODE_PRIVATE).getLong("pin_locked_until", 0L)
    private fun pinFailures(): Int = getPreferences(Context.MODE_PRIVATE).getInt("pin_failures", 0)
    private fun clearPinFailures() = getPreferences(Context.MODE_PRIVATE).edit().remove("pin_failures").remove("pin_locked_until").apply()
    private fun registerPinFailure() {
        val failures = pinFailures() + 1
        val editor = getPreferences(Context.MODE_PRIVATE).edit().putInt("pin_failures", failures)
        if (failures >= 5) {
            val exponent = (failures - 5).coerceAtMost(5)
            val seconds = (30L shl exponent).coerceAtMost(15L * 60L)
            editor.putLong("pin_locked_until", System.currentTimeMillis() + seconds * 1000L)
        }
        editor.apply()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        lastLink = intent?.dataString
        createNotificationChannel()
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result -> handleMethod(call, result) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        lastLink = intent.dataString
    }

    private fun handleMethod(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "initialLink" -> {
                result.success(lastLink)
                lastLink = null
            }
            "authenticate" -> authenticate(call.argument<String>("reason") ?: "Confirme sua identidade", result)
            "hasPin" -> result.success(getPreferences(Context.MODE_PRIVATE).contains("pin_cipher"))
            "setPin" -> {
                val pin = call.argument<String>("pin") ?: ""
                if (!pin.matches(Regex("\\d{4,8}"))) result.error("invalid_pin", "Use de 4 a 8 números.", null)
                else try { savePin(pin); result.success(null) } catch (e: Exception) { result.error("pin_error", "Não foi possível proteger o PIN.", null) }
            }
            "verifyPin" -> {
                val pin = call.argument<String>("pin") ?: ""
                if (pinLockedUntil() > System.currentTimeMillis()) {
                    result.success(false)
                } else {
                    val accepted = try { verifyPin(pin) } catch (_: Exception) { false }
                    if (accepted) clearPinFailures() else registerPinFailure()
                    result.success(accepted)
                }
            }
            "clearPin" -> {
                getPreferences(Context.MODE_PRIVATE).edit().remove("pin_cipher").remove("pin_iv").remove("pin_failures").remove("pin_locked_until").apply()
                result.success(null)
            }
            "pickFile" -> pickFile(call.argument<List<String>>("mimeTypes") ?: listOf("*/*"), result)
            "saveFile" -> saveFile(call, result)
            "saveToDownloads" -> saveToDownloads(call, result)
            "requestNotifications" -> requestNotifications(result)
            "showNotification" -> showNotification(call, result)
            "startAudioRecording" -> requestAudioRecording(result)
            "stopAudioRecording" -> stopAudioRecording(result)
            "cancelAudioRecording" -> cancelAudioRecording(result)
            else -> result.notImplemented()
        }
    }

    private fun authenticate(reason: String, result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Existe uma confirmação em andamento.", null)
            return
        }
        val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!keyguard.isDeviceSecure) {
            result.success(false)
            return
        }

        pendingResult = result
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+: o prompt do sistema oferece biometria OU a
            // credencial segura do aparelho (PIN, padrão ou senha).
            val prompt = BiometricPrompt.Builder(this)
                .setTitle("Rachey Seguro")
                .setSubtitle(reason)
                .setDeviceCredentialAllowed(true)
                .build()
            prompt.authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(value: BiometricPrompt.AuthenticationResult?) = finishPending(true)
                override fun onAuthenticationError(code: Int, message: CharSequence?) = finishPending(false)
            })
            return
        }

        // Android 9 e anteriores: garante um caminho funcional mesmo em
        // aparelhos sem biometria cadastrada, usando o PIN/padrão/senha do
        // próprio dispositivo em vez de falhar silenciosamente.
        val intent = keyguard.createConfirmDeviceCredentialIntent("Rachey Seguro", reason)
        if (intent == null) {
            finishPending(false)
            return
        }
        startActivityForResult(intent, credentialRequest)
    }

    private fun finishPending(value: Any?) {
        val result = pendingResult ?: return
        pendingResult = null
        result.success(value)
    }

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                keyAlias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build(),
        )
        return generator.generateKey()
    }

    private fun derivePin(pin: String, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, iterations, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    private fun savePin(pin: String) {
        val salt = ByteArray(24).also { SecureRandom().nextBytes(it) }
        val iterations = 120_000
        val digest = derivePin(pin, salt, iterations)
        val payload = listOf(
            "v2",
            iterations.toString(),
            Base64.encodeToString(salt, Base64.NO_WRAP),
            Base64.encodeToString(digest, Base64.NO_WRAP),
        ).joinToString(":")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val encrypted = cipher.doFinal(payload.toByteArray())
        getPreferences(Context.MODE_PRIVATE).edit()
            .putString("pin_cipher", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString("pin_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .apply()
        clearPinFailures()
    }

    private fun verifyPin(pin: String): Boolean {
        val prefs = getPreferences(Context.MODE_PRIVATE)
        val encrypted = Base64.decode(prefs.getString("pin_cipher", null) ?: return false, Base64.NO_WRAP)
        val iv = Base64.decode(prefs.getString("pin_iv", null) ?: return false, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        val parts = String(cipher.doFinal(encrypted)).split(":")
        if (parts.size == 4 && parts[0] == "v2") {
            val iterations = parts[1].toIntOrNull()?.coerceIn(50_000, 500_000) ?: return false
            val salt = Base64.decode(parts[2], Base64.NO_WRAP)
            val expected = Base64.decode(parts[3], Base64.NO_WRAP)
            val actual = derivePin(pin, salt, iterations)
            return MessageDigest.isEqual(expected, actual)
        }
        // Migração transparente do formato v11 (salt:SHA-256). Se o PIN antigo
        // estiver correto, regrava imediatamente no formato PBKDF2 v2.
        if (parts.size == 2) {
            val salt = Base64.decode(parts[0], Base64.NO_WRAP)
            val expected = Base64.decode(parts[1], Base64.NO_WRAP)
            val actual = MessageDigest.getInstance("SHA-256").digest(salt + pin.toByteArray())
            val accepted = MessageDigest.isEqual(expected, actual)
            if (accepted) savePin(pin)
            return accepted
        }
        return false
    }

    private fun pickFile(mimeTypes: List<String>, result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Existe uma seleção em andamento.", null)
            return
        }
        pendingResult = result
        val mediaOnly = mimeTypes.isNotEmpty() && mimeTypes.all {
            it.startsWith("image/") || it.startsWith("video/")
        }
        val intent = if (mediaOnly) mediaPickerIntent(mimeTypes) else Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = if (mimeTypes.size == 1) mimeTypes.first() else "*/*"
            if (mimeTypes.size > 1) putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toTypedArray())
        }
        startActivityForResult(intent, pickRequest)
    }

    /**
     * Imagens e vídeos abrem diretamente no seletor de mídia/galeria do
     * Android. Documentos continuam usando ACTION_OPEN_DOCUMENT.
     */
    private fun mediaPickerIntent(mimeTypes: List<String>): Intent {
        val hasImages = mimeTypes.any { it.startsWith("image/") }
        val hasVideos = mimeTypes.any { it.startsWith("video/") }
        val singleMime = when {
            hasImages && !hasVideos -> "image/*"
            hasVideos && !hasImages -> "video/*"
            else -> null
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return Intent(MediaStore.ACTION_PICK_IMAGES).apply {
                if (singleMime != null) type = singleMime
            }
        }
        val collection = when {
            hasVideos && !hasImages -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        }
        return Intent(Intent.ACTION_PICK, collection).apply {
            type = singleMime ?: "*/*"
            if (hasImages && hasVideos) {
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            }
        }
    }

    private fun saveFile(call: MethodCall, result: MethodChannel.Result) {
        if (pendingResult != null) {
            result.error("busy", "Existe uma operação de arquivo em andamento.", null)
            return
        }
        val bytes = call.argument<ByteArray>("bytes")
        if (bytes == null) {
            result.error("invalid_file", "Arquivo inválido.", null)
            return
        }
        pendingSaveBytes = bytes
        pendingResult = result
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = call.argument<String>("mimeType") ?: "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, call.argument<String>("name") ?: "rachey-arquivo")
        }, saveRequest)
    }

    private fun saveToDownloads(call: MethodCall, result: MethodChannel.Result) {
        val bytes = call.argument<ByteArray>("bytes")
        if (bytes == null) {
            result.error("invalid_file", "Arquivo inválido.", null)
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            result.success(false)
            return
        }
        val rawName = call.argument<String>("name") ?: "rachey-arquivo"
        val safeName = rawName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, safeName)
            put(MediaStore.Downloads.MIME_TYPE, call.argument<String>("mimeType") ?: "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Rachey")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        var uri: Uri? = null
        try {
            uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Não foi possível criar o arquivo.")
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IllegalStateException("Não foi possível gravar o arquivo.")
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            result.success(true)
        } catch (_: Exception) {
            if (uri != null) contentResolver.delete(uri, null, null)
            result.success(false)
        }
    }

    private fun requestNotifications(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            result.success(true)
            return
        }
        pendingResult = result
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
    }

    private fun showNotification(call: MethodCall, result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            result.success(null)
            return
        }
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: Intent(this, MainActivity::class.java)
        val pendingIntent = TaskStackBuilder.create(this).run {
            addNextIntentWithParentStack(launchIntent)
            getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val notification = NotificationCompat.Builder(this, "rachey_alerts")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(call.argument<String>("title") ?: "Rachey")
            .setContentText(call.argument<String>("body") ?: "Você tem uma nova notificação.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(call.argument<String>("body") ?: ""))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()
        NotificationManagerCompat.from(this).notify(call.argument<Int>("id") ?: 1, notification)
        result.success(null)
    }


    private fun requestAudioRecording(result: MethodChannel.Result) {
        if (audioRecorder != null) {
            result.error("recording", "Já existe uma gravação em andamento.", null)
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startAudioRecording(result)
            return
        }
        if (pendingResult != null) {
            result.error("busy", "Existe outra permissão em andamento.", null)
            return
        }
        pendingResult = result
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioRequest)
    }

    private fun startAudioRecording(result: MethodChannel.Result) {
        try {
            val directory = File(cacheDir, "rachey_audio").apply { mkdirs() }
            val output = File(directory, "audio_${System.currentTimeMillis()}.m4a")
            val recorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(output.absolutePath)
                prepare()
                start()
            }
            audioRecorder = recorder
            audioOutput = output
            result.success(true)
        } catch (_: Exception) {
            audioRecorder?.release()
            audioRecorder = null
            audioOutput?.delete()
            audioOutput = null
            result.error("audio_error", "Não foi possível iniciar a gravação.", null)
        }
    }

    private fun stopAudioRecording(result: MethodChannel.Result) {
        val recorder = audioRecorder
        val output = audioOutput
        audioRecorder = null
        audioOutput = null
        if (recorder == null || output == null) {
            result.success(null)
            return
        }
        try {
            recorder.stop()
            recorder.release()
            if (!output.exists() || output.length() == 0L) {
                output.delete()
                result.success(null)
                return
            }
            result.success(mapOf(
                "path" to output.absolutePath,
                "name" to output.name,
                "mimeType" to "audio/mp4",
                "size" to output.length(),
            ))
        } catch (_: Exception) {
            try { recorder.release() } catch (_: Exception) {}
            output.delete()
            result.error("audio_error", "A gravação ficou curta demais ou falhou.", null)
        }
    }

    private fun cancelAudioRecording(result: MethodChannel.Result) {
        val recorder = audioRecorder
        val output = audioOutput
        audioRecorder = null
        audioOutput = null
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        output?.delete()
        result.success(null)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("rachey_alerts", "Alertas Rachey", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            credentialRequest -> finishPending(resultCode == Activity.RESULT_OK)
            pickRequest -> {
                if (resultCode != Activity.RESULT_OK || data?.data == null) { finishPending(null); return }
                try {
                    val uri = data.data!!
                    val metadata = queryMetadata(uri)
                    if (metadata.second > 50L * 1024L * 1024L) {
                        val result = pendingResult
                        pendingResult = null
                        result?.error("file_too_large", "O arquivo excede o limite de 50 MB.", null)
                        return
                    }
                    val safeName = metadata.first.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val directory = File(cacheDir, "rachey_uploads").apply { mkdirs() }
                    val output = File(directory, "${System.currentTimeMillis()}_$safeName")
                    contentResolver.openInputStream(uri).use { input -> output.outputStream().use { out -> input!!.copyTo(out) } }
                    if (output.length() > 50L * 1024L * 1024L) {
                        output.delete()
                        val result = pendingResult
                        pendingResult = null
                        result?.error("file_too_large", "O arquivo excede o limite de 50 MB.", null)
                        return
                    }
                    finishPending(mapOf("path" to output.absolutePath, "name" to metadata.first, "mimeType" to (contentResolver.getType(uri) ?: "application/octet-stream"), "size" to output.length()))
                } catch (_: Exception) { val result = pendingResult; pendingResult = null; result?.error("file_error", "Não foi possível abrir o arquivo.", null) }
            }
            saveRequest -> {
                val bytes = pendingSaveBytes
                pendingSaveBytes = null
                if (resultCode != Activity.RESULT_OK || data?.data == null || bytes == null) { finishPending(false); return }
                try { contentResolver.openOutputStream(data.data!!)?.use { it.write(bytes) }; finishPending(true) }
                catch (_: Exception) { val result = pendingResult; pendingResult = null; result?.error("save_error", "Não foi possível salvar o arquivo.", null) }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == notificationRequest) finishPending(grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED)
        if (requestCode == audioRequest) {
            val result = pendingResult
            pendingResult = null
            if (result == null) return
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startAudioRecording(result)
            else result.error("audio_permission", "Permissão do microfone negada.", null)
        }
    }

    private fun queryMetadata(uri: Uri): Pair<String, Long> {
        var name = "arquivo"
        var size = 0L
        val cursor: Cursor? = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                name = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) ?: name
                size = it.getLong(it.getColumnIndexOrThrow(OpenableColumns.SIZE))
            }
        }
        return name to size
    }
}
