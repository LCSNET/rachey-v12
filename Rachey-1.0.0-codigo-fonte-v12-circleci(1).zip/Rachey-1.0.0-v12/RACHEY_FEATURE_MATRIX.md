# Matriz funcional do Rachey 1.0.0+9

Revisão realizada em 2026-08-10 contra a especificação integral do produto.

Legenda:

- **Integrado**: app e backend reais, sem dados mockados.
- **Implantação**: código concluído; depende da publicação das Functions e da
  migração no projeto Appwrite.
- **Credencial externa**: a implementação existe, mas o provedor exige um
  segredo que não deve ser inventado nem embutido no APK.

## Cliente e autenticação

| Requisito | Estado | Implementação |
|---|---|---|
| Cadastro, login e sessão permanente | Integrado | Appwrite Authentication e restauração segura da sessão. |
| Recuperação e verificação de e-mail | Integrado | App trata abertura a frio e retomada em `rachey://auth/recovery` e `rachey://auth/verify`; ponte HTTPS publicada no Appwrite Sites, plataforma Web cadastrada e URLs definitivas configuradas no código e no build. |
| Google | Credencial externa | Único login social exibido. Fluxo OAuth Android pronto; o Google precisa estar habilitado no Appwrite com o Client ID/Secret do projeto Google Cloud. |
| Biometria e PIN | Integrado | Android BiometricPrompt/credencial do aparelho e PIN cifrado no Android Keystore. |
| Perfil completo | Integrado | Foto, nome, telefone, WhatsApp, cidade, nascimento, CPF opcional cifrado, tema, idioma e segurança. |
| Sessões | Integrado | Listagem e encerramento das sessões Appwrite. |
| Cofre | Implantação | Bloqueio por PIN/biometria, ocultar/copiar e revelação somente após liberação; segredo AES-256-GCM no servidor. |

## Catálogo, venda e estoque

| Requisito | Estado | Implementação |
|---|---|---|
| Categorias | Implantação | CRUD, exclusão, reordenação, ícone, imagem, banner e descrição. |
| Serviços | Implantação | CRUD com imagem, banner, categoria, preço, promoção, cashback, pontos, compatibilidade, observações, FAQ e períodos padrão/personalizado. |
| Tipos de serviço | Implantação | Conta inteira, perfil, tela compartilhada, licença, código e assinatura. |
| Estoque inteligente | Implantação | Contas cifradas, vagas individuais, FEFO, vencimento da conta-mãe, reserva da vaga usada no Pix, reaproveitamento após vencimento da assinatura e expiração da conta. |
| Lista de espera | Implantação | Entrada automática sem estoque e aviso quando uma vaga realmente volta a ficar disponível; a entrega continua obedecendo à regra da conta pronta ou liberação manual. |
| Liberação manual/conta pronta | Implantação | Produto criado na hora fica `aguardando_liberacao` e seus dias começam na entrega. Conta pronta específica pode ter vencimento, preço proporcional e liberação após aprovação. Não existe auto-liberação genérica por serviço. |
| Carrinho | Integrado + implantação | Vários itens, quantidade, período, favoritos, cupom avançado, cashback, cotação de estoque pronto e reserva temporária da vaga usada no Pix. |
| Pix | Implantação | BR Code, QR Code, Copia e Cola, upload com progresso, análise, aprovação, recusa e reenvio. |
| Pedidos | Implantação | Timeline: criação, pagamento, preparação, conta, credenciais, ativação, renovação e conclusão. |
| Assinaturas | Implantação | Dias restantes, renovação/ampliação sem perder dias, renovação proporcional em conta pronta, troca de conta/tela, suporte vinculado e histórico. |
| Favoritos e recompra | Implantação | Favoritos no catálogo, comprar novamente pelo pedido e recomendações relacionadas por categoria. |
| Indicação | Implantação | Código individual e recompensas configuráveis em cashback/pontos, creditadas somente após a primeira compra aprovada. |
| Combos e cupons | Implantação | Produto tipo combo com benefícios; cupons com limite total/por usuário, pedido mínimo, primeira compra, serviços elegíveis e publicação no Grupo. |

## Operação administrativa

| Requisito | Estado | Implementação |
|---|---|---|
| Dashboard | Implantação | Painel Hoje, clientes, pedidos, pagamentos, receita, COGS, despesas, lucro líquido, vencimentos, SLA, estoque baixo, ações necessárias, gráficos e metas. |
| CRM | Implantação | Ficha, observações, etiquetas, compras, financeiro, chamados, histórico, desativação/reativação e exclusão definitiva com auditoria. |
| Grupo Rachey | Integrado | Centro único de comunicação: canais, mensagens, áudio gravado, mídia, respostas, reações, enquetes, perguntas, sorteios com elegibilidade, cupons, @todos, lembretes privados, avisos opcionais de assinatura, bot/ticket, denúncias e moderação. |
| Suporte | Implantação | Tickets, chat, anexos, prioridade, SLA, alerta de atraso, respostas rápidas, avaliação 1–5, responsável e vínculo com pedido/assinatura/Grupo. |
| Financeiro | Implantação | Faturamento, COGS/custo dos produtos, despesas operacionais, lucro líquido estimado, metas, gráficos e exportação PDF/XLSX. |
| Configurações | Implantação | Logo, banner, WhatsApp, Pix cifrado, FAQ, política, termos, redes sociais e tema. |
| Papéis | Implantação | Administrador, operador, financeiro e cliente; menus e ações são validados no app e novamente na Function. Os papéis da equipe são atribuídos pelo Appwrite. |

## Automação, notificações e dados

| Requisito | Estado | Implementação |
|---|---|---|
| Alertas no app e local | Implantação | Persistência técnica no banco e alerta local Android; a comunicação coletiva visível permanece dentro do Grupo Rachey. |
| Vencimentos | Implantação | Dois dias antes, no dia e após vencer, com prevenção de duplicidade. |
| Push e e-mail | Credencial externa | O Console não possui provedor Messaging. Requer FCM/APNs e SMTP/SendGrid próprios. |
| Automações | Implantação | Vencimentos, fila, expiração/reutilização de vagas, reservas Pix, renovação segura, lembretes no Grupo, SLA, fidelidade, auditoria e backup. |
| Auditoria | Implantação | CRUDs, pagamentos, arquivos, estoque, credenciais, renovações, exportações e backups. |
| Storage | Integrado | Foto, catálogo, logo/banner, comprovante, documentos e anexos; mídias do grupo têm retenção configurável e salvamento local automático no Android. |
| Cache offline | Integrado | Hive apenas para dados não sensíveis, estados seguros, fila de ações e sincronização automática a cada 30 segundos. |

## Interface e qualidade

| Requisito | Estado | Implementação |
|---|---|---|
| Identidade visual | Integrado | Paleta oficial, Material 3, cartões próprios, botões, campos e modo escuro coerente. |
| Experiência | Integrado | Hero, fade/scale, ripple, shimmer/skeleton, pull-to-refresh, estados de loading/erro/vazio e semântica Material. |
| Android Studio/APK/AAB | Integrado | Android API 24–36, APK e AAB release, configuração opcional de keystore de produção. |
| Sem mocks | Integrado | Telas consultam Appwrite/Functions ou cache de dados reais; não há catálogo/pedido fictício. |

## Dependências que não podem ficar no APK

Para concluir os canais externos, o proprietário deve fornecer/configurar
diretamente no Appwrite:

1. credenciais OAuth do Google;
2. provedor FCM/APNs para push;
3. provedor SMTP/SendGrid/Mailgun para e-mail;
4. keystore de upload da Play Store para a publicação final.

Esses segredos não foram colocados no código, no cache ou nos artefatos Android.
