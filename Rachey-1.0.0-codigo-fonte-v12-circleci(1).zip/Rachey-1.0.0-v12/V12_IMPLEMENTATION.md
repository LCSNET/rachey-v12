# Rachey 1.0.0+12 — implementação

Esta versão aplica as correções e melhorias solicitadas após a v11.

## Entrada e autenticação

- Sessão e perfil/permissões são buscados em paralelo no caminho crítico.
- A UI entra assim que a sessão válida é conhecida; tarefas secundárias ficam em background.
- Retomada OAuth do Google continua reagindo ao `resumed` do Android.
- Áreas do cliente e do administrador são criadas sob demanda, reduzindo carregamento inicial.

## Uploads Android

- Imagens e vídeos abrem diretamente no seletor de mídia/galeria do Android.
- Documentos continuam usando o gerenciador de arquivos.
- Limite de upload preservado em 50 MB.

## Grupo Rachey

- Links HTTP/HTTPS/`www.` clicáveis.
- Busca local de mensagens.
- Avisos e eventos administrativos.
- Enquetes com encerramento.
- Sorteios com seleção real de data e hora de término.
- Cards especiais para avisos, eventos, enquetes e sorteios.
- Áudio, reações, respostas, fixar, editar, excluir, canais, moderação e denúncias preservados.
- Correção central das notificações de Grupo/menções para o enum aceito pelo Appwrite.

## Rachey Bot — Gemini/Gemma

- IA opcional.
- Várias API keys em fallback.
- Modelo principal e vários modelos de fallback.
- Compatível com IDs Gemini e Gemma disponíveis na Gemini API.
- Painel pode consultar os modelos disponíveis para a chave e escolher o modelo principal.
- Comandos: `/ajuda`, `/regras`, `/suporte`, `/sorteios`, `/resumir`, `/bot` e `@racheybot`.
- Chaves ficam criptografadas no backend e nunca são devolvidas ao APK após salvar.

## Serviços

- Cadastro/edição visual de período + preço + custo.
- Atalhos de 7, 14, 30, 60, 90, 180 e 365 dias.
- Vários períodos por serviço.
- Compatibilidade com dados antigos preservada.

## Pix e Mercado Pago

- Modos: Pix manual, Mercado Pago automático, ou híbrido.
- Access Token, Client ID, Client Secret, Public Key, assinatura secreta de Webhook e URL de notificação configuráveis no painel Admin.
- Segredos digitados no APK são enviados ao backend e criptografados; não ficam embutidos no binário.
- Pix automático é criado pela API real do Mercado Pago usando idempotência.
- QR/Copia e Cola somente são exibidos quando vierem da resposta real do provedor.
- Verificação confere método Pix, valor e referência antes de liberar acesso.
- Webhook assinado pode confirmar automaticamente em segundo plano.
- Botão “Já paguei” permanece como fallback.
- Pix manual continua disponível quando configurado.

## Segurança financeira

- Comprovante fica imutável para o cliente depois de enviado.
- Renovação valida propriedade/tipo do comprovante.
- Aprovação exige comprovante ou confirmação real do provedor.
- Pagamento usa estado `em_processamento` e processamento idempotente.
- IDs determinísticos impedem duplicação de assinatura/credencial em retomadas.
- Configurações secretas não são ecoadas pela resposta de salvamento.

## PIN local

- PBKDF2-HMAC-SHA256, 120 mil iterações.
- Migração transparente do hash legado da v11.
- 5 tentativas antes de bloqueio temporário progressivo.
- Hash continua protegido pelo Android Keystore/AES-GCM.

## Build e CI

- `version: 1.0.0+12`.
- Callback `appwrite-callback-rachey` preservado no Manifest.
- Build release falha se não houver keystore de produção.
- GitHub Actions usa Flutter 3.44.8 + Java 17, roda analyze/test e build release assinado.
