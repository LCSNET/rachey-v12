# Redirect de verificação e recuperação do Appwrite

O Appwrite aceita `createEmailVerification` e `createRecovery` somente com URL HTTPS cujo hostname esteja cadastrado em **Project > Platforms**. O antigo `rachey://auth/verify` enviado diretamente ao Appwrite causa `general_argument_invalid / Invalid URI`.

## Implantação concluída

A ponte está ativa no Appwrite Sites e o hostname
`rachey-auth.appwrite.network` foi cadastrado como plataforma Web no projeto
`rachey`.

- Verificação: `https://rachey-auth.appwrite.network/verify.html`
- Recuperação: `https://rachey-auth.appwrite.network/recovery.html`

Essas URLs já são os valores padrão do aplicativo, do script de release e do
workflow. Para apontar um build para outro domínio, use:

```bash
flutter build apk --release \
  --dart-define=APPWRITE_EMAIL_VERIFICATION_URL=https://OUTRO-DOMINIO/verify.html \
  --dart-define=APPWRITE_PASSWORD_RECOVERY_URL=https://OUTRO-DOMINIO/recovery.html
```

A página HTTPS preserva `userId` e `secret` e abre `rachey://auth/verify` ou `rachey://auth/recovery`, que já são tratados pelo app Android.

O workflow recusa URLs vazias ou sem HTTPS. Ao trocar de domínio, cadastre
apenas o hostname no Appwrite (sem caminho), mas informe os caminhos completos
`verify.html` e `recovery.html` nas variáveis de build.
