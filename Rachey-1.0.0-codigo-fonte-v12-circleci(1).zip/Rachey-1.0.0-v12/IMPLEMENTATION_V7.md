# Rachey 1.0.0+7 — implementação consolidada

Esta versão parte do fonte v6 e consolida os ajustes solicitados em 10/08/2026.

## Fluxo comercial
- Checkout gera apenas uma intenção de pagamento temporária; não cria pedido antes do comprovante.
- Pedido, itens e pagamento são persistidos somente após o upload do comprovante.
- Reservas de estoque do Pix expiram e são liberadas pela Function agendada.
- Novos pedidos e tickets de suporte geram alertas para os membros do Team `administradores`.
- Produtos suportam vários períodos/preços no `service_meta.periods`.
- Tela administrativa de análise mostra cliente, telefone, itens, períodos, total e comprovante com zoom antes de aprovar/recusar.
- Formulário “Novo serviço” não carrega mais metadados do primeiro serviço existente.

## Grupo Rachey
- Grupo é o centro visível de comunicação; telas antigas separadas de comunidade/notificações foram removidas.
- Nome, imagem e descrição editáveis pelos administradores.
- Gravação de áudio diretamente pelo microfone no Android.
- Enquetes, perguntas e sorteios; sorteio do vencedor executado no backend.
- Identidade pública por `@username` ou telefone, escolhida pelo usuário.
- Aviso opcional de nova assinatura no grupo.
- Preferência de notificações: todas, admins, menções/@todos ou nenhuma; `@todos` administrativo força o alerta.
- Bot opcional com termos bloqueados, exclusão automática, resposta a menções de admin, alerta aos admins e progressão opcional para silenciar/banir.
- Moderação manual: silenciar, dessilenciar, banir e desbanir.
- Cupom pode ser publicado no grupo e, opcionalmente, usar `@todos`.

## Administração e conta
- Exclusão definitiva de cliente via Function administrativa: Auth + dados relacionados + arquivos; vagas de estoque são liberadas em vez de apagadas.
- Paginação por cursor é usada na exclusão para não ficar limitada aos primeiros registros.
- Ticket novo notifica administradores.

## Verificação de e-mail
O app não envia mais o deep link `rachey://` diretamente como URL de `createEmailVerification`/`createRecovery`. Ele exige uma URL HTTPS permitida pelo Appwrite e inclui uma ponte HTTPS em `deployment/auth-redirect/` para redirecionar de volta ao deep link do Android.

Antes de compilar, hospede a ponte HTTPS, registre o hostname em **Appwrite > Project > Platforms > Web** e defina:

```bash
export APPWRITE_EMAIL_VERIFICATION_URL=https://SEU-DOMINIO/auth/verify.html
export APPWRITE_PASSWORD_RECOVERY_URL=https://SEU-DOMINIO/auth/recovery.html
./build_release.sh
```

## Implantação necessária
1. Publicar a Function atualizada `rachey_admin`.
2. Publicar/atualizar a Function agendada `rachey_notifications`.
3. Hospedar/configurar o redirect HTTPS de autenticação conforme `deployment/AUTH_REDIRECT_SETUP.md`.
4. Para push remoto com o app completamente fechado, configurar um provider de push (FCM) no Appwrite. Sem FCM, os alertas persistidos continuam sendo entregues localmente quando a sessão/app executa a rotina de sincronização.

## Validação desta entrega
- `node --check` aprovado em `rachey_admin/index.js`, `rachey_admin/platform.js` e `rachey_notifications/index.js`.
- Validação estrutural de delimitadores em todos os arquivos Dart aprovada.
- Validação dos imports locais `package:rachey/...` aprovada.
- Busca por `TODO`, `FIXME` e `UnimplementedError` nos fontes alterados sem pendências.
- O ambiente que gerou esta revisão não possui o executável Flutter/Dart, portanto `flutter analyze`, `flutter test` e uma nova compilação APK da v7 não foram executados aqui. O script `build_release.sh` está preparado para fazê-los em um ambiente Flutter.
