# Rachey 1.0.0+9 — autenticação e confirmação de e-mail

Esta revisão preserva toda a implementação funcional da v8 e corrige a etapa
de autenticação solicitada para produção.

## Alterações

- removido o botão e qualquer chamada de login Apple;
- Google definido como o único provedor social do aplicativo;
- cadastro valida a URL HTTPS antes de criar a conta;
- falhas de envio da confirmação de e-mail deixaram de ser ignoradas;
- links `rachey://auth/verify` e `rachey://auth/recovery` validam `userId` e
  `secret` antes de chamar o Appwrite;
- confirmação é processada antes da leitura da sessão, permitindo abertura a
  frio mesmo quando a sessão local expirou;
- páginas HTTPS possuem botão manual de retorno ao app caso o navegador bloqueie
  a abertura automática;
- ponte HTTPS implantada no Appwrite Sites em
  `https://rachey-auth.appwrite.network`;
- hostname da ponte cadastrado como plataforma Web no projeto `rachey`;
- GitHub Actions valida e injeta as URLs HTTPS de verificação e recuperação,
  usando a ponte implantada como padrão.

## Dependência externa

O fluxo Google requer o Client ID e o Client Secret criados pelo proprietário
no Google Cloud e cadastrados em **Appwrite > Auth > Settings > Google**. Esses
segredos não pertencem ao APK nem ao código-fonte.

As páginas-fonte da ponte permanecem em `deployment/auth-redirect/`; a versão
publicada já está ativa no Appwrite Sites.
