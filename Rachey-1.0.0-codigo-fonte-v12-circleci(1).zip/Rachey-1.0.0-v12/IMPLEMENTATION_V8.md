# Rachey 1.0.0+8 — revisão completa e estoque por dias restantes

Esta revisão parte da v7 e compara as melhorias sugeridas com o que o projeto já possuía. O objetivo principal da v8 é preservar o fluxo manual de contas criadas na hora e, ao mesmo tempo, permitir vender contas/telas já prontas com preço proporcional ao tempo real restante.

## Regra principal de liberação

Existem dois comportamentos diferentes e eles não se misturam:

1. **Produto/conta criada na hora**
   - o pagamento pode ser aprovado sem iniciar a contagem do acesso;
   - a assinatura fica em `aguardando_liberacao`;
   - o administrador cria/libera a credencial quando estiver pronta;
   - somente nessa liberação `data_inicio` vira a data real da entrega e o vencimento é recalculado pelo período comprado;
   - portanto, se o cliente comprar hoje e a conta for criada depois de amanhã, ele não perde esses dois dias.

2. **Conta pronta cadastrada no estoque**
   - pode possuir vencimento real da conta-mãe;
   - pode ativar `Preço proporcional aos dias restantes`;
   - nesse modo a conta é, por definição, uma unidade pronta para entrega e é liberada automaticamente **somente após o administrador aprovar o pagamento**;
   - a vaga/tela usada no Pix é reservada antes do pagamento e permanece a mesma na entrega.

Não existe liberação automática genérica por serviço. A liberação automática depende da **conta pronta específica** cadastrada no estoque.

## Precificação proporcional

Para uma conta pronta, o backend calcula:

`dias_efetivos = min(dias_do_período, dias_restantes_da_conta)`

`preço_final = preço_do_período × dias_efetivos / dias_do_período`

O arredondamento é feito para centavos. Um preço positivo nunca vira R$ 0,00 por arredondamento.

Exemplo: período de 30 dias por R$ 20,00 e a conta tem 18 dias restantes:

- 30 dias → 18 dias efetivos → **R$ 12,00**;
- um período de 14 dias que ainda caiba inteiro nos 18 dias mantém o preço normal de 14 dias;
- quando restarem somente 5 dias, períodos de 7/14/30 dias são limitados a 5 dias e ficam proporcionais.

O catálogo mostra a cotação dinâmica antes do checkout. O backend recalcula e é a fonte de verdade do valor exibido no Pix.

## Contas compartilhadas / telas

- Uma conta-mãe pode ter várias vagas/telas.
- Todas herdam o vencimento real da conta-mãe.
- Cada tela é vendida e reservada separadamente.
- O estoque usa FEFO: primeiro tenta vender a conta que vence antes.
- Uma tela vendida por 7 dias é liberada novamente quando esses 7 dias terminam, desde que a conta-mãe ainda esteja válida.
- Quando volta ao estoque, sua próxima venda já considera os dias restantes atuais da conta-mãe.
- Quando a conta-mãe vence, ela e suas vagas deixam de ser vendáveis.
- Credenciais ligadas a uma assinatura vencida são marcadas como expiradas quando a vaga é reaproveitada.

O mesmo mecanismo de unidade pronta pode ser usado por conta inteira, perfil, tela compartilhada, licença, código ou outro serviço; os campos de estoque são apresentados como **identificador/login** e **senha/código/segredo**.

## Renovação e ampliação de período

- Produtos manuais continuam renovando a partir do vencimento atual, sem perder dias já pagos.
- Em uma conta pronta com vencimento real, a renovação consulta quanto tempo ainda cabe na conta-mãe.
- Se o período inteiro couber, usa o preço normal.
- Se não couber e a conta estiver configurada com preço proporcional, cobra somente o período efetivamente disponível.
- Se não couber e preço proporcional estiver desativado, o cliente recebe orientação para solicitar troca de conta/tela antes de pagar.
- Ao aprovar a renovação, o vencimento da assinatura, a credencial e a ocupação da vaga são atualizados juntos.
- Renovação automática é desabilitada para contas prontas com vencimento fixo, porque elas exigem uma nova cotação variável antes do Pix.

## Melhorias que já existiam e foram preservadas

- sessões e encerramento de dispositivos;
- PIN e biometria;
- papéis administrador/operador/financeiro;
- auditoria administrativa;
- estoque por conta/vaga, lista de espera e histórico;
- carrinho, Pix, comprovante, pedido e timeline;
- renovação sem perder dias já pagos;
- cashback, pontos/carteira e despesas;
- histórico de pedidos e assinaturas;
- busca/filtros do catálogo;
- tickets com prioridade;
- Grupo com mensagens fixadas, respostas, reações, mídia e moderação.

## Melhorias adicionadas/completadas na v8

### Operação
- **Central de vencimentos**: aguardando liberação, hoje, 2 dias, 7 dias e vencidas.
- **Painel Hoje / Ação necessária**: faturamento do dia, pagamentos, tickets, vencimentos, estoque baixo e liberações pendentes.
- **Financeiro real**: faturamento, custo dos produtos/serviços (COGS), despesas operacionais e lucro líquido estimado.
- Custo configurável por período e custo proporcional nas vendas de conta pronta.
- Cliente pode ser **desativado/reativado** antes de uma exclusão definitiva.
- Exclusão definitiva exige motivo e confirmação local e libera vagas de estoque vinculadas ao cliente.
- Aprovar/recusar pagamento, revelar estoque sensível e liberar credenciais usam confirmação por PIN/biometria/credencial do aparelho quando disponível.

### Suporte
- SLA por prioridade: urgente, alta, normal e baixa.
- Alerta administrativo de ticket fora do SLA.
- Respostas rápidas administráveis.
- Avaliação de atendimento de 1 a 5.
- Ticket pode nascer vinculado automaticamente à assinatura ou pedido de onde o cliente abriu o suporte.
- Novo ticket continua notificando administradores.
- O bot do Grupo pode criar um ticket quando o usuário chama `@admin`.

### Grupo
- Canais/filtros: Geral, Promoções, Suporte, Sorteios e Avisos.
- Lembretes privados de renovação podem aparecer dentro do Grupo sem expor a mensagem aos demais participantes.
- Sorteios com quantidade de ganhadores e elegibilidade por assinatura ativa, serviço e mínimo de dias ativo.
- Cupons podem ser publicados no Grupo e opcionalmente usar `@todos`.

### Vendas e relacionamento
- Favoritos.
- Comprar novamente pelo histórico de pedido.
- Cross-sell de serviços relacionados da mesma categoria.
- Produto pode ser marcado como **combo** e listar itens/benefícios incluídos.
- Programa de indicação com código individual; recompensa do indicado e de quem indicou é configurável em cashback/pontos e só é creditada na primeira compra aprovada.
- Cupons com limite total, limite por usuário, pedido mínimo, primeira compra e serviços específicos.
- Cupom restrito a serviços desconta somente os itens elegíveis, não o carrinho inteiro.

## Checkout e Pix

- O pedido continua sendo criado **somente depois que o comprovante é enviado**.
- Antes disso existe somente uma intenção de compra temporária.
- Para estoque, a vaga usada na cotação é reservada por 45 minutos.
- Se a intenção expirar, a vaga volta ao estoque.
- Se o Pix não estiver configurado, o backend não cria intenção/renovação órfã.
- Novo pedido com comprovante notifica os administradores.
- Análise administrativa mantém comprovante ampliável e aprovação/recusa.

## Banco/Appwrite

As novas propriedades de estoque, indicação, SLA, favoritos, quick replies e regras de grupo usam a tabela genérica `dados_rachey`/`data_json`. Não é necessário criar uma nova tabela dedicada para cada recurso.

É necessário publicar os pacotes atualizados das Functions `rachey_admin` e `rachey_notifications` após a implantação do APK/fonte v8.

## Validação possível neste ambiente

- `node --check` nas Functions;
- verificação estrutural dos arquivos Dart e imports locais;
- `bash -n build_release.sh`;
- inspeção de referências e busca por TODO/FIXME/UnimplementedError;
- teste de integridade do ZIP final.

O ambiente atual não possui Flutter/Dart instalados. Portanto `flutter analyze`, `flutter test` e a compilação do APK/AAB devem ser executados em um ambiente Flutter estável antes de considerar a v8 validada para produção.
