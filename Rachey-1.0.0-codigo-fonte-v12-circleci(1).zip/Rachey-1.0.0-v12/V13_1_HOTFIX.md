# Rachey v13.1 hotfix

Versão Flutter: 1.1.1+16
Backend: 13.1

Correções:
- evita assertion `_dependents.isEmpty` ao salvar período de serviço;
- evita o mesmo assertion ao recusar pagamentos/solicitações e em outros diálogos administrativos sensíveis;
- aguarda `TransitionRoute.completed` antes de reconstruir a tela, descartar controladores ou abrir autenticação nativa;
- Grupo/PV deixam de depender obrigatoriamente do escopo `teams.read`; se o Team não puder ser consultado, administradores são resolvidos pelos perfis sincronizados;
- mantém compatibilidade com a estrutura Appwrite v13 existente.
