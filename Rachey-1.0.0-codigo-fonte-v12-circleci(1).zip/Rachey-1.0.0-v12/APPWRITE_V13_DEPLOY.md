# Appwrite — atualização necessária para Rachey v13

Implante **duas Functions**.

## 1. rachey_admin v13

Arquivo de implantação: `Rachey-rachey_admin-function-v13.tar.gz`

- Function existente: `rachey_admin`
- Runtime: Node.js compatível com o projeto (>=22)
- Entrypoint: `index.js`
- Criar nova deployment e ativá-la após build.
- Preserve as mesmas variáveis de ambiente/permissões da implantação atual.

O backend informa `backend_version = 13.0` e `minimum_client_version_code = 15`.

## 2. rachey_notifications v13

Arquivo de implantação: `Rachey-rachey_notifications-function-v13.tar.gz`

- Function existente: `rachey_notifications`
- Entrypoint: `index.js`
- Criar nova deployment e ativá-la.
- Configure o schedule para `*/5 * * * *`.

Essa Function já executava rotinas de vencimento/estoque/SLA/backup; na v13 também executa tarefas recorrentes do Rachey Bot.

## Mudança de schema

Nenhuma tabela nova e nenhum atributo novo são obrigatórios para v13. Os novos registros usam `dados_rachey` (`direct_thread`, `direct_message`, `bot_task`, `bot_log`).
