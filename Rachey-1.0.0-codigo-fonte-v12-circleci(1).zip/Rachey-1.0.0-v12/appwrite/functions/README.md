# Appwrite Functions do Rachey

As pastas são pacotes independentes para implantação no Appwrite.

- `rachey_admin`: operações autenticadas de cliente e equipe, esquema dos
  módulos avançados, pagamentos, estoque, cofre, relatórios e auditoria.
- `rachey_notifications`: rotina diária de vencimentos, renovação automática,
  fila de espera, notificações persistidas e backup comprimido.

## Configuração

- Runtime: Node.js 22
- Entrypoint: `index.js`
- Build command: `npm install`
- Function IDs: `rachey_admin` e `rachey_notifications`
- `rachey_admin`: variável secreta `RACHEY_CREDENTIALS_KEY` com 32 bytes em
  Base64
- `rachey_admin`: timeout de 60 segundos. Por padrão, execução por usuários autenticados.
  Se o Pix automático do Mercado Pago usar webhook na mesma Function, permita
  execução pública da Function: o código continua bloqueando requisições anônimas
  comuns e só aceita webhook de `payment` com `x-signature` válido.
- `rachey_notifications`: cron `0 12 * * *`

Escopos mínimos:

- `rachey_admin`: `users.read`, `teams.read`, `rows.read`, `rows.write`, `tables.write`,
  `files.read` e `files.write`.
- `rachey_notifications`: `rows.read`, `rows.write` e `files.write`.

`tables.write` é usado somente para criar/migrar a tabela `dados_rachey` e seus
índices. Os escopos de Storage permitem comprovantes, anexos, exportações e
backups. Nenhuma API key fixa faz parte do código; as Functions usam a chave
temporária injetada pelo Appwrite durante cada execução.

## Mercado Pago automático (v12)

No painel Admin > Configurações > Pagamentos, informe o Access Token e, para
confirmação automática em segundo plano, também a URL pública da Function e a
**assinatura secreta do Webhook** gerada em Suas integrações do Mercado Pago.
Os segredos são enviados pelo APK para a Function e persistidos criptografados
na tabela de configurações; não voltam em respostas da API.

A Function valida `x-signature`/`x-request-id`, consulta o pagamento novamente
na API do Mercado Pago e confere método Pix, valor e referência antes de liberar
qualquer assinatura. O botão "Já paguei" continua disponível como verificação
manual caso o webhook esteja indisponível.
