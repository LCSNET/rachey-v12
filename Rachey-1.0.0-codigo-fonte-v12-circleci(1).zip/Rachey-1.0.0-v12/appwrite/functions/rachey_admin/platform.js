import crypto from 'node:crypto';
import { gzipSync } from 'node:zlib';

import ExcelJS from 'exceljs';
import PDFDocument from 'pdfkit';
import QRCode from 'qrcode';
import {
  ID,
  Permission,
  Query,
  Role,
  Storage,
  Teams,
} from 'node-appwrite';
import { InputFile } from 'node-appwrite/file';

const DATABASE_ID = 'rachey_db';
const ADMIN_TEAM_ID = 'administradores';
const BUCKET_ID = 'arquivos';
const MODULES_TABLE_ID = 'dados_rachey';
const GROUP_ID = 'rachey-main';
const GROUP_MEDIA_TYPES = new Set([
  'grupo_imagem',
  'grupo_video',
  'grupo_audio',
  'grupo_documento',
]);

const NOTIFICATION_TYPES = new Set([
  'vencimento', 'pagamento', 'renovacao', 'sistema', 'estoque',
  'pedido', 'suporte', 'credencial', 'assinatura', 'promocao',
]);

function notificationType(value) {
  const raw = String(value || 'sistema').toLowerCase();
  if (NOTIFICATION_TYPES.has(raw)) return raw;
  if (raw.includes('pedido')) return 'pedido';
  if (raw.includes('pagamento') || raw.includes('payment')) return 'pagamento';
  if (raw.includes('renov')) return 'renovacao';
  if (raw.includes('suporte') || raw.includes('ticket')) return 'suporte';
  if (raw.includes('estoque') || raw.includes('vaga')) return 'estoque';
  if (raw.includes('assin')) return 'assinatura';
  if (raw.includes('promo') || raw.includes('fidel') || raw.includes('cupom')) return 'promocao';
  if (raw.includes('credencial')) return 'credencial';
  return 'sistema';
}

const TABLES = Object.freeze({
  profiles: 'perfis',
  services: 'servicos',
  carts: 'carrinhos',
  cartItems: 'itens_carrinho',
  orders: 'pedidos',
  orderItems: 'itens_pedido',
  subscriptions: 'assinaturas',
  renewals: 'renovacoes',
  payments: 'pagamentos',
  notifications: 'notificacoes',
  fileMetadata: 'arquivos_metadata',
  audit: 'auditoria',
  credentials: 'credenciais_acesso',
  messages: 'mensagens',
  modules: MODULES_TABLE_ID,
});

const PUBLIC_KINDS = new Set([
  'category_meta',
  'service_meta',
  'faq',
  'app_setting_public',
]);

const CLIENT_CREATE_KINDS = new Set([
  'profile_meta',
  'waitlist',
  'support_ticket',
  'support_message',
  'subscription_request',
  'favorite',
  'referral_claim',
]);

const ADMIN_KINDS = new Set([
  'profile_meta',
  'category_meta',
  'service_meta',
  'inventory_account',
  'inventory_slot',
  'waitlist',
  'coupon',
  'order_timeline',
  'payment_meta',
  'crm_note',
  'crm_tag',
  'support_ticket',
  'support_message',
  'expense',
  'goal',
  'price_history',
  'stock_history',
  'loyalty_ledger',
  'app_setting',
  'app_setting_public',
  'faq',
  'subscription_request',
  'backup_run',
  'group_settings',
  'group_message',
  'group_reaction',
  'group_report',
  'group_member',
  'purchase_intent',
  'favorite',
  'quick_reply',
  'coupon_usage',
  'referral_claim',
  'support_sla_alert',
  'direct_thread',
  'direct_message',
  'bot_task',
  'bot_log',
]);

const SAFE_ACTIONS = new Set([
  'backend_info',
  'bootstrap_schema',
  'module_list',
  'module_upsert',
  'module_delete',
  'register_file',
  'delete_file',
  'checkout',
  'submit_payment_proof',
  'check_automatic_pix',
  'test_mercado_pago',
  'test_ai_bot',
  'list_ai_models',
  'approve_payment',
  'reject_payment',
  'inventory_save_account',
  'inventory_update_account',
  'inventory_delete_account',
  'inventory_release_slot',
  'inventory_reveal',
  'renew_subscription',
  'toggle_auto_renewal',
  'dashboard',
  'finance_summary',
  'export_finance',
  'save_app_settings',
  'app_settings',
  'create_ticket',
  'reply_ticket',
  'update_ticket',
  'group_action',
  'waitlist_approve',
  'broadcast_notification',
  'backup_now',
  'update_order',
  'release_credential',
  'subscription_request_update',
  'delete_client',
  'set_client_active',
  'catalog_quotes',
  'rate_ticket',
  'referral_status',
  'apply_referral',
  'direct_action',
  'bot_worker_tick',
]);

const CLIENT_READ_KINDS = new Set([
  'profile_meta',
  'category_meta',
  'service_meta',
  'waitlist',
  'order_timeline',
  'support_ticket',
  'support_message',
  'faq',
  'app_setting_public',
  'subscription_request',
  'loyalty_ledger',
  'favorite',
  'referral_claim',
  'direct_thread',
  'direct_message',
]);

function roleFlags(roles = []) {
  const normalized = new Set(roles.map((role) => String(role).toLowerCase()));
  const full = roles.length === 0 || normalized.has('owner') || normalized.has('admin') || normalized.has('administrador');
  return {
    full,
    operator: full || normalized.has('operator') || normalized.has('operador'),
    finance: full || normalized.has('finance') || normalized.has('financeiro'),
  };
}

function canManageKind(kind, roles = []) {
  const flags = roleFlags(roles);
  if (flags.full) return true;
  if (flags.finance && new Set(['expense', 'goal', 'coupon', 'payment_meta']).has(kind)) return true;
  return flags.operator && new Set([
    'category_meta', 'service_meta', 'inventory_account', 'inventory_slot',
    'waitlist', 'order_timeline', 'stock_history', 'support_ticket',
    'support_message', 'group_settings', 'group_message', 'group_reaction',
    'group_report', 'group_member', 'subscription_request', 'price_history', 'quick_reply',
    'coupon_usage', 'support_sla_alert', 'direct_thread', 'direct_message',
    'bot_task', 'bot_log',
  ]).has(kind);
}

function canReadKind(kind, roles = []) {
  const flags = roleFlags(roles);
  if (flags.full || PUBLIC_KINDS.has(kind)) return true;
  if (flags.finance && new Set([
    'category_meta', 'service_meta', 'expense', 'goal', 'coupon',
    'payment_meta', 'price_history', 'loyalty_ledger',
  ]).has(kind)) return true;
  return flags.operator && new Set([
    'profile_meta', 'category_meta', 'service_meta', 'inventory_account',
    'inventory_slot', 'waitlist', 'order_timeline', 'stock_history',
    'support_ticket', 'support_message',
    'group_settings', 'group_message', 'group_reaction', 'group_report',
    'group_member', 'subscription_request', 'price_history', 'loyalty_ledger',
    'quick_reply', 'coupon_usage', 'support_sla_alert', 'direct_thread',
    'direct_message', 'bot_task', 'bot_log',
  ]).has(kind);
}

function publicError(message, status = 400, code = 'invalid_request') {
  const value = new Error(message);
  value.status = status;
  value.code = code;
  return value;
}

function stableRowId(prefix, value) {
  const digest = crypto.createHash('sha256').update(String(value)).digest('hex');
  const safePrefix = String(prefix || 'r').replace(/[^a-zA-Z0-9]/g, '').slice(0, 4) || 'r';
  return `${safePrefix}_${digest}`.slice(0, 36);
}

function key() {
  const raw = process.env.RACHEY_CREDENTIALS_KEY;
  const value = raw ? Buffer.from(raw, 'base64') : null;
  if (!value || value.length !== 32) {
    throw publicError('Criptografia do servidor indisponível.', 503, 'encryption_unavailable');
  }
  return value;
}

function encryptObject(value) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const encrypted = Buffer.concat([
    cipher.update(JSON.stringify(value), 'utf8'),
    cipher.final(),
  ]);
  return {
    secret_ciphertext: encrypted.toString('base64'),
    secret_iv: iv.toString('base64'),
    secret_tag: cipher.getAuthTag().toString('base64'),
  };
}

function decryptObject(row) {
  if (!row?.secret_ciphertext || !row?.secret_iv || !row?.secret_tag) return {};
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    key(),
    Buffer.from(row.secret_iv, 'base64'),
  );
  decipher.setAuthTag(Buffer.from(row.secret_tag, 'base64'));
  const plain = Buffer.concat([
    decipher.update(Buffer.from(row.secret_ciphertext, 'base64')),
    decipher.final(),
  ]).toString('utf8');
  return JSON.parse(plain);
}

function encryptCredential(identifier, secret, extra = {}) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv);
  const encrypted = Buffer.concat([
    cipher.update(JSON.stringify({ identificador: identifier, segredo: secret, ...extra }), 'utf8'),
    cipher.final(),
  ]);
  return {
    segredo_criptografado: encrypted.toString('base64'),
    iv: iv.toString('base64'),
    tag_autenticacao: cipher.getAuthTag().toString('base64'),
  };
}

function parseJson(raw, fallback = {}) {
  if (raw && typeof raw === 'object') return raw;
  if (typeof raw !== 'string' || !raw) return fallback;
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function safePayload(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  const cleaned = {};
  for (const [rawKey, rawValue] of Object.entries(value).slice(0, 120)) {
    const field = String(rawKey).replace(/[^a-zA-Z0-9_.-]/g, '').slice(0, 64);
    if (!field || rawValue === undefined) continue;
    if (typeof rawValue === 'string') cleaned[field] = rawValue.slice(0, 12000);
    else if (typeof rawValue === 'number' && Number.isFinite(rawValue)) cleaned[field] = rawValue;
    else if (typeof rawValue === 'boolean' || rawValue === null) cleaned[field] = rawValue;
    else if (Array.isArray(rawValue)) cleaned[field] = rawValue.slice(0, 100);
    else if (typeof rawValue === 'object') cleaned[field] = rawValue;
  }
  const encoded = JSON.stringify(cleaned);
  if (encoded.length > 60000) throw publicError('Os dados excedem o limite permitido.');
  return cleaned;
}

function maskedIdentifier(identifier) {
  const value = String(identifier || '').trim();
  if (value.includes('@')) {
    const [name, domain] = value.split('@');
    return `${name.slice(0, 2)}***@${domain}`.slice(0, 150);
  }
  return value.length <= 4 ? '****' : `${value.slice(0, 2)}***${value.slice(-2)}`.slice(0, 150);
}

function adminPermissions() {
  return [
    Permission.read(Role.team(ADMIN_TEAM_ID)),
    Permission.update(Role.team(ADMIN_TEAM_ID, 'owner')),
    Permission.update(Role.team(ADMIN_TEAM_ID, 'admin')),
    Permission.delete(Role.team(ADMIN_TEAM_ID, 'owner')),
    Permission.delete(Role.team(ADMIN_TEAM_ID, 'admin')),
  ];
}

function modulePermissions(ownerId) {
  return [
    ...adminPermissions(),
    ...(ownerId ? [
      Permission.read(Role.user(ownerId)),
      Permission.update(Role.user(ownerId)),
      Permission.delete(Role.user(ownerId)),
    ] : []),
  ];
}

function userPermissions(ownerId) {
  return [
    Permission.read(Role.user(ownerId)),
    Permission.update(Role.user(ownerId)),
    Permission.delete(Role.user(ownerId)),
    ...adminPermissions(),
  ];
}

function maskIp(ip = '') {
  if (!ip) return null;
  if (ip.includes(':')) return `${ip.split(':').slice(0, 3).join(':')}:*`;
  const parts = ip.split('.');
  return parts.length === 4 ? `${parts[0]}.${parts[1]}.*.*` : '*';
}

function redacted(value) {
  const hidden = new Set(['senha', 'password', 'secret', 'segredo', 'cpf', 'pix_key', 'login']);
  const visit = (input, depth = 0) => {
    if (depth > 5) return '[limite]';
    if (Array.isArray(input)) return input.slice(0, 100).map((item) => visit(item, depth + 1));
    if (input && typeof input === 'object') {
      return Object.fromEntries(Object.entries(input).map(([field, item]) => [
        field,
        hidden.has(field.toLowerCase()) || field.toLowerCase().startsWith('secret_')
          ? '[protegido]'
          : visit(item, depth + 1),
      ]));
    }
    return typeof input === 'string' && input.length > 2000 ? `${input.slice(0, 2000)}…` : input;
  };
  return JSON.stringify(visit(value ?? null));
}

async function audit(tables, req, action, entity, entityId, before, after, success = true, message = 'Operação concluída.') {
  const actorUserId = req.headers['x-appwrite-user-id'] || null;
  const actorType = actorUserId
    ? (req.racheyActorType === 'admin' ? 'admin' : 'cliente')
    : 'sistema';
  await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.audit,
    rowId: ID.unique(),
    data: {
      ator_user_id: actorUserId,
      ator_tipo: actorType,
      acao: String(action).slice(0, 100),
      entidade: String(entity).slice(0, 80),
      entidade_id: entityId ? String(entityId).slice(0, 36) : null,
      dados_anteriores: redacted(before),
      daods_novos: redacted(after),
      sucesso: success,
      mensagem: String(message).slice(0, 2000),
      ip_mascarado: maskIp(req.headers['x-appwrite-client-ip']),
      dispositivo: String(req.headers['user-agent'] || '').slice(0, 255) || null,
    },
    permissions: [Permission.read(Role.team(ADMIN_TEAM_ID))],
  });
}

function moduleSchema() {
  return {
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    name: 'Dados Rachey',
    permissions: adminPermissions(),
    rowSecurity: true,
    enabled: true,
    columns: [
      { key: 'kind', type: 'string', size: 64, required: true },
      { key: 'owner_id', type: 'string', size: 36, required: false },
      { key: 'parent_id', type: 'string', size: 36, required: false },
      { key: 'reference_id', type: 'string', size: 36, required: false },
      { key: 'external_key', type: 'string', size: 128, required: false },
      { key: 'title', type: 'string', size: 255, required: false },
      { key: 'status', type: 'string', size: 64, required: false, default: 'ativo' },
      { key: 'sort_order', type: 'integer', required: false, default: 0 },
      { key: 'amount_cents', type: 'integer', required: false, default: 0 },
      { key: 'data_json', type: 'string', size: 65535, required: false },
      { key: 'secret_ciphertext', type: 'string', size: 65535, required: false },
      { key: 'secret_iv', type: 'string', size: 128, required: false },
      { key: 'secret_tag', type: 'string', size: 128, required: false },
      { key: 'created_by', type: 'string', size: 36, required: false },
      { key: 'assigned_to', type: 'string', size: 36, required: false },
      { key: 'due_at', type: 'datetime', required: false },
      { key: 'updated_at', type: 'datetime', required: false },
      { key: 'active', type: 'boolean', required: false, default: true },
      { key: 'visible', type: 'boolean', required: false, default: true },
    ],
    indexes: [
      { key: 'kind_idx', type: 'key', attributes: ['kind'] },
      { key: 'owner_kind_idx', type: 'key', attributes: ['owner_id', 'kind'] },
      { key: 'parent_kind_idx', type: 'key', attributes: ['parent_id', 'kind'] },
      { key: 'reference_kind_idx', type: 'key', attributes: ['reference_id', 'kind'] },
      { key: 'status_kind_idx', type: 'key', attributes: ['status', 'kind'] },
      { key: 'external_key_idx', type: 'key', attributes: ['external_key'] },
      { key: 'external_kind_idx', type: 'key', attributes: ['external_key', 'kind'] },
      { key: 'reference_status_kind_idx', type: 'key', attributes: ['reference_id', 'status', 'kind'] },
      { key: 'owner_reference_status_kind_idx', type: 'key', attributes: ['owner_id', 'reference_id', 'status', 'kind'] },
    ],
  };
}

async function bootstrapSchema(tables) {
  const schema = moduleSchema();
  const mutate = async (operation) => {
    try {
      return await operation();
    } catch (cause) {
      if (String(cause?.message || cause).includes('Unexpected end of JSON input')) return null;
      if (Number(cause?.code) === 409) return null;
      throw cause;
    }
  };
  await mutate(() => tables.updateTable({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    name: schema.name,
    permissions: schema.permissions,
    rowSecurity: true,
    enabled: true,
  }));
  for (const column of schema.columns) {
    const common = {
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      key: column.key,
      required: column.required === true,
      xdefault: column.default,
    };
    if (column.type === 'string') {
      await mutate(() => tables.createStringColumn({ ...common, size: column.size, encrypt: column.encrypt === true }));
    } else if (column.type === 'integer') {
      await mutate(() => tables.createIntegerColumn(common));
    } else if (column.type === 'boolean') {
      await mutate(() => tables.createBooleanColumn(common));
    } else if (column.type === 'datetime') {
      await mutate(() => tables.createDatetimeColumn(common));
    }
  }
  await new Promise((resolve) => setTimeout(resolve, 8000));
  for (const index of schema.indexes) {
    await mutate(() => tables.createIndex({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      key: index.key,
      type: index.type,
      columns: index.attributes,
    }));
  }
  return {
    created: false,
    ready: true,
    columns: schema.columns.length,
    indexes: schema.indexes.length,
    tableId: MODULES_TABLE_ID,
  };

  /* istanbul ignore next -- fluxo legado preservado como fallback documental */
  let created = false;
  try {
    await tables.getTable({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID });
  } catch (cause) {
    if (Number(cause?.code) !== 404) throw cause;
    await mutate(() => tables.createTable(schema));
    created = true;
  }

  await mutate(() => tables.updateTable({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    name: schema.name,
    permissions: schema.permissions,
    rowSecurity: true,
    enabled: true,
  }));

  let columns = (await tables.listColumns({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    queries: [Query.limit(100)],
    total: false,
  })).columns ?? [];
  const existingColumns = new Set(columns.map((column) => column.key));
  for (const column of schema.columns) {
    if (existingColumns.has(column.key)) continue;
    const common = {
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      key: column.key,
      required: column.required === true,
      xdefault: column.default,
    };
    if (column.type === 'string') {
      await mutate(() => tables.createStringColumn({ ...common, size: column.size, encrypt: column.encrypt === true }));
    } else if (column.type === 'integer') {
      await mutate(() => tables.createIntegerColumn(common));
    } else if (column.type === 'boolean') {
      await mutate(() => tables.createBooleanColumn(common));
    } else if (column.type === 'datetime') {
      await mutate(() => tables.createDatetimeColumn(common));
    }
  }

  let columnsReady = false;
  for (let attempt = 0; attempt < 24; attempt++) {
    columns = (await tables.listColumns({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      queries: [Query.limit(100)],
      total: false,
    })).columns ?? [];
    if (schema.columns.every((expected) => columns.some(
      (column) => column.key === expected.key && (!column.status || column.status === 'available'),
    ))) {
      columnsReady = true;
      break;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  if (!columnsReady) throw publicError('A estrutura do banco ainda está sendo preparada. Tente novamente em instantes.', 503, 'schema_building');

  let indexes = (await tables.listIndexes({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    queries: [Query.limit(100)],
    total: false,
  })).indexes ?? [];
  const existingIndexes = new Set(indexes.map((index) => index.key));
  for (const index of schema.indexes) {
    if (existingIndexes.has(index.key)) continue;
    await mutate(() => tables.createIndex({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      key: index.key,
      type: index.type,
      columns: index.attributes,
    }));
  }

  let indexesReady = false;
  for (let attempt = 0; attempt < 24; attempt++) {
    indexes = (await tables.listIndexes({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      queries: [Query.limit(100)],
      total: false,
    })).indexes ?? [];
    if (schema.indexes.every((expected) => indexes.some(
      (index) => index.key === expected.key && (!index.status || index.status === 'available'),
    ))) {
      indexesReady = true;
      break;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  return {
    created,
    ready: columnsReady && indexesReady,
    columns: columns.length,
    indexes: indexes.length,
    tableId: MODULES_TABLE_ID,
  };
}

function splitSensitive(kind, raw) {
  const data = safePayload(raw);
  const secret = {};
  if (kind === 'profile_meta' && Object.hasOwn(data, 'cpf')) {
    secret.cpf = data.cpf;
    delete data.cpf;
  }
  if (kind === 'inventory_account') {
    for (const field of ['login', 'password', 'secondary_pin']) {
      if (Object.hasOwn(data, field)) {
        secret[field] = data[field];
        delete data[field];
      }
    }
  }
  if (kind === 'app_setting') {
    for (const field of [
      'pix_key',
      'mercado_pago_access_token',
      'mercado_pago_client_secret',
      'mercado_pago_webhook_secret',
      'gemini_api_keys',
    ]) {
      if (Object.hasOwn(data, field)) {
        const value = data[field];
        const keep = Array.isArray(value) ? value.some((item) => String(item || '').trim()) : String(value || '').trim();
        if (keep) secret[field] = value;
        delete data[field];
      }
    }
  }
  return { data, secret };
}

function serializeModule(row, includeSecret = false) {
  const data = safePayload(parseJson(row.data_json));
  if (includeSecret && row.secret_ciphertext) Object.assign(data, decryptObject(row));
  return {
    $id: row.$id,
    $createdAt: row.$createdAt,
    $updatedAt: row.$updatedAt,
    kind: row.kind,
    owner_id: row.owner_id,
    parent_id: row.parent_id,
    reference_id: row.reference_id,
    external_key: row.external_key,
    title: row.title,
    status: row.status,
    sort_order: row.sort_order,
    amount_cents: row.amount_cents,
    created_by: row.created_by,
    assigned_to: row.assigned_to,
    due_at: row.due_at,
    active: row.active,
    visible: row.visible,
    data,
  };
}

async function listModuleRows(tables, kind, options = {}) {
  const queries = [Query.equal('kind', kind), Query.limit(Math.max(1, Math.min(500, options.limit ?? 100)))];
  if (options.ownerId) queries.push(Query.equal('owner_id', options.ownerId));
  if (options.parentId) queries.push(Query.equal('parent_id', options.parentId));
  if (options.referenceId) queries.push(Query.equal('reference_id', options.referenceId));
  if (options.externalKey) queries.push(Query.equal('external_key', options.externalKey));
  if (options.status) queries.push(Query.equal('status', options.status));
  return tables.listRows({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    queries,
    total: true,
    ttl: 0,
  });
}

async function moduleList({ tables, body, userId, isAdmin, roles = [] }) {
  const kind = String(body.kind || '').slice(0, 64);
  if (!ADMIN_KINDS.has(kind)) throw publicError('Módulo inválido.');
  if (!isAdmin && !CLIENT_READ_KINDS.has(kind)) {
    throw publicError('Você não pode consultar este módulo.', 403, 'forbidden');
  }
  if (isAdmin && !canReadKind(kind, roles)) {
    throw publicError('Seu perfil não pode consultar este módulo.', 403, 'role_forbidden');
  }
  const isPublic = PUBLIC_KINDS.has(kind);
  const ownerId = isAdmin
    ? (body.owner_id ? String(body.owner_id) : null)
    : (isPublic ? null : userId);
  const result = await listModuleRows(tables, kind, {
    ownerId,
    parentId: body.parent_id ? String(body.parent_id) : null,
    referenceId: body.reference_id ? String(body.reference_id) : null,
    externalKey: body.external_key ? String(body.external_key) : null,
    status: body.status ? String(body.status) : null,
    limit: body.limit,
  });
  const rows = (result.rows ?? [])
    .filter((row) => isAdmin || (isPublic ? row.active !== false && row.visible !== false : row.owner_id === userId))
    .map((row) => {
      const includeSecret = (!isAdmin && row.owner_id === userId)
        || (isAdmin && roleFlags(roles).full);
      const serialized = serializeModule(row, includeSecret);
      if (isPublic && !isAdmin) {
        serialized.owned_by_me = row.owner_id === userId;
        delete serialized.owner_id;
      }
      return serialized;
    });
  rows.sort((a, b) => {
    const order = Number(a.sort_order ?? 0) - Number(b.sort_order ?? 0);
    if (order) return order;
    return String(b.$createdAt || '').localeCompare(String(a.$createdAt || ''));
  });
  return { total: result.total, rows };
}

async function moduleUpsert({ tables, req, body, userId, isAdmin, roles = [] }) {
  const kind = String(body.kind || '').slice(0, 64);
  if (!ADMIN_KINDS.has(kind) || (!isAdmin && !CLIENT_CREATE_KINDS.has(kind))) {
    throw publicError('Você não pode alterar este módulo.', 403, 'forbidden');
  }
  if (isAdmin && !canManageKind(kind, roles)) {
    throw publicError('Seu perfil não pode alterar este módulo.', 403, 'role_forbidden');
  }
  const rowId = body.rowId ? String(body.rowId) : null;
  const existing = rowId
    ? await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId })
    : null;
  if (existing && existing.kind !== kind) throw publicError('Registro incompatível.');
  if (existing && !isAdmin && existing.owner_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');

  const mutationId = body.client_mutation_id ? String(body.client_mutation_id).slice(0, 128) : null;
  if (!rowId && mutationId) {
    const duplicate = await listModuleRows(tables, kind, { externalKey: mutationId, limit: 1 });
    if (duplicate.rows?.[0]) return serializeModule(duplicate.rows[0], true);
  }

  const ownerId = isAdmin
    ? (body.owner_id ? String(body.owner_id).slice(0, 36) : existing?.owner_id ?? null)
    : userId;
  const split = splitSensitive(kind, body.data);
  if (kind === 'profile_meta') {
    const username = normalizedUsername(split.data.username);
    const identityMode = String(split.data.group_identity_mode || (username ? 'username' : 'phone'));
    if (!new Set(['username', 'phone']).has(identityMode)) throw publicError('Identidade do grupo inválida.');
    if (identityMode === 'username' && username.length < 2) throw publicError('Defina um nome de usuário com pelo menos 2 caracteres.');
    if (username) {
      const existingProfiles = await listModuleRows(tables, 'profile_meta', { limit: 500 });
      const duplicate = (existingProfiles.rows ?? []).find((candidate) =>
        candidate.owner_id !== ownerId && normalizedUsername(parseJson(candidate.data_json).username) === username);
      if (duplicate) throw publicError('Este nome de usuário já está em uso.', 409, 'username_taken');
      split.data.username = username;
    }
    if (identityMode === 'phone') {
      const profile = await tables.listRows({
        databaseId: DATABASE_ID,
        tableId: TABLES.profiles,
        queries: [Query.equal('user_id', ownerId), Query.limit(1)],
        total: false,
        ttl: 0,
      });
      if (!String(profile.rows?.[0]?.telefone || '').trim()) throw publicError('Cadastre um telefone antes de usá-lo como identificação no grupo.');
    }
    split.data.group_identity_mode = identityMode;
  }
  const mergedSecret = existing && kind === 'app_setting' && Object.keys(split.secret).length
    ? { ...decryptObject(existing), ...split.secret }
    : split.secret;
  const secret = Object.keys(mergedSecret).length ? encryptObject(mergedSecret) : {};
  const rowData = {
    kind,
    owner_id: ownerId,
    parent_id: body.parent_id ? String(body.parent_id).slice(0, 36) : existing?.parent_id ?? null,
    reference_id: body.reference_id ? String(body.reference_id).slice(0, 36) : existing?.reference_id ?? null,
    external_key: mutationId || (body.external_key ? String(body.external_key).slice(0, 128) : existing?.external_key ?? null),
    title: body.title ? String(body.title).slice(0, 255) : existing?.title ?? null,
    status: body.status ? String(body.status).slice(0, 64) : existing?.status ?? 'ativo',
    sort_order: Number.isFinite(Number(body.sort_order)) ? Math.round(Number(body.sort_order)) : existing?.sort_order ?? 0,
    amount_cents: Number.isFinite(Number(body.amount_cents)) ? Math.round(Number(body.amount_cents)) : existing?.amount_cents ?? 0,
    data_json: JSON.stringify(split.data),
    created_by: existing?.created_by ?? userId,
    assigned_to: body.assigned_to ? String(body.assigned_to).slice(0, 36) : existing?.assigned_to ?? null,
    due_at: body.due_at || existing?.due_at || null,
    updated_at: new Date().toISOString(),
    active: body.active !== undefined ? Boolean(body.active) : existing?.active ?? true,
    visible: body.visible !== undefined ? Boolean(body.visible) : existing?.visible ?? true,
    ...secret,
  };
  const saved = existing
    ? await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId, data: rowData })
    : await tables.createRow({
        databaseId: DATABASE_ID,
        tableId: MODULES_TABLE_ID,
        rowId: ID.unique(),
        data: rowData,
        permissions: modulePermissions(ownerId),
      });
  await audit(tables, req, `${kind}.${existing ? 'update' : 'create'}`, MODULES_TABLE_ID, saved.$id, existing, rowData);
  return serializeModule(saved, true);
}

async function moduleDelete({ tables, req, body, userId, isAdmin, roles = [] }) {
  const rowId = String(body.rowId || '');
  if (!rowId) throw publicError('rowId é obrigatório.');
  const existing = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId });
  if (isAdmin && !canManageKind(existing.kind, roles)) {
    throw publicError('Seu perfil não pode excluir este registro.', 403, 'role_forbidden');
  }
  if (!isAdmin && existing.owner_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
  if (!isAdmin && !CLIENT_CREATE_KINDS.has(existing.kind)) throw publicError('Acesso negado.', 403, 'forbidden');
  await tables.deleteRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId });
  await audit(tables, req, `${existing.kind}.delete`, MODULES_TABLE_ID, rowId, existing, null);
  return { $id: rowId, deleted: true };
}

async function notify(tables, userId, title, message, type = 'sistema', dueAt = null) {
  if (!userId) return null;
  return tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.notifications,
    rowId: ID.unique(),
    data: {
      user_id: userId,
      titulo: String(title).slice(0, 150),
      mensagem: String(message).slice(0, 2000),
      tipo: notificationType(type),
      lida: false,
      data_vencimento: dueAt || new Date().toISOString(),
    },
    permissions: userPermissions(userId),
  });
}


async function adminUserIds(client) {
  const teams = new Teams(client);
  const memberships = await teams.listMemberships({
    teamId: ADMIN_TEAM_ID,
    total: false,
    queries: [Query.limit(500)],
  });
  return [...new Set((memberships.memberships ?? [])
    .filter((item) => item.confirm !== false)
    .map((item) => item.userId)
    .filter(Boolean))];
}

async function notifyAdmins(client, tables, title, message, type = 'admin', dueAt = null) {
  let targets = [];
  try {
    targets = await adminUserIds(client);
  } catch {
    const profiles = await tables.listRows({
      databaseId: DATABASE_ID,
      tableId: TABLES.profiles,
      queries: [Query.limit(500)],
      total: false,
      ttl: 0,
    });
    targets = [...new Set((profiles.rows ?? [])
      .filter((row) => ['admin', 'administrador', 'operador', 'financeiro'].includes(String(row.tipo || '').toLowerCase()))
      .map((row) => row.user_id)
      .filter(Boolean))];
  }
  for (const target of targets) {
    await notify(tables, target, title, message, type, dueAt);
  }
  return targets.length;
}

async function allProfiles(tables) {
  const result = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.profiles,
    queries: [Query.limit(500)],
    total: false,
    ttl: 0,
  });
  return result.rows ?? [];
}

async function profileMetaRows(tables) {
  const result = await listModuleRows(tables, 'profile_meta', { limit: 500 });
  return result.rows ?? [];
}

function normalizedUsername(value) {
  return String(value || '')
    .trim()
    .replace(/^@+/, '')
    .replace(/[^a-zA-Z0-9._-]/g, '')
    .toLowerCase()
    .slice(0, 32);
}

async function groupIdentities(tables) {
  const [profiles, metas] = await Promise.all([allProfiles(tables), profileMetaRows(tables)]);
  const metaByOwner = new Map(metas.map((row) => [row.owner_id, parseJson(row.data_json)]));
  const result = new Map();
  for (const row of profiles) {
    if (!row.user_id) continue;
    const meta = metaByOwner.get(row.user_id) || {};
    const username = normalizedUsername(meta.username);
    const phone = String(row.telefone || '').trim().slice(0, 40);
    const mode = String(meta.group_identity_mode || (username ? 'username' : 'phone'));
    let display = '';
    if (mode === 'phone' && phone) display = phone;
    else if (username) display = `@${username}`;
    else if (phone) display = phone;
    result.set(row.user_id, {
      user_id: row.user_id,
      display,
      username,
      phone,
      mode,
      name: String(row.nome || 'Membro').slice(0, 100),
      photo_id: String(row.foto_id || '').slice(0, 36) || null,
      active: row.ativo !== false,
    });
  }
  return result;
}

async function notifyGroupAudience({
  client,
  tables,
  senderUserId = null,
  senderIsAdmin = false,
  title = 'Grupo Rachey',
  message = 'Há uma nova atualização no grupo.',
  forceAll = false,
  mentionedUsernames = [],
}) {
  const [identities, memberRows] = await Promise.all([
    groupIdentities(tables),
    listModuleRows(tables, 'group_member', { limit: 500 }),
  ]);
  const members = new Map((memberRows.rows ?? []).map((row) => [row.owner_id, parseJson(row.data_json)]));
  const mentions = new Set(mentionedUsernames.map((item) => normalizedUsername(item)).filter(Boolean));
  let sent = 0;
  for (const [target, identity] of identities.entries()) {
    if (!target || target === senderUserId) continue;
    const state = members.get(target) || {};
    if (state.banned === true) continue;
    const preference = String(state.notifications || 'mentions');
    const mentioned = identity.username && mentions.has(identity.username);
    const allowed = forceAll
      || (mentioned && preference !== 'none')
      || (senderIsAdmin && new Set(['all', 'admins']).has(preference))
      || (!senderIsAdmin && preference === 'all');
    if (!allowed) continue;
    await notify(tables, target, title, message, 'grupo');
    sent++;
  }
  return sent;
}

async function registerFile({ client, tables, req, body, userId, isAdmin }) {
  const fileId = String(body.file_id || '');
  if (!fileId) throw publicError('file_id é obrigatório.');
  const type = String(body.tipo || 'outro').slice(0, 50);
  const isGroupMedia = GROUP_MEDIA_TYPES.has(type);
  if (isGroupMedia) {
    const access = await groupAccess({ tables, userId, isAdmin });
    if (!access.allowed) throw publicError(access.reason, 403, 'group_forbidden');
  }
  const storage = new Storage(client);
  const permissions = [
    Permission.read(Role.user(userId)),
    Permission.update(Role.user(userId)),
    Permission.delete(Role.user(userId)),
    ...adminPermissions(),
    ...((body.public_read && isAdmin) || isGroupMedia
      ? [Permission.read(Role.users())]
      : []),
  ];
  const file = await storage.updateFile({ bucketId: BUCKET_ID, fileId, permissions });
  const metadata = await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.fileMetadata,
    rowId: ID.unique(),
    data: {
      file_id: fileId,
      user_id: userId,
      tipo: type,
      referencia_id: body.referencia_id ? String(body.referencia_id).slice(0, 36) : null,
      nome_original: String(body.nome_original || file.name || 'arquivo').slice(0, 255),
      mime_type: String(body.mime_type || file.mimeType || 'application/octet-stream').slice(0, 150),
      tamanho_bytesw: Math.max(0, Math.round(Number(body.tamanho_bytes ?? file.sizeOriginal ?? 0))),
    },
    permissions: userPermissions(userId),
  });
  await audit(tables, req, 'arquivo.upload', TABLES.fileMetadata, metadata.$id, null, { fileId, type: body.tipo, size: body.tamanho_bytes });
  return { file_id: fileId, metadata_id: metadata.$id };
}

async function lockPaymentProof({ client, tables, fileId, userId, referenceId, allowedTypes }) {
  const found = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.fileMetadata,
    queries: [Query.equal('file_id', fileId), Query.limit(1)],
    total: false,
    ttl: 0,
  });
  const metadata = found.rows?.[0];
  if (!metadata || metadata.user_id !== userId || !allowedTypes.has(String(metadata.tipo || ''))) {
    throw publicError('Comprovante não autorizado.', 403, 'proof_forbidden');
  }
  const lockedPermissions = [
    Permission.read(Role.user(userId)),
    ...adminPermissions(),
  ];
  const storage = new Storage(client);
  await storage.updateFile({ bucketId: BUCKET_ID, fileId, permissions: lockedPermissions });
  await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.fileMetadata,
    rowId: metadata.$id,
    data: { referencia_id: String(referenceId || '').slice(0, 36) || null },
    permissions: lockedPermissions,
  });
  return metadata;
}

async function deleteFile({ client, tables, req, body, userId, isAdmin, roles = [] }) {
  const fileId = String(body.file_id || '');
  const found = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.fileMetadata,
    queries: [Query.equal('file_id', fileId), Query.limit(1)],
    total: false,
    ttl: 0,
  });
  const metadata = found.rows?.[0];
  if (!metadata || (!isAdmin && metadata.user_id !== userId)) throw publicError('Arquivo não encontrado.', 404, 'not_found');
  if (!isAdmin && String(metadata.tipo || '').startsWith('comprovante_') && metadata.referencia_id) {
    throw publicError('Um comprovante já enviado não pode ser alterado ou excluído.', 409, 'proof_locked');
  }
  if (isAdmin && metadata.user_id !== userId && !roleFlags(roles).operator) {
    throw publicError('Seu perfil não pode excluir este arquivo.', 403, 'role_forbidden');
  }
  await new Storage(client).deleteFile({ bucketId: BUCKET_ID, fileId });
  await tables.deleteRow({ databaseId: DATABASE_ID, tableId: TABLES.fileMetadata, rowId: metadata.$id });
  await audit(tables, req, 'arquivo.delete', TABLES.fileMetadata, metadata.$id, metadata, null);
  return { file_id: fileId, deleted: true };
}

async function firstModule(tables, kind, options = {}) {
  const result = await listModuleRows(tables, kind, { ...options, limit: 1 });
  return result.rows?.[0] ?? null;
}


const LEGACY_APP_SETTING_SECRET_FIELDS = Object.freeze([
  'pix_key',
  'mercado_pago_access_token',
  'mercado_pago_client_secret',
  'mercado_pago_webhook_secret',
  'gemini_api_keys',
]);

async function migrateLegacyAppSettingSecrets(tables, row) {
  if (!row || row.kind !== 'app_setting') return row;
  const data = safePayload(parseJson(row.data_json));
  const legacySecret = {};
  let changed = false;
  for (const field of LEGACY_APP_SETTING_SECRET_FIELDS) {
    if (!Object.hasOwn(data, field)) continue;
    changed = true;
    const value = data[field];
    const keep = Array.isArray(value)
      ? value.some((item) => String(item || '').trim())
      : String(value || '').trim();
    if (keep) legacySecret[field] = value;
    delete data[field];
  }
  if (!changed) return row;
  const mergedSecret = { ...decryptObject(row), ...legacySecret };
  const encrypted = Object.keys(mergedSecret).length
    ? encryptObject(mergedSecret)
    : { secret_ciphertext: null, secret_iv: null, secret_tag: null };
  return tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: row.$id,
    data: {
      data_json: JSON.stringify(data),
      ...encrypted,
      updated_at: new Date().toISOString(),
    },
  });
}

function servicePeriod(service, meta, requestedDays) {
  const data = parseJson(meta?.data_json);
  const periods = Array.isArray(data.periods) ? data.periods : [];
  const days = Math.max(1, Math.min(3650, Number(requestedDays || 30) || 30));
  const match = periods.find((item) => Number(item.days) === days);
  const baseCents = Number(service.preco_centavos ?? Math.round(Number(service.valor || 0) * 100));
  return {
    days,
    priceCents: Math.max(0, Math.round(Number(match?.price_cents ?? baseCents))),
    costCents: Math.max(0, Math.round(Number(match?.cost_cents ?? data.cost_cents ?? 0))),
    label: String(match?.label || `${days} dias`).slice(0, 80),
    meta: data,
  };
}

function remainingDaysUntil(value, now = Date.now()) {
  if (!value) return null;
  const due = new Date(value).getTime();
  if (!Number.isFinite(due)) return null;
  const remainingMs = due - now;
  if (remainingMs <= 0) return 0;
  return Math.max(1, Math.ceil(remainingMs / 86400000));
}

function quoteForAccount(period, account, now = Date.now()) {
  const data = parseJson(account?.data_json);
  const remaining = remainingDaysUntil(data.expires_at, now);
  const prorate = data.prorate_enabled === true && remaining !== null;
  const effectiveDays = prorate ? Math.max(0, Math.min(period.days, remaining)) : period.days;
  const factor = period.days > 0 ? effectiveDays / period.days : 1;
  const priceCents = prorate ? (period.priceCents > 0 ? Math.max(1, Math.round(period.priceCents * factor)) : 0) : period.priceCents;
  const costCents = prorate ? Math.max(0, Math.round(period.costCents * factor)) : period.costCents;
  const requestedDue = new Date(now + period.days * 86400000).toISOString();
  const accountDueMs = data.expires_at ? new Date(data.expires_at).getTime() : null;
  const effectiveDue = Number.isFinite(accountDueMs)
    ? new Date(Math.min(new Date(requestedDue).getTime(), accountDueMs)).toISOString()
    : requestedDue;
  return {
    priceCents,
    costCents,
    effectiveDays,
    remainingDays: remaining,
    prorated: prorate && effectiveDays < period.days,
    accountExpiresAt: data.expires_at || null,
    effectiveDue,
    autoRelease: data.auto_release === true,
  };
}

async function sellableSlots(tables, serviceId, limit = 100) {
  const result = await listModuleRows(tables, 'inventory_slot', { referenceId: serviceId, status: 'livre', limit });
  const accountCache = new Map();
  const rows = [];
  const now = Date.now();
  for (const slot of result.rows ?? []) {
    if (!slot.parent_id) continue;
    let account = accountCache.get(slot.parent_id);
    if (!account) {
      try {
        account = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: slot.parent_id });
      } catch { continue; }
      accountCache.set(slot.parent_id, account);
    }
    if (account.kind !== 'inventory_account' || account.active === false || account.status === 'expirada') continue;
    const data = parseJson(account.data_json);
    const remaining = remainingDaysUntil(data.expires_at, now);
    if (remaining === 0) continue;
    rows.push({ slot, account, remaining });
  }
  rows.sort((a, b) => {
    const ar = a.remaining ?? 999999;
    const br = b.remaining ?? 999999;
    if (ar !== br) return ar - br; // FEFO: vende primeiro a conta que vence antes.
    return Number(a.slot.sort_order || 0) - Number(b.slot.sort_order || 0);
  });
  return rows;
}

async function catalogQuotes({ tables }) {
  const services = await tableRows(tables, TABLES.services, [Query.equal('ativo', true)], 500);
  const rows = [];
  for (const service of services.rows ?? []) {
    const meta = await firstModule(tables, 'service_meta', { referenceId: service.$id });
    const metaData = parseJson(meta?.data_json);
    if (metaData.stock_enabled !== true) continue;
    const slots = await sellableSlots(tables, service.$id, 500);
    const periods = Array.isArray(metaData.periods) && metaData.periods.length
      ? metaData.periods.map((item) => servicePeriod(service, meta, item.days))
      : [servicePeriod(service, meta, 30)];
    const quotedPeriods = periods.map((period) => {
      const first = slots[0];
      if (!first) return { days: period.days, label: period.label, available: 0, price_cents: period.priceCents, effective_days: period.days, prorated: false, expires_at: null, auto_release: false };
      const quote = quoteForAccount(period, first.account);
      return {
        days: period.days,
        label: quote.prorated ? `${quote.effectiveDays} dias restantes` : period.label,
        available: slots.length,
        price_cents: quote.priceCents,
        regular_price_cents: period.priceCents,
        effective_days: quote.effectiveDays,
        prorated: quote.prorated,
        expires_at: quote.prorated ? quote.accountExpiresAt : quote.effectiveDue,
        auto_release: quote.autoRelease,
      };
    });
    rows.push({ service_id: service.$id, available: slots.length, periods: quotedPeriods });
  }
  return { rows };
}
async function availableSlot(tables, serviceId) {
  const result = await listModuleRows(tables, 'inventory_slot', { referenceId: serviceId, status: 'livre', limit: 1 });
  return result.rows?.[0] ?? null;
}

async function createModuleDirect(tables, data, ownerId = null, secret = null) {
  const rowData = {
    kind: data.kind,
    owner_id: ownerId,
    parent_id: data.parent_id || null,
    reference_id: data.reference_id || null,
    external_key: data.external_key || null,
    title: data.title || null,
    status: data.status || 'ativo',
    sort_order: Math.round(Number(data.sort_order || 0)),
    amount_cents: Math.round(Number(data.amount_cents || 0)),
    data_json: JSON.stringify(safePayload(data.data || {})),
    created_by: data.created_by || null,
    assigned_to: data.assigned_to || null,
    due_at: data.due_at || null,
    updated_at: new Date().toISOString(),
    active: data.active !== false,
    visible: data.visible !== false,
    ...(secret && Object.keys(secret).length ? encryptObject(secret) : {}),
  };
  return tables.createRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: ID.unique(),
    data: rowData,
    // O cliente acessa o grupo somente pela Function, que aplica as regras de
    // assinatura, moderação e modo de interação. Nenhuma linha do grupo fica
    // mutável diretamente pelo SDK do aplicativo.
    permissions: adminPermissions(),
  });
}

async function mercadoPagoSettings(tables) {
  let row = await firstModule(tables, 'app_setting', { externalKey: 'payments' });
  if (!row) return { mode: 'manual' };
  row = await migrateLegacyAppSettingSecrets(tables, row);
  return { ...parseJson(row.data_json), ...decryptObject(row) };
}

async function mercadoPagoPix(tables, amountCents, orderNumber, userId) {
  const settings = await mercadoPagoSettings(tables);
  const accessToken = String(settings.mercado_pago_access_token || '').trim();
  if (!accessToken) throw publicError('Access Token do Mercado Pago não configurado.', 503, 'mercado_pago_not_configured');
  const profile = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.profiles,
    queries: [Query.equal('user_id', userId), Query.limit(1)],
    total: false,
    ttl: 0,
  });
  const email = String(profile.rows?.[0]?.email || '').trim();
  if (!email) throw publicError('Cadastre um e-mail válido antes de pagar com Mercado Pago.', 409, 'payer_email_required');
  const expirationMinutes = Math.max(5, Math.min(1440, Math.round(Number(settings.pix_expiration_minutes || 45))));
  const expirationDate = new Date(Date.now() + expirationMinutes * 60000).toISOString();
  const idempotency = crypto.createHash('sha256')
    .update(`rachey:${orderNumber}:${amountCents}`)
    .digest('hex');
  const response = await fetch('https://api.mercadopago.com/v1/payments', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      'X-Idempotency-Key': idempotency,
    },
    body: JSON.stringify({
      transaction_amount: Math.max(0, amountCents) / 100,
      description: String(settings.mercado_pago_description || 'Rachey assinaturas digitais').slice(0, 250),
      payment_method_id: 'pix',
      external_reference: String(orderNumber).slice(0, 64),
      date_of_expiration: expirationDate,
      payer: { email },
      ...(settings.mercado_pago_notification_url ? { notification_url: String(settings.mercado_pago_notification_url).slice(0, 500) } : {}),
    }),
    signal: AbortSignal.timeout(15000),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = payload?.message || payload?.error || payload?.cause?.[0]?.description || `HTTP ${response.status}`;
    throw publicError(`Mercado Pago recusou a criação do Pix: ${String(detail).slice(0, 300)}`, 502, 'mercado_pago_error');
  }
  const transaction = payload?.point_of_interaction?.transaction_data || {};
  const copy = String(transaction.qr_code || '').trim();
  const qr = String(transaction.qr_code_base64 || '').replace(/^data:image\/[^;]+;base64,/, '').trim();
  if (!copy) throw publicError('O Mercado Pago não retornou o código Pix.', 502, 'mercado_pago_invalid_pix');
  return {
    copia_cola: copy,
    qr_base64: qr,
    ticket_url: transaction.ticket_url || null,
    merchant_name: String(settings.mercado_pago_display_name || 'Rachey').slice(0, 100),
    pix_key: null,
    mode: 'mercado_pago',
    provider: 'mercado_pago',
    provider_payment_id: String(payload.id || ''),
    provider_status: String(payload.status || 'pending'),
    expires_at: payload.date_of_expiration || expirationDate,
    amount_cents: amountCents,
  };
}

async function testMercadoPago(tables) {
  const settings = await mercadoPagoSettings(tables);
  const token = String(settings.mercado_pago_access_token || '').trim();
  if (!token) throw publicError('Informe e salve um Access Token antes de testar.', 409, 'mercado_pago_not_configured');
  const response = await fetch('https://api.mercadopago.com/users/me', {
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' },
    signal: AbortSignal.timeout(12000),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw publicError(`Credencial do Mercado Pago inválida ou indisponível: ${String(payload?.message || payload?.error || `HTTP ${response.status}`).slice(0, 240)}`, 502, 'mercado_pago_credentials_invalid');
  }
  return {
    connected: true,
    account_id: payload?.id ? String(payload.id) : null,
    nickname: payload?.nickname ? String(payload.nickname).slice(0, 120) : null,
    site_id: payload?.site_id ? String(payload.site_id).slice(0, 20) : null,
  };
}

async function mercadoPagoPaymentStatus(tables, paymentId) {
  const settings = await mercadoPagoSettings(tables);
  const token = String(settings.mercado_pago_access_token || '').trim();
  if (!token) throw publicError('Mercado Pago não configurado.', 503, 'mercado_pago_not_configured');
  const response = await fetch(`https://api.mercadopago.com/v1/payments/${encodeURIComponent(String(paymentId))}`, {
    headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' },
    signal: AbortSignal.timeout(12000),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw publicError('Não foi possível consultar o pagamento no Mercado Pago.', 502, 'mercado_pago_status_error');
  return {
    id: String(payload.id || paymentId),
    status: String(payload.status || ''),
    status_detail: String(payload.status_detail || ''),
    approved: String(payload.status || '') === 'approved',
    amount_cents: Math.round(Number(payload.transaction_amount || 0) * 100),
    external_reference: String(payload.external_reference || ''),
    payment_method_id: String(payload.payment_method_id || ''),
  };
}

function secureHexEquals(left, right) {
  const a = Buffer.from(String(left || ''), 'utf8');
  const b = Buffer.from(String(right || ''), 'utf8');
  return a.length === b.length && a.length > 0 && crypto.timingSafeEqual(a, b);
}

function validateMercadoPagoWebhookSignature({ xSignature, xRequestId, dataId, secret }) {
  const parts = Object.fromEntries(
    String(xSignature || '')
      .split(',')
      .map((part) => part.split('=', 2).map((value) => value.trim()))
      .filter(([key, value]) => key && value),
  );
  const ts = String(parts.ts || '');
  const received = String(parts.v1 || '');
  if (!ts || !received || !xRequestId || !dataId || !secret) return false;
  const manifest = `id:${dataId};request-id:${xRequestId};ts:${ts};`;
  const expected = crypto.createHmac('sha256', secret).update(manifest).digest('hex');
  return secureHexEquals(expected, received);
}

export async function handleMercadoPagoWebhook({ req, client, tables, body }) {
  if (String(body?.type || '') !== 'payment') return { accepted: true, ignored: true };
  const dataId = String(req?.query?.['data.id'] || body?.data?.id || '').trim();
  if (!dataId) throw publicError('Webhook do Mercado Pago sem data.id.', 400, 'webhook_invalid');
  const settings = await mercadoPagoSettings(tables);
  const webhookSecret = String(settings.mercado_pago_webhook_secret || '').trim();
  if (!webhookSecret) throw publicError('Assinatura secreta do webhook não configurada.', 503, 'webhook_secret_missing');
  const xSignature = req.headers['x-signature'] || req.headers['X-Signature'];
  const xRequestId = req.headers['x-request-id'] || req.headers['X-Request-Id'];
  if (!validateMercadoPagoWebhookSignature({
    xSignature,
    xRequestId,
    dataId,
    secret: webhookSecret,
  })) {
    throw publicError('Assinatura do webhook Mercado Pago inválida.', 401, 'webhook_signature_invalid');
  }

  const provider = await mercadoPagoPaymentStatus(tables, dataId);
  if (!provider.approved) return { accepted: true, approved: false, provider_status: provider.status };

  const externalKey = `mp:${dataId}`;
  const intent = await firstModule(tables, 'purchase_intent', { externalKey });
  if (intent) {
    const result = await checkAutomaticPix({
      action: 'check_automatic_pix',
      body: { intent_id: intent.$id },
      req,
      client,
      tables,
      userId: intent.owner_id,
      isAdmin: false,
      roles: [],
    });
    return { accepted: true, approved: true, kind: 'purchase', result };
  }

  const meta = await firstModule(tables, 'payment_meta', { externalKey });
  if (meta?.reference_id) {
    const payment = await tables.getRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.payments,
      rowId: meta.reference_id,
    });
    const result = await checkAutomaticPix({
      action: 'check_automatic_pix',
      body: { payment_id: payment.$id },
      req,
      client,
      tables,
      userId: payment.user_id,
      isAdmin: false,
      roles: [],
    });
    return { accepted: true, approved: true, kind: 'renewal', result };
  }

  // Responde 200 para evitar retries infinitos de pagamentos que não foram
  // criados por esta instalação Rachey, mas não libera nenhum acesso.
  return { accepted: true, approved: true, ignored: true };
}

async function pixData(tables, amountCents, orderNumber, userId = null) {
  const paymentSettings = await mercadoPagoSettings(tables);
  const mode = String(paymentSettings.mode || paymentSettings.payment_mode || 'manual');
  if (userId && new Set(['mercado_pago', 'hybrid']).has(mode)) {
    try {
      return await mercadoPagoPix(tables, amountCents, orderNumber, userId);
    } catch (cause) {
      if (mode === 'mercado_pago') throw cause;
      // No modo híbrido, uma indisponibilidade real do provedor cai no Pix
      // manual somente se uma chave manual também estiver configurada.
    }
  }
  const row = await firstModule(tables, 'app_setting', { externalKey: 'pix' });
  if (!row) return null;
  const publicData = parseJson(row.data_json);
  const secret = decryptObject(row);
  const pixKey = String(secret.pix_key || publicData.pix_key || '').trim();
  if (!pixKey) return null;
  // PIX manual nunca inventa QR Code ou BR Code. Ele expõe apenas a chave
  // PIX real configurada pelo administrador e mantém a aprovação por comprovante.
  // QR/Copia-e-Cola automático só pode vir de um provedor real (Mercado Pago).
  const merchantName = String(publicData.merchant_name || publicData.receiver_name || 'Rachey').trim().slice(0, 100);
  return {
    copia_cola: null,
    qr_base64: null,
    merchant_name: merchantName,
    pix_key: pixKey,
    mode: 'manual',
    provider: 'manual_key',
    amount_cents: amountCents,
  };
}

function normalizePix(value) {
  return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase();
}

function emv(id, value) {
  const text = String(value);
  return `${id}${text.length.toString().padStart(2, '0')}${text}`;
}

function crc16(value) {
  let crc = 0xffff;
  for (const char of Buffer.from(value, 'utf8')) {
    crc ^= char << 8;
    for (let bit = 0; bit < 8; bit++) crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

async function checkout({ tables, req, body, userId }) {
  const inputItems = Array.isArray(body.items) ? body.items.slice(0, 30) : [];
  if (!inputItems.length) throw publicError('O carrinho está vazio.');
  const items = [];
  const missing = [];
  const nowMs = Date.now();

  for (const input of inputItems) {
    const serviceId = String(input.servico_id || '');
    const service = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.services, rowId: serviceId });
    if (service.ativo === false) throw publicError(`${service.nome} não está disponível.`);
    const meta = await firstModule(tables, 'service_meta', { referenceId: serviceId });
    const period = servicePeriod(service, meta, input.period_days);
    const quantity = Math.max(1, Math.min(20, Math.round(Number(input.quantidade || 1))));
    if (period.meta.stock_enabled === true) {
      const slots = await sellableSlots(tables, serviceId, Math.max(100, quantity));
      if (slots.length < quantity) {
        missing.push({ service, meta, period, quantity });
        continue;
      }
      for (const selected of slots.slice(0, quantity)) {
        const quote = quoteForAccount(period, selected.account, nowMs);
        if (quote.effectiveDays < 1) continue;
        items.push({ service, meta, period, quantity: 1, selected, quote });
      }
      continue;
    }
    for (let count = 0; count < quantity; count++) {
      items.push({
        service, meta, period, quantity: 1, selected: null,
        quote: {
          priceCents: period.priceCents,
          costCents: period.costCents,
          effectiveDays: period.days,
          remainingDays: null,
          prorated: false,
          accountExpiresAt: null,
          effectiveDue: new Date(nowMs + period.days * 86400000).toISOString(),
          autoRelease: false,
        },
      });
    }
  }

  if (missing.length) {
    const queued = [];
    for (const item of missing) {
      const row = await createModuleDirect(tables, {
        kind: 'waitlist', reference_id: item.service.$id, title: item.service.nome, status: 'aguardando',
        data: { period_days: item.period.days, quantity: item.quantity, requested_at: new Date().toISOString() },
        created_by: userId,
      }, userId);
      queued.push(serializeModule(row));
    }
    await notify(tables, userId, 'Você entrou na lista de espera', 'Avisaremos assim que uma vaga estiver disponível.', 'estoque');
    await audit(tables, req, 'lista_espera.entrar', MODULES_TABLE_ID, null, null, { count: queued.length });
    return { waitlisted: true, rows: queued };
  }

  const subtotal = items.reduce((sum, item) => sum + item.quote.priceCents, 0);
  let discount = 0;
  let couponRow = null;
  const coupon = String(body.coupon || '').trim().toUpperCase();
  if (coupon) {
    couponRow = await firstModule(tables, 'coupon', { externalKey: coupon });
    if (!couponRow || couponRow.status !== 'ativo' || couponRow.active === false) throw publicError('Cupom inválido ou expirado.');
    if (couponRow.due_at && new Date(couponRow.due_at) < new Date()) throw publicError('Este cupom expirou.');
    const couponData = parseJson(couponRow.data_json);
    const usage = await listModuleRows(tables, 'coupon_usage', { externalKey: coupon, limit: 500 });
    const maxUses = Math.max(0, Number(couponData.max_uses || 0));
    const perUser = Math.max(0, Number(couponData.per_user_limit || 0));
    if (maxUses && (usage.rows?.length ?? 0) >= maxUses) throw publicError('Este cupom atingiu o limite de usos.');
    if (perUser && (usage.rows ?? []).filter((row) => row.owner_id === userId).length >= perUser) throw publicError('Você já atingiu o limite de uso deste cupom.');
    if (Number(couponData.min_order_cents || 0) > subtotal) throw publicError(`Pedido mínimo para este cupom: ${money(couponData.min_order_cents)}.`);
    const allowedServices = Array.isArray(couponData.service_ids) ? couponData.service_ids.map(String) : [];
    const eligibleSubtotal = allowedServices.length
      ? items.filter((item) => allowedServices.includes(item.service.$id)).reduce((sum, item) => sum + item.quote.priceCents, 0)
      : subtotal;
    if (allowedServices.length && eligibleSubtotal <= 0) throw publicError('Este cupom não é válido para os produtos do carrinho.');
    if (couponData.first_purchase_only === true) {
      const previous = await tables.listRows({
        databaseId: DATABASE_ID,
        tableId: TABLES.payments,
        queries: [Query.equal('user_id', userId), Query.equal('status', 'pago'), Query.limit(1)],
        total: false,
        ttl: 0,
      });
      if ((previous.rows?.length ?? 0) > 0) throw publicError('Este cupom é válido apenas na primeira compra aprovada.');
    }
    discount = couponData.type === 'fixed'
      ? Math.round(Number(couponData.value_cents || 0))
      : Math.round(eligibleSubtotal * Math.max(0, Math.min(100, Number(couponData.percent || 0))) / 100);
    discount = Math.max(0, Math.min(eligibleSubtotal, discount));
  }

  const cashback = items.reduce((sum, item) => sum + Math.round(item.quote.priceCents * Number(item.period.meta.cashback_percent || 0) / 100), 0);
  const points = items.reduce((sum, item) => sum + Math.round(Number(item.period.meta.points || 0)), 0);
  const costTotal = items.reduce((sum, item) => sum + Number(item.quote.costCents || 0), 0);
  let total = subtotal - discount;
  let cashbackUsed = 0;
  if (body.use_cashback === true && total > 100) {
    const ledger = await listModuleRows(tables, 'loyalty_ledger', { ownerId: userId, limit: 500 });
    const balance = (ledger.rows ?? []).filter((row) => !new Set(['estornado', 'cancelado']).has(row.status)).reduce((sum, row) => sum + Number(row.amount_cents || 0), 0);
    cashbackUsed = Math.max(0, Math.min(balance, total - 100));
    total -= cashbackUsed;
  }

  const now = new Date();
  const expiresAt = new Date(now.getTime() + 45 * 60000).toISOString();
  const number = `RCH-${Date.now().toString(36).toUpperCase()}`.slice(0, 30);
  const pix = await pixData(tables, total, number, userId);
  if (!pix) throw publicError('O Pix ainda não foi configurado pelo administrador.', 503, 'pix_not_configured');
  const snapshotItems = items.map((item) => ({
    servico_id: item.service.$id,
    nome_servico: item.service.nome,
    quantidade: 1,
    period_days: item.period.days,
    effective_days: item.quote.effectiveDays,
    period_label: item.quote.prorated ? `${item.quote.effectiveDays} dias restantes` : item.period.label,
    preco_unitario_centavos: item.quote.priceCents,
    custo_unitario_centavos: item.quote.costCents,
    subtotal_centavos: item.quote.priceCents,
    release_mode: 'manual',
    stock_enabled: item.period.meta.stock_enabled === true,
    slot_id: item.selected?.slot?.$id || null,
    inventory_account_id: item.selected?.account?.$id || null,
    account_expires_at: item.quote.accountExpiresAt,
    effective_due_at: item.quote.effectiveDue,
    prorated: item.quote.prorated,
    preloaded_auto_release: item.quote.autoRelease === true,
  }));

  const intent = await createModuleDirect(tables, {
    kind: 'purchase_intent',
    external_key: pix.provider_payment_id ? `mp:${pix.provider_payment_id}` : null,
    title: number, status: 'aguardando_comprovante', due_at: expiresAt,
    data: {
      number, subtotal_centavos: subtotal, desconto_centavos: discount, total_centavos: total,
      coupon, coupon_id: couponRow?.$id || null, cashback_cents: cashback,
      cashback_used_cents: cashbackUsed, points, cost_cents: costTotal,
      observacoes: body.observacoes ? String(body.observacoes).slice(0, 2000) : null,
      items: snapshotItems, created_at: now.toISOString(), expires_at: expiresAt,
      payment_provider: pix.provider || pix.mode || 'manual',
      provider_payment_id: pix.provider_payment_id || null,
      provider_status: pix.provider_status || null,
    }, created_by: userId,
  }, userId);

  // Reserva exatamente as vagas usadas para calcular o preço exibido no Pix.
  for (const item of snapshotItems.filter((candidate) => candidate.stock_enabled === true)) {
    const slot = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: String(item.slot_id || '') });
    if (slot.kind !== 'inventory_slot' || slot.status !== 'livre') {
      await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: intent.$id, data: { status: 'estoque_indisponivel', updated_at: new Date().toISOString() } });
      throw publicError('A disponibilidade mudou. Atualize o carrinho antes de pagar.', 409, 'stock_changed');
    }
    await tables.updateRow({
      databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: slot.$id,
      data: {
        owner_id: userId, status: 'reservada', updated_at: new Date().toISOString(),
        data_json: JSON.stringify({ ...parseJson(slot.data_json), intent_id: intent.$id, reserved_at: now.toISOString(), reserved_until: expiresAt, quoted_price_cents: item.preco_unitario_centavos, quoted_effective_days: item.effective_days }),
      },
    });
  }

  await audit(tables, req, 'checkout.intencao_criar', MODULES_TABLE_ID, intent.$id, null, { number, subtotal, discount, total, cashback, cashback_used: cashbackUsed, points, cost_cents: costTotal, coupon: couponRow?.$id });
  return {
    $id: intent.$id, intent_id: intent.$id, numero: number, status: 'aguardando_comprovante',
    subtotal_centavos: subtotal, desconto_centavos: discount, total_centavos: total,
    expires_at: expiresAt, cashback_cents: cashback, cashback_used_cents: cashbackUsed, points,
    prorated_items: snapshotItems.filter((item) => item.prorated).map((item) => ({ service: item.nome_servico, days: item.effective_days, expires_at: item.account_expires_at, price_cents: item.preco_unitario_centavos })),
    pix,
  };
}

async function submitPaymentProof({ client, tables, req, body, userId }) {
  const fileId = String(body.file_id || '');
  const automaticVerified = body.automatic_verified === true && String(body.provider || '') === 'mercado_pago';
  if (!fileId && !automaticVerified) throw publicError('Envie um comprovante válido.');

  const directPaymentId = String(body.payment_id || '');
  if (directPaymentId) {
    const payment = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: directPaymentId });
    if (payment.user_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
    if (!payment.renovacao_id || (body.renewal_id && String(body.renewal_id) !== payment.renovacao_id)) throw publicError('Renovação relacionada não encontrada.');
    if (!automaticVerified) {
      await lockPaymentProof({
        client, tables, fileId, userId, referenceId: directPaymentId,
        allowedTypes: new Set(['comprovante_renovacao', 'comprovante_pix']),
      });
    }
    await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: directPaymentId, data: { status: 'em_analise', comprovante_id: fileId || payment.comprovante_id || null } });
    await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.renewals, rowId: payment.renovacao_id, data: { status: 'em_analise' } });
    await notify(tables, userId, automaticVerified ? 'Pagamento confirmado' : 'Comprovante de renovação enviado', automaticVerified ? 'O Mercado Pago confirmou o Pix da renovação.' : 'A renovação entrou em análise.', 'renovacao');
    if (!automaticVerified) await notifyAdmins(client, tables, 'Renovação aguardando análise', 'Um cliente enviou comprovante de renovação.', 'renovacao_admin');
    await audit(tables, req, automaticVerified ? 'renovacao.mercado_pago_confirmado' : 'renovacao.comprovante', TABLES.payments, directPaymentId, payment, { status: 'em_analise', file_id: fileId || null, automatic_verified: automaticVerified });
    return { payment_id: directPaymentId, renewal_id: payment.renovacao_id, status: 'em_analise' };
  }

  const intentId = String(body.intent_id || body.checkout_intent_id || '');
  if (intentId) {
    const intent = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: intentId });
    if (intent.kind !== 'purchase_intent' || intent.owner_id !== userId) throw publicError('Checkout não encontrado.', 404, 'not_found');
    const intentData = parseJson(intent.data_json);
    if (intent.status === 'enviado' && intentData.order_id) {
      const existingOrder = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.orders, rowId: intentData.order_id });
      return { ...existingOrder, payment_id: intentData.payment_id || null, status: existingOrder.status, already_submitted: true };
    }
    const expiresAt = new Date(intentData.expires_at || intent.due_at || 0).getTime();
    if (Number.isFinite(expiresAt) && expiresAt > 0 && expiresAt < Date.now()) {
      throw publicError('O Pix expirou. Volte ao carrinho para gerar um novo pagamento.', 409, 'checkout_expired');
    }
    if (!automaticVerified) {
      await lockPaymentProof({
        client, tables, fileId, userId, referenceId: intentId,
        allowedTypes: new Set(['comprovante_pix']),
      });
    }

    const snapshotItems = Array.isArray(intentData.items) ? intentData.items : [];
    if (!snapshotItems.length) throw publicError('O checkout não possui itens.');
    const now = new Date().toISOString();
    const cartId = ID.unique();
    const orderId = ID.unique();
    const paymentId = ID.unique();
    const number = String(intentData.number || intent.title || `RCH-${Date.now().toString(36).toUpperCase()}`).slice(0, 30);
    const subtotal = Math.max(0, Math.round(Number(intentData.subtotal_centavos || 0)));
    const discount = Math.max(0, Math.round(Number(intentData.desconto_centavos || 0)));
    const total = Math.max(0, Math.round(Number(intentData.total_centavos || subtotal - discount)));
    const permissions = userPermissions(userId);

    // Antes de criar o pedido, confirma as vagas reservadas durante o Pix.
    for (const item of snapshotItems.filter((candidate) => candidate.stock_enabled === true)) {
      const reserved = await listModuleRows(tables, 'inventory_slot', { ownerId: userId, referenceId: item.servico_id, status: 'reservada', limit: 100 });
      const mine = (reserved.rows ?? []).filter((slot) => parseJson(slot.data_json).intent_id === intentId);
      if (mine.length < Math.max(1, Number(item.quantidade || 1))) {
        throw publicError('A reserva do estoque expirou. Entre em contato com o suporte antes de reenviar o pagamento.', 409, 'stock_reservation_expired');
      }
    }

    await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.carts,
      rowId: cartId,
      data: { user_id: userId, status: 'convertido', subtotal_centavos: subtotal, desconto_centavos: discount, total_centavos: total, atualizado_em: now },
      permissions,
    });
    for (const item of snapshotItems) {
      const quantity = Math.max(1, Math.min(20, Math.round(Number(item.quantidade || 1))));
      const unit = Math.max(0, Math.round(Number(item.preco_unitario_centavos || 0)));
      await tables.createRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.cartItems,
        rowId: ID.unique(),
        data: {
          carinho_id: cartId,
          user_id: userId,
          servico_id: String(item.servico_id || ''),
          nome_servico: String(item.nome_servico || 'Serviço').slice(0, 255),
          quantidae: quantity,
          preco_unitario_centavos: unit,
          observacoes: String(item.period_label || `${item.period_days || 30} dias`).slice(0, 500),
        },
        permissions,
      });
    }
    const order = await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.orders,
      rowId: orderId,
      data: {
        numero: number,
        user_id: userId,
        carrinho_id: cartId,
        status: 'pagamento_enviado',
        forma_pagamento: 'pix',
        subtotal_centavos: subtotal,
        desconto_centavos: discount,
        total_centavos: total,
        comprovante_file_id: fileId || null,
        observacoes_cliente: intentData.observacoes ? String(intentData.observacoes).slice(0, 2000) : null,
        observacoes_admin: null,
      },
      permissions,
    });
    for (const item of snapshotItems) {
      const quantity = Math.max(1, Math.min(20, Math.round(Number(item.quantidade || 1))));
      const unit = Math.max(0, Math.round(Number(item.preco_unitario_centavos || 0)));
      const details = JSON.stringify({
        period_days: Math.max(1, Number(item.period_days || 30)),
        period_label: String(item.period_label || `${item.period_days || 30} dias`),
        release_mode: item.release_mode || 'manual',
        effective_days: Math.max(1, Number(item.effective_days || item.period_days || 30)),
        slot_id: item.slot_id || null,
        inventory_account_id: item.inventory_account_id || null,
        account_expires_at: item.account_expires_at || null,
        effective_due_at: item.effective_due_at || null,
        prorated: item.prorated === true,
        preloaded_auto_release: item.preloaded_auto_release === true,
        cost_cents: Math.max(0, Number(item.custo_unitario_centavos || 0)),
      });
      await tables.createRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.orderItems,
        rowId: ID.unique(),
        data: {
          pedido_id: orderId,
          user_id: userId,
          servico_id: String(item.servico_id || ''),
          nome_servico: String(item.nome_servico || 'Serviço').slice(0, 255),
          quantidade: quantity,
          preco_unitario_centavos: unit,
          subtotal_centavos: unit * quantity,
          lhes: details,
        },
        permissions,
      });
      if (item.stock_enabled === true) {
        const reserved = await listModuleRows(tables, 'inventory_slot', { ownerId: userId, referenceId: item.servico_id, status: 'reservada', limit: 100 });
        for (const slot of (reserved.rows ?? []).filter((candidate) => parseJson(candidate.data_json).intent_id === intentId).slice(0, quantity)) {
          const slotData = parseJson(slot.data_json);
          delete slotData.intent_id;
          delete slotData.reserved_until;
          await tables.updateRow({
            databaseId: DATABASE_ID,
            tableId: MODULES_TABLE_ID,
            rowId: slot.$id,
            data: { updated_at: now, data_json: JSON.stringify({ ...slotData, order_id: orderId, reserved_at: now }) },
          });
        }
      }
    }
    const payment = await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.payments,
      rowId: paymentId,
      data: { user_id: userId, assinatura_id: null, renovacao_id: null, valor: total / 100, forma_pagamento: 'pix', status: 'em_analise', data_pagamento: null, comprovante_id: fileId || null },
      permissions,
    });
    await createModuleDirect(tables, {
      kind: 'payment_meta',
      external_key: (body.provider_payment_id || intentData.provider_payment_id) ? `mp:${body.provider_payment_id || intentData.provider_payment_id}` : null,
      reference_id: payment.$id, parent_id: orderId, status: 'em_analise',
      data: {
        order_id: orderId,
        intent_id: intentId,
        coupon: intentData.coupon || '',
        cashback_cents: Number(intentData.cashback_cents || 0),
        cashback_used_cents: Number(intentData.cashback_used_cents || 0),
        points: Number(intentData.points || 0),
        cost_cents: Number(intentData.cost_cents || 0),
        coupon_id: intentData.coupon_id || null,
        coupon_code: intentData.coupon || '',
        provider: automaticVerified ? 'mercado_pago' : (intentData.payment_provider || 'manual'),
        provider_payment_id: body.provider_payment_id || intentData.provider_payment_id || null,
        provider_status: automaticVerified ? 'approved' : (intentData.provider_status || null),
        provider_verified: automaticVerified,
      }, created_by: userId,
    }, userId);
    if (Number(intentData.cashback_used_cents || 0) > 0) {
      await createModuleDirect(tables, {
        kind: 'loyalty_ledger', reference_id: orderId, title: 'Cashback reservado', status: 'reservado',
        amount_cents: -Number(intentData.cashback_used_cents || 0), data: { type: 'debit', order_id: orderId, reserved_at: now }, created_by: userId,
      }, userId);
    }
    await createModuleDirect(tables, {
      kind: 'order_timeline', reference_id: orderId, title: 'Pedido enviado', status: 'concluido', sort_order: 10,
      data: { event: 'pedido_enviado', at: now }, created_by: userId,
    }, userId);
    await createModuleDirect(tables, {
      kind: 'order_timeline', reference_id: orderId, title: automaticVerified ? 'Pagamento confirmado pelo Mercado Pago' : 'Comprovante recebido', status: 'concluido', sort_order: 20,
      data: { event: automaticVerified ? 'pagamento_confirmado_provedor' : 'pagamento_enviado', file_id: fileId || null, provider: automaticVerified ? 'mercado_pago' : null, at: now }, created_by: userId,
    }, userId);
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      rowId: intentId,
      data: {
        status: 'enviado',
        updated_at: now,
        data_json: JSON.stringify({ ...intentData, order_id: orderId, payment_id: payment.$id, proof_file_id: fileId || null, provider_verified: automaticVerified, submitted_at: now }),
      },
    });
    const summary = snapshotItems.slice(0, 3).map((item) => `${item.nome_servico} (${item.period_label || `${item.period_days} dias`})`).join(', ');
    await notify(tables, userId, automaticVerified ? 'Pagamento confirmado' : 'Pedido enviado', automaticVerified ? `${number}: o Mercado Pago confirmou seu Pix.` : `${number} foi enviado e o pagamento está em análise.`, 'pedido');
    if (!automaticVerified) await notifyAdmins(client, tables, 'Novo pedido aguardando análise', `${number}: ${summary || 'novo pedido'} • comprovante recebido.`, 'pedido_admin');
    await audit(tables, req, automaticVerified ? 'pedido.mercado_pago_confirmado' : 'pedido.enviar_apos_comprovante', TABLES.orders, orderId, null, { number, intent_id: intentId, payment_id: payment.$id, file_id: fileId || null, total, automatic_verified: automaticVerified });
    return { ...order, payment_id: payment.$id, status: 'pagamento_enviado' };
  }

  // Compatibilidade com pedidos de versões anteriores já persistidos.
  const orderId = String(body.order_id || '');
  if (!orderId) throw publicError('Checkout relacionado não informado.');
  const order = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.orders, rowId: orderId });
  if (order.user_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
  const meta = await firstModule(tables, 'payment_meta', { parentId: orderId });
  if (!meta) throw publicError('Pagamento não encontrado.', 404, 'not_found');
  await lockPaymentProof({
    client, tables, fileId, userId, referenceId: meta.reference_id || orderId,
    allowedTypes: new Set(['comprovante_pix']),
  });
  await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.orders, rowId: orderId, data: { status: 'pagamento_enviado', comprovante_file_id: fileId } });
  await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: meta.reference_id, data: { status: 'em_analise', comprovante_id: fileId } });
  await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: meta.$id, data: { status: 'em_analise', updated_at: new Date().toISOString() } });
  await createModuleDirect(tables, { kind: 'order_timeline', reference_id: orderId, title: 'Comprovante enviado', status: 'concluido', sort_order: 20, data: { event: 'pagamento_enviado', file_id: fileId, at: new Date().toISOString() }, created_by: userId }, userId);
  await notifyAdmins(client, tables, 'Pedido aguardando análise', `${order.numero || orderId}: comprovante recebido.`, 'pedido_admin');
  await audit(tables, req, 'pagamento.comprovante', TABLES.orders, orderId, order, { file_id: fileId, status: 'pagamento_enviado' });
  return { order_id: orderId, status: 'pagamento_enviado' };
}


async function checkAutomaticPix(context) {
  const { tables, body, userId } = context;
  const intentId = String(body.intent_id || body.checkout_intent_id || '');
  const paymentId = String(body.payment_id || '');
  if (intentId) {
    const intent = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: intentId });
    if (intent.kind !== 'purchase_intent' || intent.owner_id !== userId) throw publicError('Checkout não encontrado.', 404, 'not_found');
    const data = parseJson(intent.data_json);
    if (String(data.payment_provider || '') !== 'mercado_pago' || !data.provider_payment_id) throw publicError('Este checkout não usa Mercado Pago.', 409, 'provider_mismatch');
    const status = await mercadoPagoPaymentStatus(tables, data.provider_payment_id);
    if (!status.approved) return { approved: false, ...status };
    const expectedAmount = Math.max(0, Math.round(Number(data.total_centavos || 0)));
    const expectedReference = String(data.number || intent.title || '');
    if (status.payment_method_id && status.payment_method_id !== 'pix') throw publicError('O pagamento confirmado não é Pix.', 409, 'provider_payment_mismatch');
    if (status.amount_cents !== expectedAmount || (status.external_reference && status.external_reference !== expectedReference)) {
      throw publicError('O pagamento confirmado não corresponde a este checkout.', 409, 'provider_payment_mismatch');
    }
    const order = await submitPaymentProof({ ...context, body: { intent_id: intentId, automatic_verified: true, provider: 'mercado_pago', provider_payment_id: status.id } });
    const approved = await approvePayment({ ...context, body: { payment_id: order.payment_id, pedido_id: order.$id || order.order_id } });
    return { approved: true, provider: status, order, result: approved };
  }
  if (paymentId) {
    const payment = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId });
    if (payment.user_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
    const meta = await firstModule(tables, 'payment_meta', { referenceId: paymentId });
    const data = parseJson(meta?.data_json);
    if (String(data.provider || '') !== 'mercado_pago' || !data.provider_payment_id) throw publicError('Este pagamento não usa Mercado Pago.', 409, 'provider_mismatch');
    const status = await mercadoPagoPaymentStatus(tables, data.provider_payment_id);
    if (!status.approved) return { approved: false, ...status };
    const expectedAmount = Math.max(0, Math.round(Number(payment.valor || 0) * 100));
    if (status.payment_method_id && status.payment_method_id !== 'pix') throw publicError('O pagamento confirmado não é Pix.', 409, 'provider_payment_mismatch');
    if (status.amount_cents !== expectedAmount) throw publicError('O valor confirmado pelo Mercado Pago não corresponde a esta renovação.', 409, 'provider_payment_mismatch');
    if (meta) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: meta.$id, data: { data_json: JSON.stringify({ ...data, provider_status: status.status, provider_verified: true, provider_checked_at: new Date().toISOString() }), updated_at: new Date().toISOString() } });
    const approved = await approvePayment({ ...context, body: { payment_id: paymentId } });
    return { approved: true, provider: status, result: approved };
  }
  throw publicError('Pagamento do Mercado Pago não informado.');
}

async function orderItems(tables, orderId) {
  return tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.orderItems,
    queries: [Query.equal('pedido_id', orderId), Query.limit(100)],
    total: false,
    ttl: 0,
  });
}

async function createCredentialFromSlot(tables, userId, serviceId, subscriptionId, slot, expiresAt = null) {
  const existing = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.credentials,
    queries: [Query.equal('assinatura_id', subscriptionId), Query.limit(1)],
    total: false,
    ttl: 0,
  });
  if (existing.rows?.[0]) return existing.rows[0];
  const account = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: slot.parent_id });
  const accountSecret = decryptObject(account);
  if (!accountSecret.login || !accountSecret.password) throw publicError('A conta de estoque está sem credenciais.');
  const slotData = parseJson(slot.data_json);
  const encrypted = encryptCredential(accountSecret.login, accountSecret.password, {
    perfil: slotData.label || `Vaga ${slotData.position || 1}`,
    secondary_pin: accountSecret.secondary_pin || null,
  });
  return tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.credentials,
    rowId: stableRowId('cred', `${subscriptionId}:${slot.$id}`),
    data: {
      cliente_id: userId,
      servico_id: serviceId,
      assinatura_id: subscriptionId,
      identificador_mascarado: maskedIdentifier(accountSecret.login),
      ...encrypted,
      versao_chave: 1,
      status: 'ativa',
      expira_em: expiresAt,
      ultima_visualizacao_em: null,
    },
    permissions: adminPermissions(),
  });
}

async function approvePayment({ tables, req, body, userId: actorId }) {
  const paymentId = String(body.paymentId || body.payment_id || '');
  if (!paymentId) throw publicError('paymentId é obrigatório.');
  const payment = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId });
  if (payment.status === 'pago') return { payment_id: paymentId, renewal_id: payment.renovacao_id || null, status: 'pago', already_processed: true };
  if (payment.status === 'em_processamento') throw publicError('Este pagamento já está sendo processado. Atualize a tela em instantes.', 409, 'payment_processing');
  const meta = await firstModule(tables, 'payment_meta', { referenceId: paymentId });
  const paymentData = parseJson(meta?.data_json);
  const providerVerified = paymentData.provider === 'mercado_pago' && paymentData.provider_verified === true;
  if (!String(payment.comprovante_id || '').trim() && !providerVerified) throw publicError('Não é possível aprovar um pagamento sem comprovante ou confirmação do provedor.', 409, 'proof_required');
  const orderId = String(body.pedido_id || paymentData.order_id || meta?.parent_id || '');
  const now = new Date().toISOString();
  await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId, data: { status: 'em_processamento' } });

  try {
  if (payment.renovacao_id) {
    const renewal = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.renewals, rowId: payment.renovacao_id });
    const subscription = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: renewal.assinatura_id });
    await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.renewals, rowId: renewal.$id, data: { status: 'confirmada' } });
    await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: subscription.$id, data: { data_vencimento: renewal.nova_data, status: 'ativa' } });
    const credentials = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.credentials, queries: [Query.equal('assinatura_id', subscription.$id), Query.limit(100)], total: false, ttl: 0 });
    for (const credential of credentials.rows ?? []) {
      if (credential.status === 'ativa') await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.credentials, rowId: credential.$id, data: { expira_em: renewal.nova_data } });
    }
    const assignment = await inventoryAssignmentForSubscription(tables, subscription);
    if (assignment?.slot) {
      const slotData = parseJson(assignment.slot.data_json);
      await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: assignment.slot.$id, data: { data_json: JSON.stringify({ ...slotData, effective_due_at: renewal.nova_data }), updated_at: now } });
    }
    if (meta) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: meta.$id, data: { status: 'pago', updated_at: now } });
    await notify(tables, payment.user_id, 'Renovação aprovada', `${subscription.nome_servico} foi renovado com sucesso.`, 'renovacao', renewal.nova_data);
    await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId, data: { status: 'pago', data_pagamento: now } });
    try {
      const loadedGroup = await groupSettings(tables);
      const profile = await profileForUser(tables, payment.user_id);
      await botPrivateAlert(tables, loadedGroup.settings, `💳 Renovação paga: ${profile?.nome || payment.user_id} renovou ${subscription.nome_servico}. Novo vencimento: ${renewal.nova_data}.`);
    } catch { /* alerta privado não pode bloquear a renovação */ }
    await audit(tables, req, 'renovacao.aprovar', TABLES.renewals, renewal.$id, renewal, { status: 'confirmada', nova_data: renewal.nova_data });
    return { payment_id: paymentId, renewal_id: renewal.$id, status: 'pago' };
  }

  if (!orderId) throw publicError('Pedido relacionado não encontrado.');
  const order = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.orders, rowId: orderId });
  const items = await orderItems(tables, orderId);
  let released = 0;
  let manual = 0;
  const subscriptionAnnouncements = [];
  for (const item of items.rows ?? []) {
    const details = parseJson(item.lhes);
    const requestedDays = Math.max(1, Number(details.period_days || 30));
    const effectiveDays = Math.max(1, Number(details.effective_days || requestedDays));
    for (let count = 0; count < Math.max(1, Number(item.quantidade || 1)); count++) {
      let slot = null;
      if (details.slot_id) {
        try {
          const candidate = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: String(details.slot_id) });
          const sd = parseJson(candidate.data_json);
          if (candidate.kind === 'inventory_slot' && candidate.owner_id === order.user_id && candidate.status === 'reservada' && sd.order_id === orderId && !sd.subscription_id) slot = candidate;
        } catch { /* tenta fallback abaixo */ }
      }
      if (!slot && details.stock_enabled !== false) {
        const reserved = await listModuleRows(tables, 'inventory_slot', { ownerId: order.user_id, referenceId: item.servico_id, status: 'reservada', limit: 100 });
        slot = (reserved.rows ?? []).find((candidate) => {
          const slotData = parseJson(candidate.data_json);
          return slotData.order_id === orderId && !slotData.subscription_id;
        }) || null;
      }
      const inventoryAccount = slot ? await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: slot.parent_id }) : null;
      const accountData = parseJson(inventoryAccount?.data_json);
      const accountRemaining = remainingDaysUntil(accountData.expires_at);
      const automaticRelease = Boolean(slot)
        && accountData.auto_release === true
        && (accountRemaining === null || accountRemaining > 0);
      const requestedDueMs = Date.now() + requestedDays * 86400000;
      const accountDueMs = accountData.expires_at ? new Date(accountData.expires_at).getTime() : null;
      const automaticDueMs = Number.isFinite(accountDueMs) ? Math.min(requestedDueMs, accountDueMs) : requestedDueMs;
      const expiresAt = automaticRelease
        ? new Date(automaticDueMs).toISOString()
        : new Date(Date.now() + effectiveDays * 86400000).toISOString();
      const displayDays = automaticRelease ? Math.max(1, remainingDaysUntil(expiresAt) || effectiveDays) : effectiveDays;

      const subscriptionId = stableRowId('sub', `${paymentId}:${item.$id}:${count}`);
      let subscription = null;
      try {
        subscription = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: subscriptionId });
      } catch { /* ainda não processado */ }
      if (subscription) {
        if (subscription.status === 'ativa') released++; else manual++;
        continue;
      }
      subscription = await tables.createRow({
        databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: subscriptionId,
        data: {
          user_id: order.user_id, servico_id: item.servico_id, nome_servico: item.nome_servico,
          valor: Number(item.preco_unitario_centavos || 0) / 100, data_inicio: now, data_vencimento: expiresAt,
          status: automaticRelease ? 'ativa' : 'aguardando_liberacao', renovacao_automatica: false,
          observacoes: details.prorated === true ? `${displayDays} dias restantes • preço proporcional` : (details.period_label || null),
        }, permissions: userPermissions(order.user_id),
      });
      subscriptionAnnouncements.push({ service: item.nome_servico, period: details.prorated === true ? `${displayDays} dias restantes` : (details.period_label || `${requestedDays} dias`), user_id: order.user_id });

      if (automaticRelease && slot) {
        await createCredentialFromSlot(tables, order.user_id, item.servico_id, subscription.$id, slot, expiresAt);
        await tables.updateRow({
          databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: slot.$id,
          data: { status: 'ocupada', updated_at: now, data_json: JSON.stringify({ ...parseJson(slot.data_json), subscription_id: subscription.$id, occupied_at: now, effective_due_at: expiresAt }) },
        });
        await createModuleDirect(tables, {
          kind: 'stock_history', reference_id: item.servico_id, parent_id: slot.$id, title: 'Vaga ocupada automaticamente', status: 'concluido',
          data: { order_id: orderId, subscription_id: subscription.$id, user_id: order.user_id, expires_at: expiresAt, prorated: details.prorated === true, at: now }, created_by: actorId,
        });
        released++;
      } else {
        if (slot) {
          await tables.updateRow({
            databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: slot.$id,
            data: { updated_at: now, data_json: JSON.stringify({ ...parseJson(slot.data_json), subscription_id: subscription.$id, awaiting_manual_release_at: now }) },
          });
        }
        manual++;
      }
    }
  }
  const status = manual > 0 ? 'em_processamento' : 'concluido';
  await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.orders, rowId: orderId, data: { status, observacoes_admin: body.observacoes_admin || null } });
  if (meta) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: meta.$id, data: { status: 'pago', updated_at: now } });
  await createModuleDirect(tables, { kind: 'order_timeline', reference_id: orderId, title: 'Pagamento aprovado', status: 'concluido', sort_order: 30, data: { event: 'pagamento_aprovado', released, manual, at: now }, created_by: actorId }, order.user_id);
  if (paymentData.cashback_cents || paymentData.points) {
    const existingBenefit = await listModuleRows(tables, 'loyalty_ledger', { ownerId: order.user_id, referenceId: orderId, externalKey: `benefit:${paymentId}`, limit: 1 });
    if (!(existingBenefit.rows?.length)) {
      await createModuleDirect(tables, { kind: 'loyalty_ledger', reference_id: orderId, external_key: `benefit:${paymentId}`, title: 'Benefícios da compra', status: 'disponivel', amount_cents: Number(paymentData.cashback_cents || 0), data: { points: Number(paymentData.points || 0), type: 'credit' }, created_by: actorId }, order.user_id);
    }
  }
  if (paymentData.cashback_used_cents) {
    const reservedLedger = await listModuleRows(tables, 'loyalty_ledger', { ownerId: order.user_id, referenceId: orderId, status: 'reservado', limit: 10 });
    for (const ledger of reservedLedger.rows ?? []) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: ledger.$id, data: { status: 'utilizado', updated_at: now } });
  }
  if (paymentData.coupon_code) {
    const existingUsage = await listModuleRows(tables, 'coupon_usage', { ownerId: order.user_id, referenceId: orderId, externalKey: paymentData.coupon_code, limit: 1 });
    if (!(existingUsage.rows?.length)) {
      await createModuleDirect(tables, { kind: 'coupon_usage', reference_id: orderId, external_key: paymentData.coupon_code, title: paymentData.coupon_code, status: 'utilizado', amount_cents: Number(order.desconto_centavos || 0), data: { payment_id: paymentId, used_at: now }, created_by: actorId }, order.user_id);
    }
  }
  await creditReferralIfEligible({ tables, order });
  await notify(tables, order.user_id, 'Pagamento aprovado', released ? 'Seu acesso de estoque já está disponível no Cofre.' : 'Seu acesso será preparado pela equipe; os dias só começam a contar quando ele for liberado.', 'pagamento');
  try {
    const loadedGroup = await groupSettings(tables);
    if (loadedGroup.settings.announce_subscriptions === true) {
      const names = await groupDisplayNames(tables, [order.user_id]);
      const display = names.get(order.user_id) || 'Um participante';
      for (const item of subscriptionAnnouncements.slice(0, 10)) {
        await createGroupRow(tables, { kind: 'group_message', ownerId: null, status: 'publicado', data: { text: `${display} acabou de assinar ${item.service} • ${item.period} 🎉`, sender_name: 'Rachey Bot', sender_role: 'bot', attachment: null, pinned: false, edited: false, channel: 'avisos', message_type: 'subscription_notice', special: { service: item.service, period: item.period } } });
      }
    }
  } catch { /* anúncio no grupo não pode bloquear a aprovação */ }
  await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId, data: { status: 'pago', data_pagamento: now } });
  try {
    const loadedGroup = await groupSettings(tables);
    const profile = await profileForUser(tables, order.user_id);
    const previousOrders = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.orders, queries: [Query.equal('user_id', order.user_id), Query.limit(100)], total: false, ttl: 0 });
    const priorCount = Math.max(0, (previousOrders.rows ?? []).filter((candidate) => candidate.$id !== orderId).length);
    const bought = subscriptionAnnouncements.map((item) => `${item.service} (${item.period})`).join(', ') || `pedido ${order.numero || orderId}`;
    await botPrivateAlert(tables, loadedGroup.settings, `🛒 Compra aprovada agora: ${profile?.nome || order.user_id} comprou ${bought}. ${priorCount > 0 ? `Já tinha ${priorCount} compra(s) anterior(es).` : 'É a primeira compra desse cliente.'}`);
  } catch { /* alerta privado não pode bloquear a compra */ }
  await audit(tables, req, 'pagamento.aprovar', TABLES.payments, paymentId, payment, { status: 'pago', order_id: orderId, released, manual });
  return { payment_id: paymentId, order_id: orderId, status, released, manual };
  } catch (cause) {
    try {
      const current = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId });
      if (current.status === 'em_processamento') {
        await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId, data: { status: 'em_analise' } });
      }
    } catch { /* preserva o erro original */ }
    throw cause;
  }
}

async function rejectPayment({ tables, req, body }) {
  const paymentId = String(body.paymentId || body.payment_id || '');
  const reason = String(body.reason || '').trim().slice(0, 2000);
  if (!paymentId) throw publicError('paymentId é obrigatório.');
  if (!reason) throw publicError('Informe o motivo da recusa.', 400, 'rejection_reason_required');
  const payment = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId });
  if (payment.status === 'pago') throw publicError('Um pagamento aprovado não pode ser recusado.', 409, 'already_paid');
  const meta = await firstModule(tables, 'payment_meta', { referenceId: paymentId });

  await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId, data: { status: 'recusado' } });
  if (meta) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: meta.$id, data: { status: 'recusado', updated_at: new Date().toISOString() } });

  // Renovação tem ID próprio. A versão anterior tentava interpretar o parent_id
  // como pedido e, por isso, a recusa falhava ou atingia a tabela errada.
  if (payment.renovacao_id) {
    const renewal = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.renewals, rowId: payment.renovacao_id });
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.renewals,
      rowId: renewal.$id,
      data: { status: 'recusada', observacoes: reason },
    });
    await notify(tables, payment.user_id, 'Renovação não aprovada', reason, 'renovacao');
    await audit(tables, req, 'renovacao.recusar', TABLES.renewals, renewal.$id, renewal, { status: 'recusada', payment_id: paymentId, reason });
    return { payment_id: paymentId, renewal_id: renewal.$id, status: 'recusado' };
  }

  const orderId = String(parseJson(meta?.data_json).order_id || meta?.parent_id || '');
  if (!orderId) throw publicError('Pedido relacionado não encontrado.', 404, 'order_not_found');
  await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.orders,
    rowId: orderId,
    data: { status: 'pagamento_recusado', observacoes_admin: reason },
  });
  const reservedLedger = await listModuleRows(tables, 'loyalty_ledger', {
    ownerId: payment.user_id,
    referenceId: orderId,
    status: 'reservado',
    limit: 10,
  });
  for (const ledger of reservedLedger.rows ?? []) {
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      rowId: ledger.$id,
      data: { status: 'estornado', updated_at: new Date().toISOString() },
    });
  }
  await notify(tables, payment.user_id, 'Pagamento não aprovado', reason, 'pagamento');
  await audit(tables, req, 'pagamento.recusar', TABLES.payments, paymentId, payment, { status: 'recusado', order_id: orderId, reason });
  return { payment_id: paymentId, order_id: orderId, status: 'recusado' };
}

async function inventorySaveAccount({ tables, req, body, userId }) {
  const serviceId = String(body.service_id || '');
  const login = String(body.login || '').trim();
  const password = String(body.password || '');
  if (!serviceId || !login || !password) throw publicError('Serviço, login e senha são obrigatórios.');
  const slots = Math.max(1, Math.min(100, Math.round(Number(body.slots || 1))));
  const expiresAt = body.expires_at ? new Date(body.expires_at) : null;
  if (expiresAt && Number.isNaN(expiresAt.getTime())) throw publicError('Data de vencimento da conta inválida.');
  if (expiresAt && expiresAt.getTime() <= Date.now()) throw publicError('A conta pronta precisa vencer no futuro.');
  const prorate = body.prorate_enabled === true;
  const autoRelease = body.auto_release === true || prorate;
  const account = await createModuleDirect(tables, {
    kind: 'inventory_account', reference_id: serviceId, title: String(body.label || `Conta ${Date.now()}`).slice(0, 255), status: 'ativa',
    data: {
      slots, service_type: body.service_type || (slots > 1 ? 'shared_screen' : 'full_account'),
      auto_release: autoRelease, prorate_enabled: prorate, expires_at: expiresAt?.toISOString() || null,
    }, created_by: userId,
  }, null, { login, password, secondary_pin: body.secondary_pin || null });
  for (let index = 1; index <= slots; index++) {
    await createModuleDirect(tables, { kind: 'inventory_slot', parent_id: account.$id, reference_id: serviceId, title: `Vaga ${index}`, status: 'livre', sort_order: index, data: { position: index, label: body.slot_labels?.[index - 1] || `Tela ${index}` }, created_by: userId });
  }
  const serviceMeta = await firstModule(tables, 'service_meta', { referenceId: serviceId });
  if (serviceMeta) {
    const currentMeta = parseJson(serviceMeta.data_json);
    if (currentMeta.stock_enabled !== true) {
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: MODULES_TABLE_ID,
        rowId: serviceMeta.$id,
        data: { data_json: JSON.stringify({ ...currentMeta, stock_enabled: true }), updated_at: new Date().toISOString() },
      });
    }
  }
  await createModuleDirect(tables, { kind: 'stock_history', reference_id: serviceId, parent_id: account.$id, title: 'Conta adicionada', status: 'concluido', data: { slots, expires_at: expiresAt?.toISOString() || null, prorate_enabled: prorate, auto_release: autoRelease, at: new Date().toISOString() }, created_by: userId });
  await audit(tables, req, 'estoque.conta_criar', MODULES_TABLE_ID, account.$id, null, { service_id: serviceId, slots, expires_at: expiresAt?.toISOString() || null, prorate_enabled: prorate, auto_release: autoRelease, login: '[protegido]' });
  return serializeModule(account);
}

async function inventoryUpdateAccount({ tables, req, body, userId }) {
  const account = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: String(body.account_id || '') });
  if (account.kind !== 'inventory_account') throw publicError('Conta de estoque inválida.');
  const currentSecret = decryptObject(account);
  const currentData = parseJson(account.data_json);
  const nextSecret = {
    login: String(body.login || currentSecret.login || '').trim(),
    password: String(body.password || currentSecret.password || ''),
    secondary_pin: body.secondary_pin === undefined ? currentSecret.secondary_pin || null : String(body.secondary_pin || '') || null,
  };
  if (!nextSecret.login || !nextSecret.password) throw publicError('Login e senha são obrigatórios.');
  const rawExpiry = body.expires_at === undefined ? currentData.expires_at : body.expires_at;
  const expiresAt = rawExpiry ? new Date(rawExpiry) : null;
  if (expiresAt && Number.isNaN(expiresAt.getTime())) throw publicError('Data de vencimento da conta inválida.');
  const prorate = body.prorate_enabled === undefined ? currentData.prorate_enabled === true : body.prorate_enabled === true;
  const autoRelease = prorate || (body.auto_release === undefined ? currentData.auto_release === true : body.auto_release === true);
  const saved = await tables.updateRow({
    databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: account.$id,
    data: {
      title: body.label ? String(body.label).slice(0, 255) : account.title,
      data_json: JSON.stringify({ ...currentData, auto_release: autoRelease, prorate_enabled: prorate, expires_at: expiresAt?.toISOString() || null }),
      ...encryptObject(nextSecret), updated_at: new Date().toISOString(),
    },
  });
  await audit(tables, req, 'estoque.conta_atualizar', MODULES_TABLE_ID, account.$id, { title: account.title, login: '[protegido]' }, { title: saved.title, expires_at: expiresAt?.toISOString() || null, prorate_enabled: prorate, auto_release: autoRelease, login: '[protegido]' });
  return serializeModule(saved);
}

async function inventoryDeleteAccount({ tables, req, body, userId }) {
  const account = await tables.getRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: String(body.account_id || ''),
  });
  if (account.kind !== 'inventory_account') throw publicError('Conta de estoque inválida.');
  const slots = await listModuleRows(tables, 'inventory_slot', {
    parentId: account.$id,
    limit: 500,
  });
  if ((slots.rows ?? []).some((slot) => slot.status !== 'livre')) {
    throw publicError('Libere todas as vagas antes de excluir esta conta.', 409, 'inventory_in_use');
  }
  for (const slot of slots.rows ?? []) {
    await tables.deleteRow({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      rowId: slot.$id,
    });
  }
  await tables.deleteRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: account.$id,
  });
  await createModuleDirect(tables, {
    kind: 'stock_history',
    reference_id: account.reference_id,
    title: 'Conta removida',
    status: 'concluido',
    data: { account_title: account.title, slots: slots.rows?.length || 0, at: new Date().toISOString() },
    created_by: userId,
  });
  await audit(tables, req, 'estoque.conta_excluir', MODULES_TABLE_ID, account.$id, { title: account.title, slots: slots.rows?.length || 0 }, null);
  return { account_id: account.$id, deleted: true };
}

async function inventoryReleaseSlot({ tables, req, body, userId }) {
  const slotId = String(body.slot_id || '');
  const slot = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: slotId });
  if (slot.kind !== 'inventory_slot') throw publicError('Vaga inválida.');
  const before = serializeModule(slot);
  await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: slotId,
    data: { owner_id: null, status: 'livre', data_json: JSON.stringify({ ...parseJson(slot.data_json), order_id: null, subscription_id: null, released_at: new Date().toISOString() }), updated_at: new Date().toISOString() },
    permissions: modulePermissions(null),
  });
  const waiting = await listModuleRows(tables, 'waitlist', { referenceId: slot.reference_id, status: 'aguardando', limit: 1 });
  const next = waiting.rows?.[0];
  if (next) {
    await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: next.$id, data: { status: 'vaga_disponivel', updated_at: new Date().toISOString() } });
    await notify(tables, next.owner_id, 'Uma vaga ficou disponível', `${next.title || 'O serviço solicitado'} já pode ser liberado.`, 'estoque');
  }
  await createModuleDirect(tables, {
    kind: 'stock_history', reference_id: slot.reference_id, parent_id: slotId, title: 'Vaga liberada', status: 'concluido',
    data: { previous_owner: slot.owner_id, notified_waitlist: next?.$id || null, at: new Date().toISOString() }, created_by: userId,
  });
  await audit(tables, req, 'estoque.vaga_liberar', MODULES_TABLE_ID, slotId, before, { status: 'livre', waitlist: next?.$id });
  return { slot_id: slotId, status: 'livre', waitlist_notified: next?.$id || null };
}

async function inventoryReveal({ tables, req, body }) {
  const row = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: String(body.account_id || '') });
  if (row.kind !== 'inventory_account') throw publicError('Conta de estoque inválida.');
  const secret = decryptObject(row);
  await audit(tables, req, 'estoque.credencial_visualizar', MODULES_TABLE_ID, row.$id, null, { login: '[protegido]' });
  return { login: secret.login, password: secret.password, secondary_pin: secret.secondary_pin || null };
}

async function inventoryAssignmentForSubscription(tables, subscription) {
  const slots = await listModuleRows(tables, 'inventory_slot', {
    ownerId: subscription.user_id,
    status: 'ocupada',
    limit: 500,
  });
  const slot = (slots.rows ?? []).find((candidate) => parseJson(candidate.data_json).subscription_id === subscription.$id);
  if (!slot?.parent_id) return null;
  try {
    const account = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: slot.parent_id });
    if (account.kind !== 'inventory_account') return null;
    return { slot, account, data: parseJson(account.data_json) };
  } catch {
    return null;
  }
}

async function renewSubscription({ tables, req, body, userId }) {
  const subscriptionId = String(body.subscription_id || '');
  const subscription = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: subscriptionId });
  if (subscription.user_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
  if (subscription.status === 'aguardando_liberacao') throw publicError('A assinatura ainda não foi liberada; os dias só começam após a entrega.');
  const days = Math.max(1, Math.min(3650, Number(body.period_days || 30)));
  const current = new Date(subscription.data_vencimento);
  const base = current > new Date() ? current : new Date();
  const service = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.services, rowId: subscription.servico_id });
  const meta = await firstModule(tables, 'service_meta', { referenceId: subscription.servico_id });
  const period = servicePeriod(service, meta, days);
  let effectiveDays = days;
  let priceCents = period.priceCents;
  let nextMs = base.getTime() + days * 86400000;
  let prorated = false;
  let accountExpiresAt = null;

  const assignment = await inventoryAssignmentForSubscription(tables, subscription);
  if (assignment?.data?.expires_at) {
    const accountDue = new Date(assignment.data.expires_at).getTime();
    accountExpiresAt = assignment.data.expires_at;
    if (!Number.isFinite(accountDue) || accountDue <= base.getTime()) {
      throw publicError('A conta atual não possui dias disponíveis para renovar. Solicite uma troca de conta/tela.', 409, 'inventory_account_no_time');
    }
    const capacityDays = Math.max(1, Math.ceil((accountDue - base.getTime()) / 86400000));
    if (capacityDays < days) {
      if (assignment.data.prorate_enabled !== true) {
        throw publicError(`A conta atual comporta apenas ${capacityDays} dia(s). Solicite uma troca de conta/tela antes de renovar.`, 409, 'inventory_account_insufficient_time');
      }
      effectiveDays = capacityDays;
      priceCents = period.priceCents > 0 ? Math.max(1, Math.round(period.priceCents * effectiveDays / days)) : 0;
      prorated = true;
    }
    nextMs = Math.min(base.getTime() + effectiveDays * 86400000, accountDue);
  }

  const next = new Date(nextMs).toISOString();
  const label = prorated ? `${effectiveDays} dias restantes na conta atual • preço proporcional` : period.label;
  const renewalId = ID.unique();
  const paymentId = ID.unique();
  const pix = await pixData(tables, priceCents, `REN-${renewalId.slice(-12)}`, userId);
  if (!pix) throw publicError('O Pix ainda não foi configurado pelo administrador.', 503, 'pix_not_configured');
  const renewal = await tables.createRow({
    databaseId: DATABASE_ID, tableId: TABLES.renewals, rowId: renewalId,
    data: { user_id: userId, assinatura_id: subscriptionId, data_anterior: subscription.data_vencimento, nova_data: next, valor: priceCents / 100, status: 'aguardando_pagamento', observacoes: label },
    permissions: userPermissions(userId),
  });
  const payment = await tables.createRow({
    databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId,
    data: { user_id: userId, assinatura_id: subscriptionId, renovacao_id: renewal.$id, valor: priceCents / 100, forma_pagamento: 'pix', status: 'aguardando', data_pagamento: null, comprovante_id: null },
    permissions: userPermissions(userId),
  });
  await createModuleDirect(tables, {
    kind: 'payment_meta',
    external_key: pix.provider_payment_id ? `mp:${pix.provider_payment_id}` : null,
    reference_id: payment.$id, parent_id: renewal.$id, status: 'aguardando',
    data: { renewal_id: renewal.$id, subscription_id: subscriptionId, effective_days: effectiveDays, requested_days: days, prorated, account_expires_at: accountExpiresAt, cost_cents: prorated ? Math.round(period.costCents * effectiveDays / days) : period.costCents, provider: pix.provider || pix.mode || 'manual', provider_payment_id: pix.provider_payment_id || null, provider_status: pix.provider_status || null, provider_verified: false },
    created_by: userId,
  }, userId);
  await audit(tables, req, 'renovacao.criar', TABLES.renewals, renewal.$id, null, { renewal, effective_days: effectiveDays, requested_days: days, prorated, account_expires_at: accountExpiresAt });
  return { renewal_id: renewal.$id, payment_id: payment.$id, new_due_at: next, effective_days: effectiveDays, prorated, price_cents: priceCents, pix };
}

async function toggleAutoRenewal({ tables, req, body, userId }) {
  const id = String(body.subscription_id || '');
  const row = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: id });
  if (row.user_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
  const enabled = body.enabled === true;
  if (enabled) {
    const assignment = await inventoryAssignmentForSubscription(tables, row);
    if (assignment?.data?.expires_at) {
      throw publicError('Contas prontas com vencimento usam preço variável. Renove manualmente para o sistema recalcular os dias restantes.', 409, 'dynamic_renewal_requires_quote');
    }
  }
  const saved = await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: id, data: { renovacao_automatica: enabled } });
  await audit(tables, req, 'assinatura.renovacao_automatica', TABLES.subscriptions, id, { renovacao_automatica: row.renovacao_automatica }, { renovacao_automatica: enabled });
  return saved;
}

async function tableRows(tables, tableId, queries = [], limit = 500) {
  return tables.listRows({ databaseId: DATABASE_ID, tableId, queries: [...queries, Query.limit(limit)], total: true, ttl: 0 });
}

async function dashboard({ tables, roles = null }) {
  const [profiles, services, orders, payments, subscriptions, renewals, expenses, goals, tickets, slots, paymentMeta] = await Promise.all([
    tableRows(tables, TABLES.profiles, [], 1), tableRows(tables, TABLES.services, [], 1),
    tableRows(tables, TABLES.orders, [], 500), tableRows(tables, TABLES.payments, [], 500),
    tableRows(tables, TABLES.subscriptions, [], 500), tableRows(tables, TABLES.renewals, [], 500),
    listModuleRows(tables, 'expense', { limit: 500 }), listModuleRows(tables, 'goal', { limit: 100 }),
    listModuleRows(tables, 'support_ticket', { limit: 500 }), listModuleRows(tables, 'inventory_slot', { limit: 500 }),
    listModuleRows(tables, 'payment_meta', { limit: 500 }),
  ]);
  const paid = (payments.rows ?? []).filter((row) => row.status === 'pago');
  const revenueCents = paid.reduce((sum, row) => sum + Math.round(Number(row.valor || 0) * 100), 0);
  const expenseCents = (expenses.rows ?? []).filter((row) => row.status !== 'cancelada').reduce((sum, row) => sum + Number(row.amount_cents || 0), 0);
  const cogsCents = (paymentMeta.rows ?? []).filter((row) => row.status === 'pago').reduce((sum, row) => sum + Number(parseJson(row.data_json).cost_cents || 0), 0);
  const now = Date.now();
  const startToday = new Date(); startToday.setHours(0,0,0,0);
  const todayRevenue = paid.filter((row) => new Date(row.data_pagamento || row.$updatedAt || row.$createdAt).getTime() >= startToday.getTime()).reduce((sum, row) => sum + Math.round(Number(row.valor || 0) * 100), 0);
  const dueCounts = { today: 0, two_days: 0, seven_days: 0, expired: 0, waiting_release: 0 };
  for (const row of subscriptions.rows ?? []) {
    if (row.status === 'aguardando_liberacao') { dueCounts.waiting_release++; continue; }
    const days = remainingDaysUntil(row.data_vencimento, now);
    const dueMs = new Date(row.data_vencimento).getTime();
    if (Number.isFinite(dueMs) && dueMs < now) dueCounts.expired++;
    else if (days === 0 || days === 1) dueCounts.today++;
    if (days !== null && days <= 2 && days >= 0) dueCounts.two_days++;
    if (days !== null && days <= 7 && days >= 0) dueCounts.seven_days++;
  }
  const statuses = {};
  for (const order of orders.rows ?? []) statuses[order.status] = (statuses[order.status] || 0) + 1;
  const pendingPayments = (payments.rows ?? []).filter((row) => row.status === 'em_analise').length;
  const openTickets = (tickets.rows ?? []).filter((row) => !new Set(['resolvido','fechado']).has(row.status)).length;
  const overdueTickets = (tickets.rows ?? []).filter((row) => row.due_at && new Date(row.due_at).getTime() < now && !new Set(['resolvido','fechado']).has(row.status)).length;
  const freeByService = new Map();
  for (const slot of slots.rows ?? []) if (slot.status === 'livre') freeByService.set(slot.reference_id, (freeByService.get(slot.reference_id) || 0) + 1);
  const stockLow = [...freeByService.values()].filter((value) => value <= 1).length;
  const financeAllowed = roles === null || roleFlags(roles).finance;
  return {
    clients: profiles.total, services: services.total, orders: orders.total, subscriptions: subscriptions.total,
    renewals: renewals.total, upcoming_renewals: dueCounts.seven_days,
    revenue_cents: financeAllowed ? revenueCents : null, today_revenue_cents: financeAllowed ? todayRevenue : null,
    expense_cents: financeAllowed ? expenseCents : null, cogs_cents: financeAllowed ? cogsCents : null,
    profit_cents: financeAllowed ? revenueCents - expenseCents - cogsCents : null,
    order_statuses: statuses, goals: (goals.rows ?? []).map((row) => serializeModule(row)),
    pending_payments: pendingPayments, open_tickets: openTickets, overdue_tickets: overdueTickets,
    stock_low: stockLow, expirations: dueCounts,
    actions: [
      ...(pendingPayments ? [{ type: 'payments', severity: 'high', count: pendingPayments, label: 'Pagamentos aguardando análise' }] : []),
      ...(dueCounts.waiting_release ? [{ type: 'release', severity: 'high', count: dueCounts.waiting_release, label: 'Acessos aguardando liberação' }] : []),
      ...(dueCounts.two_days ? [{ type: 'expirations', severity: 'medium', count: dueCounts.two_days, label: 'Assinaturas vencendo em até 2 dias' }] : []),
      ...(openTickets ? [{ type: 'tickets', severity: overdueTickets ? 'high' : 'medium', count: openTickets, label: overdueTickets ? `${overdueTickets} ticket(s) fora do SLA` : 'Tickets aguardando atendimento' }] : []),
      ...(stockLow ? [{ type: 'stock', severity: 'medium', count: stockLow, label: 'Serviços com estoque baixo' }] : []),
    ],
  };
}

async function financeSummary({ tables }) {
  const stats = await dashboard({ tables, roles: null });
  const [payments, expenses] = await Promise.all([
    tableRows(tables, TABLES.payments, [], 500),
    listModuleRows(tables, 'expense', { limit: 500 }),
  ]);
  return {
    ...stats,
    payments: (payments.rows ?? []).map((row) => ({ $id: row.$id, user_id: row.user_id, value_cents: Math.round(Number(row.valor || 0) * 100), status: row.status, paid_at: row.data_pagamento, created_at: row.$createdAt })),
    expenses: (expenses.rows ?? []).map((row) => serializeModule(row)),
  };
}

function pdfBuffer(summary) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 48, size: 'A4' });
    const parts = [];
    doc.on('data', (part) => parts.push(part));
    doc.on('end', () => resolve(Buffer.concat(parts)));
    doc.on('error', reject);
    doc.fontSize(22).fillColor('#132238').text('Relatório financeiro Rachey');
    doc.moveDown().fontSize(10).fillColor('#667085').text(`Gerado em ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}`);
    doc.moveDown().fontSize(14).fillColor('#16A36A').text(`Receitas: ${money(summary.revenue_cents)}`);
    doc.fillColor('#667085').text(`Custo dos produtos/serviços: ${money(summary.cogs_cents)}`);
    doc.fillColor('#FF8A34').text(`Despesas operacionais: ${money(summary.expense_cents)}`);
    doc.fillColor('#132238').text(`Lucro líquido estimado: ${money(summary.profit_cents)}`);
    doc.moveDown().fontSize(15).text('Pagamentos');
    for (const item of summary.payments.slice(0, 150)) doc.fontSize(9).text(`${item.created_at?.slice(0, 10) || '-'}  ${item.status}  ${money(item.value_cents)}`);
    doc.moveDown().fontSize(15).text('Despesas');
    for (const item of summary.expenses.slice(0, 150)) doc.fontSize(9).text(`${item.$createdAt?.slice(0, 10) || '-'}  ${item.title || 'Despesa'}  ${money(item.amount_cents)}`);
    doc.end();
  });
}

async function excelBuffer(summary) {
  const book = new ExcelJS.Workbook();
  book.creator = 'Rachey';
  const overview = book.addWorksheet('Resumo');
  overview.addRows([
    ['Indicador', 'Valor'],
    ['Receitas', summary.revenue_cents / 100],
    ['Custo dos produtos/serviços', summary.cogs_cents / 100],
    ['Despesas operacionais', summary.expense_cents / 100],
    ['Lucro líquido estimado', summary.profit_cents / 100],
    ['Pedidos', summary.orders],
    ['Assinaturas', summary.subscriptions],
  ]);
  overview.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  overview.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF16A36A' } };
  overview.getColumn(1).width = 24;
  overview.getColumn(2).width = 18;
  overview.getColumn(2).numFmt = 'R$ #,##0.00';
  const payments = book.addWorksheet('Pagamentos');
  payments.addRow(['ID', 'Cliente', 'Valor', 'Status', 'Pagamento', 'Criação']);
  for (const item of summary.payments) payments.addRow([item.$id, item.user_id, item.value_cents / 100, item.status, item.paid_at, item.created_at]);
  payments.getRow(1).font = { bold: true };
  const expenses = book.addWorksheet('Despesas');
  expenses.addRow(['ID', 'Descrição', 'Valor', 'Status', 'Data']);
  for (const item of summary.expenses) expenses.addRow([item.$id, item.title, item.amount_cents / 100, item.status, item.$createdAt]);
  expenses.getRow(1).font = { bold: true };
  return Buffer.from(await book.xlsx.writeBuffer());
}

function money(cents) {
  return `R$ ${(Number(cents || 0) / 100).toFixed(2).replace('.', ',')}`;
}

async function exportFinance({ client, tables, req, body, userId }) {
  const format = String(body.format || 'pdf').toLowerCase();
  if (!['pdf', 'xlsx'].includes(format)) throw publicError('Formato inválido.');
  const summary = await financeSummary({ tables });
  const bytes = format === 'pdf' ? await pdfBuffer(summary) : await excelBuffer(summary);
  const name = `rachey-financeiro-${new Date().toISOString().slice(0, 10)}.${format}`;
  const file = await new Storage(client).createFile({
    bucketId: BUCKET_ID,
    fileId: ID.unique(),
    file: InputFile.fromBuffer(bytes, name),
    permissions: adminPermissions(),
  });
  const metadata = await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.fileMetadata,
    rowId: ID.unique(),
    data: { file_id: file.$id, user_id: userId, tipo: 'relatorio_financeiro', referencia_id: null, nome_original: name, mime_type: format === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', tamanho_bytesw: bytes.length },
    permissions: adminPermissions(),
  });
  await audit(tables, req, 'financeiro.exportar', TABLES.fileMetadata, metadata.$id, null, { format, size: bytes.length });
  return { file_id: file.$id, name, mime_type: metadata.mime_type, size: bytes.length };
}

async function saveAppSettings(context) {
  const { tables, req, body, userId, roles } = context;
  const section = String(body.section || 'general').slice(0, 128);
  const rawData = safePayload(body.data || {});
  let existing = await firstModule(tables, 'app_setting', { externalKey: section });
  if (existing) existing = await migrateLegacyAppSettingSecrets(tables, existing);
  const saved = await moduleUpsert({
    tables,
    req,
    body: { kind: 'app_setting', rowId: existing?.$id, external_key: section, title: section, status: 'ativo', data: rawData, owner_id: null },
    userId,
    isAdmin: true,
    roles,
  });
  if (new Set(['general', 'legal', 'pix']).has(section)) {
    const publicData = { ...rawData };
    delete publicData.pix_key;
    const publicExisting = await firstModule(tables, 'app_setting_public', { externalKey: section });
    await moduleUpsert({
      tables,
      req,
      body: {
        kind: 'app_setting_public',
        rowId: publicExisting?.$id,
        external_key: section,
        title: section,
        status: 'ativo',
        data: publicData,
        owner_id: null,
      },
      userId,
      isAdmin: true,
      roles,
    });
  }
  return { saved: true, section, id: saved.$id };
}

function referralCodeFor(userId) {
  return `RCH${crypto.createHash('sha256').update(String(userId)).digest('hex').slice(0, 8).toUpperCase()}`;
}

async function referralSettings(tables) {
  const row = await firstModule(tables, 'app_setting', { externalKey: 'loyalty' });
  const data = parseJson(row?.data_json);
  return {
    client_cashback_cents: Math.max(0, Math.round(Number(data.referral_client_cashback_cents || 0))),
    client_points: Math.max(0, Math.round(Number(data.referral_client_points || 0))),
    referrer_cashback_cents: Math.max(0, Math.round(Number(data.referral_referrer_cashback_cents || 0))),
    referrer_points: Math.max(0, Math.round(Number(data.referral_referrer_points || 0))),
  };
}

async function referralStatus({ tables, userId }) {
  const ownClaim = await listModuleRows(tables, 'referral_claim', { ownerId: userId, limit: 10 });
  const referred = await listModuleRows(tables, 'referral_claim', { referenceId: userId, limit: 500 });
  return {
    code: referralCodeFor(userId),
    claim: ownClaim.rows?.[0] ? serializeModule(ownClaim.rows[0]) : null,
    invited_count: (referred.rows ?? []).length,
    rewarded_count: (referred.rows ?? []).filter((row) => row.status === 'creditada').length,
    rewards: await referralSettings(tables),
  };
}

async function applyReferral({ tables, req, body, userId }) {
  const code = String(body.code || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 32);
  if (!code) throw publicError('Informe um código de indicação.');
  if (code === referralCodeFor(userId)) throw publicError('Você não pode usar o próprio código.');
  const current = await listModuleRows(tables, 'referral_claim', { ownerId: userId, limit: 10 });
  if ((current.rows ?? []).length) throw publicError('Um código de indicação já foi vinculado à sua conta.', 409, 'referral_already_applied');
  const paid = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.payments, queries: [Query.equal('user_id', userId), Query.equal('status', 'pago'), Query.limit(1)], total: false, ttl: 0 });
  if ((paid.rows ?? []).length) throw publicError('O código de indicação deve ser informado antes da primeira compra aprovada.', 409, 'referral_too_late');
  const profiles = await collectTableRows(tables, TABLES.profiles);
  const referrer = profiles.find((profile) => profile.user_id !== userId && referralCodeFor(profile.user_id) === code);
  if (!referrer) throw publicError('Código de indicação não encontrado.', 404, 'referral_not_found');
  const saved = await createModuleDirect(tables, {
    kind: 'referral_claim', reference_id: referrer.user_id, external_key: `referral:${userId}`.slice(0, 128),
    title: `Indicação ${code}`, status: 'pendente',
    data: { code, referrer_user_id: referrer.user_id, applied_at: new Date().toISOString() }, created_by: userId,
  }, userId);
  await audit(tables, req, 'indicacao.vincular', MODULES_TABLE_ID, saved.$id, null, { referrer_user_id: referrer.user_id });
  return serializeModule(saved);
}

async function creditReferralIfEligible({ tables, order }) {
  const claims = await listModuleRows(tables, 'referral_claim', { ownerId: order.user_id, status: 'pendente', limit: 10 });
  const claim = claims.rows?.[0];
  if (!claim) return null;
  const claimData = parseJson(claim.data_json);
  const referrer = claim.reference_id || claimData.referrer_user_id;
  if (!referrer || referrer === order.user_id) return null;
  const settings = await referralSettings(tables);
  const orderId = order.$id;
  if (settings.client_cashback_cents > 0 || settings.client_points > 0) {
    await createModuleDirect(tables, {
      kind: 'loyalty_ledger', reference_id: orderId, title: 'Bônus de indicação', status: 'disponivel', amount_cents: settings.client_cashback_cents,
      data: { points: settings.client_points, type: 'credit', source: 'referral', referral_claim_id: claim.$id }, created_by: order.user_id,
    }, order.user_id);
  }
  if (settings.referrer_cashback_cents > 0 || settings.referrer_points > 0) {
    await createModuleDirect(tables, {
      kind: 'loyalty_ledger', reference_id: orderId, title: 'Bônus por indicar cliente', status: 'disponivel', amount_cents: settings.referrer_cashback_cents,
      data: { points: settings.referrer_points, type: 'credit', source: 'referral', referral_claim_id: claim.$id, referred_user_id: order.user_id }, created_by: order.user_id,
    }, referrer);
  }
  const saved = await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: claim.$id, data: { status: 'creditada', data_json: JSON.stringify({ ...claimData, credited_at: new Date().toISOString(), first_order_id: orderId, rewards: settings }), updated_at: new Date().toISOString() } });
  await notify(tables, order.user_id, 'Indicação confirmada', 'Sua primeira compra confirmou a indicação e os benefícios configurados foram aplicados.', 'fidelidade');
  await notify(tables, referrer, 'Sua indicação comprou no Rachey', 'Uma indicação foi confirmada e os benefícios configurados foram aplicados.', 'fidelidade');
  return saved;
}

async function appSettings({ tables, isAdmin, roles = [] }) {
  const settings = {};
  const publicRows = await listModuleRows(tables, 'app_setting_public', { limit: 100 });
  for (const row of publicRows.rows ?? []) settings[row.external_key || row.$id] = serializeModule(row, false).data;
  if (isAdmin && roleFlags(roles).full) {
    const rows = await listModuleRows(tables, 'app_setting', { limit: 100 });
    for (const originalRow of rows.rows ?? []) {
      const row = await migrateLegacyAppSettingSecrets(tables, originalRow);
      const data = serializeModule(row, false).data;
      if (row.secret_ciphertext) {
        const secret = decryptObject(row);
        data.secret_status = {
          pix_key: Boolean(String(secret.pix_key || '').trim()),
          mercado_pago_access_token: Boolean(String(secret.mercado_pago_access_token || '').trim()),
          mercado_pago_client_secret: Boolean(String(secret.mercado_pago_client_secret || '').trim()),
          mercado_pago_webhook_secret: Boolean(String(secret.mercado_pago_webhook_secret || '').trim()),
          gemini_api_keys: Array.isArray(secret.gemini_api_keys)
            ? secret.gemini_api_keys.filter((item) => String(item || '').trim()).length
            : 0,
        };
      }
      settings[row.external_key || row.$id] = data;
    }
  }
  return settings;
}

async function createTicket({ client, tables, req, body, userId }) {
  const title = String(body.title || '').trim();
  if (!title) throw publicError('Informe o assunto do chamado.');
  const priority = String(body.priority || 'normal');
  const slaHours = priority === 'urgente' ? 2 : priority === 'alta' ? 4 : priority === 'baixa' ? 48 : 24;
  const dueAt = new Date(Date.now() + slaHours * 3600000).toISOString();
  const requesterProfile = await profileForUser(tables, userId);
  const ticket = await createModuleDirect(tables, {
    kind: 'support_ticket', title, status: 'aberto', due_at: dueAt,
    data: { priority, category: body.category || 'geral', subscription_id: body.subscription_id || null, order_id: body.order_id || null, group_message_id: body.group_message_id || null, description: String(body.description || '').slice(0, 12000), file_id: body.file_id || null, mime_type: body.mime_type || null, sla_hours: slaHours, rating: null, requester_name: String(requesterProfile?.nome || 'Cliente').slice(0, 100), requester_photo_id: requesterProfile?.foto_id || null },
    created_by: userId,
  }, userId);
  await notify(tables, userId, 'Chamado aberto', `Recebemos o chamado “${title}”. Prazo inicial de atendimento: ${slaHours}h.`, 'suporte');
  await notifyAdmins(client, tables, 'Novo ticket de suporte', `Novo chamado ${priority}: ${title}.`, 'suporte_admin');
  if (new Set(['alta', 'urgente']).has(priority)) {
    try {
      const loadedGroup = await groupSettings(tables);
      const profile = await profileForUser(tables, userId);
      await botPrivateAlert(tables, loadedGroup.settings, `🆘 Ticket ${priority}: ${profile?.nome || userId} abriu “${title}”. Prazo inicial: ${slaHours}h.`);
    } catch { /* alerta privado não pode bloquear o ticket */ }
  }
  await audit(tables, req, 'suporte.chamado_criar', MODULES_TABLE_ID, ticket.$id, null, serializeModule(ticket));
  return serializeModule(ticket, true);
}

async function replyTicket({ tables, req, body, userId, isAdmin, roles = [] }) {
  if (isAdmin && !roleFlags(roles).operator) {
    throw publicError('Seu perfil não pode responder chamados.', 403, 'role_forbidden');
  }
  const ticketId = String(body.ticket_id || '');
  const ticket = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: ticketId });
  if (ticket.kind !== 'support_ticket' || (!isAdmin && ticket.owner_id !== userId)) throw publicError('Chamado não encontrado.', 404, 'not_found');
  const message = String(body.message || '').trim();
  if (!message && !body.file_id) throw publicError('A mensagem está vazia.');
  const senderProfile = await profileForUser(tables, userId);
  const saved = await createModuleDirect(tables, {
    kind: 'support_message', parent_id: ticketId, reference_id: ticket.reference_id, status: 'enviada',
    data: { message: message.slice(0, 12000), file_id: body.file_id || null, mime_type: body.mime_type || null, sender_role: isAdmin ? 'equipe' : 'cliente', sender_name: isAdmin ? String(senderProfile?.nome || 'Equipe Rachey').slice(0, 100) : String(senderProfile?.nome || 'Cliente').slice(0, 100), sender_photo_id: senderProfile?.foto_id || null }, created_by: userId,
  }, ticket.owner_id);
  if (isAdmin) await notify(tables, ticket.owner_id, 'Nova resposta no suporte', ticket.title || 'Seu chamado recebeu uma resposta.', 'suporte');
  await audit(tables, req, 'suporte.responder', MODULES_TABLE_ID, saved.$id, null, { ticket_id: ticketId, sender: isAdmin ? 'equipe' : 'cliente' });
  return serializeModule(saved, true);
}

async function updateTicket({ tables, req, body, userId }) {
  const row = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: String(body.ticket_id || '') });
  if (row.kind !== 'support_ticket') throw publicError('Chamado inválido.');
  const currentData = parseJson(row.data_json);
  const saved = await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: row.$id,
    data: {
      status: String(body.status || row.status).slice(0, 64),
      assigned_to: body.assigned_to ? String(body.assigned_to).slice(0, 36) : row.assigned_to,
      data_json: JSON.stringify({
        ...currentData,
        priority: body.priority ? String(body.priority).slice(0, 32) : currentData.priority,
      }),
      updated_at: new Date().toISOString(),
    },
  });
  await notify(tables, row.owner_id, 'Chamado atualizado', `${row.title || 'Chamado'}: ${saved.status}.`, 'suporte');
  await audit(tables, req, 'suporte.atualizar', MODULES_TABLE_ID, row.$id, row, saved);
  return serializeModule(saved);
}

async function rateTicket({ tables, req, body, userId }) {
  const id = String(body.ticket_id || '');
  const rating = Math.max(1, Math.min(5, Math.round(Number(body.rating || 0))));
  const row = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: id });
  if (row.kind !== 'support_ticket' || row.owner_id !== userId) throw publicError('Chamado não encontrado.', 404, 'not_found');
  if (!new Set(['resolvido', 'fechado']).has(row.status)) throw publicError('Avalie o atendimento depois que o chamado for resolvido.');
  const current = parseJson(row.data_json);
  const saved = await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: id, data: { data_json: JSON.stringify({ ...current, rating, rated_at: new Date().toISOString() }), updated_at: new Date().toISOString() } });
  await audit(tables, req, 'suporte.avaliar', MODULES_TABLE_ID, id, { rating: current.rating || null }, { rating });
  return serializeModule(saved);
}

const defaultGroupSettings = Object.freeze({
  name: 'Grupo Rachey',
  description: 'Grupo oficial para clientes e administradores Rachey',
  mode: 'todos',
  active_subscribers_only: false,
  slow_mode_seconds: 0,
  media_retention_days: 7,
  allow_links: true,
  allow_images: true,
  allow_videos: true,
  allow_audio: true,
  allow_documents: true,
  image_file_id: null,
  announce_subscriptions: false,
  renewal_reminders: false,
  bot_enabled: false,
  bot_auto_delete: true,
  bot_reply_admin_mention: true,
  bot_alert_admin: true,
  bot_create_ticket_on_admin_mention: true,
  bot_auto_mute: true,
  bot_auto_ban: false,
  bot_mute_after: 3,
  bot_ban_after: 5,
  bot_blocked_terms: [],
  bot_passive_observer: true,
  bot_auto_reply_clients: true,
  bot_ai_moderation: false,
  bot_can_mute: false,
  bot_can_ban: false,
  bot_can_delete: true,
  bot_admin_commands: true,
  bot_natural_admin_commands: true,
  bot_paused: false,
  bot_sleep_until: null,
  bot_private_admin_ids: [],
  allow_member_dm: true,
  allow_client_admin_dm: true,
});

async function createGroupRow(tables, {
  kind,
  ownerId = null,
  referenceId = GROUP_ID,
  externalKey = null,
  title = null,
  status = 'ativo',
  data = {},
  visible = true,
}) {
  return tables.createRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: ID.unique(),
    data: {
      kind,
      owner_id: ownerId,
      parent_id: null,
      reference_id: referenceId,
      external_key: externalKey,
      title,
      status,
      sort_order: 0,
      amount_cents: 0,
      data_json: JSON.stringify(safePayload(data)),
      secret_ciphertext: null,
      secret_iv: null,
      secret_tag: null,
      created_by: ownerId,
      assigned_to: null,
      due_at: null,
      updated_at: new Date().toISOString(),
      active: true,
      visible,
    },
    // Group records are mutated only by this Function. Clients receive the
    // sanitized state returned by group_action and never write rows directly.
    permissions: adminPermissions(),
  });
}

async function groupSettings(tables) {
  let row = await firstModule(tables, 'group_settings', { externalKey: GROUP_ID });
  if (!row) {
    row = await createGroupRow(tables, {
      kind: 'group_settings',
      referenceId: GROUP_ID,
      externalKey: GROUP_ID,
      title: defaultGroupSettings.name,
      data: defaultGroupSettings,
      visible: false,
    });
  }
  return { row, settings: { ...defaultGroupSettings, ...parseJson(row.data_json) } };
}

async function groupMembership(tables, userId) {
  return firstModule(tables, 'group_member', {
    externalKey: `${GROUP_ID}:${userId}`.slice(0, 128),
  });
}

async function groupAccess({ tables, userId, isAdmin }) {
  const loaded = await groupSettings(tables);
  const member = await groupMembership(tables, userId);
  const memberData = parseJson(member?.data_json);
  if (memberData.banned === true && !isAdmin) {
    return { allowed: false, canSend: false, reason: 'Seu acesso a este grupo foi bloqueado pela moderação.', ...loaded, member, memberData };
  }
  const identities = await groupIdentities(tables);
  const identity = identities.get(userId);
  if (!isAdmin && !identity?.display) {
    return {
      allowed: true,
      canSend: false,
      reason: 'Defina um nome de usuário ou telefone em Minha conta para participar do grupo.',
      ...loaded,
      member,
      memberData,
      identity,
    };
  }
  const mutedUntil = memberData.muted_until ? new Date(memberData.muted_until).getTime() : 0;
  const muted = Number.isFinite(mutedUntil) && mutedUntil > Date.now();
  const mode = String(loaded.settings.mode || 'todos');
  const canSend = isAdmin || (!muted && new Set(['todos', 'aprovacao']).has(mode));
  let reason = '';
  if (muted) reason = 'Você está temporariamente silenciado neste grupo.';
  else if (mode === 'somente_admin') reason = 'Somente administradores podem enviar mensagens.';
  else if (mode === 'fechado') reason = 'O grupo está temporariamente fechado.';
  return { allowed: true, canSend, reason, ...loaded, member, memberData, identity };
}

async function groupDisplayNames(tables, userIds) {
  const identities = await groupIdentities(tables);
  const wanted = new Set(userIds);
  return new Map([...identities.entries()]
    .filter(([userId]) => wanted.has(userId))
    .map(([userId, identity]) => [userId, identity.display || identity.name || 'Membro']));
}

async function groupDisplayPhotos(tables, userIds) {
  const identities = await groupIdentities(tables);
  const wanted = new Set(userIds);
  return new Map([...identities.entries()]
    .filter(([userId]) => wanted.has(userId))
    .map(([userId, identity]) => [userId, identity.photo_id || null]));
}

function groupMessageView(row, names, reactions = [], viewerUserId = null, photos = new Map()) {
  const data = parseJson(row.data_json);
  const reactionCounts = {};
  const related = reactions.filter((item) => item.reference_id === row.$id);
  for (const reaction of related) {
    const reactionData = parseJson(reaction.data_json);
    if (reactionData.kind && reactionData.kind !== 'emoji') continue;
    const emoji = String(reactionData.emoji || '👍').slice(0, 8);
    reactionCounts[emoji] = (reactionCounts[emoji] || 0) + 1;
  }
  const special = data.special && typeof data.special === 'object' ? { ...data.special } : null;
  const messageType = String(data.message_type || 'message');
  if (messageType === 'poll' && special) {
    const options = Array.isArray(special.options) ? special.options.slice(0, 8) : [];
    special.votes = options.map((_, index) => related.filter((reaction) => {
      const value = parseJson(reaction.data_json);
      return value.kind === 'poll_vote' && Number(value.option) === index;
    }).length);
    const mine = related.find((reaction) => reaction.owner_id === viewerUserId && parseJson(reaction.data_json).kind === 'poll_vote');
    special.my_vote = mine ? Number(parseJson(mine.data_json).option) : null;
  }
  if (messageType === 'raffle' && special) {
    const entries = related.filter((reaction) => parseJson(reaction.data_json).kind === 'raffle_entry');
    special.entries = entries.length;
    special.joined = entries.some((reaction) => reaction.owner_id === viewerUserId);
    special.winner_name = special.winner_user_id ? (names.get(special.winner_user_id) || 'Participante') : null;
    special.winner_names = (Array.isArray(special.winner_user_ids) ? special.winner_user_ids : [])
      .map((id) => names.get(id) || 'Participante');
  }
  return {
    $id: row.$id,
    $createdAt: row.$createdAt,
    $updatedAt: row.$updatedAt,
    owner_id: row.owner_id,
    status: row.status,
    text: String(data.text || ''),
    sender_name: data.sender_role === 'admin'
      ? String(data.sender_name || 'Equipe Rachey')
      : data.sender_role === 'bot'
        ? 'Rachey Bot'
        : (names.get(row.owner_id) || String(data.sender_name || 'Membro')),
    sender_role: data.sender_role || 'cliente',
    sender_photo_id: data.sender_role === 'bot' ? null : (data.sender_photo_id || photos.get(row.owner_id) || null),
    reply_to: data.reply_to || null,
    attachment: data.attachment || null,
    pinned: data.pinned === true,
    edited: data.edited === true,
    channel: data.channel || 'geral',
    reactions: reactionCounts,
    message_type: messageType,
    special,
  };
}

async function groupState(context) {
  const { tables, client, userId, isAdmin } = context;
  const access = await groupAccess(context);
  const publicSettings = {
    name: access.settings.name,
    description: access.settings.description,
    image_file_id: access.settings.image_file_id || null,
    mode: access.settings.mode,
    active_subscribers_only: false,
    slow_mode_seconds: access.settings.slow_mode_seconds,
    media_retention_days: access.settings.media_retention_days,
    allow_links: access.settings.allow_links,
    allow_images: access.settings.allow_images,
    allow_videos: access.settings.allow_videos,
    allow_audio: access.settings.allow_audio,
    allow_documents: access.settings.allow_documents,
    announce_subscriptions: access.settings.announce_subscriptions === true,
    renewal_reminders: access.settings.renewal_reminders === true,
    bot_enabled: access.settings.bot_enabled === true,
    bot_auto_delete: access.settings.bot_auto_delete !== false,
    bot_reply_admin_mention: access.settings.bot_reply_admin_mention !== false,
    bot_alert_admin: access.settings.bot_alert_admin !== false,
    bot_create_ticket_on_admin_mention: access.settings.bot_create_ticket_on_admin_mention !== false,
    bot_auto_mute: access.settings.bot_auto_mute !== false,
    bot_auto_ban: access.settings.bot_auto_ban === true,
    bot_mute_after: Math.max(1, Number(access.settings.bot_mute_after || 3)),
    bot_ban_after: Math.max(2, Number(access.settings.bot_ban_after || 5)),
    bot_blocked_terms: Array.isArray(access.settings.bot_blocked_terms) ? access.settings.bot_blocked_terms : [],
    allow_member_dm: access.settings.allow_member_dm === true,
    allow_client_admin_dm: access.settings.allow_client_admin_dm !== false,
    ...(isAdmin ? {
      bot_passive_observer: access.settings.bot_passive_observer === true,
      bot_auto_reply_clients: access.settings.bot_auto_reply_clients === true,
      bot_ai_moderation: access.settings.bot_ai_moderation === true,
      bot_can_mute: access.settings.bot_can_mute === true,
      bot_can_ban: access.settings.bot_can_ban === true,
      bot_can_delete: access.settings.bot_can_delete !== false,
      bot_admin_commands: access.settings.bot_admin_commands !== false,
      bot_natural_admin_commands: access.settings.bot_natural_admin_commands !== false,
      bot_paused: access.settings.bot_paused === true,
      bot_sleep_until: access.settings.bot_sleep_until || null,
      bot_private_admin_ids: Array.isArray(access.settings.bot_private_admin_ids) ? access.settings.bot_private_admin_ids : [],
    } : {}),
  };
  if (!access.allowed) {
    return { group_id: GROUP_ID, settings: publicSettings, allowed: false, can_send: false, reason: access.reason, messages: [] };
  }
  const [messageResult, reactionResult, reportResult] = await Promise.all([
    listModuleRows(tables, 'group_message', { referenceId: GROUP_ID, limit: 300 }),
    listModuleRows(tables, 'group_reaction', { limit: 500 }),
    isAdmin ? listModuleRows(tables, 'group_report', { status: 'aberta', limit: 500 }) : Promise.resolve({ rows: [] }),
  ]);
  const messages = (messageResult.rows ?? [])
    .filter((row) => row.status === 'publicado' || isAdmin || row.owner_id === userId)
    .filter((row) => {
      const target = String(parseJson(row.data_json).target_user_id || '');
      return !target || target === userId || isAdmin;
    })
    .sort((a, b) => String(a.$createdAt).localeCompare(String(b.$createdAt)));
  const reactionOwners = (reactionResult.rows ?? []).map((row) => row.owner_id).filter(Boolean);
  const specialWinners = messages.map((row) => parseJson(row.data_json)?.special?.winner_user_id).filter(Boolean);
  const wantedIds = [...new Set([...messages.map((row) => row.owner_id).filter(Boolean), ...reactionOwners, ...specialWinners, userId])];
  const identities = await groupIdentities(tables);
  const names = new Map(wantedIds.map((id) => [id, identities.get(id)?.display || identities.get(id)?.name || 'Membro']));
  const photos = new Map(wantedIds.map((id) => [id, identities.get(id)?.photo_id || null]));
  const quickRows = await listModuleRows(tables, 'quick_reply', { limit: 200 });
  const quickReplies = (quickRows.rows ?? []).filter((row) => row.status !== 'inativo').map((row) => {
    const data = parseJson(row.data_json);
    return { $id: row.$id, title: row.title || 'Mensagem', text: String(data.text || '').slice(0, 2000), scope: String(data.scope || 'support_admin') };
  }).filter((item) => isAdmin
    ? new Set(['group_admin', 'group_all', 'all']).has(item.scope)
    : new Set(['group_client', 'group_all', 'all']).has(item.scope));
  let adminTargets = [];
  if (isAdmin && client) {
    const adminIds = await adminUserIds(client);
    adminTargets = adminIds.map((id) => ({ user_id: id, name: identities.get(id)?.display || identities.get(id)?.name || id, photo_id: identities.get(id)?.photo_id || null }));
  }
  return {
    group_id: GROUP_ID,
    settings: publicSettings,
    allowed: true,
    can_send: access.canSend,
    reason: access.reason,
    my_state: { notifications: 'mentions', ...access.memberData },
    open_reports: reportResult.rows?.length ?? 0,
    quick_replies: quickReplies,
    admin_targets: adminTargets,
    messages: messages.map((row) => groupMessageView(row, names, reactionResult.rows ?? [], userId, photos)),
  };
}

function validateGroupAttachment(settings, attachment) {
  if (!attachment) return null;
  const value = typeof attachment === 'object' && !Array.isArray(attachment) ? attachment : {};
  const fileId = String(value.file_id || '').slice(0, 36);
  const type = String(value.type || '').slice(0, 50);
  if (!fileId || !GROUP_MEDIA_TYPES.has(type)) throw publicError('Anexo do grupo inválido.');
  const settingByType = {
    grupo_imagem: 'allow_images',
    grupo_video: 'allow_videos',
    grupo_audio: 'allow_audio',
    grupo_documento: 'allow_documents',
  };
  if (settings[settingByType[type]] === false) throw publicError('Este tipo de mídia foi bloqueado pela administração.', 403, 'media_disabled');
  return {
    file_id: fileId,
    type,
    name: String(value.name || 'arquivo').slice(0, 255),
    mime_type: String(value.mime_type || 'application/octet-stream').slice(0, 150),
    size: Math.max(0, Math.round(Number(value.size || 0))),
  };
}


async function aiBotSettings(tables) {
  let row = await firstModule(tables, 'app_setting', { externalKey: 'ai_bot' });
  if (!row) return { enabled: false };
  row = await migrateLegacyAppSettingSecrets(tables, row);
  return { ...parseJson(row.data_json), ...decryptObject(row) };
}

async function generateBotAnswer(tables, prompt, contextText = '', force = false) {
  const settings = await aiBotSettings(tables);
  if (settings.enabled !== true && !force) return null;
  const keys = (Array.isArray(settings.gemini_api_keys) ? settings.gemini_api_keys : [settings.gemini_api_keys])
    .map((item) => String(item || '').trim()).filter(Boolean).slice(0, 10);
  const models = [settings.primary_model, ...(Array.isArray(settings.fallback_models) ? settings.fallback_models : [])]
    .map((item) => String(item || '').trim().replace(/^models\//, '')).filter(Boolean);
  if (!keys.length || !models.length) return null;
  const system = String(settings.system_prompt || 'Você é o Rachey Bot. Responda em português do Brasil, seja objetivo, útil e não invente dados de pagamento, estoque, pedido ou credenciais. Quando não souber algo sobre a conta do cliente, oriente a abrir suporte.').slice(0, 8000);
  const userPrompt = String(prompt || '').slice(0, 12000);
  const context = String(contextText || '').slice(0, 16000);
  let lastError = null;
  for (const model of models) {
    for (const key of keys) {
      try {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
          body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: `${system}\n\n${context ? `Contexto recente do grupo:\n${context}\n\n` : ''}Solicitação:\n${userPrompt}` }] }],
            generationConfig: {
              temperature: Math.max(0, Math.min(2, Number(settings.temperature ?? 0.4))),
              maxOutputTokens: Math.max(128, Math.min(4096, Math.round(Number(settings.max_output_tokens || 1024)))),
            },
          }),
          signal: AbortSignal.timeout(Math.max(5000, Math.min(30000, Number(settings.timeout_ms || 18000)))),
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
          lastError = new Error(payload?.error?.message || `Gemini HTTP ${response.status}`);
          continue;
        }
        const text = (payload?.candidates?.[0]?.content?.parts || []).map((part) => String(part?.text || '')).join('').trim();
        if (text) return { text: text.slice(0, 4000), model };
      } catch (cause) { lastError = cause; }
    }
  }
  if (lastError) console.error('AI fallback exhausted:', lastError?.message || lastError);
  return null;
}

async function listAiModels(tables) {
  const settings = await aiBotSettings(tables);
  const keys = (Array.isArray(settings.gemini_api_keys) ? settings.gemini_api_keys : [settings.gemini_api_keys])
    .map((value) => String(value || '').trim())
    .filter(Boolean);
  if (!keys.length) throw publicError('Cadastre pelo menos uma chave da Gemini API antes de listar modelos.', 409, 'ai_not_configured');
  let lastError = null;
  for (const key of keys) {
    try {
      const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000', {
        headers: { 'x-goog-api-key': key, 'Accept': 'application/json' },
        signal: AbortSignal.timeout(12000),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        lastError = payload?.error?.message || `HTTP ${response.status}`;
        continue;
      }
      const models = (Array.isArray(payload.models) ? payload.models : [])
        .filter((item) => {
          const actions = item.supportedGenerationMethods || item.supportedActions || [];
          return actions.includes('generateContent');
        })
        .map((item) => {
          const id = String(item.baseModelId || item.name || '').replace(/^models\//, '');
          return {
            id,
            name: String(item.displayName || id).slice(0, 160),
            family: id.startsWith('gemma-') ? 'gemma' : id.startsWith('gemini-') ? 'gemini' : 'outro',
            input_token_limit: Number(item.inputTokenLimit || 0) || null,
            output_token_limit: Number(item.outputTokenLimit || 0) || null,
          };
        })
        .filter((item) => item.id)
        .sort((a, b) => `${a.family}:${a.name}`.localeCompare(`${b.family}:${b.name}`, 'pt-BR'));
      return { models };
    } catch (cause) {
      lastError = cause?.message || String(cause);
    }
  }
  throw publicError(`Não foi possível listar os modelos disponíveis: ${String(lastError || 'chaves recusadas').slice(0, 240)}`, 502, 'ai_models_unavailable');
}

async function testAiBot(tables) {
  const result = await generateBotAnswer(
    tables,
    'Responda apenas: conexão com IA funcionando.',
    '',
    true,
  );
  if (!result?.text) throw publicError('Nenhuma chave/modelo configurado respondeu ao teste.', 502, 'ai_test_failed');
  return { connected: true, model: result.model, preview: result.text.slice(0, 300) };
}

async function recentGroupContext(tables, limit = 35) {
  const rows = await listModuleRows(tables, 'group_message', { referenceId: GROUP_ID, limit: Math.max(10, Math.min(100, limit)) });
  return (rows.rows ?? []).sort((a, b) => String(a.$CreatedAt || a.$createdAt || '').localeCompare(String(b.$CreatedAt || b.$createdAt || '')))
    .slice(-limit)
    .map((row) => {
      const data = parseJson(row.data_json);
      return `${data.sender_name || data.sender_role || 'Membro'}: ${String(data.text || '').replace(/\s+/g, ' ').slice(0, 500)}`;
    }).filter((line) => !line.endsWith(': ')).join('\n');
}


async function profileForUser(tables, targetUserId) {
  if (!targetUserId || targetUserId === 'bot') return null;
  const rows = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.profiles,
    queries: [Query.equal('user_id', targetUserId), Query.limit(1)],
    total: false,
    ttl: 0,
  });
  return rows.rows?.[0] || null;
}

function groupBotAwake(settings) {
  if (settings.bot_enabled !== true || settings.bot_paused === true) return false;
  const until = settings.bot_sleep_until ? new Date(settings.bot_sleep_until).getTime() : 0;
  return !(Number.isFinite(until) && until > Date.now());
}

async function botBusinessContext(tables, userId, isAdmin) {
  const [services, slots, orders, orderItems, payments, subscriptions] = await Promise.all([
    tableRows(tables, TABLES.services, [], 500),
    listModuleRows(tables, 'inventory_slot', { limit: 500 }),
    tableRows(tables, TABLES.orders, isAdmin ? [] : [Query.equal('user_id', userId)], 500),
    tableRows(tables, TABLES.orderItems, isAdmin ? [] : [Query.equal('user_id', userId)], 500),
    tableRows(tables, TABLES.payments, isAdmin ? [] : [Query.equal('user_id', userId)], 500),
    tableRows(tables, TABLES.subscriptions, isAdmin ? [] : [Query.equal('user_id', userId)], 500),
  ]);
  const freeByService = new Map();
  for (const slot of slots.rows ?? []) {
    if (slot.status === 'livre') freeByService.set(slot.reference_id, (freeByService.get(slot.reference_id) || 0) + 1);
  }
  const serviceLines = (services.rows ?? []).slice(0, 80).map((service) => {
    const free = freeByService.get(service.$id) || 0;
    return `${service.nome || service.titulo || service.$id}: ${free} vaga(s) livre(s)`;
  });
  const itemsByOrder = new Map();
  for (const item of orderItems.rows ?? []) {
    const key = item.pedido_id;
    if (!key) continue;
    if (!itemsByOrder.has(key)) itemsByOrder.set(key, []);
    itemsByOrder.get(key).push(`${item.nome_servico || item.servico_id || 'serviço'} x${Number(item.quantidade || 1)}`);
  }

  if (!isAdmin) {
    const orderRows = [...(orders.rows ?? [])].sort((a, b) => String(b.$createdAt || '').localeCompare(String(a.$createdAt || ''))).slice(0, 8);
    const paymentRows = [...(payments.rows ?? [])].sort((a, b) => String(b.$createdAt || '').localeCompare(String(a.$createdAt || ''))).slice(0, 8);
    const subscriptionRows = [...(subscriptions.rows ?? [])].sort((a, b) => String(b.$createdAt || '').localeCompare(String(a.$createdAt || ''))).slice(0, 8);
    return [
      'DADOS AO VIVO DO CLIENTE (não revele dados de outros clientes):',
      `Compras anteriores: ${orders.total ?? orderRows.length}.`,
      `Pedidos recentes: ${orderRows.map((row) => `${row.numero || row.$id}=${row.status} [${(itemsByOrder.get(row.$id) || []).join(', ') || 'itens não informados'}]`).join('; ') || 'nenhum'}.`,
      `Pagamentos recentes: ${paymentRows.map((row) => `${row.status} R$ ${Number(row.valor || 0).toFixed(2)}`).join('; ') || 'nenhum'}.`,
      `Assinaturas: ${subscriptionRows.map((row) => `${row.nome_servico || row.servico_id}=${row.status}, vence ${row.data_vencimento || '-'}`).join('; ') || 'nenhuma'}.`,
      `Estoque disponível agora: ${serviceLines.join('; ') || 'sem dados'}.`,
    ].join('\n').slice(0, 15000);
  }

  const [profiles, accounts, tickets] = await Promise.all([
    tableRows(tables, TABLES.profiles, [], 500),
    listModuleRows(tables, 'inventory_account', { limit: 500 }),
    listModuleRows(tables, 'support_ticket', { limit: 500 }),
  ]);
  const names = new Map((profiles.rows ?? []).map((row) => [row.user_id, String(row.nome || row.email || row.user_id)]));
  const orderCountByUser = new Map();
  for (const order of orders.rows ?? []) orderCountByUser.set(order.user_id, (orderCountByUser.get(order.user_id) || 0) + 1);
  const allOrdersSorted = [...(orders.rows ?? [])]
    .sort((a, b) => String(b.$createdAt || '').localeCompare(String(a.$createdAt || '')));
  const ordersByUser = new Map();
  for (const order of allOrdersSorted) {
    if (!ordersByUser.has(order.user_id)) ordersByUser.set(order.user_id, []);
    ordersByUser.get(order.user_id).push(order);
  }
  const recentOrders = allOrdersSorted.slice(0, 12).map((row) => {
    const customerOrders = ordersByUser.get(row.user_id) || [row];
    const position = customerOrders.findIndex((candidate) => candidate.$id === row.$id);
    const previous = position >= 0 ? customerOrders[position + 1] : null;
    const count = orderCountByUser.get(row.user_id) || 1;
    const currentItems = (itemsByOrder.get(row.$id) || []).join(', ') || 'itens não informados';
    const previousItems = previous ? ((itemsByOrder.get(previous.$id) || []).join(', ') || 'itens não informados') : null;
    return `${names.get(row.user_id) || row.user_id}: ${row.numero || row.$id}=${row.status}; agora comprou [${currentItems}]${count > 1 ? `; cliente recorrente (${count} compras); compra anterior ${previous.numero || previous.$id} [${previousItems}]` : '; primeira compra'}`;
  });
  const paymentStatuses = {};
  for (const payment of payments.rows ?? []) paymentStatuses[payment.status] = (paymentStatuses[payment.status] || 0) + 1;
  const recentPayments = [...(payments.rows ?? [])]
    .sort((a, b) => String(b.$createdAt || '').localeCompare(String(a.$createdAt || '')))
    .slice(0, 15)
    .map((payment) => `${names.get(payment.user_id) || payment.user_id}: ${payment.status}, R$ ${Number(payment.valor || 0).toFixed(2)}, ${payment.$createdAt || '-'}`);
  const accountStatuses = {};
  for (const account of accounts.rows ?? []) accountStatuses[account.status] = (accountStatuses[account.status] || 0) + 1;
  const accountLines = (accounts.rows ?? []).slice(0, 80).map((account) => {
    const data = parseJson(account.data_json);
    const relatedSlots = (slots.rows ?? []).filter((slot) => slot.parent_id === account.$id);
    const free = relatedSlots.filter((slot) => slot.status === 'livre').length;
    return `${account.title || account.$id}: status=${account.status}, serviço=${account.reference_id || '-'}, vagas livres=${free}/${relatedSlots.length}, vence=${data.expires_at || account.due_at || '-'}`;
  });
  const openTicketRows = (tickets.rows ?? []).filter((row) => !new Set(['resolvido', 'fechado']).has(row.status));
  const ticketLines = openTicketRows.slice(0, 20).map((ticket) => `${ticket.title || ticket.$id}: ${ticket.status}, prioridade=${parseJson(ticket.data_json).priority || 'normal'}, prazo=${ticket.due_at || '-'}`);
  return [
    'PAINEL OPERACIONAL AO VIVO (somente administrador):',
    `Clientes: ${profiles.total ?? profiles.rows?.length ?? 0}; pedidos: ${orders.total ?? 0}; assinaturas: ${subscriptions.total ?? 0}.`,
    `Pagamentos por status: ${Object.entries(paymentStatuses).map(([k, v]) => `${k}=${v}`).join(', ') || 'nenhum'}.`,
    `Pagamentos mais recentes: ${recentPayments.join(' | ') || 'nenhum'}.`,
    `Contas de estoque por status: ${Object.entries(accountStatuses).map(([k, v]) => `${k}=${v}`).join(', ') || 'nenhuma'}.`,
    `Detalhes das contas de estoque: ${accountLines.join(' | ') || 'nenhuma'}.`,
    `Tickets abertos: ${openTicketRows.length}. ${ticketLines.join(' | ')}`,
    `Estoque livre agora: ${serviceLines.join('; ') || 'sem dados'}.`,
    `Compras mais recentes e histórico: ${recentOrders.join(' | ') || 'nenhuma'}.`,
  ].join('\n').slice(0, 26000);
}

async function resolveGroupUser(tables, value) {
  const needle = String(value || '').trim().replace(/^@+/, '').toLowerCase();
  if (!needle) return null;
  const identities = await groupIdentities(tables);
  for (const [id, identity] of identities.entries()) {
    if (id.toLowerCase() === needle || identity.username === needle || String(identity.display || '').replace(/^@/, '').toLowerCase() === needle || String(identity.name || '').toLowerCase() === needle) {
      return { id, ...identity };
    }
  }
  return null;
}

async function saveGroupSettingsPatch(tables, access, patch) {
  const next = { ...access.settings, ...patch };
  await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: access.row.$id,
    data: { title: next.name || access.row.title, data_json: JSON.stringify(next), updated_at: new Date().toISOString() },
  });
  access.settings = next;
  return next;
}

async function createBotTask(tables, actorId, { type, text = '', intervalMinutes = 60, channel = 'promocoes', data = {} }) {
  const interval = Math.max(5, Math.min(10080, Math.round(Number(intervalMinutes || 60))));
  const now = new Date();
  const nextRun = new Date(now.getTime() + interval * 60000).toISOString();
  return createModuleDirect(tables, {
    kind: 'bot_task',
    title: type === 'promotion' ? 'Promoção recorrente' : 'Automação do bot',
    status: 'ativa',
    due_at: nextRun,
    data: { task_type: type, text: String(text).slice(0, 3000), interval_minutes: interval, channel, next_run_at: nextRun, ...data },
    created_by: actorId,
  });
}

async function ensureDirectThread(tables, participantA, participantB, createdBy = null) {
  const participants = [String(participantA), String(participantB)].sort();
  const externalKey = `dm:${participants.join(':')}`.slice(0, 128);
  let thread = await firstModule(tables, 'direct_thread', { externalKey });
  if (thread) return thread;
  thread = await createModuleDirect(tables, {
    kind: 'direct_thread',
    external_key: externalKey,
    title: 'Conversa privada',
    status: 'ativa',
    data: { participants, bot_thread: participants.includes('bot'), created_at: new Date().toISOString() },
    created_by: createdBy,
  });
  return thread;
}

async function createDirectMessageInternal(tables, { senderId, targetId, text, senderRole = 'cliente', attachment = null, createdBy = null }) {
  const thread = await ensureDirectThread(tables, senderId || 'bot', targetId, createdBy || senderId || targetId);
  const senderProfile = senderId ? await profileForUser(tables, senderId) : null;
  const data = {
    text: String(text || '').trim().slice(0, 8000),
    sender_id: senderId || null,
    sender_role: senderRole,
    sender_name: senderRole === 'bot' ? 'Rachey Bot' : String(senderProfile?.nome || (senderRole === 'admin' ? 'Equipe Rachey' : 'Membro')).slice(0, 100),
    sender_photo_id: senderProfile?.foto_id || null,
    target_user_id: targetId,
    attachment,
    read_by: senderId ? [senderId] : [],
  };
  const message = await createModuleDirect(tables, {
    kind: 'direct_message',
    parent_id: thread.$id,
    reference_id: targetId,
    title: data.sender_name,
    status: 'enviada',
    data,
    created_by: createdBy || senderId || null,
  }, senderId || null);
  await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: thread.$id,
    data: { updated_at: new Date().toISOString(), data_json: JSON.stringify({ ...parseJson(thread.data_json), last_message_at: new Date().toISOString(), last_sender_id: senderId || 'bot' }) },
  });
  return { thread, message };
}

async function botPrivateAlert(tables, settings, text) {
  const targets = Array.isArray(settings.bot_private_admin_ids) ? settings.bot_private_admin_ids.map(String).filter(Boolean).slice(0, 20) : [];
  let sent = 0;
  for (const target of targets) {
    await createDirectMessageInternal(tables, { senderId: null, targetId: target, text, senderRole: 'bot', createdBy: target });
    await notify(tables, target, 'Rachey Bot no privado', String(text).slice(0, 2000), 'sistema');
    sent++;
  }
  return sent;
}

async function directAction(context) {
  const { tables, client, body, userId, isAdmin } = context;
  const operation = String(body.operation || 'state');
  const loaded = await groupSettings(tables);
  const settings = loaded.settings;
  const identities = await groupIdentities(tables);
  const adminIds = new Set(await adminUserIds(client));

  if (operation === 'state') {
    const threads = await listModuleRows(tables, 'direct_thread', { limit: 500 });
    const mine = (threads.rows ?? []).filter((row) => (parseJson(row.data_json).participants || []).includes(userId));
    const resultThreads = [];
    for (const thread of mine.sort((a, b) => String(b.updated_at || b.$updatedAt || '').localeCompare(String(a.updated_at || a.$updatedAt || ''))).slice(0, 100)) {
      const data = parseJson(thread.data_json);
      const messages = await listModuleRows(tables, 'direct_message', { parentId: thread.$id, limit: 200 });
      const ordered = [...(messages.rows ?? [])].sort((a, b) => String(a.$createdAt || '').localeCompare(String(b.$createdAt || '')));
      const last = ordered.at(-1);
      const otherId = (data.participants || []).find((id) => id !== userId) || 'bot';
      const other = otherId === 'bot' ? { display: 'Rachey Bot', name: 'Rachey Bot', photo_id: null } : identities.get(otherId) || {};
      const unread = ordered.filter((row) => {
        const md = parseJson(row.data_json);
        return md.sender_id !== userId && !(Array.isArray(md.read_by) && md.read_by.includes(userId));
      }).length;
      resultThreads.push({
        $id: thread.$id,
        contact_user_id: otherId,
        contact_name: other.display || other.name || 'Contato',
        contact_photo_id: other.photo_id || null,
        bot_thread: otherId === 'bot',
        unread,
        last_message: last ? String(parseJson(last.data_json).text || '') : '',
        last_at: last?.$createdAt || thread.$createdAt,
      });
    }
    const contacts = [...identities.entries()]
      .filter(([id, identity]) => id !== userId && identity.active !== false)
      .filter(([id]) => isAdmin || adminIds.has(id) || settings.allow_member_dm === true)
      .map(([id, identity]) => ({ user_id: id, name: identity.display || identity.name || 'Membro', photo_id: identity.photo_id || null, is_admin: adminIds.has(id) }));
    return { threads: resultThreads, contacts, allow_member_dm: settings.allow_member_dm === true, allow_client_admin_dm: settings.allow_client_admin_dm !== false };
  }

  if (operation === 'open') {
    const targetId = String(body.target_user_id || '').slice(0, 36);
    if (!targetId || targetId === userId) throw publicError('Contato inválido.');
    const targetIsAdmin = adminIds.has(targetId);
    if (!isAdmin && !targetIsAdmin && settings.allow_member_dm !== true) throw publicError('Mensagens privadas entre participantes estão desativadas.', 403, 'dm_disabled');
    if (!isAdmin && targetIsAdmin && settings.allow_client_admin_dm === false) throw publicError('Mensagens privadas com administradores estão desativadas.', 403, 'dm_disabled');
    const thread = await ensureDirectThread(tables, userId, targetId, userId);
    return { thread_id: thread.$id };
  }

  if (operation === 'messages') {
    const threadId = String(body.thread_id || '').slice(0, 36);
    const thread = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: threadId });
    if (thread.kind !== 'direct_thread' || !(parseJson(thread.data_json).participants || []).includes(userId)) throw publicError('Conversa não encontrada.', 404, 'not_found');
    const rows = await listModuleRows(tables, 'direct_message', { parentId: threadId, limit: 300 });
    const messages = [];
    for (const row of [...(rows.rows ?? [])].sort((a, b) => String(a.$createdAt || '').localeCompare(String(b.$createdAt || '')))) {
      const data = parseJson(row.data_json);
      if (data.sender_id !== userId && !(Array.isArray(data.read_by) && data.read_by.includes(userId))) {
        await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: row.$id, data: { data_json: JSON.stringify({ ...data, read_by: [...new Set([...(data.read_by || []), userId])] }), updated_at: new Date().toISOString() } });
      }
      messages.push({ $id: row.$id, $createdAt: row.$createdAt, ...data });
    }
    return { thread_id: threadId, messages };
  }

  if (operation === 'send') {
    const targetId = String(body.target_user_id || '').slice(0, 36);
    const text = String(body.text || '').trim().slice(0, 8000);
    const attachment = body.attachment && typeof body.attachment === 'object' ? safePayload(body.attachment) : null;
    if (!targetId || (!text && !attachment)) throw publicError('Destinatário e mensagem são obrigatórios.');
    const targetIsAdmin = adminIds.has(targetId);
    if (!isAdmin && !targetIsAdmin && settings.allow_member_dm !== true) throw publicError('Mensagens privadas entre participantes estão desativadas.', 403, 'dm_disabled');
    if (!isAdmin && targetIsAdmin && settings.allow_client_admin_dm === false) throw publicError('Mensagens privadas com administradores estão desativadas.', 403, 'dm_disabled');
    if (attachment?.file_id) {
      const metadata = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.fileMetadata, queries: [Query.equal('file_id', String(attachment.file_id)), Query.limit(1)], total: false, ttl: 0 });
      if (!metadata.rows?.[0] || metadata.rows[0].user_id !== userId) throw publicError('Arquivo não autorizado.', 403, 'file_forbidden');
      await new Storage(client).updateFile({
        bucketId: BUCKET_ID,
        fileId: String(attachment.file_id),
        permissions: [Permission.read(Role.user(userId)), Permission.read(Role.user(targetId)), Permission.update(Role.user(userId)), Permission.delete(Role.user(userId)), ...adminPermissions()],
      });
    }
    const role = isAdmin ? 'admin' : 'cliente';
    const result = await createDirectMessageInternal(tables, { senderId: userId, targetId, text, senderRole: role, attachment, createdBy: userId });
    await notify(tables, targetId, isAdmin ? 'Mensagem privada da equipe' : 'Nova mensagem privada', text || 'Você recebeu um arquivo no privado.', 'sistema');
    return { thread_id: result.thread.$id, message_id: result.message.$id };
  }

  throw publicError('Ação de mensagem privada inválida.');
}

async function executeAdminBotCommand(context, text, access) {
  const { tables, req, userId } = context;
  if (!context.isAdmin || access.settings.bot_admin_commands !== true) return null;
  const original = String(text || '').trim();
  const lower = original.toLowerCase();
  const commandLike = original.startsWith('/') || /^(bot|rachey)[,:]\s*/i.test(original) || access.settings.bot_natural_admin_commands === true;
  if (!commandLike) return null;
  const normalized = lower.replace(/^(bot|rachey)[,:]\s*/i, '').trim();

  if (normalized === '/pausar' || normalized === 'pausar' || /pause o bot|pare o bot/.test(normalized)) {
    await saveGroupSettingsPatch(tables, access, { bot_paused: true, bot_sleep_until: null });
    return '⏸️ Bot pausado. Use /assumir para reativar.';
  }
  if (normalized.startsWith('/dormir') || normalized.startsWith('dormir') || normalized.includes('durma')) {
    const number = Number((normalized.match(/(\d+)/) || [])[1] || 60);
    const hours = /hora|\bh\b/.test(normalized);
    const minutes = Math.max(1, Math.min(10080, hours ? number * 60 : number));
    const until = new Date(Date.now() + minutes * 60000).toISOString();
    await saveGroupSettingsPatch(tables, access, { bot_paused: false, bot_sleep_until: until });
    return `😴 Vou dormir por ${minutes} minuto(s), até ${until}.`;
  }
  if (normalized === '/assumir' || normalized === 'assumir' || /volte|acorde|retome/.test(normalized)) {
    await saveGroupSettingsPatch(tables, access, { bot_paused: false, bot_sleep_until: null });
    return '✅ Voltei a assumir o Grupo Rachey.';
  }
  if (normalized === '/status' || normalized.includes('status do bot')) {
    const contextText = await botBusinessContext(tables, userId, true);
    return `📊 Situação agora:\n${contextText}`.slice(0, 3900);
  }
  if (/mantenha.*grupo.*ativo|mantenha.*grupo.*aberto/.test(normalized)) {
    await saveGroupSettingsPatch(tables, access, { mode: 'todos' });
    const tasks = await listModuleRows(tables, 'bot_task', { status: 'ativa', limit: 100 });
    const exists = (tasks.rows ?? []).some((task) => parseJson(task.data_json).task_type === 'keep_group_active');
    if (!exists) await createBotTask(tables, userId, { type: 'keep_group_active', intervalMinutes: 15, channel: 'geral' });
    return '✅ Vou manter o grupo aberto. A automação verifica isso periodicamente até você mandar /fechar.';
  }
  if (normalized === '/abrir' || /abra o grupo|grupo aberto/.test(normalized)) {
    await saveGroupSettingsPatch(tables, access, { mode: 'todos' });
    return '✅ Grupo aberto para participantes.';
  }
  if (normalized === '/fechar' || /feche o grupo|somente admin/.test(normalized)) {
    await saveGroupSettingsPatch(tables, access, { mode: 'somente_admin' });
    const tasks = await listModuleRows(tables, 'bot_task', { status: 'ativa', limit: 100 });
    for (const task of tasks.rows ?? []) {
      if (parseJson(task.data_json).task_type !== 'keep_group_active') continue;
      await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: task.$id, data: { status: 'pausada', updated_at: new Date().toISOString() } });
    }
    return '🔒 Grupo em modo somente administradores e automação de manter aberto pausada.';
  }

  const moderation = normalized.match(/^\/?(mutar|silenciar|banir|desmutar|dessilenciar|desbanir)\s+@?([a-z0-9._-]+)(?:\s+(\d+))?/i);
  if (moderation) {
    const actionWord = moderation[1].toLowerCase();
    const target = await resolveGroupUser(tables, moderation[2]);
    if (!target) return 'Não encontrei esse participante.';
    const member = await groupMembership(tables, target.id);
    const current = parseJson(member?.data_json);
    const next = { notifications: current.notifications || 'mentions', ...current };
    if (new Set(['mutar', 'silenciar']).has(actionWord)) {
      if (access.settings.bot_can_mute !== true) return 'A permissão “Bot pode mutar” está desativada no painel.';
      const minutes = Math.max(1, Math.min(10080, Number(moderation[3] || 60)));
      next.muted_until = new Date(Date.now() + minutes * 60000).toISOString();
    } else if (new Set(['desmutar', 'dessilenciar']).has(actionWord)) next.muted_until = null;
    else if (actionWord === 'banir') {
      if (access.settings.bot_can_ban !== true) return 'A permissão “Bot pode banir” está desativada no painel.';
      next.banned = true;
    } else if (actionWord === 'desbanir') next.banned = false;
    if (member) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: member.$id, data: { data_json: JSON.stringify(next), updated_at: new Date().toISOString() } });
    else await createGroupRow(tables, { kind: 'group_member', ownerId: target.id, externalKey: `${GROUP_ID}:${target.id}`.slice(0, 128), data: next, visible: false });
    await audit(tables, req, `grupo.bot.comando.${actionWord}`, MODULES_TABLE_ID, member?.$id || null, current, next);
    return `✅ Comando ${actionWord} aplicado a ${target.display || target.name}.`;
  }

  const promo = original.match(/(?:^\/?promo(?:cao|ção)?\s+|(?:envie|mande|publice).*promo(?:cao|ção)?.*?)(?:cada\s+)?(\d+)\s*(min(?:uto)?s?|m|h|hora?s?)\s+(.+)/i);
  if (promo) {
    const n = Math.max(1, Number(promo[1] || 1));
    const interval = /h|hora/i.test(promo[2]) ? n * 60 : n;
    const task = await createBotTask(tables, userId, { type: 'promotion', text: promo[3], intervalMinutes: interval, channel: 'promocoes' });
    return `📣 Promoção agendada a cada ${Math.max(5, interval)} minuto(s). Tarefa ${task.$id.slice(0, 8)}.`;
  }
  if (/^\/?promo(?:cao|ção)?\s+parar|pare.*promo(?:cao|ção)/i.test(original)) {
    const tasks = await listModuleRows(tables, 'bot_task', { status: 'ativa', limit: 100 });
    let stopped = 0;
    for (const task of tasks.rows ?? []) {
      if (parseJson(task.data_json).task_type !== 'promotion') continue;
      await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: task.$id, data: { status: 'pausada', updated_at: new Date().toISOString() } });
      stopped++;
    }
    return `🛑 ${stopped} promoção(ões) recorrente(s) pausada(s).`;
  }

  const pv = original.match(/^\/?pv\s+@?([a-z0-9._-]+)\s+(.+)/i);
  if (pv) {
    const target = await resolveGroupUser(tables, pv[1]);
    if (!target) return 'Não encontrei esse administrador/participante.';
    await createDirectMessageInternal(tables, { senderId: null, targetId: target.id, text: pv[2], senderRole: 'bot', createdBy: userId });
    await notify(tables, target.id, 'Rachey Bot no privado', pv[2], 'sistema');
    return `✉️ Mensagem enviada no privado para ${target.display || target.name}.`;
  }

  if (original.startsWith('/')) return 'Comando não reconhecido. Use /status, /pausar, /dormir 60, /assumir, /abrir, /fechar, /mutar @usuario 60, /banir @usuario, /promo cada 1h texto, /promo parar ou /pv @usuario texto.';
  return null;
}

async function passiveBotResponse(context, text, access) {
  const { tables, userId, isAdmin } = context;
  if (!groupBotAwake(access.settings) || access.settings.bot_passive_observer !== true) return null;
  const cleaned = String(text || '').trim();
  if (!cleaned || cleaned.startsWith('/')) return null;
  const shouldAnswer = isAdmin
    ? /\?|estoque|pagamento|pedido|assinatura|cliente|venda|conta|ticket|suporte/i.test(cleaned)
    : access.settings.bot_auto_reply_clients === true && /\?|estoque|dispon[ií]vel|pagamento|pedido|assinatura|comprei|renov|conta|suporte|quando|como|onde/i.test(cleaned);
  if (!shouldAnswer) return null;
  const [recent, business] = await Promise.all([recentGroupContext(tables, 18), botBusinessContext(tables, userId, isAdmin)]);
  const prompt = isAdmin
    ? `Você está observando o grupo sem precisar ser marcado. Responda ao administrador usando os dados operacionais ao vivo. Não revele credenciais ou segredos. Mensagem: ${cleaned}`
    : `Você está observando o grupo sem precisar ser marcado. Responda apenas se puder ajudar com segurança. Use somente os dados do próprio cliente e estoque público; nunca revele dados de outros clientes. Mensagem: ${cleaned}`;
  const ai = await generateBotAnswer(tables, prompt, `${business}\n\nContexto recente do grupo:\n${recent}`);
  return ai?.text || null;
}

async function botCommandReply({ tables, text, access, userId = null, isAdmin = false }) {
  if (!groupBotAwake(access.settings)) return null;
  const trimmed = String(text || '').trim();
  const lower = trimmed.toLowerCase();
  if (lower === '/ajuda' || lower === '/bot ajuda') {
    return isAdmin ? '🤖 Admin: /status, /pausar, /dormir 60, /assumir, /abrir, /fechar, /mutar @usuario 60, /banir @usuario, /promo cada 1h texto, /promo parar, /pv @usuario texto, /resumir e /bot sua pergunta. Também entendo frases naturais quando habilitado.' : '🤖 Comandos: /regras, /sorteios, /suporte, /resumir e /bot sua pergunta. Você também pode marcar @racheybot.';
  }
  if (lower === '/regras') {
    const custom = String(access.settings.rules_text || '').trim();
    return custom || 'Respeite os participantes, não compartilhe dados sensíveis, evite spam e siga as orientações da equipe Rachey.';
  }
  if (lower === '/suporte') return 'Para atendimento privado, use a área Suporte. Se você marcar @admin ou @admins aqui, posso abrir um chamado automaticamente.';
  if (lower === '/sorteios') {
    const rows = await listModuleRows(tables, 'group_message', { referenceId: GROUP_ID, limit: 100 });
    const raffles = (rows.rows ?? []).map((row) => ({ row, data: parseJson(row.data_json) }))
      .filter((item) => item.data.message_type === 'raffle' && !item.data?.special?.winner_names?.length && !item.data?.special?.winner_name)
      .slice(0, 5);
    if (!raffles.length) return 'Não há sorteios abertos no momento.';
    return `Sorteios abertos:\n${raffles.map((item) => `• ${item.data.text || 'Sorteio'} — ${item.data.special?.prize || 'prêmio'}${item.data.special?.end_at ? ` — encerra ${item.data.special.end_at}` : ''}`).join('\n')}`;
  }
  if (lower === '/resumir') {
    const context = await recentGroupContext(tables, 40);
    const ai = await generateBotAnswer(tables, 'Resuma objetivamente as principais mensagens, decisões, dúvidas e avisos deste grupo em tópicos.', context);
    return ai?.text || 'O resumo por IA está desativado ou sem chaves/modelos válidos no painel administrativo.';
  }
  let prompt = null;
  if (lower.startsWith('/bot ')) prompt = trimmed.slice(5).trim();
  else if (/^@racheybot\b/i.test(trimmed)) prompt = trimmed.replace(/^@racheybot\b[:,]?\s*/i, '').trim();
  if (prompt) {
    const [recentContext, businessContext] = await Promise.all([
      recentGroupContext(tables, 20),
      userId ? botBusinessContext(tables, userId, isAdmin) : Promise.resolve(''),
    ]);
    const privacy = isAdmin
      ? 'Você está falando com um administrador. Pode usar os dados operacionais abaixo, mas nunca revele credenciais, chaves, senhas ou segredos.'
      : 'Você está falando com um cliente. Use somente os dados do próprio cliente e o estoque público. Nunca revele dados de terceiros.';
    const ai = await generateBotAnswer(tables, `${privacy}\nPergunta: ${prompt}`, `${businessContext}\n\nContexto recente do grupo:\n${recentContext}`);
    return ai?.text || 'Não consegui consultar a IA agora. Tente novamente ou use /suporte.';
  }
  return null;
}

async function groupAction(context) {
  const { client, tables, req, body, userId, isAdmin } = context;
  const operation = String(body.operation || 'state');
  if (operation === 'state') return groupState(context);
  const access = await groupAccess(context);
  if (!access.allowed) throw publicError(access.reason, 403, 'group_forbidden');

  const namesFor = async (rows, reactions = []) => groupDisplayNames(tables, [...new Set([
    ...rows.map((row) => row.owner_id).filter(Boolean),
    ...reactions.map((row) => row.owner_id).filter(Boolean),
  ])]);

  if (operation === 'save_member_preferences') {
    const allowed = new Set(['all', 'admins', 'mentions', 'none']);
    const notifications = allowed.has(String(body.notifications)) ? String(body.notifications) : 'mentions';
    const keyValue = `${GROUP_ID}:${userId}`.slice(0, 128);
    const existing = await firstModule(tables, 'group_member', { externalKey: keyValue });
    const current = parseJson(existing?.data_json);
    const next = { ...current, notifications };
    const saved = existing
      ? await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: existing.$id, data: { data_json: JSON.stringify(next), updated_at: new Date().toISOString() } })
      : await createGroupRow(tables, { kind: 'group_member', ownerId: userId, externalKey: keyValue, data: next, visible: false });
    return { $id: saved.$id, notifications };
  }

  if (operation === 'send') {
    if (!access.canSend) throw publicError(access.reason || 'O envio está desativado.', 403, 'group_read_only');
    const text = String(body.text || '').trim().slice(0, 4000);
    const attachment = validateGroupAttachment(access.settings, body.attachment);
    if (!text && !attachment) throw publicError('A mensagem está vazia.');
    if (!isAdmin && /(^|\s)@todos\b/i.test(text)) throw publicError('Somente administradores podem usar @todos.', 403, 'everyone_forbidden');
    if (!isAdmin && access.settings.allow_links === false && /https?:\/\/|www\./i.test(text)) throw publicError('Links estão bloqueados neste grupo.', 403, 'links_disabled');

    const blockedTerms = Array.isArray(access.settings.bot_blocked_terms)
      ? access.settings.bot_blocked_terms.map((term) => String(term).trim().toLowerCase()).filter(Boolean)
      : [];
    const blocked = !isAdmin && groupBotAwake(access.settings)
      ? blockedTerms.find((term) => text.toLowerCase().includes(term))
      : null;
    if (blocked && access.settings.bot_can_delete !== false && access.settings.bot_auto_delete !== false) {
      const keyValue = `${GROUP_ID}:${userId}`.slice(0, 128);
      const member = await firstModule(tables, 'group_member', { externalKey: keyValue });
      const memberState = parseJson(member?.data_json);
      const strikes = Math.max(0, Number(memberState.bot_strikes || 0)) + 1;
      const nextMember = { ...memberState, bot_strikes: strikes, last_bot_violation_at: new Date().toISOString() };
      const banAfter = Math.max(2, Number(access.settings.bot_ban_after || 5));
      const muteAfter = Math.max(1, Number(access.settings.bot_mute_after || 3));
      if (access.settings.bot_can_ban === true && access.settings.bot_auto_ban === true && strikes >= banAfter) nextMember.banned = true;
      else if (access.settings.bot_can_mute === true && access.settings.bot_auto_mute !== false && strikes >= muteAfter) nextMember.muted_until = new Date(Date.now() + 60 * 60000).toISOString();
      if (member) {
        await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: member.$id, data: { data_json: JSON.stringify(nextMember), updated_at: new Date().toISOString() } });
      } else {
        await createGroupRow(tables, { kind: 'group_member', ownerId: userId, externalKey: keyValue, data: nextMember, visible: false });
      }
      const botAction = nextMember.banned === true ? ' Seu acesso ao grupo foi bloqueado.' : (nextMember.muted_until ? ' Você foi silenciado por 1 hora.' : '');
      await notify(tables, userId, 'Mensagem bloqueada pelo Rachey Bot', `A mensagem continha conteúdo não autorizado.${botAction}`, 'grupo');
      if (access.settings.bot_alert_admin !== false) {
        const alertText = `O bot bloqueou uma mensagem por conter “${blocked}”.`;
        await notifyAdmins(client, tables, 'Moderação automática no grupo', alertText, 'grupo_admin');
        await botPrivateAlert(tables, access.settings, alertText);
      }
      await audit(tables, req, 'grupo.bot.bloquear', MODULES_TABLE_ID, null, null, { blocked_term: blocked, strikes });
      return { status: 'removida_bot', deleted: true, message: 'Mensagem bloqueada pelo Rachey Bot.' };
    }

    const slowSeconds = Math.max(0, Math.min(3600, Math.round(Number(access.settings.slow_mode_seconds || 0))));
    if (!isAdmin && slowSeconds > 0) {
      const previous = await listModuleRows(tables, 'group_message', { ownerId: userId, referenceId: GROUP_ID, limit: 100 });
      const latest = (previous.rows ?? []).sort((a, b) => String(b.$createdAt).localeCompare(String(a.$createdAt)))[0];
      const remaining = latest ? slowSeconds - Math.floor((Date.now() - new Date(latest.$createdAt).getTime()) / 1000) : 0;
      if (remaining > 0) throw publicError(`Aguarde ${remaining}s para enviar outra mensagem.`, 429, 'slow_mode');
    }
    if (attachment) {
      const metadata = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.fileMetadata, queries: [Query.equal('file_id', attachment.file_id), Query.limit(1)], total: false, ttl: 0 });
      const fileRow = metadata.rows?.[0];
      if (!fileRow || fileRow.tipo !== attachment.type || (!isAdmin && fileRow.user_id !== userId)) throw publicError('Arquivo não autorizado.', 403, 'file_forbidden');
      const retention = Math.max(1, Math.min(30, Math.round(Number(access.settings.media_retention_days || 7))));
      attachment.expires_at = new Date(Date.now() + retention * 86400000).toISOString();
    }
    const status = !isAdmin && access.settings.mode === 'aprovacao' ? 'pendente' : 'publicado';
    const senderName = isAdmin ? 'Equipe Rachey' : (access.identity?.display || String(body.sender_name || 'Membro').slice(0, 100));
    const saved = await createGroupRow(tables, {
      kind: 'group_message', ownerId: userId, status,
      data: { text, sender_name: senderName, sender_role: isAdmin ? 'admin' : 'cliente', sender_photo_id: access.identity?.photo_id || null, reply_to: body.reply_to ? String(body.reply_to).slice(0, 36) : null, attachment, pinned: false, edited: false, channel: String(body.channel || 'geral').slice(0, 24), message_type: 'message' },
    });
    const mentioned = [...text.matchAll(/@([a-zA-Z0-9._-]{2,32})/g)].map((match) => match[1]);
    const everyone = isAdmin && /(^|\s)@todos\b/i.test(text);
    if (everyone) {
      await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: true, title: 'Grupo Rachey • @todos', message: text || 'A administração marcou todos no grupo.', forceAll: true });
    } else {
      await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: isAdmin, title: isAdmin ? 'Nova mensagem da equipe' : 'Nova mensagem no grupo', message: text || 'Nova mídia no grupo.', mentionedUsernames: mentioned });
    }
    let botReply = null;
    if (isAdmin) botReply = await executeAdminBotCommand(context, text, access);
    if (!botReply) botReply = await botCommandReply({ tables, text, access, userId, isAdmin });
    if (!botReply) botReply = await passiveBotResponse(context, text, access);
    if (botReply) {
      await createGroupRow(tables, {
        kind: 'group_message', ownerId: null, status: 'publicado',
        data: { text: botReply, sender_name: 'Rachey Bot', sender_role: 'bot', reply_to: saved.$id, attachment: null, pinned: false, edited: false, channel: String(body.channel || 'geral').slice(0, 24), message_type: 'message' },
      });
    }

    if (!isAdmin && /(^|\s)@admins?\b/i.test(text)) {
      let createdTicket = null;
      if (access.settings.bot_enabled === true && access.settings.bot_create_ticket_on_admin_mention !== false) {
        createdTicket = await createTicket({
          client,
          tables,
          req,
          body: {
            title: 'Solicitação pelo Grupo Rachey',
            priority: 'normal',
            category: 'grupo',
            description: text,
            group_message_id: saved.$id,
          },
          userId,
        });
      } else if (access.settings.bot_alert_admin !== false) {
        const alertText = `${senderName}: ${text}`;
        await notifyAdmins(client, tables, 'Você foi marcado no Grupo Rachey', alertText, 'grupo_admin');
        await botPrivateAlert(tables, access.settings, `Marcação no grupo: ${alertText}`);
      }
      if (access.settings.bot_enabled === true && access.settings.bot_reply_admin_mention !== false) {
        const ticketText = createdTicket?.$id ? ` Ticket ${createdTicket.$id.slice(0, 8)} aberto.` : '';
        await createGroupRow(tables, {
          kind: 'group_message', ownerId: null, status: 'publicado',
          data: { text: `Recebi sua marcação. A equipe foi avisada.${ticketText}`, sender_name: 'Rachey Bot', sender_role: 'bot', reply_to: saved.$id, attachment: null, pinned: false, edited: false, channel: 'suporte', message_type: 'message' },
        });
      }
    }
    await audit(tables, req, 'grupo.mensagem.enviar', MODULES_TABLE_ID, saved.$id, null, { status, attachment_type: attachment?.type || null, everyone });
    const names = await groupDisplayNames(tables, [userId]);
    const photos = await groupDisplayPhotos(tables, [userId]);
    return groupMessageView(saved, names, [], userId, photos);
  }

  if (operation === 'create_poll') {
    if (!isAdmin) throw publicError('Somente administradores podem criar enquetes.', 403, 'forbidden');
    const question = String(body.question || '').trim().slice(0, 300);
    const options = (Array.isArray(body.options) ? body.options : [])
      .map((item) => String(item).trim().slice(0, 120)).filter(Boolean).slice(0, 8);
    if (!question || options.length < 2) throw publicError('Informe uma pergunta e pelo menos duas opções.');
    const pollEnd = body.end_at ? new Date(body.end_at) : null;
    if (pollEnd && (!Number.isFinite(pollEnd.getTime()) || pollEnd.getTime() <= Date.now())) throw publicError('Informe um encerramento futuro para a enquete.');
    const saved = await createGroupRow(tables, { kind: 'group_message', ownerId: userId, status: 'publicado', data: { text: question, sender_name: 'Equipe Rachey', sender_role: 'admin', attachment: null, pinned: false, edited: false, channel: 'geral', message_type: 'poll', special: { options, end_at: pollEnd ? pollEnd.toISOString() : null } } });
    await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: true, title: 'Nova enquete no Grupo Rachey', message: question });
    return groupMessageView(saved, new Map(), [], userId);
  }

  if (operation === 'poll_vote') {
    const rowId = String(body.row_id || '').slice(0, 36);
    const message = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId });
    const data = parseJson(message.data_json);
    if (message.kind !== 'group_message' || data.message_type !== 'poll') throw publicError('Enquete não encontrada.', 404, 'not_found');
    const options = Array.isArray(data.special?.options) ? data.special.options : [];
    if (data.special?.end_at && new Date(data.special.end_at).getTime() <= Date.now()) throw publicError('Esta enquete foi encerrada.', 409, 'poll_closed');
    const option = Math.round(Number(body.option));
    if (!Number.isInteger(option) || option < 0 || option >= options.length) throw publicError('Opção inválida.');
    const keyValue = `poll:${rowId}:${userId}`.slice(0, 128);
    const existing = await firstModule(tables, 'group_reaction', { externalKey: keyValue });
    if (existing) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: existing.$id, data: { data_json: JSON.stringify({ kind: 'poll_vote', option }), updated_at: new Date().toISOString() } });
    else await createGroupRow(tables, { kind: 'group_reaction', ownerId: userId, referenceId: rowId, externalKey: keyValue, data: { kind: 'poll_vote', option } });
    return { voted: true, option };
  }

  if (operation === 'create_question') {
    if (!isAdmin) throw publicError('Somente administradores podem criar perguntas.', 403, 'forbidden');
    const question = String(body.question || '').trim().slice(0, 1000);
    if (!question) throw publicError('Informe a pergunta.');
    const saved = await createGroupRow(tables, { kind: 'group_message', ownerId: userId, status: 'publicado', data: { text: question, sender_name: 'Equipe Rachey', sender_role: 'admin', attachment: null, pinned: false, edited: false, channel: 'suporte', message_type: 'question', special: { question } } });
    await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: true, title: 'Nova pergunta no Grupo Rachey', message: question });
    return groupMessageView(saved, new Map(), [], userId);
  }

  if (operation === 'create_raffle') {
    if (!isAdmin) throw publicError('Somente administradores podem criar sorteios.', 403, 'forbidden');
    const title = String(body.title || 'Sorteio Rachey').trim().slice(0, 200);
    const prize = String(body.prize || '').trim().slice(0, 500);
    const endDate = body.end_at ? new Date(body.end_at) : null;
    if (!prize) throw publicError('Informe o prêmio do sorteio.');
    if (!endDate || !Number.isFinite(endDate.getTime()) || endDate.getTime() <= Date.now()) throw publicError('Selecione uma data e hora futuras para encerrar o sorteio.');
    const endAt = endDate.toISOString();
    const winnersCount = Math.max(1, Math.min(10, Math.round(Number(body.winners_count || 1))));
    const eligibility = {
      active_subscription_only: body.active_subscription_only === true,
      service_id: String(body.service_id || '').trim().slice(0, 36) || null,
      min_active_days: Math.max(0, Math.min(3650, Math.round(Number(body.min_active_days || 0)))),
    };
    const saved = await createGroupRow(tables, { kind: 'group_message', ownerId: userId, status: 'publicado', data: { text: title, sender_name: 'Equipe Rachey', sender_role: 'admin', attachment: null, pinned: false, edited: false, channel: 'sorteios', message_type: 'raffle', special: { title, prize, end_at: endAt, winners_count: winnersCount, winner_user_id: null, winner_user_ids: [], drawn_at: null, eligibility } } });
    await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: true, title: 'Novo sorteio no Grupo Rachey', message: `${title}: ${prize}` });
    return groupMessageView(saved, new Map(), [], userId);
  }

  if (operation === 'raffle_join') {
    const rowId = String(body.row_id || '').slice(0, 36);
    const message = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId });
    const data = parseJson(message.data_json);
    if (message.kind !== 'group_message' || data.message_type !== 'raffle') throw publicError('Sorteio não encontrado.', 404, 'not_found');
    if (data.special?.winner_user_id || (Array.isArray(data.special?.winner_user_ids) && data.special.winner_user_ids.length)) throw publicError('Este sorteio já foi encerrado.');
    if (data.special?.end_at && new Date(data.special.end_at).getTime() < Date.now()) throw publicError('As participações deste sorteio foram encerradas.');
    const eligibility = data.special?.eligibility || {};
    if (eligibility.active_subscription_only === true || eligibility.service_id || Number(eligibility.min_active_days || 0) > 0) {
      const queries = [Query.equal('user_id', userId), Query.limit(200)];
      const owned = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, queries, total: false, ttl: 0 });
      const now = Date.now();
      const minActiveDays = Math.max(0, Number(eligibility.min_active_days || 0));
      const eligible = (owned.rows ?? []).some((subscription) => {
        if (eligibility.service_id && subscription.servico_id !== eligibility.service_id) return false;
        if (eligibility.active_subscription_only === true && subscription.status !== 'ativa') return false;
        const due = new Date(subscription.data_vencimento).getTime();
        if (eligibility.active_subscription_only === true && (!Number.isFinite(due) || due < now)) return false;
        if (minActiveDays > 0) {
          const start = new Date(subscription.data_inicio).getTime();
          if (!Number.isFinite(start) || Math.floor((now - start) / 86400000) < minActiveDays) return false;
        }
        return true;
      });
      if (!eligible) throw publicError('Sua conta ainda não atende às regras deste sorteio.', 403, 'raffle_not_eligible');
    }
    const keyValue = `raffle:${rowId}:${userId}`.slice(0, 128);
    const existing = await firstModule(tables, 'group_reaction', { externalKey: keyValue });
    if (!existing) await createGroupRow(tables, { kind: 'group_reaction', ownerId: userId, referenceId: rowId, externalKey: keyValue, data: { kind: 'raffle_entry' } });
    return { joined: true };
  }

  if (operation === 'raffle_draw') {
    if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
    const rowId = String(body.row_id || '').slice(0, 36);
    const message = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId });
    const data = parseJson(message.data_json);
    if (message.kind !== 'group_message' || data.message_type !== 'raffle') throw publicError('Sorteio não encontrado.', 404, 'not_found');
    if (data.special?.winner_user_id || (Array.isArray(data.special?.winner_user_ids) && data.special.winner_user_ids.length)) throw publicError('Este sorteio já foi realizado.');
    if (data.special?.end_at && new Date(data.special.end_at).getTime() > Date.now()) throw publicError('O sorteio só pode ser realizado após o encerramento.');
    const reactions = await listModuleRows(tables, 'group_reaction', { referenceId: rowId, limit: 500 });
    const entries = (reactions.rows ?? []).filter((row) => parseJson(row.data_json).kind === 'raffle_entry');
    if (!entries.length) throw publicError('Ainda não há participantes.');
    const candidates = [...new Set(entries.map((entry) => entry.owner_id).filter(Boolean))];
    const count = Math.min(candidates.length, Math.max(1, Math.min(10, Math.round(Number(data.special?.winners_count || 1)))));
    const winners = [];
    while (winners.length < count && candidates.length) winners.push(candidates.splice(crypto.randomInt(candidates.length), 1)[0]);
    const special = { ...(data.special || {}), winner_user_id: winners[0] || null, winner_user_ids: winners, drawn_at: new Date().toISOString() };
    const saved = await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId, data: { data_json: JSON.stringify({ ...data, special }), updated_at: new Date().toISOString() } });
    for (const winner of winners) await notify(tables, winner, 'Você ganhou um sorteio no Grupo Rachey', String(special.prize || 'Confira o resultado no grupo.'), 'grupo');
    await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: true, title: 'Resultado do sorteio', message: `${special.title || 'Sorteio Rachey'} teve ${winners.length} vencedor(es). Confira no grupo.` });
    const names = await groupDisplayNames(tables, [...winners, userId]);
    return groupMessageView(saved, names, reactions.rows ?? [], userId);
  }


  if (operation === 'create_announcement') {
    if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
    const title = String(body.title || 'Aviso da equipe').trim().slice(0, 200);
    const messageText = String(body.message || '').trim().slice(0, 3000);
    if (!messageText) throw publicError('Informe o conteúdo do aviso.');
    const saved = await createGroupRow(tables, { kind: 'group_message', ownerId: userId, status: 'publicado', data: { text: title, sender_name: 'Equipe Rachey', sender_role: 'admin', attachment: null, pinned: body.pinned !== false, edited: false, channel: 'avisos', message_type: 'announcement', special: { title, message: messageText, priority: String(body.priority || 'normal').slice(0, 20) } } });
    await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: true, title, message: messageText, forceAll: body.notify_all === true });
    return groupMessageView(saved, new Map(), [], userId);
  }

  if (operation === 'create_event') {
    if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
    const title = String(body.title || '').trim().slice(0, 200);
    const start = new Date(body.starts_at || '');
    const end = body.ends_at ? new Date(body.ends_at) : null;
    if (!title || !Number.isFinite(start.getTime())) throw publicError('Informe o título e a data/hora do evento.');
    if (end && (!Number.isFinite(end.getTime()) || end.getTime() <= start.getTime())) throw publicError('O término do evento deve ser posterior ao início.');
    const description = String(body.description || '').trim().slice(0, 2500);
    const location = String(body.location || '').trim().slice(0, 300);
    const saved = await createGroupRow(tables, { kind: 'group_message', ownerId: userId, status: 'publicado', data: { text: title, sender_name: 'Equipe Rachey', sender_role: 'admin', attachment: null, pinned: false, edited: false, channel: 'avisos', message_type: 'event', special: { title, description, location, starts_at: start.toISOString(), ends_at: end ? end.toISOString() : null } } });
    await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: true, title: `Evento: ${title}`, message: description || `Começa em ${start.toISOString()}`, forceAll: body.notify_all === true });
    return groupMessageView(saved, new Map(), [], userId);
  }

  if (operation === 'publish_coupon') {
    if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
    const code = String(body.code || '').trim().toUpperCase().slice(0, 64);
    if (!code) throw publicError('Cupom inválido.');
    const description = String(body.description || `Novo cupom: ${code}`).trim().slice(0, 1000);
    const saved = await createGroupRow(tables, { kind: 'group_message', ownerId: userId, status: 'publicado', data: { text: description, sender_name: 'Equipe Rachey', sender_role: 'admin', attachment: null, pinned: false, edited: false, channel: 'promocoes', message_type: 'coupon', special: { code, description, percent: body.percent ?? null, value_cents: body.value_cents ?? null, due_at: body.due_at ?? null } } });
    if (body.notify_all === true) await notifyGroupAudience({ client, tables, senderUserId: userId, senderIsAdmin: true, title: `Novo cupom ${code}`, message: description, forceAll: true });
    return groupMessageView(saved, new Map(), [], userId);
  }

  const rowId = String(body.row_id || body.rowId || '').slice(0, 36);
  if (new Set(['edit', 'delete', 'pin', 'approve', 'react', 'report']).has(operation) && !rowId) throw publicError('Mensagem obrigatória.');
  let message = null;
  if (rowId) {
    message = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId });
    if (message.kind !== 'group_message' || message.reference_id !== GROUP_ID) throw publicError('Mensagem não encontrada.', 404, 'not_found');
  }

  if (operation === 'edit') {
    if (!isAdmin && message.owner_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
    const current = parseJson(message.data_json);
    const text = String(body.text || '').trim().slice(0, 4000);
    if (!text && !current.attachment) throw publicError('A mensagem não pode ficar vazia.');
    const saved = await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId, data: { data_json: JSON.stringify({ ...current, text, edited: true }), updated_at: new Date().toISOString() } });
    const names = await groupDisplayNames(tables, [message.owner_id]);
    return groupMessageView(saved, names, [], userId);
  }
  if (operation === 'delete') {
    if (!isAdmin && message.owner_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
    const attachment = parseJson(message.data_json).attachment;
    if (attachment?.file_id) {
      const found = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.fileMetadata, queries: [Query.equal('file_id', attachment.file_id), Query.limit(1)], total: false, ttl: 0 });
      try { await new Storage(client).deleteFile({ bucketId: BUCKET_ID, fileId: attachment.file_id }); } catch (cause) { if (Number(cause?.code) !== 404) throw cause; }
      if (found.rows?.[0]) await tables.deleteRow({ databaseId: DATABASE_ID, tableId: TABLES.fileMetadata, rowId: found.rows[0].$id });
    }
    await tables.deleteRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId });
    await audit(tables, req, 'grupo.mensagem.excluir', MODULES_TABLE_ID, rowId, message, null);
    return { $id: rowId, deleted: true };
  }
  if (operation === 'pin' || operation === 'approve') {
    if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
    const current = parseJson(message.data_json);
    const data = operation === 'pin'
      ? { data_json: JSON.stringify({ ...current, pinned: body.pinned !== false }), updated_at: new Date().toISOString() }
      : { status: 'publicado', updated_at: new Date().toISOString() };
    const saved = await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId, data });
    const names = await groupDisplayNames(tables, [message.owner_id]);
    return groupMessageView(saved, names, [], userId);
  }
  if (operation === 'react') {
    const emoji = String(body.emoji || '👍').slice(0, 8);
    const keyValue = `emoji:${rowId}:${userId}`.slice(0, 128);
    const existing = await firstModule(tables, 'group_reaction', { externalKey: keyValue });
    if (existing && parseJson(existing.data_json).emoji === emoji) {
      await tables.deleteRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: existing.$id });
      return { removed: true };
    }
    if (existing) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: existing.$id, data: { data_json: JSON.stringify({ kind: 'emoji', emoji }), updated_at: new Date().toISOString() } });
    else await createGroupRow(tables, { kind: 'group_reaction', ownerId: userId, referenceId: rowId, externalKey: keyValue, data: { kind: 'emoji', emoji } });
    return { emoji };
  }
  if (operation === 'report') {
    const saved = await createGroupRow(tables, { kind: 'group_report', ownerId: userId, referenceId: rowId, status: 'aberta', data: { reason: String(body.reason || 'Conteúdo inadequado').slice(0, 1000), target_user_id: message.owner_id }, visible: false });
    await notifyAdmins(client, tables, 'Nova denúncia no Grupo Rachey', 'Há uma mensagem denunciada aguardando análise.', 'grupo_admin');
    return { reported: true, report_id: saved.$id };
  }
  if (operation === 'save_settings') {
    if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
    const allowedModes = new Set(['todos', 'somente_admin', 'aprovacao', 'fechado']);
    const blockedTerms = Array.isArray(body.bot_blocked_terms)
      ? body.bot_blocked_terms.map((item) => String(item).trim().slice(0, 80)).filter(Boolean).slice(0, 100)
      : access.settings.bot_blocked_terms;
    const next = {
      ...access.settings,
      name: String(body.name || access.settings.name).slice(0, 100),
      description: String(body.description ?? access.settings.description).slice(0, 1000),
      image_file_id: body.image_file_id === null ? null : String(body.image_file_id || access.settings.image_file_id || '').slice(0, 36) || null,
      mode: allowedModes.has(String(body.mode)) ? String(body.mode) : access.settings.mode,
      active_subscribers_only: false,
      slow_mode_seconds: Math.max(0, Math.min(3600, Math.round(Number(body.slow_mode_seconds || 0)))),
      media_retention_days: Math.max(1, Math.min(30, Math.round(Number(body.media_retention_days || 7)))),
      allow_links: body.allow_links !== false,
      allow_images: body.allow_images !== false,
      allow_videos: body.allow_videos !== false,
      allow_audio: body.allow_audio !== false,
      allow_documents: body.allow_documents !== false,
      announce_subscriptions: body.announce_subscriptions === true,
      renewal_reminders: body.renewal_reminders === true,
      bot_enabled: body.bot_enabled === true,
      bot_auto_delete: body.bot_auto_delete !== false,
      bot_reply_admin_mention: body.bot_reply_admin_mention !== false,
      bot_alert_admin: body.bot_alert_admin !== false,
      bot_create_ticket_on_admin_mention: body.bot_create_ticket_on_admin_mention !== false,
      bot_auto_mute: body.bot_auto_mute !== false,
      bot_auto_ban: body.bot_auto_ban === true,
      bot_mute_after: Math.max(1, Math.min(20, Math.round(Number(body.bot_mute_after || 3)))),
      bot_ban_after: Math.max(2, Math.min(50, Math.round(Number(body.bot_ban_after || 5)))),
      bot_blocked_terms: blockedTerms || [],
      bot_passive_observer: body.bot_passive_observer !== false,
      bot_auto_reply_clients: body.bot_auto_reply_clients !== false,
      bot_ai_moderation: body.bot_ai_moderation === true,
      bot_can_mute: body.bot_can_mute === true,
      bot_can_ban: body.bot_can_ban === true,
      bot_can_delete: body.bot_can_delete !== false,
      bot_admin_commands: body.bot_admin_commands !== false,
      bot_natural_admin_commands: body.bot_natural_admin_commands !== false,
      bot_paused: body.bot_paused === true,
      bot_sleep_until: body.bot_sleep_until ? String(body.bot_sleep_until).slice(0, 40) : null,
      bot_private_admin_ids: Array.isArray(body.bot_private_admin_ids)
        ? [...new Set(body.bot_private_admin_ids.map((value) => String(value).slice(0, 36)).filter(Boolean))].slice(0, 20)
        : (Array.isArray(access.settings.bot_private_admin_ids) ? access.settings.bot_private_admin_ids : []),
      allow_member_dm: body.allow_member_dm !== false,
      allow_client_admin_dm: body.allow_client_admin_dm !== false,
      rules_text: String(body.rules_text ?? access.settings.rules_text ?? '').slice(0, 4000),
    };
    const saved = await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: access.row.$id, data: { title: next.name, data_json: JSON.stringify(next), updated_at: new Date().toISOString() } });
    await audit(tables, req, 'grupo.configuracao.alterar', MODULES_TABLE_ID, saved.$id, access.settings, next);
    return next;
  }
  if (operation === 'moderate_member') {
    if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
    const target = String(body.target_user_id || '').slice(0, 36);
    if (!target || target === userId) throw publicError('Membro inválido.');
    const keyValue = `${GROUP_ID}:${target}`.slice(0, 128);
    const existing = await firstModule(tables, 'group_member', { externalKey: keyValue });
    const current = parseJson(existing?.data_json);
    const action = String(body.moderation || 'mute');
    const next = { notifications: current.notifications || 'mentions', ...current };
    if (action === 'ban') next.banned = true;
    if (action === 'unban') next.banned = false;
    if (action === 'mute') next.muted_until = new Date(Date.now() + Math.max(1, Math.min(10080, Number(body.minutes || 60))) * 60000).toISOString();
    if (action === 'unmute') next.muted_until = null;
    const saved = existing
      ? await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: existing.$id, data: { data_json: JSON.stringify(next), updated_at: new Date().toISOString() } })
      : await createGroupRow(tables, { kind: 'group_member', ownerId: target, externalKey: keyValue, data: next, visible: false });
    await notify(tables, target, action === 'ban' ? 'Acesso ao grupo bloqueado' : 'Moderação do Grupo Rachey', action === 'ban' ? 'A administração bloqueou seu acesso ao grupo.' : 'Sua permissão no grupo foi atualizada.', 'grupo');
    await audit(tables, req, `grupo.membro.${action}`, MODULES_TABLE_ID, saved.$id, current, next);
    return { target_user_id: target, ...next };
  }
  throw publicError('Ação do grupo inválida.');
}

async function collectTableRows(tables, tableId, filters = []) {
  const rows = [];
  let cursor = null;
  for (;;) {
    const queries = [...filters, Query.limit(100)];
    if (cursor) queries.push(Query.cursorAfter(cursor));
    const page = await tables.listRows({
      databaseId: DATABASE_ID,
      tableId,
      queries,
      total: false,
      ttl: 0,
    });
    const batch = page.rows ?? [];
    rows.push(...batch);
    if (batch.length < 100) break;
    cursor = batch[batch.length - 1].$id;
  }
  return rows;
}

async function setClientActive({ tables, req, body, userId: actorId }) {
  const target = String(body.user_id || '').trim().slice(0, 36);
  if (!target || target === actorId) throw publicError('Cliente inválido.');
  const rows = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.profiles, queries: [Query.equal('user_id', target), Query.limit(1)], total: false, ttl: 0 });
  const profile = rows.rows?.[0];
  if (!profile) throw publicError('Cliente não encontrado.', 404, 'not_found');
  const active = body.active === true;
  const reason = String(body.reason || '').trim().slice(0, 500);
  if (!active && reason.length < 3) throw publicError('Informe o motivo da desativação.');
  const saved = await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.profiles, rowId: profile.$id, data: { ativo: active } });
  const meta = await firstModule(tables, 'profile_meta', { ownerId: target });
  if (meta) await tables.updateRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: meta.$id, data: { status: active ? 'ativo' : 'desativado', updated_at: new Date().toISOString(), data_json: JSON.stringify({ ...parseJson(meta.data_json), disabled_reason: active ? null : reason, disabled_at: active ? null : new Date().toISOString() }) } });
  if (active) await notify(tables, target, 'Conta reativada', 'Seu acesso ao Rachey foi reativado.', 'conta');
  await audit(tables, req, active ? 'cliente.reativar' : 'cliente.desativar', TABLES.profiles, profile.$id, { ativo: profile.ativo }, { ativo: active, reason });
  return { user_id: target, active: saved.ativo !== false };
}

async function deleteClient({ client, tables, users, req, body, userId: actorId }) {
  const target = String(body.user_id || body.client_id || '').trim().slice(0, 36);
  if (!target || target === actorId) throw publicError('Cliente inválido.');
  const deletionReason = String(body.reason || '').trim().slice(0, 500);
  const profileRows = await collectTableRows(tables, TABLES.profiles, [Query.equal('user_id', target)]);
  const profile = profileRows[0] || null;
  const storage = new Storage(client);

  const fileRows = await collectTableRows(tables, TABLES.fileMetadata, [Query.equal('user_id', target)]);
  for (const file of fileRows) {
    try { await storage.deleteFile({ bucketId: BUCKET_ID, fileId: file.file_id }); }
    catch (cause) { if (Number(cause?.code) !== 404) throw cause; }
  }

  const ownedTables = [
    [TABLES.carts, 'user_id'], [TABLES.cartItems, 'user_id'], [TABLES.orders, 'user_id'],
    [TABLES.orderItems, 'user_id'], [TABLES.subscriptions, 'user_id'], [TABLES.renewals, 'user_id'],
    [TABLES.payments, 'user_id'], [TABLES.notifications, 'user_id'], [TABLES.fileMetadata, 'user_id'],
    [TABLES.credentials, 'cliente_id'],
  ];
  for (const [tableId, field] of ownedTables) {
    try {
      const rows = await collectTableRows(tables, tableId, [Query.equal(field, target)]);
      for (const row of rows) await tables.deleteRow({ databaseId: DATABASE_ID, tableId, rowId: row.$id });
    } catch (cause) {
      if (Number(cause?.code) !== 404) throw cause;
    }
  }

  // A tabela mensagens existiu em versões com schemas diferentes. Lista tudo
  // com cursor e filtra em memória para não depender de uma coluna específica.
  try {
    const messages = await collectTableRows(tables, TABLES.messages);
    for (const row of messages) {
      if ([row.user_id, row.cliente_id, row.remetente_id, row.destinatario_id].some((value) => value === target)) {
        await tables.deleteRow({ databaseId: DATABASE_ID, tableId: TABLES.messages, rowId: row.$id });
      }
    }
  } catch (cause) { if (Number(cause?.code) !== 404) throw cause; }

  // Não apaga vagas de estoque pertencentes ao cliente: libera-as para que
  // voltem ao estoque. Os demais módulos do usuário são removidos.
  const modules = await collectTableRows(tables, MODULES_TABLE_ID, [Query.equal('owner_id', target)]);
  for (const row of modules) {
    if (row.kind === 'inventory_slot') {
      const data = parseJson(row.data_json);
      delete data.intent_id;
      delete data.order_id;
      delete data.subscription_id;
      delete data.reserved_at;
      delete data.reserved_until;
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: MODULES_TABLE_ID,
        rowId: row.$id,
        data: {
          owner_id: null,
          status: 'livre',
          updated_at: new Date().toISOString(),
          data_json: JSON.stringify({ ...data, released_at: new Date().toISOString(), release_reason: 'client_deleted' }),
        },
        permissions: modulePermissions(null),
      });
      continue;
    }
    await tables.deleteRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: row.$id });
  }
  for (const row of profileRows) await tables.deleteRow({ databaseId: DATABASE_ID, tableId: TABLES.profiles, rowId: row.$id });
  await users.delete({ userId: target });
  await audit(tables, req, 'cliente.excluir_completo', TABLES.profiles, profile?.$id || null, { user_id: target, email: profile?.email || null }, { deleted: true, reason: deletionReason || null });
  return { user_id: target, deleted: true };
}

async function approveWaitlist({ tables, req, body, userId }) {
  const row = await tables.getRow({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID, rowId: String(body.row_id || '') });
  if (row.kind !== 'waitlist') throw publicError('Solicitação de fila inválida.');
  const free = await availableSlot(tables, row.reference_id);
  const status = free ? 'aprovada' : 'aprovada_aguardando_vaga';
  const saved = await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: row.$id,
    data: {
      status,
      updated_at: new Date().toISOString(),
      data_json: JSON.stringify({ ...parseJson(row.data_json), approved_at: new Date().toISOString(), approved_by: userId }),
    },
  });
  await notify(
    tables,
    row.owner_id,
    free ? 'Vaga aprovada' : 'Solicitação aprovada',
    free ? `${row.title || 'O serviço'} já possui vaga. Volte ao catálogo para concluir a compra.` : 'Sua solicitação foi aprovada e será liberada quando surgir uma vaga.',
    'estoque',
  );
  await audit(tables, req, 'lista_espera.aprovar', MODULES_TABLE_ID, row.$id, row, saved);
  return serializeModule(saved);
}

async function broadcastNotification({ tables, req, body }) {
  const title = String(body.title || '').trim().slice(0, 150);
  const message = String(body.message || '').trim().slice(0, 2000);
  if (!title || !message) throw publicError('Informe título e mensagem.');
  let userIds = [];
  if (body.all === true) {
    const profiles = await tableRows(tables, TABLES.profiles, [], 500);
    userIds = [...new Set((profiles.rows ?? []).map((row) => row.user_id).filter(Boolean))];
  } else if (body.user_id) {
    userIds = [String(body.user_id)];
  }
  if (!userIds.length) throw publicError('Nenhum destinatário encontrado.');
  let sent = 0;
  for (const target of userIds) {
    await notify(tables, target, title, message, String(body.type || 'sistema').slice(0, 50));
    sent++;
  }
  await audit(tables, req, 'notificacao.enviar', TABLES.notifications, null, null, { sent, type: body.type, all: body.all === true });
  return { sent };
}

async function updateOrder({ tables, req, body, userId }) {
  const orderId = String(body.order_id || '');
  const order = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.orders, rowId: orderId });
  const status = String(body.status || order.status).slice(0, 64);
  const saved = await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.orders,
    rowId: orderId,
    data: { status, observacoes_admin: body.notes ? String(body.notes).slice(0, 2000) : order.observacoes_admin },
  });
  const titles = {
    em_processamento: 'Preparação iniciada',
    conta_criada: 'Conta criada',
    credenciais_enviadas: 'Credenciais enviadas',
    assinatura_ativa: 'Assinatura ativa',
    renovado: 'Renovação registrada',
    concluido: 'Pedido concluído',
    cancelado: 'Pedido cancelado',
  };
  await createModuleDirect(tables, {
    kind: 'order_timeline',
    reference_id: orderId,
    title: titles[status] || `Status: ${status.replaceAll('_', ' ')}`,
    status: 'concluido',
    sort_order: Math.round(Number(body.sort_order || Date.now() / 1000000)),
    data: { event: status, notes: body.notes || null, at: new Date().toISOString() },
    created_by: userId,
  }, order.user_id);
  await notify(tables, order.user_id, 'Pedido atualizado', `${order.numero}: ${titles[status] || status.replaceAll('_', ' ')}.`, 'pedido');
  await audit(tables, req, 'pedido.atualizar', TABLES.orders, orderId, order, saved);
  return saved;
}

async function releaseManualCredential({ tables, req, body, userId }) {
  const identifier = String(body.identificador || '').trim();
  const secret = String(body.segredo || '');
  const clientId = String(body.cliente_id || '').trim();
  const serviceId = String(body.servico_id || '').trim();
  const subscriptionId = body.assinatura_id ? String(body.assinatura_id) : null;
  if (!identifier || !secret || !clientId || !serviceId) {
    throw publicError('Cliente, serviço, identificador e segredo são obrigatórios.');
  }

  let subscription = null;
  let effectiveExpiry = body.expira_em || null;
  if (subscriptionId) {
    subscription = await tables.getRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.subscriptions,
      rowId: subscriptionId,
    });
    if (subscription.user_id !== clientId || subscription.servico_id !== serviceId) {
      throw publicError('A assinatura não pertence ao cliente ou serviço informado.', 409, 'subscription_mismatch');
    }
    if (!effectiveExpiry && subscription.status === 'aguardando_liberacao') {
      const originalStart = new Date(subscription.data_inicio).getTime();
      const originalDue = new Date(subscription.data_vencimento).getTime();
      const duration = Number.isFinite(originalStart) && Number.isFinite(originalDue)
        ? Math.max(86400000, originalDue - originalStart)
        : 30 * 86400000;
      effectiveExpiry = new Date(Date.now() + duration).toISOString();
    } else if (!effectiveExpiry) {
      effectiveExpiry = subscription.data_vencimento || null;
    }
  }

  const encrypted = encryptCredential(identifier, secret);
  const credential = await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.credentials,
    rowId: ID.unique(),
    data: {
      cliente_id: clientId,
      servico_id: serviceId,
      assinatura_id: subscriptionId,
      identificador_mascarado: maskedIdentifier(identifier),
      ...encrypted,
      versao_chave: 1,
      status: 'ativa',
      expira_em: effectiveExpiry,
      ultima_visualizacao_em: null,
    },
    permissions: adminPermissions(),
  });
  if (subscriptionId) {
    await replaceActiveCredentials(tables, clientId, subscriptionId, credential.$id);
  }

  if (subscriptionId) {
    const activation = { status: 'ativa' };
    if (subscription?.status === 'aguardando_liberacao') {
      activation.data_inicio = new Date().toISOString();
      activation.data_vencimento = effectiveExpiry;
    }
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.subscriptions,
      rowId: subscriptionId,
      data: activation,
    });
  }
  const reserved = await listModuleRows(tables, 'inventory_slot', {
    ownerId: clientId,
    referenceId: serviceId,
    status: 'reservada',
    limit: 100,
  });
  const slot = (reserved.rows ?? []).find((candidate) => {
    const slotData = parseJson(candidate.data_json);
    return subscriptionId
      ? slotData.subscription_id === subscriptionId
      : !slotData.subscription_id;
  });
  if (slot) {
    const changedAt = new Date().toISOString();
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      rowId: slot.$id,
      data: {
        status: 'ocupada',
        updated_at: changedAt,
        data_json: JSON.stringify({
          ...parseJson(slot.data_json),
          subscription_id: subscriptionId,
          occupied_at: changedAt,
          manual_release: true,
        }),
      },
    });
    await createModuleDirect(tables, {
      kind: 'stock_history',
      reference_id: serviceId,
      parent_id: slot.$id,
      title: 'Vaga ocupada manualmente',
      status: 'concluido',
      data: { subscription_id: subscriptionId, user_id: clientId, at: changedAt },
      created_by: userId,
    });
  }
  const relatedOrderId = body.order_id || (slot ? parseJson(slot.data_json).order_id : null);
  if (relatedOrderId) {
    await createModuleDirect(tables, {
      kind: 'order_timeline',
      reference_id: String(relatedOrderId),
      title: 'Credenciais enviadas',
      status: 'concluido',
      sort_order: Math.round(Date.now() / 1000000),
      data: { event: 'credenciais_enviadas', at: new Date().toISOString() },
      created_by: userId,
    }, clientId);
  }
  await notify(tables, clientId, 'Acesso liberado', 'Suas credenciais já estão disponíveis no Cofre.', 'credencial');
  await audit(
    tables,
    req,
    'credencial.liberar',
    TABLES.credentials,
    credential.$id,
    null,
    {
      cliente_id: clientId,
      servico_id: serviceId,
      assinatura_id: subscriptionId,
      identificador_mascarado: credential.identificador_mascarado,
      segredo: '[protegido]',
    },
  );
  return { $id: credential.$id, identificador_mascarado: credential.identificador_mascarado };
}

async function replaceActiveCredentials(tables, clientId, subscriptionId, exceptId = null) {
  const found = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.credentials,
    queries: [Query.equal('cliente_id', clientId), Query.limit(100)],
    total: false,
    ttl: 0,
  });
  let replaced = 0;
  for (const credential of found.rows ?? []) {
    if (credential.$id === exceptId || credential.assinatura_id !== subscriptionId || credential.status !== 'ativa') continue;
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.credentials,
      rowId: credential.$id,
      data: { status: 'substituida' },
    });
    replaced++;
  }
  return replaced;
}

async function updateSubscriptionRequest({ tables, req, body, userId }) {
  const request = await tables.getRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: String(body.row_id || ''),
  });
  if (request.kind !== 'subscription_request') throw publicError('Solicitação inválida.');
  const decision = String(body.decision || 'approve');
  if (!new Set(['approve', 'reject']).has(decision)) throw publicError('Decisão inválida.');
  const requestData = parseJson(request.data_json);
  const subscription = await tables.getRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.subscriptions,
    rowId: request.reference_id,
  });
  const now = new Date().toISOString();

  if (decision === 'reject') {
    const saved = await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      rowId: request.$id,
      data: {
        status: 'recusada',
        updated_at: now,
        data_json: JSON.stringify({ ...requestData, decided_at: now, decided_by: userId, reason: String(body.reason || '').slice(0, 1000) }),
      },
    });
    await notify(tables, request.owner_id, 'Solicitação analisada', String(body.reason || 'A troca solicitada não pôde ser aprovada.'), 'assinatura');
    await audit(tables, req, 'assinatura.troca_recusar', MODULES_TABLE_ID, request.$id, request, saved);
    return serializeModule(saved);
  }

  const free = await availableSlot(tables, subscription.servico_id);
  if (!free) {
    const waiting = await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      rowId: request.$id,
      data: { status: 'aguardando_vaga', updated_at: now },
    });
    await notify(tables, request.owner_id, 'Troca aprovada', 'Sua solicitação foi aprovada e aguarda uma vaga livre.', 'assinatura');
    await audit(tables, req, 'assinatura.troca_aguardar', MODULES_TABLE_ID, request.$id, request, waiting);
    return serializeModule(waiting);
  }

  const occupied = await listModuleRows(tables, 'inventory_slot', {
    ownerId: request.owner_id,
    referenceId: subscription.servico_id,
    status: 'ocupada',
    limit: 100,
  });
  const current = (occupied.rows ?? []).find(
    (candidate) => parseJson(candidate.data_json).subscription_id === subscription.$id,
  );
  if (current) {
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: MODULES_TABLE_ID,
      rowId: current.$id,
      data: {
        owner_id: null,
        status: 'livre',
        updated_at: now,
        data_json: JSON.stringify({
          ...parseJson(current.data_json),
          order_id: null,
          subscription_id: null,
          released_at: now,
        }),
      },
      permissions: modulePermissions(null),
    });
  }
  await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: free.$id,
    data: {
      owner_id: request.owner_id,
      status: 'ocupada',
      updated_at: now,
      data_json: JSON.stringify({
        ...parseJson(free.data_json),
        subscription_id: subscription.$id,
        swap_request_id: request.$id,
        occupied_at: now,
      }),
    },
    permissions: modulePermissions(request.owner_id),
  });
  const newCredential = await createCredentialFromSlot(
    tables,
    request.owner_id,
    subscription.servico_id,
    subscription.$id,
    free,
  );
  await replaceActiveCredentials(
    tables,
    request.owner_id,
    subscription.$id,
    newCredential.$id,
  );
  const saved = await tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: MODULES_TABLE_ID,
    rowId: request.$id,
    data: {
      status: 'concluida',
      updated_at: now,
      data_json: JSON.stringify({ ...requestData, decided_at: now, decided_by: userId, previous_slot_id: current?.$id || null, new_slot_id: free.$id }),
    },
  });
  await createModuleDirect(tables, {
    kind: 'stock_history',
    reference_id: subscription.servico_id,
    parent_id: free.$id,
    title: requestData.type === 'screen' ? 'Tela trocada' : 'Conta trocada',
    status: 'concluido',
    data: { subscription_id: subscription.$id, previous_slot_id: current?.$id || null, request_id: request.$id, at: now },
    created_by: userId,
  });
  await notify(tables, request.owner_id, 'Troca concluída', 'O novo acesso já está disponível no Cofre.', 'credencial');
  await audit(tables, req, 'assinatura.troca_concluir', MODULES_TABLE_ID, request.$id, request, saved);
  return serializeModule(saved);
}

async function backupNow({ client, tables, req, userId }) {
  const tableIds = [...new Set(Object.values(TABLES))];
  const payload = { generated_at: new Date().toISOString(), database_id: DATABASE_ID, tables: {} };
  for (const tableId of tableIds) {
    try {
      const result = await tables.listRows({ databaseId: DATABASE_ID, tableId, queries: [Query.limit(500)], total: true, ttl: 0 });
      payload.tables[tableId] = { total: result.total, rows: result.rows ?? [] };
    } catch (cause) {
      payload.tables[tableId] = { error: String(cause?.message || cause) };
    }
  }
  const bytes = gzipSync(Buffer.from(JSON.stringify(payload), 'utf8'));
  const name = `rachey-backup-${new Date().toISOString().replace(/[:.]/g, '-')}.json.gz`;
  const file = await new Storage(client).createFile({
    bucketId: BUCKET_ID,
    fileId: ID.unique(),
    file: InputFile.fromBuffer(bytes, name),
    permissions: adminPermissions(),
  });
  await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.fileMetadata,
    rowId: ID.unique(),
    data: {
      file_id: file.$id,
      user_id: userId,
      tipo: 'backup',
      referencia_id: null,
      nome_original: name,
      mime_type: 'application/gzip',
      tamanho_bytesw: bytes.length,
    },
    permissions: adminPermissions(),
  });
  const record = await createModuleDirect(tables, {
    kind: 'backup_run',
    reference_id: file.$id,
    title: name,
    status: 'concluido',
    data: { file_id: file.$id, size: bytes.length, generated_at: payload.generated_at },
    created_by: userId,
  });
  await audit(tables, req, 'backup.executar', MODULES_TABLE_ID, record.$id, null, { file_id: file.$id, size: bytes.length });
  return { file_id: file.$id, name, size: bytes.length };
}


async function runBotTasks({ tables, userId = null }) {
  const tasks = await listModuleRows(tables, 'bot_task', { status: 'ativa', limit: 500 });
  const now = Date.now();
  let executed = 0;
  const results = [];
  for (const task of tasks.rows ?? []) {
    const data = parseJson(task.data_json);
    const due = new Date(data.next_run_at || task.due_at || task.$createdAt || 0).getTime();
    if (!Number.isFinite(due) || due > now) continue;
    const type = String(data.task_type || 'promotion');
    try {
      if (type === 'promotion') {
        const text = String(data.text || '').trim().slice(0, 3000);
        if (text) {
          await createGroupRow(tables, {
            kind: 'group_message',
            ownerId: null,
            status: 'publicado',
            data: {
              text,
              sender_name: 'Rachey Bot',
              sender_role: 'bot',
              attachment: null,
              pinned: false,
              edited: false,
              channel: String(data.channel || 'promocoes').slice(0, 24),
              message_type: 'promotion',
              special: { automated: true, task_id: task.$id },
            },
          });
        }
      } else if (type === 'keep_group_active') {
        const loaded = await groupSettings(tables);
        await saveGroupSettingsPatch(tables, loaded, { mode: 'todos' });
      }
      const interval = Math.max(5, Math.min(10080, Math.round(Number(data.interval_minutes || 60))));
      const nextRun = new Date(Date.now() + interval * 60000).toISOString();
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: MODULES_TABLE_ID,
        rowId: task.$id,
        data: {
          due_at: nextRun,
          updated_at: new Date().toISOString(),
          data_json: JSON.stringify({ ...data, last_run_at: new Date().toISOString(), next_run_at: nextRun, last_error: null }),
        },
      });
      executed++;
      results.push({ task_id: task.$id, ok: true, next_run_at: nextRun });
    } catch (cause) {
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: MODULES_TABLE_ID,
        rowId: task.$id,
        data: {
          updated_at: new Date().toISOString(),
          data_json: JSON.stringify({ ...data, last_error: String(cause?.message || cause).slice(0, 500), last_error_at: new Date().toISOString() }),
        },
      });
      results.push({ task_id: task.$id, ok: false, error: String(cause?.message || cause).slice(0, 200) });
    }
  }
  return { executed, checked: tasks.rows?.length ?? 0, results, actor: userId || 'worker' };
}

export async function handlePlatformAction(context) {
  const { action, tables, userId, isAdmin, roles = [] } = context;
  if (!SAFE_ACTIONS.has(action)) return { handled: false };
  if (action === 'backend_info') {
    return {
      handled: true,
      data: {
        backend_version: '13.0',
        minimum_client_version_code: 15,
        capabilities: [
          'encrypted_app_secrets',
          'mercado_pago_pix',
          'mercado_pago_webhook',
          'gemini_gemma_fallback',
          'group_v13_context_bot',
          'direct_messages',
          'profile_avatars_everywhere',
          'bot_scheduled_tasks',
          'manual_pix_key_only',
        ],
      },
    };
  }
  if (action === 'bootstrap_schema') {
    if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
    return { handled: true, data: await bootstrapSchema(tables) };
  }
  try {
    await tables.getTable({ databaseId: DATABASE_ID, tableId: MODULES_TABLE_ID });
  } catch (cause) {
    if (Number(cause?.code) === 404) throw publicError('A estrutura avançada ainda não foi inicializada pelo administrador.', 503, 'setup_required');
    throw cause;
  }

  if (action === 'module_list') return { handled: true, data: await moduleList(context) };
  if (action === 'module_upsert') return { handled: true, data: await moduleUpsert(context) };
  if (action === 'module_delete') return { handled: true, data: await moduleDelete(context) };
  if (action === 'register_file') return { handled: true, data: await registerFile(context) };
  if (action === 'delete_file') return { handled: true, data: await deleteFile(context) };
  if (action === 'checkout') return { handled: true, data: await checkout(context) };
  if (action === 'catalog_quotes') return { handled: true, data: await catalogQuotes(context) };
  if (action === 'submit_payment_proof') return { handled: true, data: await submitPaymentProof(context) };
  if (action === 'check_automatic_pix') return { handled: true, data: await checkAutomaticPix(context) };
  if (action === 'renew_subscription') return { handled: true, data: await renewSubscription(context) };
  if (action === 'toggle_auto_renewal') return { handled: true, data: await toggleAutoRenewal(context) };
  if (action === 'app_settings') return { handled: true, data: await appSettings(context) };
  if (action === 'create_ticket') return { handled: true, data: await createTicket(context) };
  if (action === 'reply_ticket') return { handled: true, data: await replyTicket(context) };
  if (action === 'group_action') return { handled: true, data: await groupAction(context) };
  if (action === 'direct_action') return { handled: true, data: await directAction(context) };
  if (action === 'rate_ticket') return { handled: true, data: await rateTicket(context) };
  if (action === 'referral_status') return { handled: true, data: await referralStatus(context) };
  if (action === 'apply_referral') return { handled: true, data: await applyReferral(context) };

  if (!isAdmin) throw publicError('Acesso administrativo necessário.', 403, 'forbidden');
  const access = roleFlags(roles);
  const need = (allowed) => {
    if (!allowed) throw publicError('Seu perfil não permite esta operação.', 403, 'role_forbidden');
  };
  if (action === 'test_mercado_pago') {
    need(access.full);
    return { handled: true, data: await testMercadoPago(tables) };
  }
  if (action === 'test_ai_bot') {
    need(access.full);
    return { handled: true, data: await testAiBot(tables) };
  }
  if (action === 'list_ai_models') {
    need(access.full);
    return { handled: true, data: await listAiModels(tables) };
  }
  if (action === 'approve_payment') {
    need(access.finance);
    return { handled: true, data: await approvePayment(context) };
  }
  if (action === 'reject_payment') {
    need(access.finance);
    return { handled: true, data: await rejectPayment(context) };
  }
  if (action === 'inventory_save_account') {
    need(access.operator);
    return { handled: true, data: await inventorySaveAccount(context) };
  }
  if (action === 'inventory_update_account') {
    need(access.operator);
    return { handled: true, data: await inventoryUpdateAccount(context) };
  }
  if (action === 'inventory_delete_account') {
    need(access.operator);
    return { handled: true, data: await inventoryDeleteAccount(context) };
  }
  if (action === 'inventory_release_slot') {
    need(access.operator);
    return { handled: true, data: await inventoryReleaseSlot(context) };
  }
  if (action === 'inventory_reveal') {
    need(access.operator);
    return { handled: true, data: await inventoryReveal(context) };
  }
  if (action === 'dashboard') return { handled: true, data: await dashboard(context) };
  if (action === 'finance_summary') {
    need(access.finance);
    return { handled: true, data: await financeSummary(context) };
  }
  if (action === 'export_finance') {
    need(access.finance);
    return { handled: true, data: await exportFinance(context) };
  }
  if (action === 'save_app_settings') {
    need(access.full);
    return { handled: true, data: await saveAppSettings(context) };
  }
  if (action === 'update_ticket') {
    need(access.operator);
    return { handled: true, data: await updateTicket(context) };
  }
  if (action === 'waitlist_approve') {
    need(access.operator);
    return { handled: true, data: await approveWaitlist(context) };
  }
  if (action === 'broadcast_notification') {
    need(access.operator);
    return { handled: true, data: await broadcastNotification(context) };
  }
  if (action === 'update_order') {
    need(access.operator);
    return { handled: true, data: await updateOrder(context) };
  }
  if (action === 'release_credential') {
    need(access.operator);
    return { handled: true, data: await releaseManualCredential(context) };
  }
  if (action === 'subscription_request_update') {
    need(access.operator);
    return { handled: true, data: await updateSubscriptionRequest(context) };
  }
  if (action === 'delete_client') {
    need(access.full);
    return { handled: true, data: await deleteClient(context) };
  }
  if (action === 'set_client_active') {
    need(access.full);
    return { handled: true, data: await setClientActive(context) };
  }
  if (action === 'backup_now') {
    need(access.full);
    return { handled: true, data: await backupNow(context) };
  }
  if (action === 'bot_worker_tick') {
    need(access.full);
    return { handled: true, data: await runBotTasks(context) };
  }
  return { handled: false };
}
