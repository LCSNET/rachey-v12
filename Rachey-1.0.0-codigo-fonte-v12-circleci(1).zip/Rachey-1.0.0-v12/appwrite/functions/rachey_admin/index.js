import crypto from 'node:crypto';

import {
  Client,
  ID,
  Permission,
  Query,
  Role,
  TablesDB,
  Users,
} from 'node-appwrite';
import { handleMercadoPagoWebhook, handlePlatformAction } from './platform.js';

const DATABASE_ID = 'rachey_db';
const ADMIN_TEAM_ID = 'administradores';

const TABLES = Object.freeze({
  profiles: 'perfis',
  categories: 'categorias',
  services: 'servicos',
  carts: 'carrinhos',
  cartItems: 'itens_carrinho',
  orders: 'pedidos',
  orderItems: 'itens_pedido',
  subscriptions: 'assinaturas',
  renewals: 'renovacoes',
  payments: 'pagamentos',
  notifications: 'notificacoes',
  messages: 'mensagens',
  fileMetadata: 'arquivos_metadata',
  audit: 'auditoria',
  credentials: 'credenciais_acesso',
});

const MUTABLE_FIELDS = Object.freeze({
  [TABLES.profiles]: [
    'user_id', 'nome', 'email', 'telefone', 'tipo', 'ativo', 'foto_id',
  ],
  [TABLES.categories]: [
    'nome', 'slug', 'descricao', 'imagem_file_id', 'ordem', 'ativo',
  ],
  [TABLES.services]: [
    'nome', 'descricao', 'valor', 'periodicidade', 'ativo', 'categoria_id',
    'preco_centavos', 'imagem_file_id', 'dsetaque', 'ordem',
  ],
  [TABLES.carts]: [
    'user_id', 'status', 'subtotal_centavos', 'desconto_centavos',
    'total_centavos', 'atualizado_em',
  ],
  [TABLES.cartItems]: [
    'carinho_id', 'user_id', 'servico_id', 'nome_servico', 'quantidae',
    'preco_unitario_centavos', 'observacoes',
  ],
  [TABLES.orders]: [
    'numero', 'user_id', 'carrinho_id', 'status', 'forma_pagamento',
    'subtotal_centavos', 'desconto_centavos', 'total_centavos',
    'comprovante_file_id', 'observacoes_cliente', 'observacoes_admin',
  ],
  [TABLES.orderItems]: [
    'pedido_id', 'user_id', 'servico_id', 'nome_servico', 'quantidade',
    'preco_unitario_centavos', 'subtotal_centavos', 'lhes',
  ],
  [TABLES.subscriptions]: [
    'user_id', 'servico_id', 'nome_servico', 'valor', 'data_inicio',
    'data_vencimento', 'status', 'renovacao_automatica', 'observacoes',
  ],
  [TABLES.renewals]: [
    'user_id', 'assinatura_id', 'data_anterior', 'nova_data', 'valor',
    'status', 'observacoes',
  ],
  [TABLES.payments]: [
    'user_id', 'assinatura_id', 'renovacao_id', 'valor', 'forma_pagamento',
    'status', 'data_pagamento', 'comprovante_id',
  ],
  [TABLES.notifications]: [
    'user_id', 'titulo', 'mensagem', 'tipo', 'lida', 'data_vencimento',
  ],
  [TABLES.messages]: [
    'cliente_id', 'remetente_id', 'pedido_id', 'texto', 'arquivo_file_id',
    'tipo', 'lida', 'lida_em',
  ],
  [TABLES.fileMetadata]: [
    'file_id', 'user_id', 'tipo', 'referencia_id', 'nome_original',
    'mime_type', 'tamanho_bytesw',
  ],
  [TABLES.credentials]: [
    'cliente_id', 'servico_id', 'assinatura_id', 'identificador_mascarado',
    'segredo_criptografado', 'iv', 'tag_autenticacao', 'versao_chave',
    'status', 'expira_em', 'ultima_visualizacao_em',
  ],
});

const ADMIN_CRUD_TABLES = new Set([
  TABLES.profiles,
  TABLES.categories,
  TABLES.services,
  TABLES.orders,
  TABLES.orderItems,
  TABLES.subscriptions,
  TABLES.renewals,
  TABLES.payments,
  TABLES.notifications,
  TABLES.messages,
  TABLES.fileMetadata,
]);

const OWNED_TABLES = Object.freeze({
  [TABLES.profiles]: 'user_id',
  [TABLES.carts]: 'user_id',
  [TABLES.cartItems]: 'user_id',
  [TABLES.orders]: 'user_id',
  [TABLES.orderItems]: 'user_id',
  [TABLES.subscriptions]: 'user_id',
  [TABLES.renewals]: 'user_id',
  [TABLES.payments]: 'user_id',
  [TABLES.notifications]: 'user_id',
  [TABLES.messages]: 'cliente_id',
  [TABLES.fileMetadata]: 'user_id',
});

function parseBody(req) {
  if (req.bodyJson && typeof req.bodyJson === 'object' && !Array.isArray(req.bodyJson)) {
    return req.bodyJson;
  }
  if (!req.bodyText) return {};
  try {
    const value = JSON.parse(req.bodyText);
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch {
    throw new Error('Corpo JSON inválido.');
  }
}

function publicError(message, status = 400, code = 'invalid_request') {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  return error;
}

function cleanData(tableId, source) {
  if (!source || typeof source !== 'object' || Array.isArray(source)) return {};
  const allowed = MUTABLE_FIELDS[tableId] ?? [];
  return Object.fromEntries(
    Object.entries(source).filter(([key, value]) => allowed.includes(key) && value !== undefined),
  );
}

function resolveTable(value) {
  if (typeof value !== 'string') return null;
  if (TABLES[value]) return TABLES[value];
  return Object.values(TABLES).includes(value) ? value : null;
}

function userPermissions(userId) {
  return [
    Permission.read(Role.user(userId)),
    Permission.update(Role.user(userId)),
    Permission.delete(Role.user(userId)),
    Permission.read(Role.team(ADMIN_TEAM_ID)),
    Permission.update(Role.team(ADMIN_TEAM_ID, 'owner')),
    Permission.update(Role.team(ADMIN_TEAM_ID, 'admin')),
    Permission.delete(Role.team(ADMIN_TEAM_ID, 'owner')),
    Permission.delete(Role.team(ADMIN_TEAM_ID, 'admin')),
  ];
}

function adminReadPermissions() {
  return [Permission.read(Role.team(ADMIN_TEAM_ID))];
}

function maskIp(ip = '') {
  if (!ip) return null;
  if (ip.includes(':')) return `${ip.split(':').slice(0, 3).join(':')}:*`;
  const parts = ip.split('.');
  return parts.length === 4 ? `${parts[0]}.${parts[1]}.*.*` : '*';
}

function safeJson(value) {
  const hidden = new Set([
    'segredo', 'password', 'senha', 'token', 'secret',
    'segredo_criptografado', 'iv', 'tag_autenticacao',
  ]);
  const sanitize = (input, depth = 0) => {
    if (depth > 5) return '[limite]';
    if (Array.isArray(input)) return input.slice(0, 100).map((item) => sanitize(item, depth + 1));
    if (input && typeof input === 'object') {
      return Object.fromEntries(
        Object.entries(input).map(([key, value]) => [
          key,
          hidden.has(key.toLowerCase()) ? '[protegido]' : sanitize(value, depth + 1),
        ]),
      );
    }
    if (typeof input === 'string' && input.length > 2000) return `${input.slice(0, 2000)}…`;
    return input;
  };
  return JSON.stringify(sanitize(value ?? null));
}

function normalizedRows(result) {
  return (result.rows ?? []).map((row) => ({
    ...row,
    $permissions: undefined,
  }));
}

function encryptionKey() {
  const raw = process.env.RACHEY_CREDENTIALS_KEY;
  if (!raw) throw publicError('Chave de criptografia da Function não configurada.', 503, 'encryption_unavailable');
  const key = Buffer.from(raw, 'base64');
  if (key.length !== 32) throw publicError('Chave de criptografia da Function é inválida.', 503, 'encryption_unavailable');
  return key;
}

function encryptCredential(identifier, secret) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', encryptionKey(), iv);
  const plain = JSON.stringify({ identificador: identifier, segredo: secret });
  const encrypted = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  return {
    ciphertext: encrypted.toString('base64'),
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
  };
}

function decryptCredential(row) {
  const decipher = crypto.createDecipheriv(
    'aes-256-gcm',
    encryptionKey(),
    Buffer.from(row.iv, 'base64'),
  );
  decipher.setAuthTag(Buffer.from(row.tag_autenticacao, 'base64'));
  const plain = Buffer.concat([
    decipher.update(Buffer.from(row.segredo_criptografado, 'base64')),
    decipher.final(),
  ]).toString('utf8');
  return JSON.parse(plain);
}

function maskedIdentifier(identifier) {
  const value = String(identifier ?? '').trim();
  if (value.includes('@')) {
    const [name, domain] = value.split('@');
    return `${name.slice(0, 2)}***@${domain}`.slice(0, 150);
  }
  if (value.length <= 4) return '****';
  return `${value.slice(0, 2)}***${value.slice(-2)}`.slice(0, 150);
}

function createAdminClient(req) {
  const apiKey = req.headers['x-appwrite-key'];
  if (!apiKey) throw publicError('Chave dinâmica da Function indisponível.', 503, 'function_key_missing');
  return new Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT || 'https://nyc.cloud.appwrite.io/v1')
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID || 'rachey')
    .setKey(apiKey);
}

async function adminStatus(users, userId) {
  const memberships = await users.listMemberships({ userId, total: false });
  const membership = (memberships.memberships ?? []).find(
    (item) => item.teamId === ADMIN_TEAM_ID && item.confirm,
  );
  return {
    isAdmin: Boolean(membership),
    roles: membership?.roles ?? [],
  };
}

function administrativeAccess(roles = []) {
  const normalized = new Set(roles.map((role) => String(role).toLowerCase()));
  const full = roles.length === 0
    || normalized.has('owner')
    || normalized.has('admin')
    || normalized.has('administrador');
  return {
    full,
    operator: full || normalized.has('operator') || normalized.has('operador'),
    finance: full || normalized.has('finance') || normalized.has('financeiro'),
  };
}

function canReadAdministrativeTable(tableId, access) {
  if (access.full) return true;
  if (access.finance) {
    return new Set([
      TABLES.profiles,
      TABLES.categories,
      TABLES.services,
      TABLES.orders,
      TABLES.orderItems,
      TABLES.subscriptions,
      TABLES.renewals,
      TABLES.payments,
      TABLES.fileMetadata,
    ]).has(tableId);
  }
  if (access.operator) {
    return new Set([
      TABLES.profiles,
      TABLES.categories,
      TABLES.services,
      TABLES.orders,
      TABLES.orderItems,
      TABLES.subscriptions,
      TABLES.notifications,
      TABLES.messages,
      TABLES.fileMetadata,
    ]).has(tableId);
  }
  return false;
}

function auditSeed(req, actorType, action, entity, entityId, before, after, message) {
  return {
    ator_user_id: req.headers['x-appwrite-user-id'] || null,
    ator_tipo: actorType,
    acao: String(action).slice(0, 100),
    entidade: String(entity).slice(0, 80),
    entidade_id: entityId ? String(entityId).slice(0, 36) : null,
    dados_anteriores: safeJson(before),
    daods_novos: safeJson(after),
    sucesso: false,
    mensagem: String(message || 'Operação iniciada.'),
    ip_mascarado: maskIp(req.headers['x-appwrite-client-ip']),
    dispositivo: String(req.headers['user-agent'] || '').slice(0, 255) || null,
  };
}

async function withAudit({ tables, req, actorType, action, entity, entityId, before, after, message }, task) {
  const audit = await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.audit,
    rowId: ID.unique(),
    data: auditSeed(req, actorType, action, entity, entityId, before, after, 'Operação iniciada.'),
    permissions: adminReadPermissions(),
  });
  try {
    const result = await task();
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.audit,
      rowId: audit.$id,
      data: {
        sucesso: true,
        mensagem: String(message || 'Operação concluída.'),
        daods_novos: safeJson(after ?? result),
      },
    });
    return result;
  } catch (cause) {
    try {
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.audit,
        rowId: audit.$id,
        data: { sucesso: false, mensagem: String(cause?.message || cause).slice(0, 2000) },
      });
    } catch {
      // O erro original é mais útil para o chamador.
    }
    throw cause;
  }
}

async function upsertProfile({ tables, users, req, userId, isAdmin, body }) {
  const account = await users.get({ userId });
  const existing = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.profiles,
    queries: [Query.equal('user_id', userId), Query.limit(1)],
    total: false,
    ttl: 0,
  });
  const current = existing.rows?.[0];
  const data = cleanData(TABLES.profiles, {
    user_id: userId,
    nome: body.nome || account.name || current?.nome || 'Cliente',
    email: account.email,
    telefone: body.telefone ?? account.phone ?? current?.telefone ?? null,
    tipo: isAdmin ? 'admin' : 'cliente',
    // Um login comum nunca reativa uma conta desativada pelo administrador.
    ativo: current?.ativo ?? true,
    foto_id: body.foto_id ?? current?.foto_id ?? null,
  });
  return withAudit({
    tables,
    req,
    actorType: isAdmin ? 'admin' : 'cliente',
    action: current ? 'perfil.atualizar' : 'perfil.criar',
    entity: TABLES.profiles,
    entityId: current?.$id,
    before: current,
    after: data,
  }, () => current
    ? tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.profiles, rowId: current.$id, data })
    : tables.createRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.profiles,
        rowId: ID.unique(),
        data,
        permissions: userPermissions(userId),
      }));
}

async function checkout({ tables, req, userId, body }) {
  const items = Array.isArray(body.items) ? body.items : [];
  if (!items.length) throw publicError('O carrinho está vazio.');
  const cleanItems = items.slice(0, 50).map((item) => {
    const quantity = Math.max(1, Math.min(99, Number(item.quantidade ?? 1) || 1));
    const unit = Math.max(0, Math.round(Number(item.preco_unitario_centavos ?? 0) || 0));
    if (!item.servico_id || !item.nome_servico) throw publicError('Item do carrinho inválido.');
    return {
      servico_id: String(item.servico_id).slice(0, 36),
      nome_servico: String(item.nome_servico).slice(0, 150),
      quantidade: quantity,
      preco_unitario_centavos: unit,
      subtotal_centavos: quantity * unit,
    };
  });
  const subtotal = cleanItems.reduce((sum, item) => sum + item.subtotal_centavos, 0);
  const discount = Math.max(0, Math.min(subtotal, Math.round(Number(body.desconto_centavos ?? 0) || 0)));
  const total = subtotal - discount;
  const now = new Date().toISOString();
  const cartId = ID.unique();
  const orderId = ID.unique();
  const orderNumber = `RCH-${Date.now().toString(36).toUpperCase()}`.slice(0, 30);
  const permissions = userPermissions(userId);

  return withAudit({
    tables,
    req,
    actorType: 'cliente',
    action: 'pedido.criar',
    entity: TABLES.orders,
    entityId: orderId,
    after: { orderNumber, total, itemCount: cleanItems.length },
  }, async () => {
    await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.carts,
      rowId: cartId,
      data: {
        user_id: userId,
        status: 'convertido',
        subtotal_centavos: subtotal,
        desconto_centavos: discount,
        total_centavos: total,
        atualizado_em: now,
      },
      permissions,
    });
    for (const item of cleanItems) {
      await tables.createRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.cartItems,
        rowId: ID.unique(),
        data: {
          carinho_id: cartId,
          user_id: userId,
          servico_id: item.servico_id,
          nome_servico: item.nome_servico,
          quantidae: item.quantidade,
          preco_unitario_centavos: item.preco_unitario_centavos,
          observacoes: body.observacoes || null,
        },
        permissions,
      });
    }
    const order = await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.orders,
      rowId: orderId,
      data: {
        numero: orderNumber,
        user_id: userId,
        carrinho_id: cartId,
        status: 'aguardando_pagamento',
        forma_pagamento: body.forma_pagamento || 'pix',
        subtotal_centavos: subtotal,
        desconto_centavos: discount,
        total_centavos: total,
        comprovante_file_id: body.comprovante_file_id || null,
        observacoes_cliente: body.observacoes || null,
        observacoes_admin: null,
      },
      permissions,
    });
    for (const item of cleanItems) {
      await tables.createRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.orderItems,
        rowId: ID.unique(),
        data: {
          pedido_id: orderId,
          user_id: userId,
          servico_id: item.servico_id,
          nome_servico: item.nome_servico,
          quantidade: item.quantidade,
          preco_unitario_centavos: item.preco_unitario_centavos,
          subtotal_centavos: item.subtotal_centavos,
          lhes: body.detalhes || null,
        },
        permissions,
      });
    }
    return order;
  });
}

async function adminList({ tables, body }) {
  const tableId = resolveTable(body.table);
  if (!tableId || tableId === TABLES.credentials) {
    throw publicError('Tabela não permitida para esta consulta.');
  }
  const limit = Math.max(1, Math.min(100, Number(body.limit ?? 50) || 50));
  const queries = [Query.limit(limit), Query.orderDesc('$createdAt')];
  if (body.filters && typeof body.filters === 'object') {
    for (const [field, value] of Object.entries(body.filters).slice(0, 5)) {
      if ((MUTABLE_FIELDS[tableId] ?? []).includes(field) && value !== undefined && value !== null) {
        queries.push(Query.equal(field, value));
      }
    }
  }
  const result = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId,
    queries,
    total: true,
    ttl: 0,
  });
  return { total: result.total, rows: normalizedRows(result) };
}

async function clientList({ tables, userId, body }) {
  const tableId = resolveTable(body.table);
  const ownerColumn = tableId ? OWNED_TABLES[tableId] : null;
  if (!tableId || !ownerColumn) throw publicError('Tabela não permitida para esta consulta.');
  const limit = Math.max(1, Math.min(100, Number(body.limit ?? 100) || 100));
  const result = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId,
    queries: [
      Query.equal(ownerColumn, userId),
      Query.orderDesc('$createdAt'),
      Query.limit(limit),
    ],
    total: true,
    ttl: 0,
  });
  return { total: result.total, rows: normalizedRows(result) };
}

async function catalogList({ tables, body }) {
  const tableId = resolveTable(body.table);
  if (![TABLES.categories, TABLES.services].includes(tableId)) {
    throw publicError('Catálogo solicitado é inválido.');
  }
  const result = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId,
    queries: [Query.equal('ativo', true), Query.limit(100)],
    total: true,
    ttl: 0,
  });
  const rows = normalizedRows(result).sort((a, b) => Number(a.ordem ?? 0) - Number(b.ordem ?? 0));
  return { total: result.total, rows };
}

async function listCredentials({ tables, userId, isAdmin, body }) {
  const clientId = isAdmin && body.cliente_id ? String(body.cliente_id) : userId;
  const result = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.credentials,
    queries: [Query.equal('cliente_id', clientId), Query.orderDesc('$createdAt'), Query.limit(100)],
    total: true,
    ttl: 0,
  });
  return {
    total: result.total,
    rows: (result.rows ?? []).map((row) => ({
      $id: row.$id,
      $createdAt: row.$createdAt,
      cliente_id: row.cliente_id,
      servico_id: row.servico_id,
      assinatura_id: row.assinatura_id,
      identificador_mascarado: row.identificador_mascarado,
      status: row.status,
      expira_em: row.expira_em,
      ultima_visualizacao_em: row.ultima_visualizacao_em,
    })),
  };
}

async function adminCrud({ tables, req, body }) {
  const tableId = resolveTable(body.table);
  if (!tableId || !ADMIN_CRUD_TABLES.has(tableId)) throw publicError('Tabela administrativa não permitida.');
  const operation = String(body.operation || '').toLowerCase();
  const rowId = body.rowId ? String(body.rowId) : null;
  const data = cleanData(tableId, body.data);
  if (!['create', 'update', 'delete'].includes(operation)) throw publicError('Operação administrativa inválida.');
  if (operation !== 'create' && !rowId) throw publicError('rowId é obrigatório.');
  const before = rowId
    ? await tables.getRow({ databaseId: DATABASE_ID, tableId, rowId })
    : null;
  const ownerId = data.user_id || data.cliente_id || before?.user_id || before?.cliente_id;
  return withAudit({
    tables,
    req,
    actorType: 'admin',
    action: `${tableId}.${operation}`,
    entity: tableId,
    entityId: rowId,
    before,
    after: data,
  }, async () => {
    if (operation === 'create') {
      return tables.createRow({
        databaseId: DATABASE_ID,
        tableId,
        rowId: ID.unique(),
        data,
        permissions: ownerId ? userPermissions(String(ownerId)) : [
          Permission.read(Role.users()),
          Permission.read(Role.team(ADMIN_TEAM_ID)),
          Permission.update(Role.team(ADMIN_TEAM_ID)),
          Permission.delete(Role.team(ADMIN_TEAM_ID)),
        ],
      });
    }
    if (operation === 'update') {
      return tables.updateRow({ databaseId: DATABASE_ID, tableId, rowId, data });
    }
    await tables.deleteRow({ databaseId: DATABASE_ID, tableId, rowId });
    return { $id: rowId, deleted: true };
  });
}

async function approvePayment({ tables, req, body }) {
  const paymentId = String(body.paymentId || '');
  if (!paymentId) throw publicError('paymentId é obrigatório.');
  const payment = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.payments, rowId: paymentId });
  const now = new Date().toISOString();
  return withAudit({
    tables,
    req,
    actorType: 'admin',
    action: 'pagamento.aprovar',
    entity: TABLES.payments,
    entityId: paymentId,
    before: payment,
    after: { status: 'pago', data_pagamento: now },
  }, async () => {
    const updated = await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.payments,
      rowId: paymentId,
      data: { status: 'pago', data_pagamento: now },
    });
    if (payment.renovacao_id) {
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.renewals,
        rowId: payment.renovacao_id,
        data: { status: 'confirmada' },
      });
    }
    if (body.pedido_id) {
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.orders,
        rowId: String(body.pedido_id),
        data: { status: 'aprovado', observacoes_admin: body.observacoes_admin || null },
      });
    }
    await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.notifications,
      rowId: ID.unique(),
      data: {
        user_id: payment.user_id,
        titulo: 'Pagamento aprovado',
        mensagem: 'Seu pagamento foi aprovado e já está sendo processado.',
        tipo: 'pagamento',
        lida: false,
        data_vencimento: now,
      },
      permissions: userPermissions(payment.user_id),
    });
    return updated;
  });
}

async function releaseCredential({ tables, req, body }) {
  const identifier = String(body.identificador || '').trim();
  const secret = String(body.segredo || '');
  const clientId = String(body.cliente_id || '');
  const serviceId = String(body.servico_id || '');
  if (!identifier || !secret || !clientId || !serviceId) {
    throw publicError('cliente_id, servico_id, identificador e segredo são obrigatórios.');
  }
  const encrypted = encryptCredential(identifier, secret);
  const data = {
    cliente_id: clientId,
    servico_id: serviceId,
    assinatura_id: body.assinatura_id || null,
    identificador_mascarado: maskedIdentifier(identifier),
    segredo_criptografado: encrypted.ciphertext,
    iv: encrypted.iv,
    tag_autenticacao: encrypted.tag,
    versao_chave: 1,
    status: 'ativa',
    expira_em: body.expira_em || null,
    ultima_visualizacao_em: null,
  };
  return withAudit({
    tables,
    req,
    actorType: 'admin',
    action: 'credencial.liberar',
    entity: TABLES.credentials,
    before: null,
    after: { ...data, segredo_criptografado: '[protegido]', iv: '[protegido]', tag_autenticacao: '[protegido]' },
  }, () => tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.credentials,
    rowId: ID.unique(),
    data,
    permissions: adminReadPermissions(),
  }));
}

async function revealCredential({ tables, req, userId, isAdmin, body }) {
  const credentialId = String(body.credentialId || '');
  if (!credentialId) throw publicError('credentialId é obrigatório.');
  const credential = await tables.getRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.credentials,
    rowId: credentialId,
  });
  if (!isAdmin && credential.cliente_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
  if (credential.status !== 'ativa') throw publicError('Esta credencial não está ativa.', 409, 'credential_inactive');
  return withAudit({
    tables,
    req,
    actorType: isAdmin ? 'admin' : 'cliente',
    action: 'credencial.visualizar',
    entity: TABLES.credentials,
    entityId: credentialId,
    before: { status: credential.status },
    after: { ultima_visualizacao_em: new Date().toISOString() },
  }, async () => {
    const clear = decryptCredential(credential);
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.credentials,
      rowId: credentialId,
      data: { ultima_visualizacao_em: new Date().toISOString() },
    });
    return {
      identificador: clear.identificador,
      segredo: clear.segredo,
      expira_em: credential.expira_em,
    };
  });
}

async function createMessage({ tables, req, userId, isAdmin, body }) {
  const clientId = isAdmin ? String(body.cliente_id || '') : userId;
  if (!clientId) throw publicError('cliente_id é obrigatório.');
  const type = ['texto', 'imagem', 'arquivo', 'sistema'].includes(body.tipo) ? body.tipo : 'texto';
  if (!body.texto && !body.arquivo_file_id) throw publicError('A mensagem está vazia.');
  const data = {
    cliente_id: clientId,
    remetente_id: userId,
    pedido_id: body.pedido_id || null,
    texto: body.texto ? String(body.texto).slice(0, 10000) : null,
    arquivo_file_id: body.arquivo_file_id || null,
    tipo: type,
    lida: false,
    lida_em: new Date().toISOString(),
  };
  return withAudit({
    tables,
    req,
    actorType: isAdmin ? 'admin' : 'cliente',
    action: 'mensagem.enviar',
    entity: TABLES.messages,
    after: { ...data, texto: data.texto ? '[conteúdo]' : null },
  }, () => tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.messages,
    rowId: ID.unique(),
    data,
    permissions: userPermissions(clientId),
  }));
}

async function markNotificationRead({ tables, req, userId, isAdmin, body }) {
  const notificationId = String(body.notificationId || '');
  const notification = await tables.getRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.notifications,
    rowId: notificationId,
  });
  if (!isAdmin && notification.user_id !== userId) throw publicError('Acesso negado.', 403, 'forbidden');
  return withAudit({
    tables,
    req,
    actorType: isAdmin ? 'admin' : 'cliente',
    action: 'notificacao.ler',
    entity: TABLES.notifications,
    entityId: notificationId,
    before: { lida: notification.lida },
    after: { lida: true },
  }, () => tables.updateRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.notifications,
    rowId: notificationId,
    data: { lida: true },
  }));
}

export default async ({ req, res, log, error }) => {
  try {
    const body = parseBody(req);
    const action = String(body.action || 'health');
    const userId = req.headers['x-appwrite-user-id'];

    const client = createAdminClient(req);
    const tables = new TablesDB(client);
    const looksLikeMercadoPagoWebhook = !userId
      && String(body.type || '') === 'payment'
      && body.data?.id
      && req.headers['x-signature'];
    if (looksLikeMercadoPagoWebhook) {
      const data = await handleMercadoPagoWebhook({ req, client, tables, body });
      return res.json({ ok: true, data });
    }
    if (!userId) return res.json({ ok: false, code: 'unauthenticated', message: 'Faça login para continuar.' }, 401);

    const users = new Users(client);
    const status = await adminStatus(users, userId);
    const access = administrativeAccess(status.roles);
    req.racheyActorType = status.isAdmin ? 'admin' : 'cliente';
    const profileLookup = await tables.listRows({
      databaseId: DATABASE_ID,
      tableId: TABLES.profiles,
      queries: [Query.equal('user_id', userId), Query.limit(1)],
      total: false,
      ttl: 0,
    });
    const accountActive = profileLookup.rows?.[0]?.ativo !== false;
    if (!status.isAdmin && !accountActive && action !== 'me') {
      return res.json({ ok: false, code: 'account_disabled', message: 'Sua conta está desativada. Entre em contato com o suporte.' }, 403);
    }

    const platformResult = await handlePlatformAction({
      action,
      body,
      req,
      client,
      tables,
      users,
      userId,
      isAdmin: status.isAdmin,
      roles: status.roles,
    });
    if (platformResult.handled) {
      return res.json({ ok: true, data: platformResult.data });
    }

    if (action === 'health' || action === 'me') {
      return res.json({ ok: true, data: { userId, isAdmin: status.isAdmin, roles: status.roles, active: accountActive } });
    }
    if (action === 'upsert_profile') {
      const data = await upsertProfile({ tables, users, req, userId, isAdmin: status.isAdmin, body });
      return res.json({ ok: true, data });
    }
    if (action === 'checkout') {
      const data = await checkout({ tables, req, userId, body });
      return res.json({ ok: true, data });
    }
    if (action === 'client_list') {
      const data = await clientList({ tables, userId, body });
      return res.json({ ok: true, data });
    }
    if (action === 'catalog_list') {
      const data = await catalogList({ tables, body });
      return res.json({ ok: true, data });
    }
    if (action === 'list_credentials') {
      if (status.isAdmin && !access.operator) {
        return res.json({ ok: false, code: 'role_forbidden', message: 'Seu perfil não permite consultar credenciais.' }, 403);
      }
      const data = await listCredentials({ tables, userId, isAdmin: status.isAdmin, body });
      return res.json({ ok: true, data });
    }
    if (action === 'create_message') {
      if (status.isAdmin && !access.operator) {
        return res.json({ ok: false, code: 'role_forbidden', message: 'Seu perfil não permite responder clientes.' }, 403);
      }
      const data = await createMessage({ tables, req, userId, isAdmin: status.isAdmin, body });
      return res.json({ ok: true, data });
    }
    if (action === 'mark_notification_read') {
      const data = await markNotificationRead({ tables, req, userId, isAdmin: status.isAdmin, body });
      return res.json({ ok: true, data });
    }
    if (action === 'reveal_credential') {
      if (status.isAdmin && !access.operator) {
        return res.json({ ok: false, code: 'role_forbidden', message: 'Seu perfil não permite visualizar credenciais.' }, 403);
      }
      const data = await revealCredential({ tables, req, userId, isAdmin: status.isAdmin, body });
      return res.json({ ok: true, data });
    }

    if (!status.isAdmin) return res.json({ ok: false, code: 'forbidden', message: 'Acesso administrativo necessário.' }, 403);

    if (action === 'admin_list') {
      const tableId = resolveTable(body.table);
      if (!tableId || !canReadAdministrativeTable(tableId, access)) {
        return res.json({ ok: false, code: 'role_forbidden', message: 'Seu perfil não permite consultar este registro.' }, 403);
      }
      const data = await adminList({ tables, body });
      return res.json({ ok: true, data });
    }
    if (action === 'admin_crud') {
      const tableId = resolveTable(body.table);
      const operatorTable = tableId === TABLES.categories || tableId === TABLES.services;
      if (!access.full && !(access.operator && operatorTable)) {
        return res.json({ ok: false, code: 'role_forbidden', message: 'Seu perfil não permite alterar este registro.' }, 403);
      }
      const data = await adminCrud({ tables, req, body });
      return res.json({ ok: true, data });
    }
    if (action === 'approve_payment') {
      if (!access.finance) {
        return res.json({ ok: false, code: 'role_forbidden', message: 'Seu perfil não permite aprovar pagamentos.' }, 403);
      }
      const data = await approvePayment({ tables, req, body });
      return res.json({ ok: true, data });
    }
    if (action === 'release_credential') {
      if (!access.operator) {
        return res.json({ ok: false, code: 'role_forbidden', message: 'Seu perfil não permite liberar credenciais.' }, 403);
      }
      const data = await releaseCredential({ tables, req, body });
      return res.json({ ok: true, data: { $id: data.$id, identificador_mascarado: data.identificador_mascarado } });
    }

    return res.json({ ok: false, code: 'unknown_action', message: 'Ação desconhecida.' }, 404);
  } catch (cause) {
    const status = Number(cause?.status || cause?.code) >= 400 && Number(cause?.status || cause?.code) < 600
      ? Number(cause.status || cause.code)
      : 500;
    const code = typeof cause?.code === 'string' ? cause.code : 'internal_error';
    const message = status >= 500 ? 'Não foi possível concluir a operação.' : String(cause?.message || 'Solicitação inválida.');
    error(`[${code}] ${cause?.message || cause}`);
    log(JSON.stringify({ action: (() => { try { return parseBody(req).action; } catch { return null; } })(), status }));
    return res.json({ ok: false, code, message }, status);
  }
};
