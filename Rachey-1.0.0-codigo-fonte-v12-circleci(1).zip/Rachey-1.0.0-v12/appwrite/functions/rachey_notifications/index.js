import { gzipSync } from 'node:zlib';

import {
  Client,
  ID,
  Permission,
  Query,
  Role,
  Storage,
  TablesDB,
} from 'node-appwrite';
import { InputFile } from 'node-appwrite/file';

const DATABASE_ID = 'rachey_db';
const ADMIN_TEAM_ID = 'administradores';
const BUCKET_ID = 'arquivos';
const GROUP_MEDIA_TYPES = new Set([
  'grupo_imagem',
  'grupo_video',
  'grupo_audio',
  'grupo_documento',
]);
const TABLES = Object.freeze({
  profiles: 'perfis',
  categories: 'categorias',
  services: 'servicos',
  orders: 'pedidos',
  orderItems: 'itens_pedido',
  subscriptions: 'assinaturas',
  renewals: 'renovacoes',
  payments: 'pagamentos',
  notifications: 'notificacoes',
  messages: 'mensagens',
  fileMetadata: 'arquivos_metadata',
  audit: 'auditoria',
  credentials: 'credenciais_acesso',
  modules: 'dados_rachey',
});

function clientFor(req) {
  const key = req.headers['x-appwrite-key'];
  if (!key) throw new Error('Chave dinâmica da Function indisponível.');
  return new Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT || 'https://nyc.cloud.appwrite.io/v1')
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID || 'rachey')
    .setKey(key);
}

function adminPermissions() {
  return [
    Permission.read(Role.team(ADMIN_TEAM_ID)),
    Permission.update(Role.team(ADMIN_TEAM_ID, 'owner')),
    Permission.update(Role.team(ADMIN_TEAM_ID, 'admin')),
    Permission.delete(Role.team(ADMIN_TEAM_ID, 'owner')),
    Permission.delete(Role.team(ADMIN_TEAM_ID, 'admin')),
  ];
}

function userPermissions(userId) {
  return [
    Permission.read(Role.user(userId)),
    Permission.update(Role.user(userId)),
    Permission.delete(Role.user(userId)),
    ...adminPermissions(),
  ];
}

function parseJson(raw, fallback = {}) {
  try {
    return typeof raw === 'string' && raw ? JSON.parse(raw) : raw || fallback;
  } catch {
    return fallback;
  }
}

async function audit(tables, data) {
  await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.audit,
    rowId: ID.unique(),
    data: {
      ator_user_id: null,
      ator_tipo: 'sistema',
      acao: String(data.action).slice(0, 100),
      entidade: String(data.entity).slice(0, 80),
      entidade_id: data.entityId ? String(data.entityId).slice(0, 36) : null,
      dados_anteriores: JSON.stringify(data.before ?? null),
      daods_novos: JSON.stringify(data.after ?? null),
      sucesso: data.success !== false,
      mensagem: String(data.message || 'Rotina automática concluída.').slice(0, 2000),
      ip_mascarado: null,
      dispositivo: 'Appwrite Schedule',
    },
    permissions: [Permission.read(Role.team(ADMIN_TEAM_ID))],
  });
}

function dayKey(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString().slice(0, 10);
}

function daysUntil(value) {
  const due = new Date(value);
  if (Number.isNaN(due.getTime())) return null;
  const now = new Date();
  const today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  const dueDay = Date.UTC(due.getUTCFullYear(), due.getUTCMonth(), due.getUTCDate());
  return Math.ceil((dueDay - today) / 86400000);
}

async function createNotification(tables, subscription, title, message) {
  return tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.notifications,
    rowId: ID.unique(),
    data: {
      user_id: subscription.user_id,
      titulo: title,
      mensagem: message,
      tipo: 'vencimento',
      lida: false,
      data_vencimento: subscription.data_vencimento,
    },
    permissions: userPermissions(subscription.user_id),
  });
}

async function processExpirations(tables) {
  const [subscriptions, notifications] = await Promise.all([
    tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, queries: [Query.limit(500)], total: false, ttl: 0 }),
    tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.notifications, queries: [Query.limit(500)], total: false, ttl: 0 }),
  ]);
  const existing = new Set((notifications.rows ?? []).filter((item) => item.tipo === 'vencimento').map((item) => `${item.user_id}|${dayKey(item.data_vencimento)}|${item.titulo}`));
  let created = 0;
  let updated = 0;
  let skipped = 0;
  for (const subscription of subscriptions.rows ?? []) {
    if (new Set(['cancelada', 'aguardando_liberacao']).has(subscription.status)) { skipped++; continue; }
    const days = daysUntil(subscription.data_vencimento);
    if (days === null || days > 2) { skipped++; continue; }
    const desiredStatus = days < 0 ? 'vencida' : (days <= 2 ? 'vencendo' : 'ativa');
    if (subscription.status !== desiredStatus) {
      await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: subscription.$id, data: { status: desiredStatus } });
      updated++;
    }
    let title;
    let message;
    if (days === 2) {
      title = 'Assinatura vence em 2 dias';
      message = `${subscription.nome_servico} vence em 2 dias. Renove com antecedência.`;
    } else if (days === 0) {
      title = 'Assinatura vence hoje';
      message = `${subscription.nome_servico} vence hoje.`;
    } else if (days < 0) {
      title = 'Assinatura vencida';
      message = `${subscription.nome_servico} venceu. Renove para manter o acesso.`;
    } else {
      continue;
    }
    const key = `${subscription.user_id}|${dayKey(subscription.data_vencimento)}|${title}`;
    if (!existing.has(key)) {
      await createNotification(tables, subscription, title, message);
      existing.add(key);
      created++;
    }
  }
  return { created, updated, skipped, processed: subscriptions.rows?.length ?? 0 };
}

async function modulesAvailable(tables) {
  try {
    await tables.getTable({ databaseId: DATABASE_ID, tableId: TABLES.modules });
    return true;
  } catch (cause) {
    if (Number(cause?.code) === 404) return false;
    throw cause;
  }
}

async function moduleRows(tables, kind, status = null, limit = 500) {
  const queries = [Query.equal('kind', kind), Query.limit(limit)];
  if (status) queries.push(Query.equal('status', status));
  return tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.modules, queries, total: false, ttl: 0 });
}

async function processWaitlist(tables) {
  const [slots, waiting] = await Promise.all([
    moduleRows(tables, 'inventory_slot', 'livre'),
    moduleRows(tables, 'waitlist', 'aguardando'),
  ]);
  let notified = 0;
  const availableByService = new Map();
  for (const slot of slots.rows ?? []) {
    if (!availableByService.has(slot.reference_id)) availableByService.set(slot.reference_id, []);
    availableByService.get(slot.reference_id).push(slot);
  }
  for (const request of waiting.rows ?? []) {
    const available = availableByService.get(request.reference_id) ?? [];
    if (!available.length) continue;
    available.shift();
    await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.modules, rowId: request.$id, data: { status: 'vaga_disponivel', updated_at: new Date().toISOString() } });
    await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.notifications,
      rowId: ID.unique(),
      data: { user_id: request.owner_id, titulo: 'Vaga disponível', mensagem: `${request.title || 'O serviço solicitado'} está disponível. Finalize a compra pelo aplicativo.`, tipo: 'estoque', lida: false, data_vencimento: new Date().toISOString() },
      permissions: userPermissions(request.owner_id),
    });
    notified++;
  }
  return { notified };
}

async function processAutomaticRenewals(tables) {
  const subscriptions = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.subscriptions,
    queries: [Query.limit(500)],
    total: false,
    ttl: 0,
  });
  const renewals = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.renewals, queries: [Query.limit(500)], total: false, ttl: 0 });
  const existing = new Set((renewals.rows ?? []).map((row) => `${row.assinatura_id}|${row.data_anterior}`));
  const [occupiedSlots, accounts] = await Promise.all([
    moduleRows(tables, 'inventory_slot', 'ocupada', 500),
    moduleRows(tables, 'inventory_account', null, 500),
  ]);
  const accountById = new Map((accounts.rows ?? []).map((row) => [row.$id, row]));
  const assignmentBySubscription = new Map();
  for (const slot of occupiedSlots.rows ?? []) {
    const subscriptionId = String(parseJson(slot.data_json).subscription_id || '');
    if (subscriptionId) assignmentBySubscription.set(subscriptionId, slot);
  }
  let created = 0;
  let dynamicDisabled = 0;
  for (const subscription of subscriptions.rows ?? []) {
    if (subscription.renovacao_automatica !== true) continue;
    const assignedSlot = assignmentBySubscription.get(subscription.$id);
    const parent = assignedSlot?.parent_id ? accountById.get(assignedSlot.parent_id) : null;
    const parentData = parseJson(parent?.data_json);
    if (parentData.expires_at) {
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.subscriptions,
        rowId: subscription.$id,
        data: { renovacao_automatica: false },
      });
      await tables.createRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.notifications,
        rowId: ID.unique(),
        data: {
          user_id: subscription.user_id,
          titulo: 'Renovação com preço variável',
          mensagem: `${subscription.nome_servico} usa uma conta pronta com vencimento. Renove manualmente para recalcular os dias e o valor disponíveis.`,
          tipo: 'renovacao',
          lida: false,
          data_vencimento: subscription.data_vencimento,
        },
        permissions: userPermissions(subscription.user_id),
      });
      dynamicDisabled++;
      continue;
    }
    const days = daysUntil(subscription.data_vencimento);
    const marker = `${subscription.$id}|${subscription.data_vencimento}`;
    if (days === null || days > 2 || existing.has(marker) || subscription.status === 'cancelada') continue;
    const oldDue = new Date(subscription.data_vencimento);
    const base = oldDue > new Date() ? oldDue : new Date();
    const nextDue = new Date(base.getTime() + 30 * 86400000).toISOString();
    const renewal = await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.renewals,
      rowId: ID.unique(),
      data: { user_id: subscription.user_id, assinatura_id: subscription.$id, data_anterior: subscription.data_vencimento, nova_data: nextDue, valor: subscription.valor, status: 'aguardando_pagamento', observacoes: 'Renovação automática gerada pelo sistema.' },
      permissions: userPermissions(subscription.user_id),
    });
    await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.payments,
      rowId: ID.unique(),
      data: { user_id: subscription.user_id, assinatura_id: subscription.$id, renovacao_id: renewal.$id, valor: subscription.valor, forma_pagamento: 'pix', status: 'aguardando', data_pagamento: null, comprovante_id: null },
      permissions: userPermissions(subscription.user_id),
    });
    await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.notifications,
      rowId: ID.unique(),
      data: { user_id: subscription.user_id, titulo: 'Renovação automática disponível', mensagem: `O pagamento da renovação de ${subscription.nome_servico} já pode ser realizado.`, tipo: 'renovacao', lida: false, data_vencimento: subscription.data_vencimento },
      permissions: userPermissions(subscription.user_id),
    });
    created++;
  }
  return { created, dynamic_disabled: dynamicDisabled };
}

async function cleanupGroupMedia(client, tables) {
  const settingsResult = await moduleRows(tables, 'group_settings', null, 10);
  const settings = parseJson(settingsResult.rows?.[0]?.data_json);
  const retentionDays = Math.max(
    1,
    Math.min(30, Math.round(Number(settings.media_retention_days || 7))),
  );
  const cutoff = Date.now() - retentionDays * 86400000;
  const files = await tables.listRows({
    databaseId: DATABASE_ID,
    tableId: TABLES.fileMetadata,
    queries: [Query.limit(500)],
    total: false,
    ttl: 0,
  });
  const groupImageId = String(settings.image_file_id || '');
  const expired = (files.rows ?? []).filter((row) => {
    if (!GROUP_MEDIA_TYPES.has(String(row.tipo))) return false;
    if (groupImageId && row.file_id === groupImageId) return false;
    const created = new Date(row.$createdAt).getTime();
    return Number.isFinite(created) && created <= cutoff;
  });
  const storage = new Storage(client);
  let deleted = 0;
  let failed = 0;
  for (const row of expired) {
    try {
      try {
        await storage.deleteFile({ bucketId: BUCKET_ID, fileId: row.file_id });
      } catch (cause) {
        if (Number(cause?.code) !== 404) throw cause;
      }
      await tables.deleteRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.fileMetadata,
        rowId: row.$id,
      });
      deleted++;
    } catch {
      failed++;
    }
  }
  return { retention_days: retentionDays, found: expired.length, deleted, failed };
}

async function cleanupPurchaseIntents(tables) {
  const intents = await moduleRows(tables, 'purchase_intent', 'aguardando_comprovante', 500);
  const reserved = await moduleRows(tables, 'inventory_slot', 'reservada', 500);
  const now = Date.now();
  let expired = 0;
  let released = 0;
  for (const intent of intents.rows ?? []) {
    const data = parseJson(intent.data_json);
    const due = new Date(data.expires_at || intent.due_at || 0).getTime();
    if (!Number.isFinite(due) || due > now) continue;
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.modules,
      rowId: intent.$id,
      data: { status: 'expirado', updated_at: new Date().toISOString() },
    });
    for (const slot of reserved.rows ?? []) {
      const slotData = parseJson(slot.data_json);
      if (slotData.intent_id !== intent.$id) continue;
      delete slotData.intent_id;
      delete slotData.reserved_at;
      delete slotData.reserved_until;
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.modules,
        rowId: slot.$id,
        data: { owner_id: null, status: 'livre', data_json: JSON.stringify(slotData), updated_at: new Date().toISOString() },
      });
      released++;
    }
    expired++;
  }
  return { expired, released };
}


async function processInventoryExpirations(tables) {
  const accounts = await moduleRows(tables, 'inventory_account', null, 500);
  const slots = await moduleRows(tables, 'inventory_slot', null, 500);
  const now = Date.now();
  let accountsExpired = 0;
  let slotsExpired = 0;
  for (const account of accounts.rows ?? []) {
    const data = parseJson(account.data_json);
    const due = data.expires_at ? new Date(data.expires_at).getTime() : null;
    if (!Number.isFinite(due) || due > now || account.status === 'expirada') continue;
    await tables.updateRow({
      databaseId: DATABASE_ID, tableId: TABLES.modules, rowId: account.$id,
      data: { status: 'expirada', active: false, updated_at: new Date().toISOString() },
    });
    accountsExpired++;
    for (const slot of slots.rows ?? []) {
      if (slot.parent_id !== account.$id || slot.status === 'expirada') continue;
      await tables.updateRow({
        databaseId: DATABASE_ID, tableId: TABLES.modules, rowId: slot.$id,
        data: { status: 'expirada', updated_at: new Date().toISOString(), data_json: JSON.stringify({ ...parseJson(slot.data_json), expired_at: new Date().toISOString() }) },
      });
      slotsExpired++;
    }
  }
  return { accounts_expired: accountsExpired, slots_expired: slotsExpired };
}


async function releaseExpiredInventoryAssignments(tables) {
  const slots = await moduleRows(tables, 'inventory_slot', 'ocupada', 500);
  const now = Date.now();
  const accountCache = new Map();
  let released = 0;
  let credentialsExpired = 0;
  for (const slot of slots.rows ?? []) {
    const slotData = parseJson(slot.data_json);
    const subscriptionId = String(slotData.subscription_id || '');
    if (!subscriptionId || !slot.parent_id) continue;
    let subscription;
    try {
      subscription = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, rowId: subscriptionId });
    } catch { continue; }
    const due = new Date(subscription.data_vencimento || 0).getTime();
    if (!Number.isFinite(due) || due >= now || subscription.status === 'aguardando_liberacao') continue;

    let account = accountCache.get(slot.parent_id);
    if (account === undefined) {
      try {
        account = await tables.getRow({ databaseId: DATABASE_ID, tableId: TABLES.modules, rowId: slot.parent_id });
      } catch { account = null; }
      accountCache.set(slot.parent_id, account);
    }
    if (!account || account.kind !== 'inventory_account' || account.status === 'expirada' || account.active === false) continue;
    const accountData = parseJson(account.data_json);
    const accountDue = accountData.expires_at ? new Date(accountData.expires_at).getTime() : null;
    if (Number.isFinite(accountDue) && accountDue <= now) continue;

    const nextData = { ...slotData };
    delete nextData.subscription_id;
    delete nextData.order_id;
    delete nextData.occupied_at;
    delete nextData.effective_due_at;
    delete nextData.manual_release;
    nextData.last_subscription_id = subscriptionId;
    nextData.last_released_at = new Date().toISOString();
    await tables.updateRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.modules,
      rowId: slot.$id,
      data: { owner_id: null, status: 'livre', data_json: JSON.stringify(nextData), updated_at: new Date().toISOString() },
    });

    const credentials = await tables.listRows({
      databaseId: DATABASE_ID,
      tableId: TABLES.credentials,
      queries: [Query.equal('assinatura_id', subscriptionId), Query.limit(100)],
      total: false,
      ttl: 0,
    });
    for (const credential of credentials.rows ?? []) {
      if (credential.status === 'ativa') {
        await tables.updateRow({ databaseId: DATABASE_ID, tableId: TABLES.credentials, rowId: credential.$id, data: { status: 'expirada' } });
        credentialsExpired++;
      }
    }

    await tables.createRow({
      databaseId: DATABASE_ID,
      tableId: TABLES.modules,
      rowId: ID.unique(),
      data: {
        kind: 'stock_history', owner_id: null, parent_id: slot.$id, reference_id: slot.reference_id, external_key: null,
        title: 'Vaga liberada após vencimento', status: 'concluido', sort_order: 0, amount_cents: 0,
        data_json: JSON.stringify({ subscription_id: subscriptionId, account_id: slot.parent_id, released_at: new Date().toISOString(), reason: 'subscription_expired' }),
        secret_ciphertext: null, secret_iv: null, secret_tag: null, created_by: null, assigned_to: null,
        due_at: null, updated_at: new Date().toISOString(), active: true, visible: false,
      },
      permissions: adminPermissions(),
    });
    released++;
  }
  return { released_slots: released, credentials_expired: credentialsExpired };
}

async function processSupportSla(tables) {
  const tickets = await moduleRows(tables, 'support_ticket', null, 500);
  const alerts = await moduleRows(tables, 'support_sla_alert', null, 500);
  const warned = new Set((alerts.rows ?? []).map((row) => row.reference_id));
  const now = Date.now();
  let overdue = 0;
  for (const ticket of tickets.rows ?? []) {
    if (new Set(['resolvido', 'fechado']).has(ticket.status)) continue;
    const due = ticket.due_at ? new Date(ticket.due_at).getTime() : null;
    if (!Number.isFinite(due) || due > now || warned.has(ticket.$id)) continue;
    await tables.createRow({
      databaseId: DATABASE_ID, tableId: TABLES.modules, rowId: ID.unique(),
      data: {
        kind: 'support_sla_alert', owner_id: null, parent_id: null, reference_id: ticket.$id, external_key: null,
        title: 'Ticket fora do SLA', status: 'ativo', sort_order: 0, amount_cents: 0,
        data_json: JSON.stringify({ ticket_id: ticket.$id, title: ticket.title, due_at: ticket.due_at, alerted_at: new Date().toISOString() }),
        secret_ciphertext: null, secret_iv: null, secret_tag: null, created_by: null, assigned_to: null,
        due_at: null, updated_at: new Date().toISOString(), active: true, visible: false,
      }, permissions: adminPermissions(),
    });
    overdue++;
  }
  return { overdue_alerts: overdue };
}

async function processBotTasks(tables) {
  const tasks = await moduleRows(tables, 'bot_task', 'ativa', 500);
  const now = Date.now();
  let executed = 0;
  let failed = 0;
  let skipped = 0;

  for (const task of tasks.rows ?? []) {
    const data = parseJson(task.data_json);
    const dueAt = data.next_run_at || task.due_at;
    const dueMs = dueAt ? new Date(dueAt).getTime() : 0;
    if (Number.isFinite(dueMs) && dueMs > now) {
      skipped++;
      continue;
    }

    const intervalMinutes = Math.max(5, Math.min(10080, Math.round(Number(data.interval_minutes || 60))));
    const nextRun = new Date(Date.now() + intervalMinutes * 60000).toISOString();
    try {
      if (data.task_type === 'promotion') {
        const text = String(data.text || '').trim();
        if (!text) throw new Error('Promoção recorrente sem texto.');
        await tables.createRow({
          databaseId: DATABASE_ID,
          tableId: TABLES.modules,
          rowId: ID.unique(),
          data: {
            kind: 'group_message', owner_id: null, parent_id: null, reference_id: 'rachey-main', external_key: null,
            title: null, status: 'publicado', sort_order: 0, amount_cents: 0,
            data_json: JSON.stringify({
              text: text.slice(0, 4000), sender_name: 'Rachey Bot', sender_role: 'bot', target_user_id: null,
              attachment: null, pinned: false, edited: false, channel: data.channel || 'promocoes',
              message_type: 'promotion', special: { bot_task_id: task.$id, scheduled: true },
            }),
            secret_ciphertext: null, secret_iv: null, secret_tag: null, created_by: task.created_by || null, assigned_to: null,
            due_at: null, updated_at: new Date().toISOString(), active: true, visible: true,
          },
          permissions: adminPermissions(),
        });
      } else if (data.task_type === 'keep_group_active') {
        const settingsRows = await moduleRows(tables, 'group_settings', null, 10);
        const settingsRow = settingsRows.rows?.[0];
        if (!settingsRow) throw new Error('Configuração do grupo não encontrada.');
        const settings = parseJson(settingsRow.data_json);
        settings.mode = 'todos';
        await tables.updateRow({
          databaseId: DATABASE_ID,
          tableId: TABLES.modules,
          rowId: settingsRow.$id,
          data: { data_json: JSON.stringify(settings), updated_at: new Date().toISOString() },
        });
      } else {
        await tables.updateRow({
          databaseId: DATABASE_ID,
          tableId: TABLES.modules,
          rowId: task.$id,
          data: { status: 'pausada', updated_at: new Date().toISOString() },
        });
        skipped++;
        continue;
      }

      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.modules,
        rowId: task.$id,
        data: {
          due_at: nextRun,
          data_json: JSON.stringify({ ...data, next_run_at: nextRun, last_run_at: new Date().toISOString(), last_status: 'ok', last_error: null }),
          updated_at: new Date().toISOString(),
        },
      });
      executed++;
    } catch (cause) {
      const message = String(cause?.message || cause).slice(0, 1000);
      await tables.updateRow({
        databaseId: DATABASE_ID,
        tableId: TABLES.modules,
        rowId: task.$id,
        data: {
          due_at: nextRun,
          data_json: JSON.stringify({ ...data, next_run_at: nextRun, last_run_at: new Date().toISOString(), last_status: 'error', last_error: message }),
          updated_at: new Date().toISOString(),
        },
      });
      failed++;
    }
  }
  return { executed, failed, skipped };
}

async function processGroupRenewalReminders(tables) {
  const settingsResult = await moduleRows(tables, 'group_settings', null, 10);
  const settings = parseJson(settingsResult.rows?.[0]?.data_json);
  if (settings.renewal_reminders !== true) return { skipped: true, reason: 'disabled' };
  const subscriptions = await tables.listRows({ databaseId: DATABASE_ID, tableId: TABLES.subscriptions, queries: [Query.limit(500)], total: false, ttl: 0 });
  const existingMessages = await moduleRows(tables, 'group_message', null, 500);
  const today = new Date().toISOString().slice(0, 10);
  let created = 0;
  for (const subscription of subscriptions.rows ?? []) {
    if (new Set(['cancelada', 'aguardando_liberacao']).has(subscription.status)) continue;
    const days = daysUntil(subscription.data_vencimento);
    if (days !== 2 && days !== 0) continue;
    const marker = `renewal:${subscription.$id}:${today}`;
    if ((existingMessages.rows ?? []).some((row) => row.external_key === marker)) continue;
    await tables.createRow({
      databaseId: DATABASE_ID, tableId: TABLES.modules, rowId: ID.unique(),
      data: {
        kind: 'group_message', owner_id: null, parent_id: null, reference_id: 'rachey-main', external_key: marker,
        title: null, status: 'publicado', sort_order: 0, amount_cents: 0,
        data_json: JSON.stringify({
          text: days === 0 ? `Sua assinatura ${subscription.nome_servico} vence hoje. Abra Assinaturas para renovar.` : `Sua assinatura ${subscription.nome_servico} vence em 2 dias. Abra Assinaturas para renovar.`,
          sender_name: 'Rachey Bot', sender_role: 'bot', target_user_id: subscription.user_id,
          attachment: null, pinned: false, edited: false, channel: 'avisos', message_type: 'renewal_reminder',
          special: { subscription_id: subscription.$id, days },
        }),
        secret_ciphertext: null, secret_iv: null, secret_tag: null, created_by: null, assigned_to: null,
        due_at: subscription.data_vencimento, updated_at: new Date().toISOString(), active: true, visible: true,
      }, permissions: adminPermissions(),
    });
    created++;
  }
  return { skipped: false, created };
}

async function logicalBackup(client, tables) {
  const date = new Date().toISOString().slice(0, 10);
  const runs = await moduleRows(tables, 'backup_run', null, 100);
  if ((runs.rows ?? []).some((row) => row.external_key === date)) return { skipped: true, reason: 'already_created' };
  const backup = { version: 1, project: 'rachey', database: DATABASE_ID, created_at: new Date().toISOString(), tables: {} };
  for (const tableId of Object.values(TABLES)) {
    if (tableId === TABLES.audit) continue;
    try {
      const result = await tables.listRows({ databaseId: DATABASE_ID, tableId, queries: [Query.limit(500)], total: false, ttl: 0 });
      backup.tables[tableId] = result.rows ?? [];
    } catch (cause) {
      backup.tables[tableId] = { error: String(cause?.message || cause) };
    }
  }
  const compressed = gzipSync(Buffer.from(JSON.stringify(backup), 'utf8'), { level: 9 });
  const name = `rachey-backup-${date}.json.gz`;
  const file = await new Storage(client).createFile({
    bucketId: BUCKET_ID,
    fileId: ID.unique(),
    file: InputFile.fromBuffer(compressed, name),
    permissions: adminPermissions(),
  });
  await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.fileMetadata,
    rowId: ID.unique(),
    data: {
      file_id: file.$id,
      user_id: 'sistema',
      tipo: 'backup',
      referencia_id: null,
      nome_original: name,
      mime_type: 'application/gzip',
      tamanho_bytesw: compressed.length,
    },
    permissions: adminPermissions(),
  });
  await tables.createRow({
    databaseId: DATABASE_ID,
    tableId: TABLES.modules,
    rowId: ID.unique(),
    data: {
      kind: 'backup_run', owner_id: null, parent_id: null, reference_id: file.$id, external_key: date,
      title: name, status: 'concluido', sort_order: 0, amount_cents: 0,
      data_json: JSON.stringify({ file_id: file.$id, size: compressed.length, tables: Object.keys(backup.tables).length }),
      secret_ciphertext: null, secret_iv: null, secret_tag: null, created_by: null, assigned_to: null,
      due_at: null, updated_at: new Date().toISOString(), active: true, visible: false,
    },
    permissions: adminPermissions(),
  });
  return { skipped: false, file_id: file.$id, size: compressed.length };
}

export default async ({ req, res, log, error }) => {
  try {
    const client = clientFor(req);
    const tables = new TablesDB(client);
    const expirations = await processExpirations(tables);
    let waitlist = { skipped: true };
    let autoRenewals = { skipped: true };
    let backup = { skipped: true };
    let groupMedia = { skipped: true };
    let purchaseIntents = { skipped: true };
    let inventoryExpirations = { skipped: true };
    let inventoryAssignments = { skipped: true };
    let supportSla = { skipped: true };
    let groupRenewalReminders = { skipped: true };
    let botTasks = { skipped: true };
    if (await modulesAvailable(tables)) {
      purchaseIntents = await cleanupPurchaseIntents(tables);
      inventoryExpirations = await processInventoryExpirations(tables);
      inventoryAssignments = await releaseExpiredInventoryAssignments(tables);
      waitlist = await processWaitlist(tables);
      autoRenewals = await processAutomaticRenewals(tables);
      groupMedia = await cleanupGroupMedia(client, tables);
      supportSla = await processSupportSla(tables);
      groupRenewalReminders = await processGroupRenewalReminders(tables);
      botTasks = await processBotTasks(tables);
      backup = await logicalBackup(client, tables);
    }
    const result = {
      expirations,
      waitlist,
      auto_renewals: autoRenewals,
      group_media: groupMedia,
      purchase_intents: purchaseIntents,
      inventory_expirations: inventoryExpirations,
      inventory_assignments: inventoryAssignments,
      support_sla: supportSla,
      group_renewal_reminders: groupRenewalReminders,
      bot_tasks: botTasks,
      backup,
    };
    await audit(tables, {
      action: 'automacoes.executar',
      entity: TABLES.subscriptions,
      after: result,
      message: 'Vencimentos, renovações, fila, estoque, SLA, reservas Pix, mídias, tarefas agendadas do bot e backup processados.',
    });
    log(JSON.stringify(result));
    return res.json({ ok: true, data: result });
  } catch (cause) {
    error(String(cause?.stack || cause));
    return res.json({ ok: false, code: 'automation_job_failed', message: 'Falha ao processar automações.' }, 500);
  }
};
