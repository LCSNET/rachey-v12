# Backend Appwrite integrado

O aplicativo preserva e utiliza as 16 tabelas existentes do database
`rachey_db`. A Function `rachey_admin` cria e migra uma tabela adicional,
`dados_rachey`, destinada aos módulos avançados que não cabem no esquema
original: estoque por vaga, fila, timeline, cupons, CRM, Grupo Rachey, suporte,
financeiro, configurações, histórico e automações.

Functions:

- `rachey_admin`: autenticação de contexto, validação de papéis, CRUDs,
  pagamentos, mensagens, credenciais criptografadas, arquivos e auditoria.
- `rachey_notifications`: vencimentos, renovação automática, lista de espera,
  notificações, auditoria de sistema e backup no Storage.

Escopos mínimos:

- `rachey_admin`: `users.read`, `teams.read`, `rows.read`, `rows.write`, `tables.write`,
  `files.read`, `files.write`.
- `rachey_notifications`: `rows.read`, `rows.write`, `files.write`.

O acesso de execução de `rachey_admin` deve permanecer limitado a usuários
autenticados. A própria Function confirma a equipe `administradores` e os
papéis do membro antes de qualquer operação administrativa.
